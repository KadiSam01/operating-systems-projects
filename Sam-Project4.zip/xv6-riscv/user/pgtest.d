user/pgtest.o: user/pgtest.c kernel/types.h kernel/stat.h kernel/riscv.h \
 user/user.h
