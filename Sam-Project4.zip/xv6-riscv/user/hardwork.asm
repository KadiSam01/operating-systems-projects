
user/_hardwork:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <decide>:
#include "user/user.h"

#define N 3

int decide(int a, int b, int direction)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
    if (direction)
        if (a < b) return 1; else return 0;
    else if (a<b) return 0; else return 1;
   8:	00b52533          	slt	a0,a0,a1
   c:	00153513          	seqz	a0,a0
    if (direction)
  10:	00c03633          	snez	a2,a2
}
  14:	8d31                	xor	a0,a0,a2
  16:	60a2                	ld	ra,8(sp)
  18:	6402                	ld	s0,0(sp)
  1a:	0141                	addi	sp,sp,16
  1c:	8082                	ret

000000000000001e <hardWork>:
int hardWork()
{
  1e:	715d                	addi	sp,sp,-80
  20:	e486                	sd	ra,72(sp)
  22:	e0a2                	sd	s0,64(sp)
  24:	0880                	addi	s0,sp,80
    int bFun[3];
    for (int r = 0; r < N; ++r)
    {
        for (int c = 0; c < N; ++c)
        {
            bigFun[r][c] = r; 
  26:	fc042423          	sw	zero,-56(s0)
  2a:	fc042623          	sw	zero,-52(s0)
  2e:	fc042823          	sw	zero,-48(s0)
        }
        bFun[r] = r; 
  32:	fa042c23          	sw	zero,-72(s0)
            bigFun[r][c] = r; 
  36:	4785                	li	a5,1
  38:	fcf42a23          	sw	a5,-44(s0)
  3c:	fcf42c23          	sw	a5,-40(s0)
  40:	fcf42e23          	sw	a5,-36(s0)
        bFun[r] = r; 
  44:	faf42e23          	sw	a5,-68(s0)
            bigFun[r][c] = r; 
  48:	4789                	li	a5,2
  4a:	fef42023          	sw	a5,-32(s0)
  4e:	fef42223          	sw	a5,-28(s0)
  52:	fef42423          	sw	a5,-24(s0)
        bFun[r] = r; 
  56:	fcf42023          	sw	a5,-64(s0)
    }
    printf("initialized\n");
  5a:	00001517          	auipc	a0,0x1
  5e:	95650513          	addi	a0,a0,-1706 # 9b0 <malloc+0xfa>
  62:	79c000ef          	jal	7fe <printf>
    int changes = 1;
  66:	4505                	li	a0,1
    int total = 0;
    int direction = 0;
    for (;;)
    {
        while (changes)
  68:	8f2a                	mv	t5,a0
        {
            changes = 0;
            for (int r = 0; r < N-1; ++r)
                for (int c =0; c < N; ++c)
  6a:	4e8d                	li	t4,3
  6c:	a0b9                	j	ba <hardWork+0x9c>
  6e:	0791                	addi	a5,a5,4
  70:	0711                	addi	a4,a4,4
                {
                    if (bigFun[r][c] > bigFun[r+1][c])
  72:	4390                	lw	a2,0(a5)
  74:	430c                	lw	a1,0(a4)
  76:	02c5d563          	bge	a1,a2,a0 <hardWork+0x82>
                    {
                        int temp = bigFun[r][c];
                        bigFun[r][c] = bigFun[r+1][c];
  7a:	c38c                	sw	a1,0(a5)
                        bigFun[r+1][c] = bFun[r]*temp;
  7c:	00032583          	lw	a1,0(t1)
  80:	02c5863b          	mulw	a2,a1,a2
  84:	c310                	sw	a2,0(a4)
                        changes++;
  86:	2505                	addiw	a0,a0,1
                for (int c =0; c < N; ++c)
  88:	2685                	addiw	a3,a3,1
  8a:	ffd692e3          	bne	a3,t4,6e <hardWork+0x50>
            for (int r = 0; r < N-1; ++r)
  8e:	2e05                	addiw	t3,t3,1
  90:	0311                	addi	t1,t1,4
  92:	03de0463          	beq	t3,t4,ba <hardWork+0x9c>
                for (int c =0; c < N; ++c)
  96:	87c6                	mv	a5,a7
  98:	08b1                	addi	a7,a7,12
{
  9a:	8746                	mv	a4,a7
                for (int c =0; c < N; ++c)
  9c:	4681                	li	a3,0
  9e:	bfd1                	j	72 <hardWork+0x54>
                        ++total;
                    }
                    else if (c < N-1 && bigFun[r][c] > bigFun[r][c+1])
  a0:	fedf47e3          	blt	t5,a3,8e <hardWork+0x70>
  a4:	43cc                	lw	a1,4(a5)
  a6:	00c5d563          	bge	a1,a2,b0 <hardWork+0x92>
                    {
                        int temp = bigFun[r][c];
                        bigFun[r][c] = bigFun[r][c+1];
  aa:	c38c                	sw	a1,0(a5)
                        bigFun[r][c+1] = temp;
  ac:	c3d0                	sw	a2,4(a5)
                        changes++;
  ae:	2505                	addiw	a0,a0,1
                for (int c =0; c < N; ++c)
  b0:	2685                	addiw	a3,a3,1
  b2:	0791                	addi	a5,a5,4
  b4:	0711                	addi	a4,a4,4
  b6:	bf75                	j	72 <hardWork+0x54>
                        ++total;
                    }
                }
        }
        if (direction == 1) direction = 0; else direction = 1;
        changes = 1;
  b8:	857a                	mv	a0,t5
        while (changes)
  ba:	dd7d                	beqz	a0,b8 <hardWork+0x9a>
  bc:	fc840893          	addi	a7,s0,-56
  c0:	fb840313          	addi	t1,s0,-72
  c4:	8e7a                	mv	t3,t5
            changes = 0;
  c6:	4501                	li	a0,0
  c8:	b7f9                	j	96 <hardWork+0x78>

00000000000000ca <main>:
    }
    return total;
}

int main(int argc, char *argv[])
{
  ca:	1141                	addi	sp,sp,-16
  cc:	e406                	sd	ra,8(sp)
  ce:	e022                	sd	s0,0(sp)
  d0:	0800                	addi	s0,sp,16
/* uncomment the following to use strides */
/*
    if (argc >1)
        setstride(atoi(argv[1]));
*/
    printf("starting main\n");
  d2:	00001517          	auipc	a0,0x1
  d6:	8ee50513          	addi	a0,a0,-1810 # 9c0 <malloc+0x10a>
  da:	724000ef          	jal	7fe <printf>
    val = hardWork();
  de:	f41ff0ef          	jal	1e <hardWork>

00000000000000e2 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  e2:	1141                	addi	sp,sp,-16
  e4:	e406                	sd	ra,8(sp)
  e6:	e022                	sd	s0,0(sp)
  e8:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  ea:	fe1ff0ef          	jal	ca <main>
  exit(r);
  ee:	2aa000ef          	jal	398 <exit>

00000000000000f2 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  f2:	1141                	addi	sp,sp,-16
  f4:	e406                	sd	ra,8(sp)
  f6:	e022                	sd	s0,0(sp)
  f8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  fa:	87aa                	mv	a5,a0
  fc:	0585                	addi	a1,a1,1
  fe:	0785                	addi	a5,a5,1
 100:	fff5c703          	lbu	a4,-1(a1)
 104:	fee78fa3          	sb	a4,-1(a5)
 108:	fb75                	bnez	a4,fc <strcpy+0xa>
    ;
  return os;
}
 10a:	60a2                	ld	ra,8(sp)
 10c:	6402                	ld	s0,0(sp)
 10e:	0141                	addi	sp,sp,16
 110:	8082                	ret

0000000000000112 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 112:	1141                	addi	sp,sp,-16
 114:	e406                	sd	ra,8(sp)
 116:	e022                	sd	s0,0(sp)
 118:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 11a:	00054783          	lbu	a5,0(a0)
 11e:	cb91                	beqz	a5,132 <strcmp+0x20>
 120:	0005c703          	lbu	a4,0(a1)
 124:	00f71763          	bne	a4,a5,132 <strcmp+0x20>
    p++, q++;
 128:	0505                	addi	a0,a0,1
 12a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 12c:	00054783          	lbu	a5,0(a0)
 130:	fbe5                	bnez	a5,120 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 132:	0005c503          	lbu	a0,0(a1)
}
 136:	40a7853b          	subw	a0,a5,a0
 13a:	60a2                	ld	ra,8(sp)
 13c:	6402                	ld	s0,0(sp)
 13e:	0141                	addi	sp,sp,16
 140:	8082                	ret

0000000000000142 <strlen>:

uint
strlen(const char *s)
{
 142:	1141                	addi	sp,sp,-16
 144:	e406                	sd	ra,8(sp)
 146:	e022                	sd	s0,0(sp)
 148:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 14a:	00054783          	lbu	a5,0(a0)
 14e:	cf91                	beqz	a5,16a <strlen+0x28>
 150:	00150793          	addi	a5,a0,1
 154:	86be                	mv	a3,a5
 156:	0785                	addi	a5,a5,1
 158:	fff7c703          	lbu	a4,-1(a5)
 15c:	ff65                	bnez	a4,154 <strlen+0x12>
 15e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 162:	60a2                	ld	ra,8(sp)
 164:	6402                	ld	s0,0(sp)
 166:	0141                	addi	sp,sp,16
 168:	8082                	ret
  for(n = 0; s[n]; n++)
 16a:	4501                	li	a0,0
 16c:	bfdd                	j	162 <strlen+0x20>

000000000000016e <memset>:

void*
memset(void *dst, int c, uint n)
{
 16e:	1141                	addi	sp,sp,-16
 170:	e406                	sd	ra,8(sp)
 172:	e022                	sd	s0,0(sp)
 174:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 176:	ca19                	beqz	a2,18c <memset+0x1e>
 178:	87aa                	mv	a5,a0
 17a:	1602                	slli	a2,a2,0x20
 17c:	9201                	srli	a2,a2,0x20
 17e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 182:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 186:	0785                	addi	a5,a5,1
 188:	fee79de3          	bne	a5,a4,182 <memset+0x14>
  }
  return dst;
}
 18c:	60a2                	ld	ra,8(sp)
 18e:	6402                	ld	s0,0(sp)
 190:	0141                	addi	sp,sp,16
 192:	8082                	ret

0000000000000194 <strchr>:

char*
strchr(const char *s, char c)
{
 194:	1141                	addi	sp,sp,-16
 196:	e406                	sd	ra,8(sp)
 198:	e022                	sd	s0,0(sp)
 19a:	0800                	addi	s0,sp,16
  for(; *s; s++)
 19c:	00054783          	lbu	a5,0(a0)
 1a0:	cf81                	beqz	a5,1b8 <strchr+0x24>
    if(*s == c)
 1a2:	00f58763          	beq	a1,a5,1b0 <strchr+0x1c>
  for(; *s; s++)
 1a6:	0505                	addi	a0,a0,1
 1a8:	00054783          	lbu	a5,0(a0)
 1ac:	fbfd                	bnez	a5,1a2 <strchr+0xe>
      return (char*)s;
  return 0;
 1ae:	4501                	li	a0,0
}
 1b0:	60a2                	ld	ra,8(sp)
 1b2:	6402                	ld	s0,0(sp)
 1b4:	0141                	addi	sp,sp,16
 1b6:	8082                	ret
  return 0;
 1b8:	4501                	li	a0,0
 1ba:	bfdd                	j	1b0 <strchr+0x1c>

00000000000001bc <gets>:

char*
gets(char *buf, int max)
{
 1bc:	711d                	addi	sp,sp,-96
 1be:	ec86                	sd	ra,88(sp)
 1c0:	e8a2                	sd	s0,80(sp)
 1c2:	e4a6                	sd	s1,72(sp)
 1c4:	e0ca                	sd	s2,64(sp)
 1c6:	fc4e                	sd	s3,56(sp)
 1c8:	f852                	sd	s4,48(sp)
 1ca:	f456                	sd	s5,40(sp)
 1cc:	f05a                	sd	s6,32(sp)
 1ce:	ec5e                	sd	s7,24(sp)
 1d0:	e862                	sd	s8,16(sp)
 1d2:	1080                	addi	s0,sp,96
 1d4:	8baa                	mv	s7,a0
 1d6:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1d8:	892a                	mv	s2,a0
 1da:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1dc:	faf40b13          	addi	s6,s0,-81
 1e0:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1e2:	8c26                	mv	s8,s1
 1e4:	0014899b          	addiw	s3,s1,1
 1e8:	84ce                	mv	s1,s3
 1ea:	0349d463          	bge	s3,s4,212 <gets+0x56>
    cc = read(0, &c, 1);
 1ee:	8656                	mv	a2,s5
 1f0:	85da                	mv	a1,s6
 1f2:	4501                	li	a0,0
 1f4:	1bc000ef          	jal	3b0 <read>
    if(cc < 1)
 1f8:	00a05d63          	blez	a0,212 <gets+0x56>
      break;
    buf[i++] = c;
 1fc:	faf44783          	lbu	a5,-81(s0)
 200:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 204:	0905                	addi	s2,s2,1
 206:	ff678713          	addi	a4,a5,-10
 20a:	c319                	beqz	a4,210 <gets+0x54>
 20c:	17cd                	addi	a5,a5,-13
 20e:	fbf1                	bnez	a5,1e2 <gets+0x26>
    buf[i++] = c;
 210:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 212:	9c5e                	add	s8,s8,s7
 214:	000c0023          	sb	zero,0(s8)
  return buf;
}
 218:	855e                	mv	a0,s7
 21a:	60e6                	ld	ra,88(sp)
 21c:	6446                	ld	s0,80(sp)
 21e:	64a6                	ld	s1,72(sp)
 220:	6906                	ld	s2,64(sp)
 222:	79e2                	ld	s3,56(sp)
 224:	7a42                	ld	s4,48(sp)
 226:	7aa2                	ld	s5,40(sp)
 228:	7b02                	ld	s6,32(sp)
 22a:	6be2                	ld	s7,24(sp)
 22c:	6c42                	ld	s8,16(sp)
 22e:	6125                	addi	sp,sp,96
 230:	8082                	ret

0000000000000232 <stat>:

int
stat(const char *n, struct stat *st)
{
 232:	1101                	addi	sp,sp,-32
 234:	ec06                	sd	ra,24(sp)
 236:	e822                	sd	s0,16(sp)
 238:	e04a                	sd	s2,0(sp)
 23a:	1000                	addi	s0,sp,32
 23c:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 23e:	4581                	li	a1,0
 240:	198000ef          	jal	3d8 <open>
  if(fd < 0)
 244:	02054263          	bltz	a0,268 <stat+0x36>
 248:	e426                	sd	s1,8(sp)
 24a:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 24c:	85ca                	mv	a1,s2
 24e:	1a2000ef          	jal	3f0 <fstat>
 252:	892a                	mv	s2,a0
  close(fd);
 254:	8526                	mv	a0,s1
 256:	16a000ef          	jal	3c0 <close>
  return r;
 25a:	64a2                	ld	s1,8(sp)
}
 25c:	854a                	mv	a0,s2
 25e:	60e2                	ld	ra,24(sp)
 260:	6442                	ld	s0,16(sp)
 262:	6902                	ld	s2,0(sp)
 264:	6105                	addi	sp,sp,32
 266:	8082                	ret
    return -1;
 268:	57fd                	li	a5,-1
 26a:	893e                	mv	s2,a5
 26c:	bfc5                	j	25c <stat+0x2a>

000000000000026e <atoi>:

int
atoi(const char *s)
{
 26e:	1141                	addi	sp,sp,-16
 270:	e406                	sd	ra,8(sp)
 272:	e022                	sd	s0,0(sp)
 274:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 276:	00054683          	lbu	a3,0(a0)
 27a:	fd06879b          	addiw	a5,a3,-48
 27e:	0ff7f793          	zext.b	a5,a5
 282:	4625                	li	a2,9
 284:	02f66963          	bltu	a2,a5,2b6 <atoi+0x48>
 288:	872a                	mv	a4,a0
  n = 0;
 28a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 28c:	0705                	addi	a4,a4,1
 28e:	0025179b          	slliw	a5,a0,0x2
 292:	9fa9                	addw	a5,a5,a0
 294:	0017979b          	slliw	a5,a5,0x1
 298:	9fb5                	addw	a5,a5,a3
 29a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 29e:	00074683          	lbu	a3,0(a4)
 2a2:	fd06879b          	addiw	a5,a3,-48
 2a6:	0ff7f793          	zext.b	a5,a5
 2aa:	fef671e3          	bgeu	a2,a5,28c <atoi+0x1e>
  return n;
}
 2ae:	60a2                	ld	ra,8(sp)
 2b0:	6402                	ld	s0,0(sp)
 2b2:	0141                	addi	sp,sp,16
 2b4:	8082                	ret
  n = 0;
 2b6:	4501                	li	a0,0
 2b8:	bfdd                	j	2ae <atoi+0x40>

00000000000002ba <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2ba:	1141                	addi	sp,sp,-16
 2bc:	e406                	sd	ra,8(sp)
 2be:	e022                	sd	s0,0(sp)
 2c0:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2c2:	02b57563          	bgeu	a0,a1,2ec <memmove+0x32>
    while(n-- > 0)
 2c6:	00c05f63          	blez	a2,2e4 <memmove+0x2a>
 2ca:	1602                	slli	a2,a2,0x20
 2cc:	9201                	srli	a2,a2,0x20
 2ce:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2d2:	872a                	mv	a4,a0
      *dst++ = *src++;
 2d4:	0585                	addi	a1,a1,1
 2d6:	0705                	addi	a4,a4,1
 2d8:	fff5c683          	lbu	a3,-1(a1)
 2dc:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2e0:	fee79ae3          	bne	a5,a4,2d4 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2e4:	60a2                	ld	ra,8(sp)
 2e6:	6402                	ld	s0,0(sp)
 2e8:	0141                	addi	sp,sp,16
 2ea:	8082                	ret
    while(n-- > 0)
 2ec:	fec05ce3          	blez	a2,2e4 <memmove+0x2a>
    dst += n;
 2f0:	00c50733          	add	a4,a0,a2
    src += n;
 2f4:	95b2                	add	a1,a1,a2
 2f6:	fff6079b          	addiw	a5,a2,-1
 2fa:	1782                	slli	a5,a5,0x20
 2fc:	9381                	srli	a5,a5,0x20
 2fe:	fff7c793          	not	a5,a5
 302:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 304:	15fd                	addi	a1,a1,-1
 306:	177d                	addi	a4,a4,-1
 308:	0005c683          	lbu	a3,0(a1)
 30c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 310:	fef71ae3          	bne	a4,a5,304 <memmove+0x4a>
 314:	bfc1                	j	2e4 <memmove+0x2a>

0000000000000316 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 316:	1141                	addi	sp,sp,-16
 318:	e406                	sd	ra,8(sp)
 31a:	e022                	sd	s0,0(sp)
 31c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 31e:	c61d                	beqz	a2,34c <memcmp+0x36>
 320:	1602                	slli	a2,a2,0x20
 322:	9201                	srli	a2,a2,0x20
 324:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 328:	00054783          	lbu	a5,0(a0)
 32c:	0005c703          	lbu	a4,0(a1)
 330:	00e79863          	bne	a5,a4,340 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 334:	0505                	addi	a0,a0,1
    p2++;
 336:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 338:	fed518e3          	bne	a0,a3,328 <memcmp+0x12>
  }
  return 0;
 33c:	4501                	li	a0,0
 33e:	a019                	j	344 <memcmp+0x2e>
      return *p1 - *p2;
 340:	40e7853b          	subw	a0,a5,a4
}
 344:	60a2                	ld	ra,8(sp)
 346:	6402                	ld	s0,0(sp)
 348:	0141                	addi	sp,sp,16
 34a:	8082                	ret
  return 0;
 34c:	4501                	li	a0,0
 34e:	bfdd                	j	344 <memcmp+0x2e>

0000000000000350 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 350:	1141                	addi	sp,sp,-16
 352:	e406                	sd	ra,8(sp)
 354:	e022                	sd	s0,0(sp)
 356:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 358:	f63ff0ef          	jal	2ba <memmove>
}
 35c:	60a2                	ld	ra,8(sp)
 35e:	6402                	ld	s0,0(sp)
 360:	0141                	addi	sp,sp,16
 362:	8082                	ret

0000000000000364 <sbrk>:

char *
sbrk(int n) {
 364:	1141                	addi	sp,sp,-16
 366:	e406                	sd	ra,8(sp)
 368:	e022                	sd	s0,0(sp)
 36a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 36c:	4585                	li	a1,1
 36e:	0b2000ef          	jal	420 <sys_sbrk>
}
 372:	60a2                	ld	ra,8(sp)
 374:	6402                	ld	s0,0(sp)
 376:	0141                	addi	sp,sp,16
 378:	8082                	ret

000000000000037a <sbrklazy>:

char *
sbrklazy(int n) {
 37a:	1141                	addi	sp,sp,-16
 37c:	e406                	sd	ra,8(sp)
 37e:	e022                	sd	s0,0(sp)
 380:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 382:	4589                	li	a1,2
 384:	09c000ef          	jal	420 <sys_sbrk>
}
 388:	60a2                	ld	ra,8(sp)
 38a:	6402                	ld	s0,0(sp)
 38c:	0141                	addi	sp,sp,16
 38e:	8082                	ret

0000000000000390 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 390:	4885                	li	a7,1
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <exit>:
.global exit
exit:
 li a7, SYS_exit
 398:	4889                	li	a7,2
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3a0:	488d                	li	a7,3
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3a8:	4891                	li	a7,4
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <read>:
.global read
read:
 li a7, SYS_read
 3b0:	4895                	li	a7,5
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <write>:
.global write
write:
 li a7, SYS_write
 3b8:	48c1                	li	a7,16
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <close>:
.global close
close:
 li a7, SYS_close
 3c0:	48d5                	li	a7,21
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3c8:	4899                	li	a7,6
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <exec>:
.global exec
exec:
 li a7, SYS_exec
 3d0:	489d                	li	a7,7
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <open>:
.global open
open:
 li a7, SYS_open
 3d8:	48bd                	li	a7,15
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3e0:	48c5                	li	a7,17
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3e8:	48c9                	li	a7,18
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3f0:	48a1                	li	a7,8
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <link>:
.global link
link:
 li a7, SYS_link
 3f8:	48cd                	li	a7,19
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 400:	48d1                	li	a7,20
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 408:	48a5                	li	a7,9
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <dup>:
.global dup
dup:
 li a7, SYS_dup
 410:	48a9                	li	a7,10
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 418:	48ad                	li	a7,11
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 420:	48b1                	li	a7,12
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <pause>:
.global pause
pause:
 li a7, SYS_pause
 428:	48b5                	li	a7,13
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 430:	48b9                	li	a7,14
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <getfilenum>:
.global getfilenum
getfilenum:
 li a7, SYS_getfilenum
 438:	48d9                	li	a7,22
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <getpinfo>:
.global getpinfo
getpinfo:
 li a7, SYS_getpinfo
 440:	48dd                	li	a7,23
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <setStride>:
.global setStride
setStride:
 li a7, SYS_setStride
 448:	48e1                	li	a7,24
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <pgaccess>:
.global pgaccess
pgaccess:
 li a7, SYS_pgaccess
 450:	48e5                	li	a7,25
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 458:	1101                	addi	sp,sp,-32
 45a:	ec06                	sd	ra,24(sp)
 45c:	e822                	sd	s0,16(sp)
 45e:	1000                	addi	s0,sp,32
 460:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 464:	4605                	li	a2,1
 466:	fef40593          	addi	a1,s0,-17
 46a:	f4fff0ef          	jal	3b8 <write>
}
 46e:	60e2                	ld	ra,24(sp)
 470:	6442                	ld	s0,16(sp)
 472:	6105                	addi	sp,sp,32
 474:	8082                	ret

0000000000000476 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 476:	715d                	addi	sp,sp,-80
 478:	e486                	sd	ra,72(sp)
 47a:	e0a2                	sd	s0,64(sp)
 47c:	f84a                	sd	s2,48(sp)
 47e:	f44e                	sd	s3,40(sp)
 480:	0880                	addi	s0,sp,80
 482:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 484:	c6d1                	beqz	a3,510 <printint+0x9a>
 486:	0805d563          	bgez	a1,510 <printint+0x9a>
    neg = 1;
    x = -xx;
 48a:	40b005b3          	neg	a1,a1
    neg = 1;
 48e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 490:	fb840993          	addi	s3,s0,-72
  neg = 0;
 494:	86ce                	mv	a3,s3
  i = 0;
 496:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 498:	00000817          	auipc	a6,0x0
 49c:	54080813          	addi	a6,a6,1344 # 9d8 <digits>
 4a0:	88ba                	mv	a7,a4
 4a2:	0017051b          	addiw	a0,a4,1
 4a6:	872a                	mv	a4,a0
 4a8:	02c5f7b3          	remu	a5,a1,a2
 4ac:	97c2                	add	a5,a5,a6
 4ae:	0007c783          	lbu	a5,0(a5)
 4b2:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4b6:	87ae                	mv	a5,a1
 4b8:	02c5d5b3          	divu	a1,a1,a2
 4bc:	0685                	addi	a3,a3,1
 4be:	fec7f1e3          	bgeu	a5,a2,4a0 <printint+0x2a>
  if(neg)
 4c2:	00030c63          	beqz	t1,4da <printint+0x64>
    buf[i++] = '-';
 4c6:	fd050793          	addi	a5,a0,-48
 4ca:	00878533          	add	a0,a5,s0
 4ce:	02d00793          	li	a5,45
 4d2:	fef50423          	sb	a5,-24(a0)
 4d6:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 4da:	02e05563          	blez	a4,504 <printint+0x8e>
 4de:	fc26                	sd	s1,56(sp)
 4e0:	377d                	addiw	a4,a4,-1
 4e2:	00e984b3          	add	s1,s3,a4
 4e6:	19fd                	addi	s3,s3,-1
 4e8:	99ba                	add	s3,s3,a4
 4ea:	1702                	slli	a4,a4,0x20
 4ec:	9301                	srli	a4,a4,0x20
 4ee:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4f2:	0004c583          	lbu	a1,0(s1)
 4f6:	854a                	mv	a0,s2
 4f8:	f61ff0ef          	jal	458 <putc>
  while(--i >= 0)
 4fc:	14fd                	addi	s1,s1,-1
 4fe:	ff349ae3          	bne	s1,s3,4f2 <printint+0x7c>
 502:	74e2                	ld	s1,56(sp)
}
 504:	60a6                	ld	ra,72(sp)
 506:	6406                	ld	s0,64(sp)
 508:	7942                	ld	s2,48(sp)
 50a:	79a2                	ld	s3,40(sp)
 50c:	6161                	addi	sp,sp,80
 50e:	8082                	ret
  neg = 0;
 510:	4301                	li	t1,0
 512:	bfbd                	j	490 <printint+0x1a>

0000000000000514 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 514:	711d                	addi	sp,sp,-96
 516:	ec86                	sd	ra,88(sp)
 518:	e8a2                	sd	s0,80(sp)
 51a:	e4a6                	sd	s1,72(sp)
 51c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 51e:	0005c483          	lbu	s1,0(a1)
 522:	22048363          	beqz	s1,748 <vprintf+0x234>
 526:	e0ca                	sd	s2,64(sp)
 528:	fc4e                	sd	s3,56(sp)
 52a:	f852                	sd	s4,48(sp)
 52c:	f456                	sd	s5,40(sp)
 52e:	f05a                	sd	s6,32(sp)
 530:	ec5e                	sd	s7,24(sp)
 532:	e862                	sd	s8,16(sp)
 534:	8b2a                	mv	s6,a0
 536:	8a2e                	mv	s4,a1
 538:	8bb2                	mv	s7,a2
  state = 0;
 53a:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 53c:	4901                	li	s2,0
 53e:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 540:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 544:	06400c13          	li	s8,100
 548:	a00d                	j	56a <vprintf+0x56>
        putc(fd, c0);
 54a:	85a6                	mv	a1,s1
 54c:	855a                	mv	a0,s6
 54e:	f0bff0ef          	jal	458 <putc>
 552:	a019                	j	558 <vprintf+0x44>
    } else if(state == '%'){
 554:	03598363          	beq	s3,s5,57a <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 558:	0019079b          	addiw	a5,s2,1
 55c:	893e                	mv	s2,a5
 55e:	873e                	mv	a4,a5
 560:	97d2                	add	a5,a5,s4
 562:	0007c483          	lbu	s1,0(a5)
 566:	1c048a63          	beqz	s1,73a <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 56a:	0004879b          	sext.w	a5,s1
    if(state == 0){
 56e:	fe0993e3          	bnez	s3,554 <vprintf+0x40>
      if(c0 == '%'){
 572:	fd579ce3          	bne	a5,s5,54a <vprintf+0x36>
        state = '%';
 576:	89be                	mv	s3,a5
 578:	b7c5                	j	558 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 57a:	00ea06b3          	add	a3,s4,a4
 57e:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 582:	1c060863          	beqz	a2,752 <vprintf+0x23e>
      if(c0 == 'd'){
 586:	03878763          	beq	a5,s8,5b4 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 58a:	f9478693          	addi	a3,a5,-108
 58e:	0016b693          	seqz	a3,a3
 592:	f9c60593          	addi	a1,a2,-100
 596:	e99d                	bnez	a1,5cc <vprintf+0xb8>
 598:	ca95                	beqz	a3,5cc <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 59a:	008b8493          	addi	s1,s7,8
 59e:	4685                	li	a3,1
 5a0:	4629                	li	a2,10
 5a2:	000bb583          	ld	a1,0(s7)
 5a6:	855a                	mv	a0,s6
 5a8:	ecfff0ef          	jal	476 <printint>
        i += 1;
 5ac:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5ae:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5b0:	4981                	li	s3,0
 5b2:	b75d                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5b4:	008b8493          	addi	s1,s7,8
 5b8:	4685                	li	a3,1
 5ba:	4629                	li	a2,10
 5bc:	000ba583          	lw	a1,0(s7)
 5c0:	855a                	mv	a0,s6
 5c2:	eb5ff0ef          	jal	476 <printint>
 5c6:	8ba6                	mv	s7,s1
      state = 0;
 5c8:	4981                	li	s3,0
 5ca:	b779                	j	558 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 5cc:	9752                	add	a4,a4,s4
 5ce:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5d2:	f9460713          	addi	a4,a2,-108
 5d6:	00173713          	seqz	a4,a4
 5da:	8f75                	and	a4,a4,a3
 5dc:	f9c58513          	addi	a0,a1,-100
 5e0:	18051363          	bnez	a0,766 <vprintf+0x252>
 5e4:	18070163          	beqz	a4,766 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5e8:	008b8493          	addi	s1,s7,8
 5ec:	4685                	li	a3,1
 5ee:	4629                	li	a2,10
 5f0:	000bb583          	ld	a1,0(s7)
 5f4:	855a                	mv	a0,s6
 5f6:	e81ff0ef          	jal	476 <printint>
        i += 2;
 5fa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5fc:	8ba6                	mv	s7,s1
      state = 0;
 5fe:	4981                	li	s3,0
        i += 2;
 600:	bfa1                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 602:	008b8493          	addi	s1,s7,8
 606:	4681                	li	a3,0
 608:	4629                	li	a2,10
 60a:	000be583          	lwu	a1,0(s7)
 60e:	855a                	mv	a0,s6
 610:	e67ff0ef          	jal	476 <printint>
 614:	8ba6                	mv	s7,s1
      state = 0;
 616:	4981                	li	s3,0
 618:	b781                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 61a:	008b8493          	addi	s1,s7,8
 61e:	4681                	li	a3,0
 620:	4629                	li	a2,10
 622:	000bb583          	ld	a1,0(s7)
 626:	855a                	mv	a0,s6
 628:	e4fff0ef          	jal	476 <printint>
        i += 1;
 62c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 62e:	8ba6                	mv	s7,s1
      state = 0;
 630:	4981                	li	s3,0
 632:	b71d                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 634:	008b8493          	addi	s1,s7,8
 638:	4681                	li	a3,0
 63a:	4629                	li	a2,10
 63c:	000bb583          	ld	a1,0(s7)
 640:	855a                	mv	a0,s6
 642:	e35ff0ef          	jal	476 <printint>
        i += 2;
 646:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 648:	8ba6                	mv	s7,s1
      state = 0;
 64a:	4981                	li	s3,0
        i += 2;
 64c:	b731                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 64e:	008b8493          	addi	s1,s7,8
 652:	4681                	li	a3,0
 654:	4641                	li	a2,16
 656:	000be583          	lwu	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	e1bff0ef          	jal	476 <printint>
 660:	8ba6                	mv	s7,s1
      state = 0;
 662:	4981                	li	s3,0
 664:	bdd5                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 666:	008b8493          	addi	s1,s7,8
 66a:	4681                	li	a3,0
 66c:	4641                	li	a2,16
 66e:	000bb583          	ld	a1,0(s7)
 672:	855a                	mv	a0,s6
 674:	e03ff0ef          	jal	476 <printint>
        i += 1;
 678:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 67a:	8ba6                	mv	s7,s1
      state = 0;
 67c:	4981                	li	s3,0
 67e:	bde9                	j	558 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 680:	008b8493          	addi	s1,s7,8
 684:	4681                	li	a3,0
 686:	4641                	li	a2,16
 688:	000bb583          	ld	a1,0(s7)
 68c:	855a                	mv	a0,s6
 68e:	de9ff0ef          	jal	476 <printint>
        i += 2;
 692:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 694:	8ba6                	mv	s7,s1
      state = 0;
 696:	4981                	li	s3,0
        i += 2;
 698:	b5c1                	j	558 <vprintf+0x44>
 69a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 69c:	008b8793          	addi	a5,s7,8
 6a0:	8cbe                	mv	s9,a5
 6a2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6a6:	03000593          	li	a1,48
 6aa:	855a                	mv	a0,s6
 6ac:	dadff0ef          	jal	458 <putc>
  putc(fd, 'x');
 6b0:	07800593          	li	a1,120
 6b4:	855a                	mv	a0,s6
 6b6:	da3ff0ef          	jal	458 <putc>
 6ba:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6bc:	00000b97          	auipc	s7,0x0
 6c0:	31cb8b93          	addi	s7,s7,796 # 9d8 <digits>
 6c4:	03c9d793          	srli	a5,s3,0x3c
 6c8:	97de                	add	a5,a5,s7
 6ca:	0007c583          	lbu	a1,0(a5)
 6ce:	855a                	mv	a0,s6
 6d0:	d89ff0ef          	jal	458 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6d4:	0992                	slli	s3,s3,0x4
 6d6:	34fd                	addiw	s1,s1,-1
 6d8:	f4f5                	bnez	s1,6c4 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6da:	8be6                	mv	s7,s9
      state = 0;
 6dc:	4981                	li	s3,0
 6de:	6ca2                	ld	s9,8(sp)
 6e0:	bda5                	j	558 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 6e2:	008b8493          	addi	s1,s7,8
 6e6:	000bc583          	lbu	a1,0(s7)
 6ea:	855a                	mv	a0,s6
 6ec:	d6dff0ef          	jal	458 <putc>
 6f0:	8ba6                	mv	s7,s1
      state = 0;
 6f2:	4981                	li	s3,0
 6f4:	b595                	j	558 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6f6:	008b8993          	addi	s3,s7,8
 6fa:	000bb483          	ld	s1,0(s7)
 6fe:	cc91                	beqz	s1,71a <vprintf+0x206>
        for(; *s; s++)
 700:	0004c583          	lbu	a1,0(s1)
 704:	c985                	beqz	a1,734 <vprintf+0x220>
          putc(fd, *s);
 706:	855a                	mv	a0,s6
 708:	d51ff0ef          	jal	458 <putc>
        for(; *s; s++)
 70c:	0485                	addi	s1,s1,1
 70e:	0004c583          	lbu	a1,0(s1)
 712:	f9f5                	bnez	a1,706 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 714:	8bce                	mv	s7,s3
      state = 0;
 716:	4981                	li	s3,0
 718:	b581                	j	558 <vprintf+0x44>
          s = "(null)";
 71a:	00000497          	auipc	s1,0x0
 71e:	2b648493          	addi	s1,s1,694 # 9d0 <malloc+0x11a>
        for(; *s; s++)
 722:	02800593          	li	a1,40
 726:	b7c5                	j	706 <vprintf+0x1f2>
        putc(fd, '%');
 728:	85be                	mv	a1,a5
 72a:	855a                	mv	a0,s6
 72c:	d2dff0ef          	jal	458 <putc>
      state = 0;
 730:	4981                	li	s3,0
 732:	b51d                	j	558 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 734:	8bce                	mv	s7,s3
      state = 0;
 736:	4981                	li	s3,0
 738:	b505                	j	558 <vprintf+0x44>
 73a:	6906                	ld	s2,64(sp)
 73c:	79e2                	ld	s3,56(sp)
 73e:	7a42                	ld	s4,48(sp)
 740:	7aa2                	ld	s5,40(sp)
 742:	7b02                	ld	s6,32(sp)
 744:	6be2                	ld	s7,24(sp)
 746:	6c42                	ld	s8,16(sp)
    }
  }
}
 748:	60e6                	ld	ra,88(sp)
 74a:	6446                	ld	s0,80(sp)
 74c:	64a6                	ld	s1,72(sp)
 74e:	6125                	addi	sp,sp,96
 750:	8082                	ret
      if(c0 == 'd'){
 752:	06400713          	li	a4,100
 756:	e4e78fe3          	beq	a5,a4,5b4 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 75a:	f9478693          	addi	a3,a5,-108
 75e:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 762:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 764:	4701                	li	a4,0
      } else if(c0 == 'u'){
 766:	07500513          	li	a0,117
 76a:	e8a78ce3          	beq	a5,a0,602 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 76e:	f8b60513          	addi	a0,a2,-117
 772:	e119                	bnez	a0,778 <vprintf+0x264>
 774:	ea0693e3          	bnez	a3,61a <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 778:	f8b58513          	addi	a0,a1,-117
 77c:	e119                	bnez	a0,782 <vprintf+0x26e>
 77e:	ea071be3          	bnez	a4,634 <vprintf+0x120>
      } else if(c0 == 'x'){
 782:	07800513          	li	a0,120
 786:	eca784e3          	beq	a5,a0,64e <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 78a:	f8860613          	addi	a2,a2,-120
 78e:	e219                	bnez	a2,794 <vprintf+0x280>
 790:	ec069be3          	bnez	a3,666 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 794:	f8858593          	addi	a1,a1,-120
 798:	e199                	bnez	a1,79e <vprintf+0x28a>
 79a:	ee0713e3          	bnez	a4,680 <vprintf+0x16c>
      } else if(c0 == 'p'){
 79e:	07000713          	li	a4,112
 7a2:	eee78ce3          	beq	a5,a4,69a <vprintf+0x186>
      } else if(c0 == 'c'){
 7a6:	06300713          	li	a4,99
 7aa:	f2e78ce3          	beq	a5,a4,6e2 <vprintf+0x1ce>
      } else if(c0 == 's'){
 7ae:	07300713          	li	a4,115
 7b2:	f4e782e3          	beq	a5,a4,6f6 <vprintf+0x1e2>
      } else if(c0 == '%'){
 7b6:	02500713          	li	a4,37
 7ba:	f6e787e3          	beq	a5,a4,728 <vprintf+0x214>
        putc(fd, '%');
 7be:	02500593          	li	a1,37
 7c2:	855a                	mv	a0,s6
 7c4:	c95ff0ef          	jal	458 <putc>
        putc(fd, c0);
 7c8:	85a6                	mv	a1,s1
 7ca:	855a                	mv	a0,s6
 7cc:	c8dff0ef          	jal	458 <putc>
      state = 0;
 7d0:	4981                	li	s3,0
 7d2:	b359                	j	558 <vprintf+0x44>

00000000000007d4 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7d4:	715d                	addi	sp,sp,-80
 7d6:	ec06                	sd	ra,24(sp)
 7d8:	e822                	sd	s0,16(sp)
 7da:	1000                	addi	s0,sp,32
 7dc:	e010                	sd	a2,0(s0)
 7de:	e414                	sd	a3,8(s0)
 7e0:	e818                	sd	a4,16(s0)
 7e2:	ec1c                	sd	a5,24(s0)
 7e4:	03043023          	sd	a6,32(s0)
 7e8:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7ec:	8622                	mv	a2,s0
 7ee:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7f2:	d23ff0ef          	jal	514 <vprintf>
}
 7f6:	60e2                	ld	ra,24(sp)
 7f8:	6442                	ld	s0,16(sp)
 7fa:	6161                	addi	sp,sp,80
 7fc:	8082                	ret

00000000000007fe <printf>:

void
printf(const char *fmt, ...)
{
 7fe:	711d                	addi	sp,sp,-96
 800:	ec06                	sd	ra,24(sp)
 802:	e822                	sd	s0,16(sp)
 804:	1000                	addi	s0,sp,32
 806:	e40c                	sd	a1,8(s0)
 808:	e810                	sd	a2,16(s0)
 80a:	ec14                	sd	a3,24(s0)
 80c:	f018                	sd	a4,32(s0)
 80e:	f41c                	sd	a5,40(s0)
 810:	03043823          	sd	a6,48(s0)
 814:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 818:	00840613          	addi	a2,s0,8
 81c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 820:	85aa                	mv	a1,a0
 822:	4505                	li	a0,1
 824:	cf1ff0ef          	jal	514 <vprintf>
}
 828:	60e2                	ld	ra,24(sp)
 82a:	6442                	ld	s0,16(sp)
 82c:	6125                	addi	sp,sp,96
 82e:	8082                	ret

0000000000000830 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 830:	1141                	addi	sp,sp,-16
 832:	e406                	sd	ra,8(sp)
 834:	e022                	sd	s0,0(sp)
 836:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 838:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 83c:	00000797          	auipc	a5,0x0
 840:	7c47b783          	ld	a5,1988(a5) # 1000 <freep>
 844:	a039                	j	852 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 846:	6398                	ld	a4,0(a5)
 848:	00e7e463          	bltu	a5,a4,850 <free+0x20>
 84c:	00e6ea63          	bltu	a3,a4,860 <free+0x30>
{
 850:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 852:	fed7fae3          	bgeu	a5,a3,846 <free+0x16>
 856:	6398                	ld	a4,0(a5)
 858:	00e6e463          	bltu	a3,a4,860 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 85c:	fee7eae3          	bltu	a5,a4,850 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 860:	ff852583          	lw	a1,-8(a0)
 864:	6390                	ld	a2,0(a5)
 866:	02059813          	slli	a6,a1,0x20
 86a:	01c85713          	srli	a4,a6,0x1c
 86e:	9736                	add	a4,a4,a3
 870:	02e60563          	beq	a2,a4,89a <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 874:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 878:	4790                	lw	a2,8(a5)
 87a:	02061593          	slli	a1,a2,0x20
 87e:	01c5d713          	srli	a4,a1,0x1c
 882:	973e                	add	a4,a4,a5
 884:	02e68263          	beq	a3,a4,8a8 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 888:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 88a:	00000717          	auipc	a4,0x0
 88e:	76f73b23          	sd	a5,1910(a4) # 1000 <freep>
}
 892:	60a2                	ld	ra,8(sp)
 894:	6402                	ld	s0,0(sp)
 896:	0141                	addi	sp,sp,16
 898:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 89a:	4618                	lw	a4,8(a2)
 89c:	9f2d                	addw	a4,a4,a1
 89e:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8a2:	6398                	ld	a4,0(a5)
 8a4:	6310                	ld	a2,0(a4)
 8a6:	b7f9                	j	874 <free+0x44>
    p->s.size += bp->s.size;
 8a8:	ff852703          	lw	a4,-8(a0)
 8ac:	9f31                	addw	a4,a4,a2
 8ae:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8b0:	ff053683          	ld	a3,-16(a0)
 8b4:	bfd1                	j	888 <free+0x58>

00000000000008b6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8b6:	7139                	addi	sp,sp,-64
 8b8:	fc06                	sd	ra,56(sp)
 8ba:	f822                	sd	s0,48(sp)
 8bc:	f04a                	sd	s2,32(sp)
 8be:	ec4e                	sd	s3,24(sp)
 8c0:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8c2:	02051993          	slli	s3,a0,0x20
 8c6:	0209d993          	srli	s3,s3,0x20
 8ca:	09bd                	addi	s3,s3,15
 8cc:	0049d993          	srli	s3,s3,0x4
 8d0:	2985                	addiw	s3,s3,1
 8d2:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8d4:	00000517          	auipc	a0,0x0
 8d8:	72c53503          	ld	a0,1836(a0) # 1000 <freep>
 8dc:	c905                	beqz	a0,90c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8de:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8e0:	4798                	lw	a4,8(a5)
 8e2:	09377663          	bgeu	a4,s3,96e <malloc+0xb8>
 8e6:	f426                	sd	s1,40(sp)
 8e8:	e852                	sd	s4,16(sp)
 8ea:	e456                	sd	s5,8(sp)
 8ec:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8ee:	8a4e                	mv	s4,s3
 8f0:	6705                	lui	a4,0x1
 8f2:	00e9f363          	bgeu	s3,a4,8f8 <malloc+0x42>
 8f6:	6a05                	lui	s4,0x1
 8f8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8fc:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 900:	00000497          	auipc	s1,0x0
 904:	70048493          	addi	s1,s1,1792 # 1000 <freep>
  if(p == SBRK_ERROR)
 908:	5afd                	li	s5,-1
 90a:	a83d                	j	948 <malloc+0x92>
 90c:	f426                	sd	s1,40(sp)
 90e:	e852                	sd	s4,16(sp)
 910:	e456                	sd	s5,8(sp)
 912:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 914:	00000797          	auipc	a5,0x0
 918:	6fc78793          	addi	a5,a5,1788 # 1010 <base>
 91c:	00000717          	auipc	a4,0x0
 920:	6ef73223          	sd	a5,1764(a4) # 1000 <freep>
 924:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 926:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 92a:	b7d1                	j	8ee <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 92c:	6398                	ld	a4,0(a5)
 92e:	e118                	sd	a4,0(a0)
 930:	a899                	j	986 <malloc+0xd0>
  hp->s.size = nu;
 932:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 936:	0541                	addi	a0,a0,16
 938:	ef9ff0ef          	jal	830 <free>
  return freep;
 93c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 93e:	c125                	beqz	a0,99e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 940:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 942:	4798                	lw	a4,8(a5)
 944:	03277163          	bgeu	a4,s2,966 <malloc+0xb0>
    if(p == freep)
 948:	6098                	ld	a4,0(s1)
 94a:	853e                	mv	a0,a5
 94c:	fef71ae3          	bne	a4,a5,940 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 950:	8552                	mv	a0,s4
 952:	a13ff0ef          	jal	364 <sbrk>
  if(p == SBRK_ERROR)
 956:	fd551ee3          	bne	a0,s5,932 <malloc+0x7c>
        return 0;
 95a:	4501                	li	a0,0
 95c:	74a2                	ld	s1,40(sp)
 95e:	6a42                	ld	s4,16(sp)
 960:	6aa2                	ld	s5,8(sp)
 962:	6b02                	ld	s6,0(sp)
 964:	a03d                	j	992 <malloc+0xdc>
 966:	74a2                	ld	s1,40(sp)
 968:	6a42                	ld	s4,16(sp)
 96a:	6aa2                	ld	s5,8(sp)
 96c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 96e:	fae90fe3          	beq	s2,a4,92c <malloc+0x76>
        p->s.size -= nunits;
 972:	4137073b          	subw	a4,a4,s3
 976:	c798                	sw	a4,8(a5)
        p += p->s.size;
 978:	02071693          	slli	a3,a4,0x20
 97c:	01c6d713          	srli	a4,a3,0x1c
 980:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 982:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 986:	00000717          	auipc	a4,0x0
 98a:	66a73d23          	sd	a0,1658(a4) # 1000 <freep>
      return (void*)(p + 1);
 98e:	01078513          	addi	a0,a5,16
  }
}
 992:	70e2                	ld	ra,56(sp)
 994:	7442                	ld	s0,48(sp)
 996:	7902                	ld	s2,32(sp)
 998:	69e2                	ld	s3,24(sp)
 99a:	6121                	addi	sp,sp,64
 99c:	8082                	ret
 99e:	74a2                	ld	s1,40(sp)
 9a0:	6a42                	ld	s4,16(sp)
 9a2:	6aa2                	ld	s5,8(sp)
 9a4:	6b02                	ld	s6,0(sp)
 9a6:	b7f5                	j	992 <malloc+0xdc>
