
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	8c010113          	addi	sp,sp,-1856 # 800078c0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdda37>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e2a78793          	addi	a5,a5,-470 # 80000eae <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	37a020ef          	jal	80002494 <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	0000f517          	auipc	a0,0xf
    80000196:	72e50513          	addi	a0,a0,1838 # 8000f8c0 <cons>
    8000019a:	28f000ef          	jal	80000c28 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	0000f497          	auipc	s1,0xf
    800001a2:	72248493          	addi	s1,s1,1826 # 8000f8c0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	0000f917          	auipc	s2,0xf
    800001aa:	7b290913          	addi	s2,s2,1970 # 8000f958 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	0cb010ef          	jal	80001a88 <myproc>
    800001c2:	16a020ef          	jal	8000232c <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	725010ef          	jal	800020f0 <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	0000f717          	auipc	a4,0xf
    800001e2:	6e270713          	addi	a4,a4,1762 # 8000f8c0 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	23a020ef          	jal	8000244a <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	0000f517          	auipc	a0,0xf
    8000022c:	69850513          	addi	a0,a0,1688 # 8000f8c0 <cons>
    80000230:	28d000ef          	jal	80000cbc <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	0000f717          	auipc	a4,0xf
    80000252:	70f72523          	sw	a5,1802(a4) # 8000f958 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	0000f517          	auipc	a0,0xf
    80000268:	65c50513          	addi	a0,a0,1628 # 8000f8c0 <cons>
    8000026c:	251000ef          	jal	80000cbc <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	0000f517          	auipc	a0,0xf
    800002bc:	60850513          	addi	a0,a0,1544 # 8000f8c0 <cons>
    800002c0:	169000ef          	jal	80000c28 <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	204020ef          	jal	800024de <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	0000f517          	auipc	a0,0xf
    800002e2:	5e250513          	addi	a0,a0,1506 # 8000f8c0 <cons>
    800002e6:	1d7000ef          	jal	80000cbc <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	0000f717          	auipc	a4,0xf
    80000300:	5c470713          	addi	a4,a4,1476 # 8000f8c0 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	0000f717          	auipc	a4,0xf
    80000326:	59e70713          	addi	a4,a4,1438 # 8000f8c0 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	0000f717          	auipc	a4,0xf
    80000350:	60c72703          	lw	a4,1548(a4) # 8000f958 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	0000f717          	auipc	a4,0xf
    80000366:	55e70713          	addi	a4,a4,1374 # 8000f8c0 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	0000f497          	auipc	s1,0xf
    80000376:	54e48493          	addi	s1,s1,1358 # 8000f8c0 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	0000f717          	auipc	a4,0xf
    800003b8:	50c70713          	addi	a4,a4,1292 # 8000f8c0 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	0000f717          	auipc	a4,0xf
    800003ce:	58f72b23          	sw	a5,1430(a4) # 8000f960 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	0000f797          	auipc	a5,0xf
    800003ec:	4d878793          	addi	a5,a5,1240 # 8000f8c0 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	0000f797          	auipc	a5,0xf
    8000040e:	54c7a923          	sw	a2,1362(a5) # 8000f95c <cons+0x9c>
        wakeup(&cons.r);
    80000412:	0000f517          	auipc	a0,0xf
    80000416:	54650513          	addi	a0,a0,1350 # 8000f958 <cons+0x98>
    8000041a:	523010ef          	jal	8000213c <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00007597          	auipc	a1,0x7
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80007000 <etext>
    80000430:	0000f517          	auipc	a0,0xf
    80000434:	49050513          	addi	a0,a0,1168 # 8000f8c0 <cons>
    80000438:	766000ef          	jal	80000b9e <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	0001f797          	auipc	a5,0x1f
    80000444:	7f078793          	addi	a5,a5,2032 # 8001fc30 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007817          	auipc	a6,0x7
    80000482:	2c280813          	addi	a6,a6,706 # 80007740 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	36c7a783          	lw	a5,876(a5) # 80007884 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	0000f517          	auipc	a0,0xf
    80000562:	40a50513          	addi	a0,a0,1034 # 8000f968 <pr>
    80000566:	6c2000ef          	jal	80000c28 <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00007c97          	auipc	s9,0x7
    800006d6:	06ec8c93          	addi	s9,s9,110 # 80007740 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00007a17          	auipc	s4,0x7
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80007008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	00007797          	auipc	a5,0x7
    8000075e:	12a7a783          	lw	a5,298(a5) # 80007884 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
    release(&pr.lock);

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
    release(&pr.lock);
    80000784:	0000f517          	auipc	a0,0xf
    80000788:	1e450513          	addi	a0,a0,484 # 8000f968 <pr>
    8000078c:	530000ef          	jal	80000cbc <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	00007797          	auipc	a5,0x7
    80000838:	0497a823          	sw	s1,80(a5) # 80007884 <panicking>
  printf("panic: ");
    8000083c:	00006517          	auipc	a0,0x6
    80000840:	7dc50513          	addi	a0,a0,2012 # 80007018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7d650513          	addi	a0,a0,2006 # 80007020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	00007797          	auipc	a5,0x7
    8000085a:	0297a523          	sw	s1,42(a5) # 80007880 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00006597          	auipc	a1,0x6
    8000086c:	7c058593          	addi	a1,a1,1984 # 80007028 <etext+0x28>
    80000870:	0000f517          	auipc	a0,0xf
    80000874:	0f850513          	addi	a0,a0,248 # 8000f968 <pr>
    80000878:	326000ef          	jal	80000b9e <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00006597          	auipc	a1,0x6
    800008c2:	77258593          	addi	a1,a1,1906 # 80007030 <etext+0x30>
    800008c6:	0000f517          	auipc	a0,0xf
    800008ca:	0ba50513          	addi	a0,a0,186 # 8000f980 <tx_lock>
    800008ce:	2d0000ef          	jal	80000b9e <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	0000f517          	auipc	a0,0xf
    800008ee:	09650513          	addi	a0,a0,150 # 8000f980 <tx_lock>
    800008f2:	336000ef          	jal	80000c28 <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	00007497          	auipc	s1,0x7
    8000090c:	f8448493          	addi	s1,s1,-124 # 8000788c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	0000f997          	auipc	s3,0xf
    80000914:	07098993          	addi	s3,s3,112 # 8000f980 <tx_lock>
    80000918:	00007917          	auipc	s2,0x7
    8000091c:	f7090913          	addi	s2,s2,-144 # 80007888 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	7c4010ef          	jal	800020f0 <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	0000f517          	auipc	a0,0xf
    8000095a:	02a50513          	addi	a0,a0,42 # 8000f980 <tx_lock>
    8000095e:	35e000ef          	jal	80000cbc <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	00007797          	auipc	a5,0x7
    8000097e:	f0a7a783          	lw	a5,-246(a5) # 80007884 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	00007797          	auipc	a5,0x7
    80000988:	efc7a783          	lw	a5,-260(a5) # 80007880 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	00007797          	auipc	a5,0x7
    800009ae:	eda7a783          	lw	a5,-294(a5) # 80007884 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	226000ef          	jal	80000be4 <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	2a6000ef          	jal	80000c6c <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	0000f517          	auipc	a0,0xf
    80000a0a:	f7a50513          	addi	a0,a0,-134 # 8000f980 <tx_lock>
    80000a0e:	21a000ef          	jal	80000c28 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	0000f517          	auipc	a0,0xf
    80000a24:	f6050513          	addi	a0,a0,-160 # 8000f980 <tx_lock>
    80000a28:	294000ef          	jal	80000cbc <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	00007797          	auipc	a5,0x7
    80000a40:	e407a823          	sw	zero,-432(a5) # 8000788c <tx_busy>
    wakeup(&tx_chan);
    80000a44:	00007517          	auipc	a0,0x7
    80000a48:	e4450513          	addi	a0,a0,-444 # 80007888 <tx_chan>
    80000a4c:	6f0010ef          	jal	8000213c <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	e04a                	sd	s2,0(sp)
    80000a66:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a68:	00020797          	auipc	a5,0x20
    80000a6c:	36078793          	addi	a5,a5,864 # 80020dc8 <end>
    80000a70:	00f53733          	sltu	a4,a0,a5
    80000a74:	47c5                	li	a5,17
    80000a76:	07ee                	slli	a5,a5,0x1b
    80000a78:	17fd                	addi	a5,a5,-1
    80000a7a:	00a7b7b3          	sltu	a5,a5,a0
    80000a7e:	8fd9                	or	a5,a5,a4
    80000a80:	ef95                	bnez	a5,80000abc <kfree+0x60>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	03451793          	slli	a5,a0,0x34
    80000a88:	eb95                	bnez	a5,80000abc <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a8a:	6605                	lui	a2,0x1
    80000a8c:	4585                	li	a1,1
    80000a8e:	26a000ef          	jal	80000cf8 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a92:	0000f917          	auipc	s2,0xf
    80000a96:	f0690913          	addi	s2,s2,-250 # 8000f998 <kmem>
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	18c000ef          	jal	80000c28 <acquire>
  r->next = kmem.freelist;
    80000aa0:	01893783          	ld	a5,24(s2)
    80000aa4:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000aa6:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000aaa:	854a                	mv	a0,s2
    80000aac:	210000ef          	jal	80000cbc <release>
}
    80000ab0:	60e2                	ld	ra,24(sp)
    80000ab2:	6442                	ld	s0,16(sp)
    80000ab4:	64a2                	ld	s1,8(sp)
    80000ab6:	6902                	ld	s2,0(sp)
    80000ab8:	6105                	addi	sp,sp,32
    80000aba:	8082                	ret
    panic("kfree");
    80000abc:	00006517          	auipc	a0,0x6
    80000ac0:	57c50513          	addi	a0,a0,1404 # 80007038 <etext+0x38>
    80000ac4:	d61ff0ef          	jal	80000824 <panic>

0000000080000ac8 <freerange>:
{
    80000ac8:	7179                	addi	sp,sp,-48
    80000aca:	f406                	sd	ra,40(sp)
    80000acc:	f022                	sd	s0,32(sp)
    80000ace:	ec26                	sd	s1,24(sp)
    80000ad0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ad2:	6785                	lui	a5,0x1
    80000ad4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad8:	00e504b3          	add	s1,a0,a4
    80000adc:	777d                	lui	a4,0xfffff
    80000ade:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae0:	94be                	add	s1,s1,a5
    80000ae2:	0295e263          	bltu	a1,s1,80000b06 <freerange+0x3e>
    80000ae6:	e84a                	sd	s2,16(sp)
    80000ae8:	e44e                	sd	s3,8(sp)
    80000aea:	e052                	sd	s4,0(sp)
    80000aec:	892e                	mv	s2,a1
    kfree(p);
    80000aee:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af0:	89be                	mv	s3,a5
    kfree(p);
    80000af2:	01448533          	add	a0,s1,s4
    80000af6:	f67ff0ef          	jal	80000a5c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000afa:	94ce                	add	s1,s1,s3
    80000afc:	fe997be3          	bgeu	s2,s1,80000af2 <freerange+0x2a>
    80000b00:	6942                	ld	s2,16(sp)
    80000b02:	69a2                	ld	s3,8(sp)
    80000b04:	6a02                	ld	s4,0(sp)
}
    80000b06:	70a2                	ld	ra,40(sp)
    80000b08:	7402                	ld	s0,32(sp)
    80000b0a:	64e2                	ld	s1,24(sp)
    80000b0c:	6145                	addi	sp,sp,48
    80000b0e:	8082                	ret

0000000080000b10 <kinit>:
{
    80000b10:	1141                	addi	sp,sp,-16
    80000b12:	e406                	sd	ra,8(sp)
    80000b14:	e022                	sd	s0,0(sp)
    80000b16:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b18:	00006597          	auipc	a1,0x6
    80000b1c:	52858593          	addi	a1,a1,1320 # 80007040 <etext+0x40>
    80000b20:	0000f517          	auipc	a0,0xf
    80000b24:	e7850513          	addi	a0,a0,-392 # 8000f998 <kmem>
    80000b28:	076000ef          	jal	80000b9e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00020517          	auipc	a0,0x20
    80000b34:	29850513          	addi	a0,a0,664 # 80020dc8 <end>
    80000b38:	f91ff0ef          	jal	80000ac8 <freerange>
}
    80000b3c:	60a2                	ld	ra,8(sp)
    80000b3e:	6402                	ld	s0,0(sp)
    80000b40:	0141                	addi	sp,sp,16
    80000b42:	8082                	ret

0000000080000b44 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b44:	1101                	addi	sp,sp,-32
    80000b46:	ec06                	sd	ra,24(sp)
    80000b48:	e822                	sd	s0,16(sp)
    80000b4a:	e426                	sd	s1,8(sp)
    80000b4c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4e:	0000f517          	auipc	a0,0xf
    80000b52:	e4a50513          	addi	a0,a0,-438 # 8000f998 <kmem>
    80000b56:	0d2000ef          	jal	80000c28 <acquire>
  r = kmem.freelist;
    80000b5a:	0000f497          	auipc	s1,0xf
    80000b5e:	e564b483          	ld	s1,-426(s1) # 8000f9b0 <kmem+0x18>
  if(r)
    80000b62:	c49d                	beqz	s1,80000b90 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b64:	609c                	ld	a5,0(s1)
    80000b66:	0000f717          	auipc	a4,0xf
    80000b6a:	e4f73523          	sd	a5,-438(a4) # 8000f9b0 <kmem+0x18>
  release(&kmem.lock);
    80000b6e:	0000f517          	auipc	a0,0xf
    80000b72:	e2a50513          	addi	a0,a0,-470 # 8000f998 <kmem>
    80000b76:	146000ef          	jal	80000cbc <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	178000ef          	jal	80000cf8 <memset>
  return (void*)r;
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	0000f517          	auipc	a0,0xf
    80000b94:	e0850513          	addi	a0,a0,-504 # 8000f998 <kmem>
    80000b98:	124000ef          	jal	80000cbc <release>
  if(r)
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x40>

0000000080000b9e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b9e:	1141                	addi	sp,sp,-16
    80000ba0:	e406                	sd	ra,8(sp)
    80000ba2:	e022                	sd	s0,0(sp)
    80000ba4:	0800                	addi	s0,sp,16
  lk->name = name;
    80000ba6:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000ba8:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bac:	00053823          	sd	zero,16(a0)
}
    80000bb0:	60a2                	ld	ra,8(sp)
    80000bb2:	6402                	ld	s0,0(sp)
    80000bb4:	0141                	addi	sp,sp,16
    80000bb6:	8082                	ret

0000000080000bb8 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bb8:	411c                	lw	a5,0(a0)
    80000bba:	e399                	bnez	a5,80000bc0 <holding+0x8>
    80000bbc:	4501                	li	a0,0
  return r;
}
    80000bbe:	8082                	ret
{
    80000bc0:	1101                	addi	sp,sp,-32
    80000bc2:	ec06                	sd	ra,24(sp)
    80000bc4:	e822                	sd	s0,16(sp)
    80000bc6:	e426                	sd	s1,8(sp)
    80000bc8:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bca:	691c                	ld	a5,16(a0)
    80000bcc:	84be                	mv	s1,a5
    80000bce:	69b000ef          	jal	80001a68 <mycpu>
    80000bd2:	40a48533          	sub	a0,s1,a0
    80000bd6:	00153513          	seqz	a0,a0
}
    80000bda:	60e2                	ld	ra,24(sp)
    80000bdc:	6442                	ld	s0,16(sp)
    80000bde:	64a2                	ld	s1,8(sp)
    80000be0:	6105                	addi	sp,sp,32
    80000be2:	8082                	ret

0000000080000be4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000be4:	1101                	addi	sp,sp,-32
    80000be6:	ec06                	sd	ra,24(sp)
    80000be8:	e822                	sd	s0,16(sp)
    80000bea:	e426                	sd	s1,8(sp)
    80000bec:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bee:	100027f3          	csrr	a5,sstatus
    80000bf2:	84be                	mv	s1,a5
    80000bf4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bf8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bfa:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000bfe:	66b000ef          	jal	80001a68 <mycpu>
    80000c02:	5d3c                	lw	a5,120(a0)
    80000c04:	cb99                	beqz	a5,80000c1a <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c06:	663000ef          	jal	80001a68 <mycpu>
    80000c0a:	5d3c                	lw	a5,120(a0)
    80000c0c:	2785                	addiw	a5,a5,1
    80000c0e:	dd3c                	sw	a5,120(a0)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    mycpu()->intena = old;
    80000c1a:	64f000ef          	jal	80001a68 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c1e:	0014d793          	srli	a5,s1,0x1
    80000c22:	8b85                	andi	a5,a5,1
    80000c24:	dd7c                	sw	a5,124(a0)
    80000c26:	b7c5                	j	80000c06 <push_off+0x22>

0000000080000c28 <acquire>:
{
    80000c28:	1101                	addi	sp,sp,-32
    80000c2a:	ec06                	sd	ra,24(sp)
    80000c2c:	e822                	sd	s0,16(sp)
    80000c2e:	e426                	sd	s1,8(sp)
    80000c30:	1000                	addi	s0,sp,32
    80000c32:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c34:	fb1ff0ef          	jal	80000be4 <push_off>
  if(holding(lk))
    80000c38:	8526                	mv	a0,s1
    80000c3a:	f7fff0ef          	jal	80000bb8 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c3e:	4705                	li	a4,1
  if(holding(lk))
    80000c40:	e105                	bnez	a0,80000c60 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c42:	87ba                	mv	a5,a4
    80000c44:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c48:	2781                	sext.w	a5,a5
    80000c4a:	ffe5                	bnez	a5,80000c42 <acquire+0x1a>
  __sync_synchronize();
    80000c4c:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c50:	619000ef          	jal	80001a68 <mycpu>
    80000c54:	e888                	sd	a0,16(s1)
}
    80000c56:	60e2                	ld	ra,24(sp)
    80000c58:	6442                	ld	s0,16(sp)
    80000c5a:	64a2                	ld	s1,8(sp)
    80000c5c:	6105                	addi	sp,sp,32
    80000c5e:	8082                	ret
    panic("acquire");
    80000c60:	00006517          	auipc	a0,0x6
    80000c64:	3e850513          	addi	a0,a0,1000 # 80007048 <etext+0x48>
    80000c68:	bbdff0ef          	jal	80000824 <panic>

0000000080000c6c <pop_off>:

void
pop_off(void)
{
    80000c6c:	1141                	addi	sp,sp,-16
    80000c6e:	e406                	sd	ra,8(sp)
    80000c70:	e022                	sd	s0,0(sp)
    80000c72:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c74:	5f5000ef          	jal	80001a68 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c7c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c7e:	e39d                	bnez	a5,80000ca4 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c80:	5d3c                	lw	a5,120(a0)
    80000c82:	02f05763          	blez	a5,80000cb0 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000c86:	37fd                	addiw	a5,a5,-1
    80000c88:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c8a:	eb89                	bnez	a5,80000c9c <pop_off+0x30>
    80000c8c:	5d7c                	lw	a5,124(a0)
    80000c8e:	c799                	beqz	a5,80000c9c <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c90:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c94:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c98:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c9c:	60a2                	ld	ra,8(sp)
    80000c9e:	6402                	ld	s0,0(sp)
    80000ca0:	0141                	addi	sp,sp,16
    80000ca2:	8082                	ret
    panic("pop_off - interruptible");
    80000ca4:	00006517          	auipc	a0,0x6
    80000ca8:	3ac50513          	addi	a0,a0,940 # 80007050 <etext+0x50>
    80000cac:	b79ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000cb0:	00006517          	auipc	a0,0x6
    80000cb4:	3b850513          	addi	a0,a0,952 # 80007068 <etext+0x68>
    80000cb8:	b6dff0ef          	jal	80000824 <panic>

0000000080000cbc <release>:
{
    80000cbc:	1101                	addi	sp,sp,-32
    80000cbe:	ec06                	sd	ra,24(sp)
    80000cc0:	e822                	sd	s0,16(sp)
    80000cc2:	e426                	sd	s1,8(sp)
    80000cc4:	1000                	addi	s0,sp,32
    80000cc6:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cc8:	ef1ff0ef          	jal	80000bb8 <holding>
    80000ccc:	c105                	beqz	a0,80000cec <release+0x30>
  lk->cpu = 0;
    80000cce:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cd2:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000cd6:	0310000f          	fence	rw,w
    80000cda:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cde:	f8fff0ef          	jal	80000c6c <pop_off>
}
    80000ce2:	60e2                	ld	ra,24(sp)
    80000ce4:	6442                	ld	s0,16(sp)
    80000ce6:	64a2                	ld	s1,8(sp)
    80000ce8:	6105                	addi	sp,sp,32
    80000cea:	8082                	ret
    panic("release");
    80000cec:	00006517          	auipc	a0,0x6
    80000cf0:	38450513          	addi	a0,a0,900 # 80007070 <etext+0x70>
    80000cf4:	b31ff0ef          	jal	80000824 <panic>

0000000080000cf8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cf8:	1141                	addi	sp,sp,-16
    80000cfa:	e406                	sd	ra,8(sp)
    80000cfc:	e022                	sd	s0,0(sp)
    80000cfe:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d00:	ca19                	beqz	a2,80000d16 <memset+0x1e>
    80000d02:	87aa                	mv	a5,a0
    80000d04:	1602                	slli	a2,a2,0x20
    80000d06:	9201                	srli	a2,a2,0x20
    80000d08:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d0c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d10:	0785                	addi	a5,a5,1
    80000d12:	fee79de3          	bne	a5,a4,80000d0c <memset+0x14>
  }
  return dst;
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret

0000000080000d1e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e406                	sd	ra,8(sp)
    80000d22:	e022                	sd	s0,0(sp)
    80000d24:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d26:	c61d                	beqz	a2,80000d54 <memcmp+0x36>
    80000d28:	1602                	slli	a2,a2,0x20
    80000d2a:	9201                	srli	a2,a2,0x20
    80000d2c:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d30:	00054783          	lbu	a5,0(a0)
    80000d34:	0005c703          	lbu	a4,0(a1)
    80000d38:	00e79863          	bne	a5,a4,80000d48 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d3c:	0505                	addi	a0,a0,1
    80000d3e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d40:	fed518e3          	bne	a0,a3,80000d30 <memcmp+0x12>
  }

  return 0;
    80000d44:	4501                	li	a0,0
    80000d46:	a019                	j	80000d4c <memcmp+0x2e>
      return *s1 - *s2;
    80000d48:	40e7853b          	subw	a0,a5,a4
}
    80000d4c:	60a2                	ld	ra,8(sp)
    80000d4e:	6402                	ld	s0,0(sp)
    80000d50:	0141                	addi	sp,sp,16
    80000d52:	8082                	ret
  return 0;
    80000d54:	4501                	li	a0,0
    80000d56:	bfdd                	j	80000d4c <memcmp+0x2e>

0000000080000d58 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d58:	1141                	addi	sp,sp,-16
    80000d5a:	e406                	sd	ra,8(sp)
    80000d5c:	e022                	sd	s0,0(sp)
    80000d5e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d60:	c205                	beqz	a2,80000d80 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d62:	02a5e363          	bltu	a1,a0,80000d88 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d66:	1602                	slli	a2,a2,0x20
    80000d68:	9201                	srli	a2,a2,0x20
    80000d6a:	00c587b3          	add	a5,a1,a2
{
    80000d6e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	0705                	addi	a4,a4,1
    80000d74:	fff5c683          	lbu	a3,-1(a1)
    80000d78:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d7c:	feb79ae3          	bne	a5,a1,80000d70 <memmove+0x18>

  return dst;
}
    80000d80:	60a2                	ld	ra,8(sp)
    80000d82:	6402                	ld	s0,0(sp)
    80000d84:	0141                	addi	sp,sp,16
    80000d86:	8082                	ret
  if(s < d && s + n > d){
    80000d88:	02061693          	slli	a3,a2,0x20
    80000d8c:	9281                	srli	a3,a3,0x20
    80000d8e:	00d58733          	add	a4,a1,a3
    80000d92:	fce57ae3          	bgeu	a0,a4,80000d66 <memmove+0xe>
    d += n;
    80000d96:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d98:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d9c:	1782                	slli	a5,a5,0x20
    80000d9e:	9381                	srli	a5,a5,0x20
    80000da0:	fff7c793          	not	a5,a5
    80000da4:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000da6:	177d                	addi	a4,a4,-1
    80000da8:	16fd                	addi	a3,a3,-1
    80000daa:	00074603          	lbu	a2,0(a4)
    80000dae:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000db2:	fee79ae3          	bne	a5,a4,80000da6 <memmove+0x4e>
    80000db6:	b7e9                	j	80000d80 <memmove+0x28>

0000000080000db8 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000db8:	1141                	addi	sp,sp,-16
    80000dba:	e406                	sd	ra,8(sp)
    80000dbc:	e022                	sd	s0,0(sp)
    80000dbe:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dc0:	f99ff0ef          	jal	80000d58 <memmove>
}
    80000dc4:	60a2                	ld	ra,8(sp)
    80000dc6:	6402                	ld	s0,0(sp)
    80000dc8:	0141                	addi	sp,sp,16
    80000dca:	8082                	ret

0000000080000dcc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000dcc:	1141                	addi	sp,sp,-16
    80000dce:	e406                	sd	ra,8(sp)
    80000dd0:	e022                	sd	s0,0(sp)
    80000dd2:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dd4:	ce11                	beqz	a2,80000df0 <strncmp+0x24>
    80000dd6:	00054783          	lbu	a5,0(a0)
    80000dda:	cf89                	beqz	a5,80000df4 <strncmp+0x28>
    80000ddc:	0005c703          	lbu	a4,0(a1)
    80000de0:	00f71a63          	bne	a4,a5,80000df4 <strncmp+0x28>
    n--, p++, q++;
    80000de4:	367d                	addiw	a2,a2,-1
    80000de6:	0505                	addi	a0,a0,1
    80000de8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dea:	f675                	bnez	a2,80000dd6 <strncmp+0xa>
  if(n == 0)
    return 0;
    80000dec:	4501                	li	a0,0
    80000dee:	a801                	j	80000dfe <strncmp+0x32>
    80000df0:	4501                	li	a0,0
    80000df2:	a031                	j	80000dfe <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000df4:	00054503          	lbu	a0,0(a0)
    80000df8:	0005c783          	lbu	a5,0(a1)
    80000dfc:	9d1d                	subw	a0,a0,a5
}
    80000dfe:	60a2                	ld	ra,8(sp)
    80000e00:	6402                	ld	s0,0(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e406                	sd	ra,8(sp)
    80000e0a:	e022                	sd	s0,0(sp)
    80000e0c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e0e:	87aa                	mv	a5,a0
    80000e10:	a011                	j	80000e14 <strncpy+0xe>
    80000e12:	8636                	mv	a2,a3
    80000e14:	02c05863          	blez	a2,80000e44 <strncpy+0x3e>
    80000e18:	fff6069b          	addiw	a3,a2,-1
    80000e1c:	8836                	mv	a6,a3
    80000e1e:	0785                	addi	a5,a5,1
    80000e20:	0005c703          	lbu	a4,0(a1)
    80000e24:	fee78fa3          	sb	a4,-1(a5)
    80000e28:	0585                	addi	a1,a1,1
    80000e2a:	f765                	bnez	a4,80000e12 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e2c:	873e                	mv	a4,a5
    80000e2e:	01005b63          	blez	a6,80000e44 <strncpy+0x3e>
    80000e32:	9fb1                	addw	a5,a5,a2
    80000e34:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e36:	0705                	addi	a4,a4,1
    80000e38:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e3c:	40e786bb          	subw	a3,a5,a4
    80000e40:	fed04be3          	bgtz	a3,80000e36 <strncpy+0x30>
  return os;
}
    80000e44:	60a2                	ld	ra,8(sp)
    80000e46:	6402                	ld	s0,0(sp)
    80000e48:	0141                	addi	sp,sp,16
    80000e4a:	8082                	ret

0000000080000e4c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e4c:	1141                	addi	sp,sp,-16
    80000e4e:	e406                	sd	ra,8(sp)
    80000e50:	e022                	sd	s0,0(sp)
    80000e52:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e54:	02c05363          	blez	a2,80000e7a <safestrcpy+0x2e>
    80000e58:	fff6069b          	addiw	a3,a2,-1
    80000e5c:	1682                	slli	a3,a3,0x20
    80000e5e:	9281                	srli	a3,a3,0x20
    80000e60:	96ae                	add	a3,a3,a1
    80000e62:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e64:	00d58963          	beq	a1,a3,80000e76 <safestrcpy+0x2a>
    80000e68:	0585                	addi	a1,a1,1
    80000e6a:	0785                	addi	a5,a5,1
    80000e6c:	fff5c703          	lbu	a4,-1(a1)
    80000e70:	fee78fa3          	sb	a4,-1(a5)
    80000e74:	fb65                	bnez	a4,80000e64 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e76:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e7a:	60a2                	ld	ra,8(sp)
    80000e7c:	6402                	ld	s0,0(sp)
    80000e7e:	0141                	addi	sp,sp,16
    80000e80:	8082                	ret

0000000080000e82 <strlen>:

int
strlen(const char *s)
{
    80000e82:	1141                	addi	sp,sp,-16
    80000e84:	e406                	sd	ra,8(sp)
    80000e86:	e022                	sd	s0,0(sp)
    80000e88:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e8a:	00054783          	lbu	a5,0(a0)
    80000e8e:	cf91                	beqz	a5,80000eaa <strlen+0x28>
    80000e90:	00150793          	addi	a5,a0,1
    80000e94:	86be                	mv	a3,a5
    80000e96:	0785                	addi	a5,a5,1
    80000e98:	fff7c703          	lbu	a4,-1(a5)
    80000e9c:	ff65                	bnez	a4,80000e94 <strlen+0x12>
    80000e9e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ea2:	60a2                	ld	ra,8(sp)
    80000ea4:	6402                	ld	s0,0(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret
  for(n = 0; s[n]; n++)
    80000eaa:	4501                	li	a0,0
    80000eac:	bfdd                	j	80000ea2 <strlen+0x20>

0000000080000eae <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000eae:	1141                	addi	sp,sp,-16
    80000eb0:	e406                	sd	ra,8(sp)
    80000eb2:	e022                	sd	s0,0(sp)
    80000eb4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000eb6:	39f000ef          	jal	80001a54 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000eba:	00007717          	auipc	a4,0x7
    80000ebe:	9d670713          	addi	a4,a4,-1578 # 80007890 <started>
  if(cpuid() == 0){
    80000ec2:	c51d                	beqz	a0,80000ef0 <main+0x42>
    while(started == 0)
    80000ec4:	431c                	lw	a5,0(a4)
    80000ec6:	2781                	sext.w	a5,a5
    80000ec8:	dff5                	beqz	a5,80000ec4 <main+0x16>
      ;
    __sync_synchronize();
    80000eca:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ece:	387000ef          	jal	80001a54 <cpuid>
    80000ed2:	85aa                	mv	a1,a0
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	1c450513          	addi	a0,a0,452 # 80007098 <etext+0x98>
    80000edc:	e1eff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000ee0:	11a000ef          	jal	80000ffa <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ee4:	0ab010ef          	jal	8000278e <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ee8:	191040ef          	jal	80005878 <plicinithart>
  }

  scheduler();        
    80000eec:	00e010ef          	jal	80001efa <scheduler>
    consoleinit();
    80000ef0:	d30ff0ef          	jal	80000420 <consoleinit>
    printfinit();
    80000ef4:	96dff0ef          	jal	80000860 <printfinit>
    printf("\n");
    80000ef8:	00006517          	auipc	a0,0x6
    80000efc:	18050513          	addi	a0,a0,384 # 80007078 <etext+0x78>
    80000f00:	dfaff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000f04:	00006517          	auipc	a0,0x6
    80000f08:	17c50513          	addi	a0,a0,380 # 80007080 <etext+0x80>
    80000f0c:	deeff0ef          	jal	800004fa <printf>
    printf("\n");
    80000f10:	00006517          	auipc	a0,0x6
    80000f14:	16850513          	addi	a0,a0,360 # 80007078 <etext+0x78>
    80000f18:	de2ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000f1c:	bf5ff0ef          	jal	80000b10 <kinit>
    kvminit();       // create kernel page table
    80000f20:	366000ef          	jal	80001286 <kvminit>
    kvminithart();   // turn on paging
    80000f24:	0d6000ef          	jal	80000ffa <kvminithart>
    procinit();      // process table
    80000f28:	277000ef          	jal	8000199e <procinit>
    trapinit();      // trap vectors
    80000f2c:	03f010ef          	jal	8000276a <trapinit>
    trapinithart();  // install kernel trap vector
    80000f30:	05f010ef          	jal	8000278e <trapinithart>
    plicinit();      // set up interrupt controller
    80000f34:	12b040ef          	jal	8000585e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f38:	141040ef          	jal	80005878 <plicinithart>
    binit();         // buffer cache
    80000f3c:	7a1010ef          	jal	80002edc <binit>
    iinit();         // inode table
    80000f40:	4f2020ef          	jal	80003432 <iinit>
    fileinit();      // file table
    80000f44:	41e030ef          	jal	80004362 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f48:	221040ef          	jal	80005968 <virtio_disk_init>
    userinit();      // first user process
    80000f4c:	615000ef          	jal	80001d60 <userinit>
    __sync_synchronize();
    80000f50:	0330000f          	fence	rw,rw
    started = 1;
    80000f54:	4785                	li	a5,1
    80000f56:	00007717          	auipc	a4,0x7
    80000f5a:	92f72d23          	sw	a5,-1734(a4) # 80007890 <started>
    80000f5e:	b779                	j	80000eec <main+0x3e>

0000000080000f60 <vmprinthelper>:
  vmprinthelper(pagetable, 1);
}

static void
vmprinthelper(pagetable_t pagetable, int level)
{
    80000f60:	711d                	addi	sp,sp,-96
    80000f62:	ec86                	sd	ra,88(sp)
    80000f64:	e8a2                	sd	s0,80(sp)
    80000f66:	e4a6                	sd	s1,72(sp)
    80000f68:	e0ca                	sd	s2,64(sp)
    80000f6a:	fc4e                	sd	s3,56(sp)
    80000f6c:	f852                	sd	s4,48(sp)
    80000f6e:	f456                	sd	s5,40(sp)
    80000f70:	f05a                	sd	s6,32(sp)
    80000f72:	ec5e                	sd	s7,24(sp)
    80000f74:	e862                	sd	s8,16(sp)
    80000f76:	e466                	sd	s9,8(sp)
    80000f78:	1080                	addi	s0,sp,96
    80000f7a:	89ae                	mv	s3,a1
  for (int i = 0; i < 512; i++) {
    80000f7c:	8b2a                	mv	s6,a0
    80000f7e:	4a81                	li	s5,0
      continue;
    uint64 pa = PTE2PA(pte);
    for (int j = 0; j < level; j++) {
      printf(" ..");
    }
    printf(" %d: pte %p pa %p\n", i, (void*)pte, (void*)pa);
    80000f80:	00006c97          	auipc	s9,0x6
    80000f84:	138c8c93          	addi	s9,s9,312 # 800070b8 <etext+0xb8>
      printf(" ..");
    80000f88:	00006a17          	auipc	s4,0x6
    80000f8c:	128a0a13          	addi	s4,s4,296 # 800070b0 <etext+0xb0>
  for (int i = 0; i < 512; i++) {
    80000f90:	20000c13          	li	s8,512
    80000f94:	a029                	j	80000f9e <vmprinthelper+0x3e>
    80000f96:	2a85                	addiw	s5,s5,1
    80000f98:	0b21                	addi	s6,s6,8
    80000f9a:	058a8363          	beq	s5,s8,80000fe0 <vmprinthelper+0x80>
    pte_t pte = pagetable[i];
    80000f9e:	000b3903          	ld	s2,0(s6)
    if ((pte & PTE_V) == 0)
    80000fa2:	00197793          	andi	a5,s2,1
    80000fa6:	dbe5                	beqz	a5,80000f96 <vmprinthelper+0x36>
    uint64 pa = PTE2PA(pte);
    80000fa8:	00a95b93          	srli	s7,s2,0xa
    80000fac:	0bb2                	slli	s7,s7,0xc
    for (int j = 0; j < level; j++) {
    80000fae:	01305963          	blez	s3,80000fc0 <vmprinthelper+0x60>
    80000fb2:	4481                	li	s1,0
      printf(" ..");
    80000fb4:	8552                	mv	a0,s4
    80000fb6:	d44ff0ef          	jal	800004fa <printf>
    for (int j = 0; j < level; j++) {
    80000fba:	2485                	addiw	s1,s1,1
    80000fbc:	fe999ce3          	bne	s3,s1,80000fb4 <vmprinthelper+0x54>
    printf(" %d: pte %p pa %p\n", i, (void*)pte, (void*)pa);
    80000fc0:	86de                	mv	a3,s7
    80000fc2:	864a                	mv	a2,s2
    80000fc4:	85d6                	mv	a1,s5
    80000fc6:	8566                	mv	a0,s9
    80000fc8:	d32ff0ef          	jal	800004fa <printf>
    if ((pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80000fcc:	00e97913          	andi	s2,s2,14
    80000fd0:	fc0913e3          	bnez	s2,80000f96 <vmprinthelper+0x36>
      vmprinthelper((pagetable_t)pa, level + 1);
    80000fd4:	0019859b          	addiw	a1,s3,1
    80000fd8:	855e                	mv	a0,s7
    80000fda:	f87ff0ef          	jal	80000f60 <vmprinthelper>
    80000fde:	bf65                	j	80000f96 <vmprinthelper+0x36>
    }
  }
}
    80000fe0:	60e6                	ld	ra,88(sp)
    80000fe2:	6446                	ld	s0,80(sp)
    80000fe4:	64a6                	ld	s1,72(sp)
    80000fe6:	6906                	ld	s2,64(sp)
    80000fe8:	79e2                	ld	s3,56(sp)
    80000fea:	7a42                	ld	s4,48(sp)
    80000fec:	7aa2                	ld	s5,40(sp)
    80000fee:	7b02                	ld	s6,32(sp)
    80000ff0:	6be2                	ld	s7,24(sp)
    80000ff2:	6c42                	ld	s8,16(sp)
    80000ff4:	6ca2                	ld	s9,8(sp)
    80000ff6:	6125                	addi	sp,sp,96
    80000ff8:	8082                	ret

0000000080000ffa <kvminithart>:
{
    80000ffa:	1141                	addi	sp,sp,-16
    80000ffc:	e406                	sd	ra,8(sp)
    80000ffe:	e022                	sd	s0,0(sp)
    80001000:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80001002:	12000073          	sfence.vma
  w_satp(MAKE_SATP(kernel_pagetable));
    80001006:	00007797          	auipc	a5,0x7
    8000100a:	8927b783          	ld	a5,-1902(a5) # 80007898 <kernel_pagetable>
    8000100e:	83b1                	srli	a5,a5,0xc
    80001010:	577d                	li	a4,-1
    80001012:	177e                	slli	a4,a4,0x3f
    80001014:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80001016:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    8000101a:	12000073          	sfence.vma
}
    8000101e:	60a2                	ld	ra,8(sp)
    80001020:	6402                	ld	s0,0(sp)
    80001022:	0141                	addi	sp,sp,16
    80001024:	8082                	ret

0000000080001026 <walk>:
{
    80001026:	7139                	addi	sp,sp,-64
    80001028:	fc06                	sd	ra,56(sp)
    8000102a:	f822                	sd	s0,48(sp)
    8000102c:	f426                	sd	s1,40(sp)
    8000102e:	f04a                	sd	s2,32(sp)
    80001030:	ec4e                	sd	s3,24(sp)
    80001032:	e852                	sd	s4,16(sp)
    80001034:	e456                	sd	s5,8(sp)
    80001036:	e05a                	sd	s6,0(sp)
    80001038:	0080                	addi	s0,sp,64
    8000103a:	84aa                	mv	s1,a0
    8000103c:	89ae                	mv	s3,a1
    8000103e:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80001040:	57fd                	li	a5,-1
    80001042:	83e9                	srli	a5,a5,0x1a
    80001044:	4a79                	li	s4,30
  for(int level = 2; level > 0; level--) {
    80001046:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80001048:	04b7e263          	bltu	a5,a1,8000108c <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    8000104c:	0149d933          	srl	s2,s3,s4
    80001050:	1ff97913          	andi	s2,s2,511
    80001054:	090e                	slli	s2,s2,0x3
    80001056:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80001058:	00093483          	ld	s1,0(s2)
    8000105c:	0014f793          	andi	a5,s1,1
    80001060:	cf85                	beqz	a5,80001098 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001062:	80a9                	srli	s1,s1,0xa
    80001064:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80001066:	3a5d                	addiw	s4,s4,-9
    80001068:	ff5a12e3          	bne	s4,s5,8000104c <walk+0x26>
  return &pagetable[PX(0, va)];
    8000106c:	00c9d513          	srli	a0,s3,0xc
    80001070:	1ff57513          	andi	a0,a0,511
    80001074:	050e                	slli	a0,a0,0x3
    80001076:	9526                	add	a0,a0,s1
}
    80001078:	70e2                	ld	ra,56(sp)
    8000107a:	7442                	ld	s0,48(sp)
    8000107c:	74a2                	ld	s1,40(sp)
    8000107e:	7902                	ld	s2,32(sp)
    80001080:	69e2                	ld	s3,24(sp)
    80001082:	6a42                	ld	s4,16(sp)
    80001084:	6aa2                	ld	s5,8(sp)
    80001086:	6b02                	ld	s6,0(sp)
    80001088:	6121                	addi	sp,sp,64
    8000108a:	8082                	ret
    panic("walk");
    8000108c:	00006517          	auipc	a0,0x6
    80001090:	04450513          	addi	a0,a0,68 # 800070d0 <etext+0xd0>
    80001094:	f90ff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80001098:	020b0263          	beqz	s6,800010bc <walk+0x96>
    8000109c:	aa9ff0ef          	jal	80000b44 <kalloc>
    800010a0:	84aa                	mv	s1,a0
    800010a2:	d979                	beqz	a0,80001078 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    800010a4:	6605                	lui	a2,0x1
    800010a6:	4581                	li	a1,0
    800010a8:	c51ff0ef          	jal	80000cf8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    800010ac:	00c4d793          	srli	a5,s1,0xc
    800010b0:	07aa                	slli	a5,a5,0xa
    800010b2:	0017e793          	ori	a5,a5,1
    800010b6:	00f93023          	sd	a5,0(s2)
    800010ba:	b775                	j	80001066 <walk+0x40>
        return 0;
    800010bc:	4501                	li	a0,0
    800010be:	bf6d                	j	80001078 <walk+0x52>

00000000800010c0 <walkaddr>:
  if(va >= MAXVA)
    800010c0:	57fd                	li	a5,-1
    800010c2:	83e9                	srli	a5,a5,0x1a
    800010c4:	00b7f463          	bgeu	a5,a1,800010cc <walkaddr+0xc>
    return 0;
    800010c8:	4501                	li	a0,0
}
    800010ca:	8082                	ret
{
    800010cc:	1141                	addi	sp,sp,-16
    800010ce:	e406                	sd	ra,8(sp)
    800010d0:	e022                	sd	s0,0(sp)
    800010d2:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800010d4:	4601                	li	a2,0
    800010d6:	f51ff0ef          	jal	80001026 <walk>
  if(pte == 0)
    800010da:	c901                	beqz	a0,800010ea <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    800010dc:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800010de:	0117f693          	andi	a3,a5,17
    800010e2:	4745                	li	a4,17
    return 0;
    800010e4:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800010e6:	00e68663          	beq	a3,a4,800010f2 <walkaddr+0x32>
}
    800010ea:	60a2                	ld	ra,8(sp)
    800010ec:	6402                	ld	s0,0(sp)
    800010ee:	0141                	addi	sp,sp,16
    800010f0:	8082                	ret
  pa = PTE2PA(*pte);
    800010f2:	83a9                	srli	a5,a5,0xa
    800010f4:	00c79513          	slli	a0,a5,0xc
  return pa;
    800010f8:	bfcd                	j	800010ea <walkaddr+0x2a>

00000000800010fa <mappages>:
{
    800010fa:	715d                	addi	sp,sp,-80
    800010fc:	e486                	sd	ra,72(sp)
    800010fe:	e0a2                	sd	s0,64(sp)
    80001100:	fc26                	sd	s1,56(sp)
    80001102:	f84a                	sd	s2,48(sp)
    80001104:	f44e                	sd	s3,40(sp)
    80001106:	f052                	sd	s4,32(sp)
    80001108:	ec56                	sd	s5,24(sp)
    8000110a:	e85a                	sd	s6,16(sp)
    8000110c:	e45e                	sd	s7,8(sp)
    8000110e:	0880                	addi	s0,sp,80
  if((va % PGSIZE) != 0)
    80001110:	03459793          	slli	a5,a1,0x34
    80001114:	eba1                	bnez	a5,80001164 <mappages+0x6a>
    80001116:	8a2a                	mv	s4,a0
    80001118:	8aba                	mv	s5,a4
  if((size % PGSIZE) != 0)
    8000111a:	03461793          	slli	a5,a2,0x34
    8000111e:	eba9                	bnez	a5,80001170 <mappages+0x76>
  if(size == 0)
    80001120:	ce31                	beqz	a2,8000117c <mappages+0x82>
  last = va + size - PGSIZE;
    80001122:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    80001126:	80060613          	addi	a2,a2,-2048
    8000112a:	00b60933          	add	s2,a2,a1
  a = va;
    8000112e:	84ae                	mv	s1,a1
    if((pte = walk(pagetable, a, 1)) == 0)
    80001130:	4b05                	li	s6,1
    80001132:	40b689b3          	sub	s3,a3,a1
    a += PGSIZE;
    80001136:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    80001138:	865a                	mv	a2,s6
    8000113a:	85a6                	mv	a1,s1
    8000113c:	8552                	mv	a0,s4
    8000113e:	ee9ff0ef          	jal	80001026 <walk>
    80001142:	c929                	beqz	a0,80001194 <mappages+0x9a>
    if(*pte & PTE_V)
    80001144:	611c                	ld	a5,0(a0)
    80001146:	8b85                	andi	a5,a5,1
    80001148:	e3a1                	bnez	a5,80001188 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000114a:	013487b3          	add	a5,s1,s3
    8000114e:	83b1                	srli	a5,a5,0xc
    80001150:	07aa                	slli	a5,a5,0xa
    80001152:	0157e7b3          	or	a5,a5,s5
    80001156:	0017e793          	ori	a5,a5,1
    8000115a:	e11c                	sd	a5,0(a0)
    if(a == last)
    8000115c:	05248863          	beq	s1,s2,800011ac <mappages+0xb2>
    a += PGSIZE;
    80001160:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001162:	bfd9                	j	80001138 <mappages+0x3e>
    panic("mappages: va not aligned");
    80001164:	00006517          	auipc	a0,0x6
    80001168:	f7450513          	addi	a0,a0,-140 # 800070d8 <etext+0xd8>
    8000116c:	eb8ff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    80001170:	00006517          	auipc	a0,0x6
    80001174:	f8850513          	addi	a0,a0,-120 # 800070f8 <etext+0xf8>
    80001178:	eacff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    8000117c:	00006517          	auipc	a0,0x6
    80001180:	f9c50513          	addi	a0,a0,-100 # 80007118 <etext+0x118>
    80001184:	ea0ff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    80001188:	00006517          	auipc	a0,0x6
    8000118c:	fa050513          	addi	a0,a0,-96 # 80007128 <etext+0x128>
    80001190:	e94ff0ef          	jal	80000824 <panic>
      return -1;
    80001194:	557d                	li	a0,-1
}
    80001196:	60a6                	ld	ra,72(sp)
    80001198:	6406                	ld	s0,64(sp)
    8000119a:	74e2                	ld	s1,56(sp)
    8000119c:	7942                	ld	s2,48(sp)
    8000119e:	79a2                	ld	s3,40(sp)
    800011a0:	7a02                	ld	s4,32(sp)
    800011a2:	6ae2                	ld	s5,24(sp)
    800011a4:	6b42                	ld	s6,16(sp)
    800011a6:	6ba2                	ld	s7,8(sp)
    800011a8:	6161                	addi	sp,sp,80
    800011aa:	8082                	ret
  return 0;
    800011ac:	4501                	li	a0,0
    800011ae:	b7e5                	j	80001196 <mappages+0x9c>

00000000800011b0 <kvmmap>:
{
    800011b0:	1141                	addi	sp,sp,-16
    800011b2:	e406                	sd	ra,8(sp)
    800011b4:	e022                	sd	s0,0(sp)
    800011b6:	0800                	addi	s0,sp,16
    800011b8:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800011ba:	86b2                	mv	a3,a2
    800011bc:	863e                	mv	a2,a5
    800011be:	f3dff0ef          	jal	800010fa <mappages>
    800011c2:	e509                	bnez	a0,800011cc <kvmmap+0x1c>
}
    800011c4:	60a2                	ld	ra,8(sp)
    800011c6:	6402                	ld	s0,0(sp)
    800011c8:	0141                	addi	sp,sp,16
    800011ca:	8082                	ret
    panic("kvmmap");
    800011cc:	00006517          	auipc	a0,0x6
    800011d0:	f6c50513          	addi	a0,a0,-148 # 80007138 <etext+0x138>
    800011d4:	e50ff0ef          	jal	80000824 <panic>

00000000800011d8 <kvmmake>:
{
    800011d8:	1101                	addi	sp,sp,-32
    800011da:	ec06                	sd	ra,24(sp)
    800011dc:	e822                	sd	s0,16(sp)
    800011de:	e426                	sd	s1,8(sp)
    800011e0:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800011e2:	963ff0ef          	jal	80000b44 <kalloc>
    800011e6:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800011e8:	6605                	lui	a2,0x1
    800011ea:	4581                	li	a1,0
    800011ec:	b0dff0ef          	jal	80000cf8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800011f0:	4719                	li	a4,6
    800011f2:	6685                	lui	a3,0x1
    800011f4:	10000637          	lui	a2,0x10000
    800011f8:	85b2                	mv	a1,a2
    800011fa:	8526                	mv	a0,s1
    800011fc:	fb5ff0ef          	jal	800011b0 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001200:	4719                	li	a4,6
    80001202:	6685                	lui	a3,0x1
    80001204:	10001637          	lui	a2,0x10001
    80001208:	85b2                	mv	a1,a2
    8000120a:	8526                	mv	a0,s1
    8000120c:	fa5ff0ef          	jal	800011b0 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001210:	4719                	li	a4,6
    80001212:	040006b7          	lui	a3,0x4000
    80001216:	0c000637          	lui	a2,0xc000
    8000121a:	85b2                	mv	a1,a2
    8000121c:	8526                	mv	a0,s1
    8000121e:	f93ff0ef          	jal	800011b0 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001222:	4729                	li	a4,10
    80001224:	80006697          	auipc	a3,0x80006
    80001228:	ddc68693          	addi	a3,a3,-548 # 7000 <_entry-0x7fff9000>
    8000122c:	4605                	li	a2,1
    8000122e:	067e                	slli	a2,a2,0x1f
    80001230:	85b2                	mv	a1,a2
    80001232:	8526                	mv	a0,s1
    80001234:	f7dff0ef          	jal	800011b0 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001238:	4719                	li	a4,6
    8000123a:	00006697          	auipc	a3,0x6
    8000123e:	dc668693          	addi	a3,a3,-570 # 80007000 <etext>
    80001242:	47c5                	li	a5,17
    80001244:	07ee                	slli	a5,a5,0x1b
    80001246:	40d786b3          	sub	a3,a5,a3
    8000124a:	00006617          	auipc	a2,0x6
    8000124e:	db660613          	addi	a2,a2,-586 # 80007000 <etext>
    80001252:	85b2                	mv	a1,a2
    80001254:	8526                	mv	a0,s1
    80001256:	f5bff0ef          	jal	800011b0 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000125a:	4729                	li	a4,10
    8000125c:	6685                	lui	a3,0x1
    8000125e:	00005617          	auipc	a2,0x5
    80001262:	da260613          	addi	a2,a2,-606 # 80006000 <_trampoline>
    80001266:	040005b7          	lui	a1,0x4000
    8000126a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000126c:	05b2                	slli	a1,a1,0xc
    8000126e:	8526                	mv	a0,s1
    80001270:	f41ff0ef          	jal	800011b0 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001274:	8526                	mv	a0,s1
    80001276:	684000ef          	jal	800018fa <proc_mapstacks>
}
    8000127a:	8526                	mv	a0,s1
    8000127c:	60e2                	ld	ra,24(sp)
    8000127e:	6442                	ld	s0,16(sp)
    80001280:	64a2                	ld	s1,8(sp)
    80001282:	6105                	addi	sp,sp,32
    80001284:	8082                	ret

0000000080001286 <kvminit>:
{
    80001286:	1141                	addi	sp,sp,-16
    80001288:	e406                	sd	ra,8(sp)
    8000128a:	e022                	sd	s0,0(sp)
    8000128c:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000128e:	f4bff0ef          	jal	800011d8 <kvmmake>
    80001292:	00006797          	auipc	a5,0x6
    80001296:	60a7b323          	sd	a0,1542(a5) # 80007898 <kernel_pagetable>
}
    8000129a:	60a2                	ld	ra,8(sp)
    8000129c:	6402                	ld	s0,0(sp)
    8000129e:	0141                	addi	sp,sp,16
    800012a0:	8082                	ret

00000000800012a2 <uvmcreate>:
{
    800012a2:	1101                	addi	sp,sp,-32
    800012a4:	ec06                	sd	ra,24(sp)
    800012a6:	e822                	sd	s0,16(sp)
    800012a8:	e426                	sd	s1,8(sp)
    800012aa:	1000                	addi	s0,sp,32
  pagetable = (pagetable_t) kalloc();
    800012ac:	899ff0ef          	jal	80000b44 <kalloc>
    800012b0:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800012b2:	c509                	beqz	a0,800012bc <uvmcreate+0x1a>
  memset(pagetable, 0, PGSIZE);
    800012b4:	6605                	lui	a2,0x1
    800012b6:	4581                	li	a1,0
    800012b8:	a41ff0ef          	jal	80000cf8 <memset>
}
    800012bc:	8526                	mv	a0,s1
    800012be:	60e2                	ld	ra,24(sp)
    800012c0:	6442                	ld	s0,16(sp)
    800012c2:	64a2                	ld	s1,8(sp)
    800012c4:	6105                	addi	sp,sp,32
    800012c6:	8082                	ret

00000000800012c8 <uvmunmap>:
{
    800012c8:	7139                	addi	sp,sp,-64
    800012ca:	fc06                	sd	ra,56(sp)
    800012cc:	f822                	sd	s0,48(sp)
    800012ce:	0080                	addi	s0,sp,64
  if((va % PGSIZE) != 0)
    800012d0:	03459793          	slli	a5,a1,0x34
    800012d4:	e38d                	bnez	a5,800012f6 <uvmunmap+0x2e>
    800012d6:	f04a                	sd	s2,32(sp)
    800012d8:	ec4e                	sd	s3,24(sp)
    800012da:	e852                	sd	s4,16(sp)
    800012dc:	e456                	sd	s5,8(sp)
    800012de:	e05a                	sd	s6,0(sp)
    800012e0:	8a2a                	mv	s4,a0
    800012e2:	892e                	mv	s2,a1
    800012e4:	8ab6                	mv	s5,a3
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012e6:	0632                	slli	a2,a2,0xc
    800012e8:	00b609b3          	add	s3,a2,a1
    800012ec:	6b05                	lui	s6,0x1
    800012ee:	0535f963          	bgeu	a1,s3,80001340 <uvmunmap+0x78>
    800012f2:	f426                	sd	s1,40(sp)
    800012f4:	a015                	j	80001318 <uvmunmap+0x50>
    800012f6:	f426                	sd	s1,40(sp)
    800012f8:	f04a                	sd	s2,32(sp)
    800012fa:	ec4e                	sd	s3,24(sp)
    800012fc:	e852                	sd	s4,16(sp)
    800012fe:	e456                	sd	s5,8(sp)
    80001300:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001302:	00006517          	auipc	a0,0x6
    80001306:	e3e50513          	addi	a0,a0,-450 # 80007140 <etext+0x140>
    8000130a:	d1aff0ef          	jal	80000824 <panic>
    *pte = 0;
    8000130e:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001312:	995a                	add	s2,s2,s6
    80001314:	03397563          	bgeu	s2,s3,8000133e <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001318:	4601                	li	a2,0
    8000131a:	85ca                	mv	a1,s2
    8000131c:	8552                	mv	a0,s4
    8000131e:	d09ff0ef          	jal	80001026 <walk>
    80001322:	84aa                	mv	s1,a0
    80001324:	d57d                	beqz	a0,80001312 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001326:	611c                	ld	a5,0(a0)
    80001328:	0017f713          	andi	a4,a5,1
    8000132c:	d37d                	beqz	a4,80001312 <uvmunmap+0x4a>
    if(do_free){
    8000132e:	fe0a80e3          	beqz	s5,8000130e <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001332:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001334:	00c79513          	slli	a0,a5,0xc
    80001338:	f24ff0ef          	jal	80000a5c <kfree>
    8000133c:	bfc9                	j	8000130e <uvmunmap+0x46>
    8000133e:	74a2                	ld	s1,40(sp)
    80001340:	7902                	ld	s2,32(sp)
    80001342:	69e2                	ld	s3,24(sp)
    80001344:	6a42                	ld	s4,16(sp)
    80001346:	6aa2                	ld	s5,8(sp)
    80001348:	6b02                	ld	s6,0(sp)
}
    8000134a:	70e2                	ld	ra,56(sp)
    8000134c:	7442                	ld	s0,48(sp)
    8000134e:	6121                	addi	sp,sp,64
    80001350:	8082                	ret

0000000080001352 <uvmdealloc>:
{
    80001352:	1101                	addi	sp,sp,-32
    80001354:	ec06                	sd	ra,24(sp)
    80001356:	e822                	sd	s0,16(sp)
    80001358:	e426                	sd	s1,8(sp)
    8000135a:	1000                	addi	s0,sp,32
    return oldsz;
    8000135c:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000135e:	00b67d63          	bgeu	a2,a1,80001378 <uvmdealloc+0x26>
    80001362:	84b2                	mv	s1,a2
  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001364:	6785                	lui	a5,0x1
    80001366:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001368:	00f60733          	add	a4,a2,a5
    8000136c:	76fd                	lui	a3,0xfffff
    8000136e:	8f75                	and	a4,a4,a3
    80001370:	97ae                	add	a5,a5,a1
    80001372:	8ff5                	and	a5,a5,a3
    80001374:	00f76863          	bltu	a4,a5,80001384 <uvmdealloc+0x32>
}
    80001378:	8526                	mv	a0,s1
    8000137a:	60e2                	ld	ra,24(sp)
    8000137c:	6442                	ld	s0,16(sp)
    8000137e:	64a2                	ld	s1,8(sp)
    80001380:	6105                	addi	sp,sp,32
    80001382:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001384:	8f99                	sub	a5,a5,a4
    80001386:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001388:	4685                	li	a3,1
    8000138a:	0007861b          	sext.w	a2,a5
    8000138e:	85ba                	mv	a1,a4
    80001390:	f39ff0ef          	jal	800012c8 <uvmunmap>
    80001394:	b7d5                	j	80001378 <uvmdealloc+0x26>

0000000080001396 <uvmalloc>:
  if(newsz < oldsz)
    80001396:	0ab66163          	bltu	a2,a1,80001438 <uvmalloc+0xa2>
{
    8000139a:	715d                	addi	sp,sp,-80
    8000139c:	e486                	sd	ra,72(sp)
    8000139e:	e0a2                	sd	s0,64(sp)
    800013a0:	f84a                	sd	s2,48(sp)
    800013a2:	f052                	sd	s4,32(sp)
    800013a4:	ec56                	sd	s5,24(sp)
    800013a6:	e45e                	sd	s7,8(sp)
    800013a8:	0880                	addi	s0,sp,80
    800013aa:	8aaa                	mv	s5,a0
    800013ac:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800013ae:	6785                	lui	a5,0x1
    800013b0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013b2:	95be                	add	a1,a1,a5
    800013b4:	77fd                	lui	a5,0xfffff
    800013b6:	00f5f933          	and	s2,a1,a5
    800013ba:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    800013bc:	08c97063          	bgeu	s2,a2,8000143c <uvmalloc+0xa6>
    800013c0:	fc26                	sd	s1,56(sp)
    800013c2:	f44e                	sd	s3,40(sp)
    800013c4:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    800013c6:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013c8:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800013cc:	f78ff0ef          	jal	80000b44 <kalloc>
    800013d0:	84aa                	mv	s1,a0
    if(mem == 0){
    800013d2:	c50d                	beqz	a0,800013fc <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    800013d4:	864e                	mv	a2,s3
    800013d6:	4581                	li	a1,0
    800013d8:	921ff0ef          	jal	80000cf8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013dc:	875a                	mv	a4,s6
    800013de:	86a6                	mv	a3,s1
    800013e0:	864e                	mv	a2,s3
    800013e2:	85ca                	mv	a1,s2
    800013e4:	8556                	mv	a0,s5
    800013e6:	d15ff0ef          	jal	800010fa <mappages>
    800013ea:	e915                	bnez	a0,8000141e <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800013ec:	994e                	add	s2,s2,s3
    800013ee:	fd496fe3          	bltu	s2,s4,800013cc <uvmalloc+0x36>
  return newsz;
    800013f2:	8552                	mv	a0,s4
    800013f4:	74e2                	ld	s1,56(sp)
    800013f6:	79a2                	ld	s3,40(sp)
    800013f8:	6b42                	ld	s6,16(sp)
    800013fa:	a811                	j	8000140e <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    800013fc:	865e                	mv	a2,s7
    800013fe:	85ca                	mv	a1,s2
    80001400:	8556                	mv	a0,s5
    80001402:	f51ff0ef          	jal	80001352 <uvmdealloc>
      return 0;
    80001406:	4501                	li	a0,0
    80001408:	74e2                	ld	s1,56(sp)
    8000140a:	79a2                	ld	s3,40(sp)
    8000140c:	6b42                	ld	s6,16(sp)
}
    8000140e:	60a6                	ld	ra,72(sp)
    80001410:	6406                	ld	s0,64(sp)
    80001412:	7942                	ld	s2,48(sp)
    80001414:	7a02                	ld	s4,32(sp)
    80001416:	6ae2                	ld	s5,24(sp)
    80001418:	6ba2                	ld	s7,8(sp)
    8000141a:	6161                	addi	sp,sp,80
    8000141c:	8082                	ret
      kfree(mem);
    8000141e:	8526                	mv	a0,s1
    80001420:	e3cff0ef          	jal	80000a5c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001424:	865e                	mv	a2,s7
    80001426:	85ca                	mv	a1,s2
    80001428:	8556                	mv	a0,s5
    8000142a:	f29ff0ef          	jal	80001352 <uvmdealloc>
      return 0;
    8000142e:	4501                	li	a0,0
    80001430:	74e2                	ld	s1,56(sp)
    80001432:	79a2                	ld	s3,40(sp)
    80001434:	6b42                	ld	s6,16(sp)
    80001436:	bfe1                	j	8000140e <uvmalloc+0x78>
    return oldsz;
    80001438:	852e                	mv	a0,a1
}
    8000143a:	8082                	ret
  return newsz;
    8000143c:	8532                	mv	a0,a2
    8000143e:	bfc1                	j	8000140e <uvmalloc+0x78>

0000000080001440 <freewalk>:
{
    80001440:	7179                	addi	sp,sp,-48
    80001442:	f406                	sd	ra,40(sp)
    80001444:	f022                	sd	s0,32(sp)
    80001446:	ec26                	sd	s1,24(sp)
    80001448:	e84a                	sd	s2,16(sp)
    8000144a:	e44e                	sd	s3,8(sp)
    8000144c:	1800                	addi	s0,sp,48
    8000144e:	89aa                	mv	s3,a0
  for(int i = 0; i < 512; i++){
    80001450:	84aa                	mv	s1,a0
    80001452:	6905                	lui	s2,0x1
    80001454:	992a                	add	s2,s2,a0
    80001456:	a811                	j	8000146a <freewalk+0x2a>
      panic("freewalk: leaf");
    80001458:	00006517          	auipc	a0,0x6
    8000145c:	d0050513          	addi	a0,a0,-768 # 80007158 <etext+0x158>
    80001460:	bc4ff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    80001464:	04a1                	addi	s1,s1,8
    80001466:	03248163          	beq	s1,s2,80001488 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000146a:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000146c:	0017f713          	andi	a4,a5,1
    80001470:	db75                	beqz	a4,80001464 <freewalk+0x24>
    80001472:	00e7f713          	andi	a4,a5,14
    80001476:	f36d                	bnez	a4,80001458 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001478:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000147a:	00c79513          	slli	a0,a5,0xc
    8000147e:	fc3ff0ef          	jal	80001440 <freewalk>
      pagetable[i] = 0;
    80001482:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001486:	bff9                	j	80001464 <freewalk+0x24>
  kfree((void*)pagetable);
    80001488:	854e                	mv	a0,s3
    8000148a:	dd2ff0ef          	jal	80000a5c <kfree>
}
    8000148e:	70a2                	ld	ra,40(sp)
    80001490:	7402                	ld	s0,32(sp)
    80001492:	64e2                	ld	s1,24(sp)
    80001494:	6942                	ld	s2,16(sp)
    80001496:	69a2                	ld	s3,8(sp)
    80001498:	6145                	addi	sp,sp,48
    8000149a:	8082                	ret

000000008000149c <uvmfree>:
{
    8000149c:	1101                	addi	sp,sp,-32
    8000149e:	ec06                	sd	ra,24(sp)
    800014a0:	e822                	sd	s0,16(sp)
    800014a2:	e426                	sd	s1,8(sp)
    800014a4:	1000                	addi	s0,sp,32
    800014a6:	84aa                	mv	s1,a0
  if(sz > 0)
    800014a8:	e989                	bnez	a1,800014ba <uvmfree+0x1e>
  freewalk(pagetable);
    800014aa:	8526                	mv	a0,s1
    800014ac:	f95ff0ef          	jal	80001440 <freewalk>
}
    800014b0:	60e2                	ld	ra,24(sp)
    800014b2:	6442                	ld	s0,16(sp)
    800014b4:	64a2                	ld	s1,8(sp)
    800014b6:	6105                	addi	sp,sp,32
    800014b8:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800014ba:	6785                	lui	a5,0x1
    800014bc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014be:	95be                	add	a1,a1,a5
    800014c0:	4685                	li	a3,1
    800014c2:	00c5d613          	srli	a2,a1,0xc
    800014c6:	4581                	li	a1,0
    800014c8:	e01ff0ef          	jal	800012c8 <uvmunmap>
    800014cc:	bff9                	j	800014aa <uvmfree+0xe>

00000000800014ce <uvmcopy>:
  for(i = 0; i < sz; i += PGSIZE){
    800014ce:	ca59                	beqz	a2,80001564 <uvmcopy+0x96>
{
    800014d0:	715d                	addi	sp,sp,-80
    800014d2:	e486                	sd	ra,72(sp)
    800014d4:	e0a2                	sd	s0,64(sp)
    800014d6:	fc26                	sd	s1,56(sp)
    800014d8:	f84a                	sd	s2,48(sp)
    800014da:	f44e                	sd	s3,40(sp)
    800014dc:	f052                	sd	s4,32(sp)
    800014de:	ec56                	sd	s5,24(sp)
    800014e0:	e85a                	sd	s6,16(sp)
    800014e2:	e45e                	sd	s7,8(sp)
    800014e4:	0880                	addi	s0,sp,80
    800014e6:	8b2a                	mv	s6,a0
    800014e8:	8bae                	mv	s7,a1
    800014ea:	8ab2                	mv	s5,a2
  for(i = 0; i < sz; i += PGSIZE){
    800014ec:	4481                	li	s1,0
    memmove(mem, (char*)pa, PGSIZE);
    800014ee:	6a05                	lui	s4,0x1
    800014f0:	a021                	j	800014f8 <uvmcopy+0x2a>
  for(i = 0; i < sz; i += PGSIZE){
    800014f2:	94d2                	add	s1,s1,s4
    800014f4:	0554fc63          	bgeu	s1,s5,8000154c <uvmcopy+0x7e>
    if((pte = walk(old, i, 0)) == 0)
    800014f8:	4601                	li	a2,0
    800014fa:	85a6                	mv	a1,s1
    800014fc:	855a                	mv	a0,s6
    800014fe:	b29ff0ef          	jal	80001026 <walk>
    80001502:	d965                	beqz	a0,800014f2 <uvmcopy+0x24>
    if((*pte & PTE_V) == 0)
    80001504:	00053983          	ld	s3,0(a0)
    80001508:	0019f793          	andi	a5,s3,1
    8000150c:	d3fd                	beqz	a5,800014f2 <uvmcopy+0x24>
    if((mem = kalloc()) == 0)
    8000150e:	e36ff0ef          	jal	80000b44 <kalloc>
    80001512:	892a                	mv	s2,a0
    80001514:	c11d                	beqz	a0,8000153a <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    80001516:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char*)pa, PGSIZE);
    8000151a:	8652                	mv	a2,s4
    8000151c:	05b2                	slli	a1,a1,0xc
    8000151e:	83bff0ef          	jal	80000d58 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001522:	3ff9f713          	andi	a4,s3,1023
    80001526:	86ca                	mv	a3,s2
    80001528:	8652                	mv	a2,s4
    8000152a:	85a6                	mv	a1,s1
    8000152c:	855e                	mv	a0,s7
    8000152e:	bcdff0ef          	jal	800010fa <mappages>
    80001532:	d161                	beqz	a0,800014f2 <uvmcopy+0x24>
      kfree(mem);
    80001534:	854a                	mv	a0,s2
    80001536:	d26ff0ef          	jal	80000a5c <kfree>
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000153a:	4685                	li	a3,1
    8000153c:	00c4d613          	srli	a2,s1,0xc
    80001540:	4581                	li	a1,0
    80001542:	855e                	mv	a0,s7
    80001544:	d85ff0ef          	jal	800012c8 <uvmunmap>
  return -1;
    80001548:	557d                	li	a0,-1
    8000154a:	a011                	j	8000154e <uvmcopy+0x80>
  return 0;
    8000154c:	4501                	li	a0,0
}
    8000154e:	60a6                	ld	ra,72(sp)
    80001550:	6406                	ld	s0,64(sp)
    80001552:	74e2                	ld	s1,56(sp)
    80001554:	7942                	ld	s2,48(sp)
    80001556:	79a2                	ld	s3,40(sp)
    80001558:	7a02                	ld	s4,32(sp)
    8000155a:	6ae2                	ld	s5,24(sp)
    8000155c:	6b42                	ld	s6,16(sp)
    8000155e:	6ba2                	ld	s7,8(sp)
    80001560:	6161                	addi	sp,sp,80
    80001562:	8082                	ret
  return 0;
    80001564:	4501                	li	a0,0
}
    80001566:	8082                	ret

0000000080001568 <uvmclear>:
{
    80001568:	1141                	addi	sp,sp,-16
    8000156a:	e406                	sd	ra,8(sp)
    8000156c:	e022                	sd	s0,0(sp)
    8000156e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001570:	4601                	li	a2,0
    80001572:	ab5ff0ef          	jal	80001026 <walk>
  if(pte == 0)
    80001576:	c901                	beqz	a0,80001586 <uvmclear+0x1e>
  *pte &= ~PTE_U;
    80001578:	611c                	ld	a5,0(a0)
    8000157a:	9bbd                	andi	a5,a5,-17
    8000157c:	e11c                	sd	a5,0(a0)
}
    8000157e:	60a2                	ld	ra,8(sp)
    80001580:	6402                	ld	s0,0(sp)
    80001582:	0141                	addi	sp,sp,16
    80001584:	8082                	ret
    panic("uvmclear");
    80001586:	00006517          	auipc	a0,0x6
    8000158a:	be250513          	addi	a0,a0,-1054 # 80007168 <etext+0x168>
    8000158e:	a96ff0ef          	jal	80000824 <panic>

0000000080001592 <copyinstr>:
  while(got_null == 0 && max > 0){
    80001592:	cac5                	beqz	a3,80001642 <copyinstr+0xb0>
{
    80001594:	715d                	addi	sp,sp,-80
    80001596:	e486                	sd	ra,72(sp)
    80001598:	e0a2                	sd	s0,64(sp)
    8000159a:	fc26                	sd	s1,56(sp)
    8000159c:	f84a                	sd	s2,48(sp)
    8000159e:	f44e                	sd	s3,40(sp)
    800015a0:	f052                	sd	s4,32(sp)
    800015a2:	ec56                	sd	s5,24(sp)
    800015a4:	e85a                	sd	s6,16(sp)
    800015a6:	e45e                	sd	s7,8(sp)
    800015a8:	0880                	addi	s0,sp,80
    800015aa:	8aaa                	mv	s5,a0
    800015ac:	84ae                	mv	s1,a1
    800015ae:	8bb2                	mv	s7,a2
    800015b0:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    800015b2:	7b7d                	lui	s6,0xfffff
    n = PGSIZE - (srcva - va0);
    800015b4:	6a05                	lui	s4,0x1
    800015b6:	a82d                	j	800015f0 <copyinstr+0x5e>
        *dst = '\0';
    800015b8:	00078023          	sb	zero,0(a5)
        got_null = 1;
    800015bc:	4785                	li	a5,1
  if(got_null){
    800015be:	0017c793          	xori	a5,a5,1
    800015c2:	40f0053b          	negw	a0,a5
}
    800015c6:	60a6                	ld	ra,72(sp)
    800015c8:	6406                	ld	s0,64(sp)
    800015ca:	74e2                	ld	s1,56(sp)
    800015cc:	7942                	ld	s2,48(sp)
    800015ce:	79a2                	ld	s3,40(sp)
    800015d0:	7a02                	ld	s4,32(sp)
    800015d2:	6ae2                	ld	s5,24(sp)
    800015d4:	6b42                	ld	s6,16(sp)
    800015d6:	6ba2                	ld	s7,8(sp)
    800015d8:	6161                	addi	sp,sp,80
    800015da:	8082                	ret
    800015dc:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    800015e0:	9726                	add	a4,a4,s1
      --max;
    800015e2:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    800015e6:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    800015ea:	04e58463          	beq	a1,a4,80001632 <copyinstr+0xa0>
{
    800015ee:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    800015f0:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    800015f4:	85ca                	mv	a1,s2
    800015f6:	8556                	mv	a0,s5
    800015f8:	ac9ff0ef          	jal	800010c0 <walkaddr>
    if(pa0 == 0)
    800015fc:	cd0d                	beqz	a0,80001636 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    800015fe:	417906b3          	sub	a3,s2,s7
    80001602:	96d2                	add	a3,a3,s4
    if(n > max)
    80001604:	00d9f363          	bgeu	s3,a3,8000160a <copyinstr+0x78>
    80001608:	86ce                	mv	a3,s3
    while(n > 0){
    8000160a:	ca85                	beqz	a3,8000163a <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    8000160c:	01750633          	add	a2,a0,s7
    80001610:	41260633          	sub	a2,a2,s2
    80001614:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80001616:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80001618:	96a6                	add	a3,a3,s1
    8000161a:	85be                	mv	a1,a5
      if(*p == '\0'){
    8000161c:	00f60733          	add	a4,a2,a5
    80001620:	00074703          	lbu	a4,0(a4)
    80001624:	db51                	beqz	a4,800015b8 <copyinstr+0x26>
        *dst = *p;
    80001626:	00e78023          	sb	a4,0(a5)
      dst++;
    8000162a:	0785                	addi	a5,a5,1
    while(n > 0){
    8000162c:	fed797e3          	bne	a5,a3,8000161a <copyinstr+0x88>
    80001630:	b775                	j	800015dc <copyinstr+0x4a>
    80001632:	4781                	li	a5,0
    80001634:	b769                	j	800015be <copyinstr+0x2c>
      return -1;
    80001636:	557d                	li	a0,-1
    80001638:	b779                	j	800015c6 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    8000163a:	6b85                	lui	s7,0x1
    8000163c:	9bca                	add	s7,s7,s2
    8000163e:	87a6                	mv	a5,s1
    80001640:	b77d                	j	800015ee <copyinstr+0x5c>
  int got_null = 0;
    80001642:	4781                	li	a5,0
  if(got_null){
    80001644:	0017c793          	xori	a5,a5,1
    80001648:	40f0053b          	negw	a0,a5
}
    8000164c:	8082                	ret

000000008000164e <ismapped>:
{
    8000164e:	1141                	addi	sp,sp,-16
    80001650:	e406                	sd	ra,8(sp)
    80001652:	e022                	sd	s0,0(sp)
    80001654:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001656:	4601                	li	a2,0
    80001658:	9cfff0ef          	jal	80001026 <walk>
  if (pte == 0) {
    8000165c:	c119                	beqz	a0,80001662 <ismapped+0x14>
  if (*pte & PTE_V){
    8000165e:	6108                	ld	a0,0(a0)
    80001660:	8905                	andi	a0,a0,1
}
    80001662:	60a2                	ld	ra,8(sp)
    80001664:	6402                	ld	s0,0(sp)
    80001666:	0141                	addi	sp,sp,16
    80001668:	8082                	ret

000000008000166a <vmfault>:
{
    8000166a:	7179                	addi	sp,sp,-48
    8000166c:	f406                	sd	ra,40(sp)
    8000166e:	f022                	sd	s0,32(sp)
    80001670:	e84a                	sd	s2,16(sp)
    80001672:	e44e                	sd	s3,8(sp)
    80001674:	1800                	addi	s0,sp,48
    80001676:	89aa                	mv	s3,a0
    80001678:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000167a:	40e000ef          	jal	80001a88 <myproc>
  if (va >= p->sz)
    8000167e:	693c                	ld	a5,80(a0)
    80001680:	00f96a63          	bltu	s2,a5,80001694 <vmfault+0x2a>
    return 0;
    80001684:	4981                	li	s3,0
}
    80001686:	854e                	mv	a0,s3
    80001688:	70a2                	ld	ra,40(sp)
    8000168a:	7402                	ld	s0,32(sp)
    8000168c:	6942                	ld	s2,16(sp)
    8000168e:	69a2                	ld	s3,8(sp)
    80001690:	6145                	addi	sp,sp,48
    80001692:	8082                	ret
    80001694:	ec26                	sd	s1,24(sp)
    80001696:	e052                	sd	s4,0(sp)
    80001698:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    8000169a:	77fd                	lui	a5,0xfffff
    8000169c:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    800016a0:	85d2                	mv	a1,s4
    800016a2:	854e                	mv	a0,s3
    800016a4:	fabff0ef          	jal	8000164e <ismapped>
    return 0;
    800016a8:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    800016aa:	c501                	beqz	a0,800016b2 <vmfault+0x48>
    800016ac:	64e2                	ld	s1,24(sp)
    800016ae:	6a02                	ld	s4,0(sp)
    800016b0:	bfd9                	j	80001686 <vmfault+0x1c>
  mem = (uint64) kalloc();
    800016b2:	c92ff0ef          	jal	80000b44 <kalloc>
    800016b6:	892a                	mv	s2,a0
  if(mem == 0)
    800016b8:	c905                	beqz	a0,800016e8 <vmfault+0x7e>
  mem = (uint64) kalloc();
    800016ba:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    800016bc:	6605                	lui	a2,0x1
    800016be:	4581                	li	a1,0
    800016c0:	e38ff0ef          	jal	80000cf8 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    800016c4:	4759                	li	a4,22
    800016c6:	86ca                	mv	a3,s2
    800016c8:	6605                	lui	a2,0x1
    800016ca:	85d2                	mv	a1,s4
    800016cc:	6ca8                	ld	a0,88(s1)
    800016ce:	a2dff0ef          	jal	800010fa <mappages>
    800016d2:	e501                	bnez	a0,800016da <vmfault+0x70>
    800016d4:	64e2                	ld	s1,24(sp)
    800016d6:	6a02                	ld	s4,0(sp)
    800016d8:	b77d                	j	80001686 <vmfault+0x1c>
    kfree((void *)mem);
    800016da:	854a                	mv	a0,s2
    800016dc:	b80ff0ef          	jal	80000a5c <kfree>
    return 0;
    800016e0:	4981                	li	s3,0
    800016e2:	64e2                	ld	s1,24(sp)
    800016e4:	6a02                	ld	s4,0(sp)
    800016e6:	b745                	j	80001686 <vmfault+0x1c>
    800016e8:	64e2                	ld	s1,24(sp)
    800016ea:	6a02                	ld	s4,0(sp)
    800016ec:	bf69                	j	80001686 <vmfault+0x1c>

00000000800016ee <copyout>:
  while(len > 0){
    800016ee:	cad1                	beqz	a3,80001782 <copyout+0x94>
{
    800016f0:	711d                	addi	sp,sp,-96
    800016f2:	ec86                	sd	ra,88(sp)
    800016f4:	e8a2                	sd	s0,80(sp)
    800016f6:	e4a6                	sd	s1,72(sp)
    800016f8:	e0ca                	sd	s2,64(sp)
    800016fa:	fc4e                	sd	s3,56(sp)
    800016fc:	f852                	sd	s4,48(sp)
    800016fe:	f456                	sd	s5,40(sp)
    80001700:	f05a                	sd	s6,32(sp)
    80001702:	ec5e                	sd	s7,24(sp)
    80001704:	e862                	sd	s8,16(sp)
    80001706:	e466                	sd	s9,8(sp)
    80001708:	e06a                	sd	s10,0(sp)
    8000170a:	1080                	addi	s0,sp,96
    8000170c:	8baa                	mv	s7,a0
    8000170e:	8a2e                	mv	s4,a1
    80001710:	8b32                	mv	s6,a2
    80001712:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    80001714:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    80001716:	5cfd                	li	s9,-1
    80001718:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    8000171c:	6c05                	lui	s8,0x1
    8000171e:	a005                	j	8000173e <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001720:	409a0533          	sub	a0,s4,s1
    80001724:	0009061b          	sext.w	a2,s2
    80001728:	85da                	mv	a1,s6
    8000172a:	954e                	add	a0,a0,s3
    8000172c:	e2cff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001730:	412a8ab3          	sub	s5,s5,s2
    src += n;
    80001734:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    80001736:	01848a33          	add	s4,s1,s8
  while(len > 0){
    8000173a:	040a8263          	beqz	s5,8000177e <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    8000173e:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    80001742:	049ce263          	bltu	s9,s1,80001786 <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    80001746:	85a6                	mv	a1,s1
    80001748:	855e                	mv	a0,s7
    8000174a:	977ff0ef          	jal	800010c0 <walkaddr>
    8000174e:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    80001750:	e901                	bnez	a0,80001760 <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001752:	4601                	li	a2,0
    80001754:	85a6                	mv	a1,s1
    80001756:	855e                	mv	a0,s7
    80001758:	f13ff0ef          	jal	8000166a <vmfault>
    8000175c:	89aa                	mv	s3,a0
    8000175e:	c139                	beqz	a0,800017a4 <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    80001760:	4601                	li	a2,0
    80001762:	85a6                	mv	a1,s1
    80001764:	855e                	mv	a0,s7
    80001766:	8c1ff0ef          	jal	80001026 <walk>
    if((*pte & PTE_W) == 0)
    8000176a:	611c                	ld	a5,0(a0)
    8000176c:	8b91                	andi	a5,a5,4
    8000176e:	cf8d                	beqz	a5,800017a8 <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    80001770:	41448933          	sub	s2,s1,s4
    80001774:	9962                	add	s2,s2,s8
    if(n > len)
    80001776:	fb2af5e3          	bgeu	s5,s2,80001720 <copyout+0x32>
    8000177a:	8956                	mv	s2,s5
    8000177c:	b755                	j	80001720 <copyout+0x32>
  return 0;
    8000177e:	4501                	li	a0,0
    80001780:	a021                	j	80001788 <copyout+0x9a>
    80001782:	4501                	li	a0,0
}
    80001784:	8082                	ret
      return -1;
    80001786:	557d                	li	a0,-1
}
    80001788:	60e6                	ld	ra,88(sp)
    8000178a:	6446                	ld	s0,80(sp)
    8000178c:	64a6                	ld	s1,72(sp)
    8000178e:	6906                	ld	s2,64(sp)
    80001790:	79e2                	ld	s3,56(sp)
    80001792:	7a42                	ld	s4,48(sp)
    80001794:	7aa2                	ld	s5,40(sp)
    80001796:	7b02                	ld	s6,32(sp)
    80001798:	6be2                	ld	s7,24(sp)
    8000179a:	6c42                	ld	s8,16(sp)
    8000179c:	6ca2                	ld	s9,8(sp)
    8000179e:	6d02                	ld	s10,0(sp)
    800017a0:	6125                	addi	sp,sp,96
    800017a2:	8082                	ret
        return -1;
    800017a4:	557d                	li	a0,-1
    800017a6:	b7cd                	j	80001788 <copyout+0x9a>
      return -1;
    800017a8:	557d                	li	a0,-1
    800017aa:	bff9                	j	80001788 <copyout+0x9a>

00000000800017ac <copyin>:
  while(len > 0){
    800017ac:	c6c9                	beqz	a3,80001836 <copyin+0x8a>
{
    800017ae:	715d                	addi	sp,sp,-80
    800017b0:	e486                	sd	ra,72(sp)
    800017b2:	e0a2                	sd	s0,64(sp)
    800017b4:	fc26                	sd	s1,56(sp)
    800017b6:	f84a                	sd	s2,48(sp)
    800017b8:	f44e                	sd	s3,40(sp)
    800017ba:	f052                	sd	s4,32(sp)
    800017bc:	ec56                	sd	s5,24(sp)
    800017be:	e85a                	sd	s6,16(sp)
    800017c0:	e45e                	sd	s7,8(sp)
    800017c2:	e062                	sd	s8,0(sp)
    800017c4:	0880                	addi	s0,sp,80
    800017c6:	8baa                	mv	s7,a0
    800017c8:	8aae                	mv	s5,a1
    800017ca:	8932                	mv	s2,a2
    800017cc:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    800017ce:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800017d0:	6b05                	lui	s6,0x1
    800017d2:	a035                	j	800017fe <copyin+0x52>
    800017d4:	412984b3          	sub	s1,s3,s2
    800017d8:	94da                	add	s1,s1,s6
    if(n > len)
    800017da:	009a7363          	bgeu	s4,s1,800017e0 <copyin+0x34>
    800017de:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800017e0:	413905b3          	sub	a1,s2,s3
    800017e4:	0004861b          	sext.w	a2,s1
    800017e8:	95aa                	add	a1,a1,a0
    800017ea:	8556                	mv	a0,s5
    800017ec:	d6cff0ef          	jal	80000d58 <memmove>
    len -= n;
    800017f0:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800017f4:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800017f6:	01698933          	add	s2,s3,s6
  while(len > 0){
    800017fa:	020a0163          	beqz	s4,8000181c <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    800017fe:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001802:	85ce                	mv	a1,s3
    80001804:	855e                	mv	a0,s7
    80001806:	8bbff0ef          	jal	800010c0 <walkaddr>
    if(pa0 == 0) {
    8000180a:	f569                	bnez	a0,800017d4 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    8000180c:	4601                	li	a2,0
    8000180e:	85ce                	mv	a1,s3
    80001810:	855e                	mv	a0,s7
    80001812:	e59ff0ef          	jal	8000166a <vmfault>
    80001816:	fd5d                	bnez	a0,800017d4 <copyin+0x28>
        return -1;
    80001818:	557d                	li	a0,-1
    8000181a:	a011                	j	8000181e <copyin+0x72>
  return 0;
    8000181c:	4501                	li	a0,0
}
    8000181e:	60a6                	ld	ra,72(sp)
    80001820:	6406                	ld	s0,64(sp)
    80001822:	74e2                	ld	s1,56(sp)
    80001824:	7942                	ld	s2,48(sp)
    80001826:	79a2                	ld	s3,40(sp)
    80001828:	7a02                	ld	s4,32(sp)
    8000182a:	6ae2                	ld	s5,24(sp)
    8000182c:	6b42                	ld	s6,16(sp)
    8000182e:	6ba2                	ld	s7,8(sp)
    80001830:	6c02                	ld	s8,0(sp)
    80001832:	6161                	addi	sp,sp,80
    80001834:	8082                	ret
  return 0;
    80001836:	4501                	li	a0,0
}
    80001838:	8082                	ret

000000008000183a <vmprint>:
{
    8000183a:	1101                	addi	sp,sp,-32
    8000183c:	ec06                	sd	ra,24(sp)
    8000183e:	e822                	sd	s0,16(sp)
    80001840:	e426                	sd	s1,8(sp)
    80001842:	1000                	addi	s0,sp,32
    80001844:	84aa                	mv	s1,a0
  printf("page table %p\n", pagetable);
    80001846:	85aa                	mv	a1,a0
    80001848:	00006517          	auipc	a0,0x6
    8000184c:	93050513          	addi	a0,a0,-1744 # 80007178 <etext+0x178>
    80001850:	cabfe0ef          	jal	800004fa <printf>
  vmprinthelper(pagetable, 1);
    80001854:	4585                	li	a1,1
    80001856:	8526                	mv	a0,s1
    80001858:	f08ff0ef          	jal	80000f60 <vmprinthelper>
}
    8000185c:	60e2                	ld	ra,24(sp)
    8000185e:	6442                	ld	s0,16(sp)
    80001860:	64a2                	ld	s1,8(sp)
    80001862:	6105                	addi	sp,sp,32
    80001864:	8082                	ret

0000000080001866 <pgaccess>:
// Check which of the next 'num_pages' pages starting at 'start_va'
// have been accessed. We store the result in *bitmask.
// Bit i is 1 if page i was accessed.
int
pgaccess(pagetable_t table, uint64 start_va, int num_pages, uint64 *bitmask)
{
    80001866:	711d                	addi	sp,sp,-96
    80001868:	ec86                	sd	ra,88(sp)
    8000186a:	e8a2                	sd	s0,80(sp)
    8000186c:	ec5e                	sd	s7,24(sp)
    8000186e:	e466                	sd	s9,8(sp)
    80001870:	1080                	addi	s0,sp,96
    80001872:	8cb6                	mv	s9,a3
    uint64 bits = 0;
    if (num_pages > 64)
    {
        num_pages = 64;
    }
    for (int i = 0; i < num_pages; i++)
    80001874:	08c05163          	blez	a2,800018f6 <pgaccess+0x90>
    80001878:	e4a6                	sd	s1,72(sp)
    8000187a:	e0ca                	sd	s2,64(sp)
    8000187c:	fc4e                	sd	s3,56(sp)
    8000187e:	f852                	sd	s4,48(sp)
    80001880:	f456                	sd	s5,40(sp)
    80001882:	f05a                	sd	s6,32(sp)
    80001884:	e862                	sd	s8,16(sp)
    80001886:	8a2a                	mv	s4,a0
    80001888:	84ae                	mv	s1,a1
    if (num_pages > 64)
    8000188a:	89b2                	mv	s3,a2
    8000188c:	04000793          	li	a5,64
    80001890:	00c7d463          	bge	a5,a2,80001898 <pgaccess+0x32>
    80001894:	04000993          	li	s3,64
    80001898:	2981                	sext.w	s3,s3
    for (int i = 0; i < num_pages; i++)
    8000189a:	4901                	li	s2,0
    uint64 bits = 0;
    8000189c:	4b81                	li	s7,0

        if (pte == 0)
        {
            continue;
        }
        if ((*pte & PTE_V) && (*pte & PTE_A))
    8000189e:	04100b13          	li	s6,65
        {
            bits = bits | (1ULL << i);
    800018a2:	4c05                	li	s8,1
    for (int i = 0; i < num_pages; i++)
    800018a4:	6a85                	lui	s5,0x1
    800018a6:	a029                	j	800018b0 <pgaccess+0x4a>
    800018a8:	2905                	addiw	s2,s2,1 # 1001 <_entry-0x7fffefff>
    800018aa:	94d6                	add	s1,s1,s5
    800018ac:	03395563          	bge	s2,s3,800018d6 <pgaccess+0x70>
        pte_t *pte = walk(table, addr, 0);
    800018b0:	4601                	li	a2,0
    800018b2:	85a6                	mv	a1,s1
    800018b4:	8552                	mv	a0,s4
    800018b6:	f70ff0ef          	jal	80001026 <walk>
        if (pte == 0)
    800018ba:	d57d                	beqz	a0,800018a8 <pgaccess+0x42>
        if ((*pte & PTE_V) && (*pte & PTE_A))
    800018bc:	611c                	ld	a5,0(a0)
    800018be:	0417f713          	andi	a4,a5,65
    800018c2:	ff6713e3          	bne	a4,s6,800018a8 <pgaccess+0x42>
            bits = bits | (1ULL << i);
    800018c6:	012c1733          	sll	a4,s8,s2
    800018ca:	00ebebb3          	or	s7,s7,a4
            *pte = *pte ^ PTE_A;  
    800018ce:	0407c793          	xori	a5,a5,64
    800018d2:	e11c                	sd	a5,0(a0)
    800018d4:	bfd1                	j	800018a8 <pgaccess+0x42>
    800018d6:	64a6                	ld	s1,72(sp)
    800018d8:	6906                	ld	s2,64(sp)
    800018da:	79e2                	ld	s3,56(sp)
    800018dc:	7a42                	ld	s4,48(sp)
    800018de:	7aa2                	ld	s5,40(sp)
    800018e0:	7b02                	ld	s6,32(sp)
    800018e2:	6c42                	ld	s8,16(sp)
        }
    }
    *bitmask = bits;
    800018e4:	017cb023          	sd	s7,0(s9)
    return 0;
}
    800018e8:	4501                	li	a0,0
    800018ea:	60e6                	ld	ra,88(sp)
    800018ec:	6446                	ld	s0,80(sp)
    800018ee:	6be2                	ld	s7,24(sp)
    800018f0:	6ca2                	ld	s9,8(sp)
    800018f2:	6125                	addi	sp,sp,96
    800018f4:	8082                	ret
    uint64 bits = 0;
    800018f6:	4b81                	li	s7,0
    800018f8:	b7f5                	j	800018e4 <pgaccess+0x7e>

00000000800018fa <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800018fa:	715d                	addi	sp,sp,-80
    800018fc:	e486                	sd	ra,72(sp)
    800018fe:	e0a2                	sd	s0,64(sp)
    80001900:	fc26                	sd	s1,56(sp)
    80001902:	f84a                	sd	s2,48(sp)
    80001904:	f44e                	sd	s3,40(sp)
    80001906:	f052                	sd	s4,32(sp)
    80001908:	ec56                	sd	s5,24(sp)
    8000190a:	e85a                	sd	s6,16(sp)
    8000190c:	e45e                	sd	s7,8(sp)
    8000190e:	e062                	sd	s8,0(sp)
    80001910:	0880                	addi	s0,sp,80
    80001912:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001914:	0000e497          	auipc	s1,0xe
    80001918:	4d448493          	addi	s1,s1,1236 # 8000fde8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    8000191c:	8c26                	mv	s8,s1
    8000191e:	ff4df937          	lui	s2,0xff4df
    80001922:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdbf5>
    80001926:	0936                	slli	s2,s2,0xd
    80001928:	6f590913          	addi	s2,s2,1781
    8000192c:	0936                	slli	s2,s2,0xd
    8000192e:	bd390913          	addi	s2,s2,-1069
    80001932:	0932                	slli	s2,s2,0xc
    80001934:	7a790913          	addi	s2,s2,1959
    80001938:	040009b7          	lui	s3,0x4000
    8000193c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000193e:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001940:	4b99                	li	s7,6
    80001942:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80001944:	00014a97          	auipc	s5,0x14
    80001948:	0a4a8a93          	addi	s5,s5,164 # 800159e8 <tickslock>
    char *pa = kalloc();
    8000194c:	9f8ff0ef          	jal	80000b44 <kalloc>
    80001950:	862a                	mv	a2,a0
    if(pa == 0)
    80001952:	c121                	beqz	a0,80001992 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80001954:	418485b3          	sub	a1,s1,s8
    80001958:	8591                	srai	a1,a1,0x4
    8000195a:	032585b3          	mul	a1,a1,s2
    8000195e:	05b6                	slli	a1,a1,0xd
    80001960:	6789                	lui	a5,0x2
    80001962:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001964:	875e                	mv	a4,s7
    80001966:	86da                	mv	a3,s6
    80001968:	40b985b3          	sub	a1,s3,a1
    8000196c:	8552                	mv	a0,s4
    8000196e:	843ff0ef          	jal	800011b0 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001972:	17048493          	addi	s1,s1,368
    80001976:	fd549be3          	bne	s1,s5,8000194c <proc_mapstacks+0x52>
  }
}
    8000197a:	60a6                	ld	ra,72(sp)
    8000197c:	6406                	ld	s0,64(sp)
    8000197e:	74e2                	ld	s1,56(sp)
    80001980:	7942                	ld	s2,48(sp)
    80001982:	79a2                	ld	s3,40(sp)
    80001984:	7a02                	ld	s4,32(sp)
    80001986:	6ae2                	ld	s5,24(sp)
    80001988:	6b42                	ld	s6,16(sp)
    8000198a:	6ba2                	ld	s7,8(sp)
    8000198c:	6c02                	ld	s8,0(sp)
    8000198e:	6161                	addi	sp,sp,80
    80001990:	8082                	ret
      panic("kalloc");
    80001992:	00005517          	auipc	a0,0x5
    80001996:	7f650513          	addi	a0,a0,2038 # 80007188 <etext+0x188>
    8000199a:	e8bfe0ef          	jal	80000824 <panic>

000000008000199e <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000199e:	7139                	addi	sp,sp,-64
    800019a0:	fc06                	sd	ra,56(sp)
    800019a2:	f822                	sd	s0,48(sp)
    800019a4:	f426                	sd	s1,40(sp)
    800019a6:	f04a                	sd	s2,32(sp)
    800019a8:	ec4e                	sd	s3,24(sp)
    800019aa:	e852                	sd	s4,16(sp)
    800019ac:	e456                	sd	s5,8(sp)
    800019ae:	e05a                	sd	s6,0(sp)
    800019b0:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    800019b2:	00005597          	auipc	a1,0x5
    800019b6:	7de58593          	addi	a1,a1,2014 # 80007190 <etext+0x190>
    800019ba:	0000e517          	auipc	a0,0xe
    800019be:	ffe50513          	addi	a0,a0,-2 # 8000f9b8 <pid_lock>
    800019c2:	9dcff0ef          	jal	80000b9e <initlock>
  initlock(&wait_lock, "wait_lock");
    800019c6:	00005597          	auipc	a1,0x5
    800019ca:	7d258593          	addi	a1,a1,2002 # 80007198 <etext+0x198>
    800019ce:	0000e517          	auipc	a0,0xe
    800019d2:	00250513          	addi	a0,a0,2 # 8000f9d0 <wait_lock>
    800019d6:	9c8ff0ef          	jal	80000b9e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800019da:	0000e497          	auipc	s1,0xe
    800019de:	40e48493          	addi	s1,s1,1038 # 8000fde8 <proc>
      initlock(&p->lock, "proc");
    800019e2:	00005b17          	auipc	s6,0x5
    800019e6:	7c6b0b13          	addi	s6,s6,1990 # 800071a8 <etext+0x1a8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    800019ea:	8aa6                	mv	s5,s1
    800019ec:	ff4df937          	lui	s2,0xff4df
    800019f0:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdbf5>
    800019f4:	0936                	slli	s2,s2,0xd
    800019f6:	6f590913          	addi	s2,s2,1781
    800019fa:	0936                	slli	s2,s2,0xd
    800019fc:	bd390913          	addi	s2,s2,-1069
    80001a00:	0932                	slli	s2,s2,0xc
    80001a02:	7a790913          	addi	s2,s2,1959
    80001a06:	040009b7          	lui	s3,0x4000
    80001a0a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001a0c:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a0e:	00014a17          	auipc	s4,0x14
    80001a12:	fdaa0a13          	addi	s4,s4,-38 # 800159e8 <tickslock>
      initlock(&p->lock, "proc");
    80001a16:	85da                	mv	a1,s6
    80001a18:	8526                	mv	a0,s1
    80001a1a:	984ff0ef          	jal	80000b9e <initlock>
      p->state = UNUSED;
    80001a1e:	0204a223          	sw	zero,36(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001a22:	415487b3          	sub	a5,s1,s5
    80001a26:	8791                	srai	a5,a5,0x4
    80001a28:	032787b3          	mul	a5,a5,s2
    80001a2c:	07b6                	slli	a5,a5,0xd
    80001a2e:	6709                	lui	a4,0x2
    80001a30:	9fb9                	addw	a5,a5,a4
    80001a32:	40f987b3          	sub	a5,s3,a5
    80001a36:	e4bc                	sd	a5,72(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a38:	17048493          	addi	s1,s1,368
    80001a3c:	fd449de3          	bne	s1,s4,80001a16 <procinit+0x78>
  }
}
    80001a40:	70e2                	ld	ra,56(sp)
    80001a42:	7442                	ld	s0,48(sp)
    80001a44:	74a2                	ld	s1,40(sp)
    80001a46:	7902                	ld	s2,32(sp)
    80001a48:	69e2                	ld	s3,24(sp)
    80001a4a:	6a42                	ld	s4,16(sp)
    80001a4c:	6aa2                	ld	s5,8(sp)
    80001a4e:	6b02                	ld	s6,0(sp)
    80001a50:	6121                	addi	sp,sp,64
    80001a52:	8082                	ret

0000000080001a54 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001a54:	1141                	addi	sp,sp,-16
    80001a56:	e406                	sd	ra,8(sp)
    80001a58:	e022                	sd	s0,0(sp)
    80001a5a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a5c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001a5e:	2501                	sext.w	a0,a0
    80001a60:	60a2                	ld	ra,8(sp)
    80001a62:	6402                	ld	s0,0(sp)
    80001a64:	0141                	addi	sp,sp,16
    80001a66:	8082                	ret

0000000080001a68 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001a68:	1141                	addi	sp,sp,-16
    80001a6a:	e406                	sd	ra,8(sp)
    80001a6c:	e022                	sd	s0,0(sp)
    80001a6e:	0800                	addi	s0,sp,16
    80001a70:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001a72:	2781                	sext.w	a5,a5
    80001a74:	079e                	slli	a5,a5,0x7
  return c;
}
    80001a76:	0000e517          	auipc	a0,0xe
    80001a7a:	f7250513          	addi	a0,a0,-142 # 8000f9e8 <cpus>
    80001a7e:	953e                	add	a0,a0,a5
    80001a80:	60a2                	ld	ra,8(sp)
    80001a82:	6402                	ld	s0,0(sp)
    80001a84:	0141                	addi	sp,sp,16
    80001a86:	8082                	ret

0000000080001a88 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001a88:	1101                	addi	sp,sp,-32
    80001a8a:	ec06                	sd	ra,24(sp)
    80001a8c:	e822                	sd	s0,16(sp)
    80001a8e:	e426                	sd	s1,8(sp)
    80001a90:	1000                	addi	s0,sp,32
  push_off();
    80001a92:	952ff0ef          	jal	80000be4 <push_off>
    80001a96:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001a98:	2781                	sext.w	a5,a5
    80001a9a:	079e                	slli	a5,a5,0x7
    80001a9c:	0000e717          	auipc	a4,0xe
    80001aa0:	f1c70713          	addi	a4,a4,-228 # 8000f9b8 <pid_lock>
    80001aa4:	97ba                	add	a5,a5,a4
    80001aa6:	7b9c                	ld	a5,48(a5)
    80001aa8:	84be                	mv	s1,a5
  pop_off();
    80001aaa:	9c2ff0ef          	jal	80000c6c <pop_off>
  return p;
}
    80001aae:	8526                	mv	a0,s1
    80001ab0:	60e2                	ld	ra,24(sp)
    80001ab2:	6442                	ld	s0,16(sp)
    80001ab4:	64a2                	ld	s1,8(sp)
    80001ab6:	6105                	addi	sp,sp,32
    80001ab8:	8082                	ret

0000000080001aba <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001aba:	7179                	addi	sp,sp,-48
    80001abc:	f406                	sd	ra,40(sp)
    80001abe:	f022                	sd	s0,32(sp)
    80001ac0:	ec26                	sd	s1,24(sp)
    80001ac2:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001ac4:	fc5ff0ef          	jal	80001a88 <myproc>
    80001ac8:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001aca:	9f2ff0ef          	jal	80000cbc <release>

  if (first) {
    80001ace:	00006797          	auipc	a5,0x6
    80001ad2:	da27a783          	lw	a5,-606(a5) # 80007870 <first.1>
    80001ad6:	cf95                	beqz	a5,80001b12 <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001ad8:	4505                	li	a0,1
    80001ada:	615010ef          	jal	800038ee <fsinit>

    first = 0;
    80001ade:	00006797          	auipc	a5,0x6
    80001ae2:	d807a923          	sw	zero,-622(a5) # 80007870 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    80001ae6:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001aea:	00005797          	auipc	a5,0x5
    80001aee:	6c678793          	addi	a5,a5,1734 # 800071b0 <etext+0x1b0>
    80001af2:	fcf43823          	sd	a5,-48(s0)
    80001af6:	fc043c23          	sd	zero,-40(s0)
    80001afa:	fd040593          	addi	a1,s0,-48
    80001afe:	853e                	mv	a0,a5
    80001b00:	76d020ef          	jal	80004a6c <kexec>
    80001b04:	70bc                	ld	a5,96(s1)
    80001b06:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001b08:	70bc                	ld	a5,96(s1)
    80001b0a:	7bb8                	ld	a4,112(a5)
    80001b0c:	57fd                	li	a5,-1
    80001b0e:	02f70d63          	beq	a4,a5,80001b48 <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001b12:	499000ef          	jal	800027aa <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001b16:	6ca8                	ld	a0,88(s1)
    80001b18:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001b1a:	04000737          	lui	a4,0x4000
    80001b1e:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001b20:	0732                	slli	a4,a4,0xc
    80001b22:	00004797          	auipc	a5,0x4
    80001b26:	57a78793          	addi	a5,a5,1402 # 8000609c <userret>
    80001b2a:	00004697          	auipc	a3,0x4
    80001b2e:	4d668693          	addi	a3,a3,1238 # 80006000 <_trampoline>
    80001b32:	8f95                	sub	a5,a5,a3
    80001b34:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001b36:	577d                	li	a4,-1
    80001b38:	177e                	slli	a4,a4,0x3f
    80001b3a:	8d59                	or	a0,a0,a4
    80001b3c:	9782                	jalr	a5
}
    80001b3e:	70a2                	ld	ra,40(sp)
    80001b40:	7402                	ld	s0,32(sp)
    80001b42:	64e2                	ld	s1,24(sp)
    80001b44:	6145                	addi	sp,sp,48
    80001b46:	8082                	ret
      panic("exec");
    80001b48:	00005517          	auipc	a0,0x5
    80001b4c:	67050513          	addi	a0,a0,1648 # 800071b8 <etext+0x1b8>
    80001b50:	cd5fe0ef          	jal	80000824 <panic>

0000000080001b54 <allocpid>:
{
    80001b54:	1101                	addi	sp,sp,-32
    80001b56:	ec06                	sd	ra,24(sp)
    80001b58:	e822                	sd	s0,16(sp)
    80001b5a:	e426                	sd	s1,8(sp)
    80001b5c:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001b5e:	0000e517          	auipc	a0,0xe
    80001b62:	e5a50513          	addi	a0,a0,-422 # 8000f9b8 <pid_lock>
    80001b66:	8c2ff0ef          	jal	80000c28 <acquire>
  pid = nextpid;
    80001b6a:	00006797          	auipc	a5,0x6
    80001b6e:	d0a78793          	addi	a5,a5,-758 # 80007874 <nextpid>
    80001b72:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001b74:	0014871b          	addiw	a4,s1,1
    80001b78:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001b7a:	0000e517          	auipc	a0,0xe
    80001b7e:	e3e50513          	addi	a0,a0,-450 # 8000f9b8 <pid_lock>
    80001b82:	93aff0ef          	jal	80000cbc <release>
}
    80001b86:	8526                	mv	a0,s1
    80001b88:	60e2                	ld	ra,24(sp)
    80001b8a:	6442                	ld	s0,16(sp)
    80001b8c:	64a2                	ld	s1,8(sp)
    80001b8e:	6105                	addi	sp,sp,32
    80001b90:	8082                	ret

0000000080001b92 <proc_pagetable>:
{
    80001b92:	1101                	addi	sp,sp,-32
    80001b94:	ec06                	sd	ra,24(sp)
    80001b96:	e822                	sd	s0,16(sp)
    80001b98:	e426                	sd	s1,8(sp)
    80001b9a:	e04a                	sd	s2,0(sp)
    80001b9c:	1000                	addi	s0,sp,32
    80001b9e:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001ba0:	f02ff0ef          	jal	800012a2 <uvmcreate>
    80001ba4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001ba6:	cd05                	beqz	a0,80001bde <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001ba8:	4729                	li	a4,10
    80001baa:	00004697          	auipc	a3,0x4
    80001bae:	45668693          	addi	a3,a3,1110 # 80006000 <_trampoline>
    80001bb2:	6605                	lui	a2,0x1
    80001bb4:	040005b7          	lui	a1,0x4000
    80001bb8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001bba:	05b2                	slli	a1,a1,0xc
    80001bbc:	d3eff0ef          	jal	800010fa <mappages>
    80001bc0:	02054663          	bltz	a0,80001bec <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001bc4:	4719                	li	a4,6
    80001bc6:	06093683          	ld	a3,96(s2)
    80001bca:	6605                	lui	a2,0x1
    80001bcc:	020005b7          	lui	a1,0x2000
    80001bd0:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001bd2:	05b6                	slli	a1,a1,0xd
    80001bd4:	8526                	mv	a0,s1
    80001bd6:	d24ff0ef          	jal	800010fa <mappages>
    80001bda:	00054f63          	bltz	a0,80001bf8 <proc_pagetable+0x66>
}
    80001bde:	8526                	mv	a0,s1
    80001be0:	60e2                	ld	ra,24(sp)
    80001be2:	6442                	ld	s0,16(sp)
    80001be4:	64a2                	ld	s1,8(sp)
    80001be6:	6902                	ld	s2,0(sp)
    80001be8:	6105                	addi	sp,sp,32
    80001bea:	8082                	ret
    uvmfree(pagetable, 0);
    80001bec:	4581                	li	a1,0
    80001bee:	8526                	mv	a0,s1
    80001bf0:	8adff0ef          	jal	8000149c <uvmfree>
    return 0;
    80001bf4:	4481                	li	s1,0
    80001bf6:	b7e5                	j	80001bde <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001bf8:	4681                	li	a3,0
    80001bfa:	4605                	li	a2,1
    80001bfc:	040005b7          	lui	a1,0x4000
    80001c00:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c02:	05b2                	slli	a1,a1,0xc
    80001c04:	8526                	mv	a0,s1
    80001c06:	ec2ff0ef          	jal	800012c8 <uvmunmap>
    uvmfree(pagetable, 0);
    80001c0a:	4581                	li	a1,0
    80001c0c:	8526                	mv	a0,s1
    80001c0e:	88fff0ef          	jal	8000149c <uvmfree>
    return 0;
    80001c12:	4481                	li	s1,0
    80001c14:	b7e9                	j	80001bde <proc_pagetable+0x4c>

0000000080001c16 <proc_freepagetable>:
{
    80001c16:	1101                	addi	sp,sp,-32
    80001c18:	ec06                	sd	ra,24(sp)
    80001c1a:	e822                	sd	s0,16(sp)
    80001c1c:	e426                	sd	s1,8(sp)
    80001c1e:	e04a                	sd	s2,0(sp)
    80001c20:	1000                	addi	s0,sp,32
    80001c22:	84aa                	mv	s1,a0
    80001c24:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001c26:	4681                	li	a3,0
    80001c28:	4605                	li	a2,1
    80001c2a:	040005b7          	lui	a1,0x4000
    80001c2e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c30:	05b2                	slli	a1,a1,0xc
    80001c32:	e96ff0ef          	jal	800012c8 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001c36:	4681                	li	a3,0
    80001c38:	4605                	li	a2,1
    80001c3a:	020005b7          	lui	a1,0x2000
    80001c3e:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001c40:	05b6                	slli	a1,a1,0xd
    80001c42:	8526                	mv	a0,s1
    80001c44:	e84ff0ef          	jal	800012c8 <uvmunmap>
  uvmfree(pagetable, sz);
    80001c48:	85ca                	mv	a1,s2
    80001c4a:	8526                	mv	a0,s1
    80001c4c:	851ff0ef          	jal	8000149c <uvmfree>
}
    80001c50:	60e2                	ld	ra,24(sp)
    80001c52:	6442                	ld	s0,16(sp)
    80001c54:	64a2                	ld	s1,8(sp)
    80001c56:	6902                	ld	s2,0(sp)
    80001c58:	6105                	addi	sp,sp,32
    80001c5a:	8082                	ret

0000000080001c5c <freeproc>:
{
    80001c5c:	1101                	addi	sp,sp,-32
    80001c5e:	ec06                	sd	ra,24(sp)
    80001c60:	e822                	sd	s0,16(sp)
    80001c62:	e426                	sd	s1,8(sp)
    80001c64:	1000                	addi	s0,sp,32
    80001c66:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001c68:	7128                	ld	a0,96(a0)
    80001c6a:	c119                	beqz	a0,80001c70 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001c6c:	df1fe0ef          	jal	80000a5c <kfree>
  p->trapframe = 0;
    80001c70:	0604b023          	sd	zero,96(s1)
  if(p->pagetable)
    80001c74:	6ca8                	ld	a0,88(s1)
    80001c76:	c501                	beqz	a0,80001c7e <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001c78:	68ac                	ld	a1,80(s1)
    80001c7a:	f9dff0ef          	jal	80001c16 <proc_freepagetable>
  p->pagetable = 0;
    80001c7e:	0404bc23          	sd	zero,88(s1)
  p->sz = 0;
    80001c82:	0404b823          	sd	zero,80(s1)
  p->pid = 0;
    80001c86:	0204ac23          	sw	zero,56(s1)
  p->parent = 0;
    80001c8a:	0404b023          	sd	zero,64(s1)
  p->name[0] = 0;
    80001c8e:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    80001c92:	0204b423          	sd	zero,40(s1)
  p->killed = 0;
    80001c96:	0204a823          	sw	zero,48(s1)
  p->xstate = 0;
    80001c9a:	0204aa23          	sw	zero,52(s1)
  p->state = UNUSED;
    80001c9e:	0204a223          	sw	zero,36(s1)
}
    80001ca2:	60e2                	ld	ra,24(sp)
    80001ca4:	6442                	ld	s0,16(sp)
    80001ca6:	64a2                	ld	s1,8(sp)
    80001ca8:	6105                	addi	sp,sp,32
    80001caa:	8082                	ret

0000000080001cac <allocproc>:
{
    80001cac:	1101                	addi	sp,sp,-32
    80001cae:	ec06                	sd	ra,24(sp)
    80001cb0:	e822                	sd	s0,16(sp)
    80001cb2:	e426                	sd	s1,8(sp)
    80001cb4:	e04a                	sd	s2,0(sp)
    80001cb6:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001cb8:	0000e497          	auipc	s1,0xe
    80001cbc:	13048493          	addi	s1,s1,304 # 8000fde8 <proc>
    80001cc0:	00014917          	auipc	s2,0x14
    80001cc4:	d2890913          	addi	s2,s2,-728 # 800159e8 <tickslock>
    acquire(&p->lock);
    80001cc8:	8526                	mv	a0,s1
    80001cca:	f5ffe0ef          	jal	80000c28 <acquire>
    if(p->state == UNUSED) {
    80001cce:	50dc                	lw	a5,36(s1)
    80001cd0:	cb91                	beqz	a5,80001ce4 <allocproc+0x38>
      release(&p->lock);
    80001cd2:	8526                	mv	a0,s1
    80001cd4:	fe9fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001cd8:	17048493          	addi	s1,s1,368
    80001cdc:	ff2496e3          	bne	s1,s2,80001cc8 <allocproc+0x1c>
  return 0;
    80001ce0:	4481                	li	s1,0
    80001ce2:	a881                	j	80001d32 <allocproc+0x86>
      p->runtime = 0;
    80001ce4:	0004ac23          	sw	zero,24(s1)
  p->pid = allocpid();
    80001ce8:	e6dff0ef          	jal	80001b54 <allocpid>
    80001cec:	dc88                	sw	a0,56(s1)
  p->state = USED;
    80001cee:	4785                	li	a5,1
    80001cf0:	d0dc                	sw	a5,36(s1)
  p->runtime = 0;
    80001cf2:	0004ac23          	sw	zero,24(s1)
  p->pass = 0;
    80001cf6:	0204a023          	sw	zero,32(s1)
  p->stride = 1;
    80001cfa:	ccdc                	sw	a5,28(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001cfc:	e49fe0ef          	jal	80000b44 <kalloc>
    80001d00:	892a                	mv	s2,a0
    80001d02:	f0a8                	sd	a0,96(s1)
    80001d04:	cd15                	beqz	a0,80001d40 <allocproc+0x94>
  p->pagetable = proc_pagetable(p);
    80001d06:	8526                	mv	a0,s1
    80001d08:	e8bff0ef          	jal	80001b92 <proc_pagetable>
    80001d0c:	892a                	mv	s2,a0
    80001d0e:	eca8                	sd	a0,88(s1)
  if(p->pagetable == 0){
    80001d10:	c121                	beqz	a0,80001d50 <allocproc+0xa4>
  memset(&p->context, 0, sizeof(p->context));
    80001d12:	07000613          	li	a2,112
    80001d16:	4581                	li	a1,0
    80001d18:	06848513          	addi	a0,s1,104
    80001d1c:	fddfe0ef          	jal	80000cf8 <memset>
  p->context.ra = (uint64)forkret;
    80001d20:	00000797          	auipc	a5,0x0
    80001d24:	d9a78793          	addi	a5,a5,-614 # 80001aba <forkret>
    80001d28:	f4bc                	sd	a5,104(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001d2a:	64bc                	ld	a5,72(s1)
    80001d2c:	6705                	lui	a4,0x1
    80001d2e:	97ba                	add	a5,a5,a4
    80001d30:	f8bc                	sd	a5,112(s1)
}
    80001d32:	8526                	mv	a0,s1
    80001d34:	60e2                	ld	ra,24(sp)
    80001d36:	6442                	ld	s0,16(sp)
    80001d38:	64a2                	ld	s1,8(sp)
    80001d3a:	6902                	ld	s2,0(sp)
    80001d3c:	6105                	addi	sp,sp,32
    80001d3e:	8082                	ret
    freeproc(p);
    80001d40:	8526                	mv	a0,s1
    80001d42:	f1bff0ef          	jal	80001c5c <freeproc>
    release(&p->lock);
    80001d46:	8526                	mv	a0,s1
    80001d48:	f75fe0ef          	jal	80000cbc <release>
    return 0;
    80001d4c:	84ca                	mv	s1,s2
    80001d4e:	b7d5                	j	80001d32 <allocproc+0x86>
    freeproc(p);
    80001d50:	8526                	mv	a0,s1
    80001d52:	f0bff0ef          	jal	80001c5c <freeproc>
    release(&p->lock);
    80001d56:	8526                	mv	a0,s1
    80001d58:	f65fe0ef          	jal	80000cbc <release>
    return 0;
    80001d5c:	84ca                	mv	s1,s2
    80001d5e:	bfd1                	j	80001d32 <allocproc+0x86>

0000000080001d60 <userinit>:
{
    80001d60:	1101                	addi	sp,sp,-32
    80001d62:	ec06                	sd	ra,24(sp)
    80001d64:	e822                	sd	s0,16(sp)
    80001d66:	e426                	sd	s1,8(sp)
    80001d68:	1000                	addi	s0,sp,32
  p = allocproc();
    80001d6a:	f43ff0ef          	jal	80001cac <allocproc>
    80001d6e:	84aa                	mv	s1,a0
  initproc = p;
    80001d70:	00006797          	auipc	a5,0x6
    80001d74:	b2a7bc23          	sd	a0,-1224(a5) # 800078a8 <initproc>
  p->cwd = namei("/");
    80001d78:	00005517          	auipc	a0,0x5
    80001d7c:	44850513          	addi	a0,a0,1096 # 800071c0 <etext+0x1c0>
    80001d80:	0a8020ef          	jal	80003e28 <namei>
    80001d84:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    80001d88:	478d                	li	a5,3
    80001d8a:	d0dc                	sw	a5,36(s1)
  release(&p->lock);
    80001d8c:	8526                	mv	a0,s1
    80001d8e:	f2ffe0ef          	jal	80000cbc <release>
}
    80001d92:	60e2                	ld	ra,24(sp)
    80001d94:	6442                	ld	s0,16(sp)
    80001d96:	64a2                	ld	s1,8(sp)
    80001d98:	6105                	addi	sp,sp,32
    80001d9a:	8082                	ret

0000000080001d9c <growproc>:
{
    80001d9c:	1101                	addi	sp,sp,-32
    80001d9e:	ec06                	sd	ra,24(sp)
    80001da0:	e822                	sd	s0,16(sp)
    80001da2:	e426                	sd	s1,8(sp)
    80001da4:	e04a                	sd	s2,0(sp)
    80001da6:	1000                	addi	s0,sp,32
    80001da8:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001daa:	cdfff0ef          	jal	80001a88 <myproc>
    80001dae:	84aa                	mv	s1,a0
  sz = p->sz;
    80001db0:	692c                	ld	a1,80(a0)
  if(n > 0){
    80001db2:	01204c63          	bgtz	s2,80001dca <growproc+0x2e>
  } else if(n < 0){
    80001db6:	02094463          	bltz	s2,80001dde <growproc+0x42>
  p->sz = sz;
    80001dba:	e8ac                	sd	a1,80(s1)
  return 0;
    80001dbc:	4501                	li	a0,0
}
    80001dbe:	60e2                	ld	ra,24(sp)
    80001dc0:	6442                	ld	s0,16(sp)
    80001dc2:	64a2                	ld	s1,8(sp)
    80001dc4:	6902                	ld	s2,0(sp)
    80001dc6:	6105                	addi	sp,sp,32
    80001dc8:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001dca:	4691                	li	a3,4
    80001dcc:	00b90633          	add	a2,s2,a1
    80001dd0:	6d28                	ld	a0,88(a0)
    80001dd2:	dc4ff0ef          	jal	80001396 <uvmalloc>
    80001dd6:	85aa                	mv	a1,a0
    80001dd8:	f16d                	bnez	a0,80001dba <growproc+0x1e>
      return -1;
    80001dda:	557d                	li	a0,-1
    80001ddc:	b7cd                	j	80001dbe <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001dde:	00b90633          	add	a2,s2,a1
    80001de2:	6d28                	ld	a0,88(a0)
    80001de4:	d6eff0ef          	jal	80001352 <uvmdealloc>
    80001de8:	85aa                	mv	a1,a0
    80001dea:	bfc1                	j	80001dba <growproc+0x1e>

0000000080001dec <kfork>:
{
    80001dec:	7139                	addi	sp,sp,-64
    80001dee:	fc06                	sd	ra,56(sp)
    80001df0:	f822                	sd	s0,48(sp)
    80001df2:	f426                	sd	s1,40(sp)
    80001df4:	e456                	sd	s5,8(sp)
    80001df6:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001df8:	c91ff0ef          	jal	80001a88 <myproc>
    80001dfc:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001dfe:	eafff0ef          	jal	80001cac <allocproc>
    80001e02:	0e050a63          	beqz	a0,80001ef6 <kfork+0x10a>
    80001e06:	e852                	sd	s4,16(sp)
    80001e08:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001e0a:	050ab603          	ld	a2,80(s5)
    80001e0e:	6d2c                	ld	a1,88(a0)
    80001e10:	058ab503          	ld	a0,88(s5)
    80001e14:	ebaff0ef          	jal	800014ce <uvmcopy>
    80001e18:	04054863          	bltz	a0,80001e68 <kfork+0x7c>
    80001e1c:	f04a                	sd	s2,32(sp)
    80001e1e:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001e20:	050ab783          	ld	a5,80(s5)
    80001e24:	04fa3823          	sd	a5,80(s4)
  *(np->trapframe) = *(p->trapframe);
    80001e28:	060ab683          	ld	a3,96(s5)
    80001e2c:	87b6                	mv	a5,a3
    80001e2e:	060a3703          	ld	a4,96(s4)
    80001e32:	12068693          	addi	a3,a3,288
    80001e36:	6388                	ld	a0,0(a5)
    80001e38:	678c                	ld	a1,8(a5)
    80001e3a:	6b90                	ld	a2,16(a5)
    80001e3c:	e308                	sd	a0,0(a4)
    80001e3e:	e70c                	sd	a1,8(a4)
    80001e40:	eb10                	sd	a2,16(a4)
    80001e42:	6f90                	ld	a2,24(a5)
    80001e44:	ef10                	sd	a2,24(a4)
    80001e46:	02078793          	addi	a5,a5,32
    80001e4a:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001e4e:	fed794e3          	bne	a5,a3,80001e36 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001e52:	060a3783          	ld	a5,96(s4)
    80001e56:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001e5a:	0d8a8493          	addi	s1,s5,216
    80001e5e:	0d8a0913          	addi	s2,s4,216
    80001e62:	158a8993          	addi	s3,s5,344
    80001e66:	a831                	j	80001e82 <kfork+0x96>
    freeproc(np);
    80001e68:	8552                	mv	a0,s4
    80001e6a:	df3ff0ef          	jal	80001c5c <freeproc>
    release(&np->lock);
    80001e6e:	8552                	mv	a0,s4
    80001e70:	e4dfe0ef          	jal	80000cbc <release>
    return -1;
    80001e74:	54fd                	li	s1,-1
    80001e76:	6a42                	ld	s4,16(sp)
    80001e78:	a885                	j	80001ee8 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001e7a:	04a1                	addi	s1,s1,8
    80001e7c:	0921                	addi	s2,s2,8
    80001e7e:	01348963          	beq	s1,s3,80001e90 <kfork+0xa4>
    if(p->ofile[i])
    80001e82:	6088                	ld	a0,0(s1)
    80001e84:	d97d                	beqz	a0,80001e7a <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001e86:	55e020ef          	jal	800043e4 <filedup>
    80001e8a:	00a93023          	sd	a0,0(s2)
    80001e8e:	b7f5                	j	80001e7a <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001e90:	158ab503          	ld	a0,344(s5)
    80001e94:	730010ef          	jal	800035c4 <idup>
    80001e98:	14aa3c23          	sd	a0,344(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001e9c:	4641                	li	a2,16
    80001e9e:	160a8593          	addi	a1,s5,352
    80001ea2:	160a0513          	addi	a0,s4,352
    80001ea6:	fa7fe0ef          	jal	80000e4c <safestrcpy>
  pid = np->pid;
    80001eaa:	038a2483          	lw	s1,56(s4)
  release(&np->lock);
    80001eae:	8552                	mv	a0,s4
    80001eb0:	e0dfe0ef          	jal	80000cbc <release>
  acquire(&wait_lock);
    80001eb4:	0000e517          	auipc	a0,0xe
    80001eb8:	b1c50513          	addi	a0,a0,-1252 # 8000f9d0 <wait_lock>
    80001ebc:	d6dfe0ef          	jal	80000c28 <acquire>
  np->parent = p;
    80001ec0:	055a3023          	sd	s5,64(s4)
  release(&wait_lock);
    80001ec4:	0000e517          	auipc	a0,0xe
    80001ec8:	b0c50513          	addi	a0,a0,-1268 # 8000f9d0 <wait_lock>
    80001ecc:	df1fe0ef          	jal	80000cbc <release>
  acquire(&np->lock);
    80001ed0:	8552                	mv	a0,s4
    80001ed2:	d57fe0ef          	jal	80000c28 <acquire>
  np->state = RUNNABLE;
    80001ed6:	478d                	li	a5,3
    80001ed8:	02fa2223          	sw	a5,36(s4)
  release(&np->lock);
    80001edc:	8552                	mv	a0,s4
    80001ede:	ddffe0ef          	jal	80000cbc <release>
  return pid;
    80001ee2:	7902                	ld	s2,32(sp)
    80001ee4:	69e2                	ld	s3,24(sp)
    80001ee6:	6a42                	ld	s4,16(sp)
}
    80001ee8:	8526                	mv	a0,s1
    80001eea:	70e2                	ld	ra,56(sp)
    80001eec:	7442                	ld	s0,48(sp)
    80001eee:	74a2                	ld	s1,40(sp)
    80001ef0:	6aa2                	ld	s5,8(sp)
    80001ef2:	6121                	addi	sp,sp,64
    80001ef4:	8082                	ret
    return -1;
    80001ef6:	54fd                	li	s1,-1
    80001ef8:	bfc5                	j	80001ee8 <kfork+0xfc>

0000000080001efa <scheduler>:
{
    80001efa:	711d                	addi	sp,sp,-96
    80001efc:	ec86                	sd	ra,88(sp)
    80001efe:	e8a2                	sd	s0,80(sp)
    80001f00:	e4a6                	sd	s1,72(sp)
    80001f02:	e0ca                	sd	s2,64(sp)
    80001f04:	fc4e                	sd	s3,56(sp)
    80001f06:	f852                	sd	s4,48(sp)
    80001f08:	f456                	sd	s5,40(sp)
    80001f0a:	f05a                	sd	s6,32(sp)
    80001f0c:	ec5e                	sd	s7,24(sp)
    80001f0e:	e862                	sd	s8,16(sp)
    80001f10:	e466                	sd	s9,8(sp)
    80001f12:	1080                	addi	s0,sp,96
    80001f14:	8792                	mv	a5,tp
  int id = r_tp();
    80001f16:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001f18:	00779b93          	slli	s7,a5,0x7
    80001f1c:	0000e717          	auipc	a4,0xe
    80001f20:	a9c70713          	addi	a4,a4,-1380 # 8000f9b8 <pid_lock>
    80001f24:	975e                	add	a4,a4,s7
    80001f26:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001f2a:	0000e717          	auipc	a4,0xe
    80001f2e:	ac670713          	addi	a4,a4,-1338 # 8000f9f0 <cpus+0x8>
    80001f32:	9bba                	add	s7,s7,a4
      if(p->state == RUNNABLE) {
    80001f34:	4a0d                	li	s4,3
        p->state = RUNNING;
    80001f36:	4c11                	li	s8,4
        c->proc = p;
    80001f38:	079e                	slli	a5,a5,0x7
    80001f3a:	0000eb17          	auipc	s6,0xe
    80001f3e:	a7eb0b13          	addi	s6,s6,-1410 # 8000f9b8 <pid_lock>
    80001f42:	9b3e                	add	s6,s6,a5
    80001f44:	a849                	j	80001fd6 <scheduler+0xdc>
          passTotal = 0;
    80001f46:	000aa023          	sw	zero,0(s5)
        c->proc = p;
    80001f4a:	032b3823          	sd	s2,48(s6)
        swtch(&c->context, &p->context);
    80001f4e:	068c8593          	addi	a1,s9,104
    80001f52:	855e                	mv	a0,s7
    80001f54:	7ac000ef          	jal	80002700 <swtch>
        c->proc = 0;
    80001f58:	020b3823          	sd	zero,48(s6)
        found = 1;
    80001f5c:	4485                	li	s1,1
      release(&p->lock);
    80001f5e:	854a                	mv	a0,s2
    80001f60:	d5dfe0ef          	jal	80000cbc <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001f64:	17090913          	addi	s2,s2,368
    80001f68:	07390463          	beq	s2,s3,80001fd0 <scheduler+0xd6>
      acquire(&p->lock);
    80001f6c:	854a                	mv	a0,s2
    80001f6e:	cbbfe0ef          	jal	80000c28 <acquire>
      if(p->state == RUNNABLE) {
    80001f72:	02492783          	lw	a5,36(s2)
    80001f76:	ff4794e3          	bne	a5,s4,80001f5e <scheduler+0x64>
    80001f7a:	8cca                	mv	s9,s2
        p->state = RUNNING;
    80001f7c:	03892223          	sw	s8,36(s2)
        p->runtime++;
    80001f80:	01892783          	lw	a5,24(s2)
    80001f84:	2785                	addiw	a5,a5,1
    80001f86:	00f92c23          	sw	a5,24(s2)
        p->pass += p->stride;
    80001f8a:	01c92703          	lw	a4,28(s2)
    80001f8e:	02092783          	lw	a5,32(s2)
    80001f92:	9fb9                	addw	a5,a5,a4
    80001f94:	02f92023          	sw	a5,32(s2)
        passTotal += p->stride;
    80001f98:	000aa783          	lw	a5,0(s5)
    80001f9c:	9fb9                	addw	a5,a5,a4
    80001f9e:	00faa023          	sw	a5,0(s5)
        if(passTotal >= MaxPassTotal){
    80001fa2:	000f4737          	lui	a4,0xf4
    80001fa6:	23f70713          	addi	a4,a4,575 # f423f <_entry-0x7ff0bdc1>
    80001faa:	faf750e3          	bge	a4,a5,80001f4a <scheduler+0x50>
          for (struct proc *q = proc; q < &proc[NPROC]; q++)
    80001fae:	0000e497          	auipc	s1,0xe
    80001fb2:	e3a48493          	addi	s1,s1,-454 # 8000fde8 <proc>
            acquire(&q->lock);
    80001fb6:	8526                	mv	a0,s1
    80001fb8:	c71fe0ef          	jal	80000c28 <acquire>
            q->pass = 0;
    80001fbc:	0204a023          	sw	zero,32(s1)
            release(&q->lock);
    80001fc0:	8526                	mv	a0,s1
    80001fc2:	cfbfe0ef          	jal	80000cbc <release>
          for (struct proc *q = proc; q < &proc[NPROC]; q++)
    80001fc6:	17048493          	addi	s1,s1,368
    80001fca:	ff3496e3          	bne	s1,s3,80001fb6 <scheduler+0xbc>
    80001fce:	bfa5                	j	80001f46 <scheduler+0x4c>
    if(found == 0) {
    80001fd0:	e099                	bnez	s1,80001fd6 <scheduler+0xdc>
      asm volatile("wfi");
    80001fd2:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001fd6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001fda:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001fde:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001fe2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001fe6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001fe8:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001fec:	4481                	li	s1,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001fee:	0000e917          	auipc	s2,0xe
    80001ff2:	dfa90913          	addi	s2,s2,-518 # 8000fde8 <proc>
        passTotal += p->stride;
    80001ff6:	00006a97          	auipc	s5,0x6
    80001ffa:	8aaa8a93          	addi	s5,s5,-1878 # 800078a0 <passTotal>
          for (struct proc *q = proc; q < &proc[NPROC]; q++)
    80001ffe:	00014997          	auipc	s3,0x14
    80002002:	9ea98993          	addi	s3,s3,-1558 # 800159e8 <tickslock>
    80002006:	b79d                	j	80001f6c <scheduler+0x72>

0000000080002008 <sched>:
{
    80002008:	7179                	addi	sp,sp,-48
    8000200a:	f406                	sd	ra,40(sp)
    8000200c:	f022                	sd	s0,32(sp)
    8000200e:	ec26                	sd	s1,24(sp)
    80002010:	e84a                	sd	s2,16(sp)
    80002012:	e44e                	sd	s3,8(sp)
    80002014:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002016:	a73ff0ef          	jal	80001a88 <myproc>
    8000201a:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000201c:	b9dfe0ef          	jal	80000bb8 <holding>
    80002020:	c935                	beqz	a0,80002094 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002022:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80002024:	2781                	sext.w	a5,a5
    80002026:	079e                	slli	a5,a5,0x7
    80002028:	0000e717          	auipc	a4,0xe
    8000202c:	99070713          	addi	a4,a4,-1648 # 8000f9b8 <pid_lock>
    80002030:	97ba                	add	a5,a5,a4
    80002032:	0a87a703          	lw	a4,168(a5)
    80002036:	4785                	li	a5,1
    80002038:	06f71463          	bne	a4,a5,800020a0 <sched+0x98>
  if(p->state == RUNNING)
    8000203c:	50d8                	lw	a4,36(s1)
    8000203e:	4791                	li	a5,4
    80002040:	06f70663          	beq	a4,a5,800020ac <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002044:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002048:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000204a:	e7bd                	bnez	a5,800020b8 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000204c:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000204e:	0000e917          	auipc	s2,0xe
    80002052:	96a90913          	addi	s2,s2,-1686 # 8000f9b8 <pid_lock>
    80002056:	2781                	sext.w	a5,a5
    80002058:	079e                	slli	a5,a5,0x7
    8000205a:	97ca                	add	a5,a5,s2
    8000205c:	0ac7a983          	lw	s3,172(a5)
    80002060:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80002062:	2781                	sext.w	a5,a5
    80002064:	079e                	slli	a5,a5,0x7
    80002066:	07a1                	addi	a5,a5,8
    80002068:	0000e597          	auipc	a1,0xe
    8000206c:	98058593          	addi	a1,a1,-1664 # 8000f9e8 <cpus>
    80002070:	95be                	add	a1,a1,a5
    80002072:	06848513          	addi	a0,s1,104
    80002076:	68a000ef          	jal	80002700 <swtch>
    8000207a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    8000207c:	2781                	sext.w	a5,a5
    8000207e:	079e                	slli	a5,a5,0x7
    80002080:	993e                	add	s2,s2,a5
    80002082:	0b392623          	sw	s3,172(s2)
}
    80002086:	70a2                	ld	ra,40(sp)
    80002088:	7402                	ld	s0,32(sp)
    8000208a:	64e2                	ld	s1,24(sp)
    8000208c:	6942                	ld	s2,16(sp)
    8000208e:	69a2                	ld	s3,8(sp)
    80002090:	6145                	addi	sp,sp,48
    80002092:	8082                	ret
    panic("sched p->lock");
    80002094:	00005517          	auipc	a0,0x5
    80002098:	13450513          	addi	a0,a0,308 # 800071c8 <etext+0x1c8>
    8000209c:	f88fe0ef          	jal	80000824 <panic>
    panic("sched locks");
    800020a0:	00005517          	auipc	a0,0x5
    800020a4:	13850513          	addi	a0,a0,312 # 800071d8 <etext+0x1d8>
    800020a8:	f7cfe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    800020ac:	00005517          	auipc	a0,0x5
    800020b0:	13c50513          	addi	a0,a0,316 # 800071e8 <etext+0x1e8>
    800020b4:	f70fe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    800020b8:	00005517          	auipc	a0,0x5
    800020bc:	14050513          	addi	a0,a0,320 # 800071f8 <etext+0x1f8>
    800020c0:	f64fe0ef          	jal	80000824 <panic>

00000000800020c4 <yield>:
{
    800020c4:	1101                	addi	sp,sp,-32
    800020c6:	ec06                	sd	ra,24(sp)
    800020c8:	e822                	sd	s0,16(sp)
    800020ca:	e426                	sd	s1,8(sp)
    800020cc:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800020ce:	9bbff0ef          	jal	80001a88 <myproc>
    800020d2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020d4:	b55fe0ef          	jal	80000c28 <acquire>
  p->state = RUNNABLE;
    800020d8:	478d                	li	a5,3
    800020da:	d0dc                	sw	a5,36(s1)
  sched();
    800020dc:	f2dff0ef          	jal	80002008 <sched>
  release(&p->lock);
    800020e0:	8526                	mv	a0,s1
    800020e2:	bdbfe0ef          	jal	80000cbc <release>
}
    800020e6:	60e2                	ld	ra,24(sp)
    800020e8:	6442                	ld	s0,16(sp)
    800020ea:	64a2                	ld	s1,8(sp)
    800020ec:	6105                	addi	sp,sp,32
    800020ee:	8082                	ret

00000000800020f0 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800020f0:	7179                	addi	sp,sp,-48
    800020f2:	f406                	sd	ra,40(sp)
    800020f4:	f022                	sd	s0,32(sp)
    800020f6:	ec26                	sd	s1,24(sp)
    800020f8:	e84a                	sd	s2,16(sp)
    800020fa:	e44e                	sd	s3,8(sp)
    800020fc:	1800                	addi	s0,sp,48
    800020fe:	89aa                	mv	s3,a0
    80002100:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002102:	987ff0ef          	jal	80001a88 <myproc>
    80002106:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002108:	b21fe0ef          	jal	80000c28 <acquire>
  release(lk);
    8000210c:	854a                	mv	a0,s2
    8000210e:	baffe0ef          	jal	80000cbc <release>

  // Go to sleep.
  p->chan = chan;
    80002112:	0334b423          	sd	s3,40(s1)
  p->state = SLEEPING;
    80002116:	4789                	li	a5,2
    80002118:	d0dc                	sw	a5,36(s1)

  sched();
    8000211a:	eefff0ef          	jal	80002008 <sched>

  // Tidy up.
  p->chan = 0;
    8000211e:	0204b423          	sd	zero,40(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002122:	8526                	mv	a0,s1
    80002124:	b99fe0ef          	jal	80000cbc <release>
  acquire(lk);
    80002128:	854a                	mv	a0,s2
    8000212a:	afffe0ef          	jal	80000c28 <acquire>
}
    8000212e:	70a2                	ld	ra,40(sp)
    80002130:	7402                	ld	s0,32(sp)
    80002132:	64e2                	ld	s1,24(sp)
    80002134:	6942                	ld	s2,16(sp)
    80002136:	69a2                	ld	s3,8(sp)
    80002138:	6145                	addi	sp,sp,48
    8000213a:	8082                	ret

000000008000213c <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    8000213c:	7139                	addi	sp,sp,-64
    8000213e:	fc06                	sd	ra,56(sp)
    80002140:	f822                	sd	s0,48(sp)
    80002142:	f426                	sd	s1,40(sp)
    80002144:	f04a                	sd	s2,32(sp)
    80002146:	ec4e                	sd	s3,24(sp)
    80002148:	e852                	sd	s4,16(sp)
    8000214a:	e456                	sd	s5,8(sp)
    8000214c:	0080                	addi	s0,sp,64
    8000214e:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80002150:	0000e497          	auipc	s1,0xe
    80002154:	c9848493          	addi	s1,s1,-872 # 8000fde8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002158:	4989                	li	s3,2
        p->state = RUNNABLE;
    8000215a:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000215c:	00014917          	auipc	s2,0x14
    80002160:	88c90913          	addi	s2,s2,-1908 # 800159e8 <tickslock>
    80002164:	a801                	j	80002174 <wakeup+0x38>
      }
      release(&p->lock);
    80002166:	8526                	mv	a0,s1
    80002168:	b55fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000216c:	17048493          	addi	s1,s1,368
    80002170:	03248263          	beq	s1,s2,80002194 <wakeup+0x58>
    if(p != myproc()){
    80002174:	915ff0ef          	jal	80001a88 <myproc>
    80002178:	fe950ae3          	beq	a0,s1,8000216c <wakeup+0x30>
      acquire(&p->lock);
    8000217c:	8526                	mv	a0,s1
    8000217e:	aabfe0ef          	jal	80000c28 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80002182:	50dc                	lw	a5,36(s1)
    80002184:	ff3791e3          	bne	a5,s3,80002166 <wakeup+0x2a>
    80002188:	749c                	ld	a5,40(s1)
    8000218a:	fd479ee3          	bne	a5,s4,80002166 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000218e:	0354a223          	sw	s5,36(s1)
    80002192:	bfd1                	j	80002166 <wakeup+0x2a>
    }
  }
}
    80002194:	70e2                	ld	ra,56(sp)
    80002196:	7442                	ld	s0,48(sp)
    80002198:	74a2                	ld	s1,40(sp)
    8000219a:	7902                	ld	s2,32(sp)
    8000219c:	69e2                	ld	s3,24(sp)
    8000219e:	6a42                	ld	s4,16(sp)
    800021a0:	6aa2                	ld	s5,8(sp)
    800021a2:	6121                	addi	sp,sp,64
    800021a4:	8082                	ret

00000000800021a6 <reparent>:
{
    800021a6:	7179                	addi	sp,sp,-48
    800021a8:	f406                	sd	ra,40(sp)
    800021aa:	f022                	sd	s0,32(sp)
    800021ac:	ec26                	sd	s1,24(sp)
    800021ae:	e84a                	sd	s2,16(sp)
    800021b0:	e44e                	sd	s3,8(sp)
    800021b2:	e052                	sd	s4,0(sp)
    800021b4:	1800                	addi	s0,sp,48
    800021b6:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800021b8:	0000e497          	auipc	s1,0xe
    800021bc:	c3048493          	addi	s1,s1,-976 # 8000fde8 <proc>
      pp->parent = initproc;
    800021c0:	00005a17          	auipc	s4,0x5
    800021c4:	6e8a0a13          	addi	s4,s4,1768 # 800078a8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800021c8:	00014997          	auipc	s3,0x14
    800021cc:	82098993          	addi	s3,s3,-2016 # 800159e8 <tickslock>
    800021d0:	a029                	j	800021da <reparent+0x34>
    800021d2:	17048493          	addi	s1,s1,368
    800021d6:	01348b63          	beq	s1,s3,800021ec <reparent+0x46>
    if(pp->parent == p){
    800021da:	60bc                	ld	a5,64(s1)
    800021dc:	ff279be3          	bne	a5,s2,800021d2 <reparent+0x2c>
      pp->parent = initproc;
    800021e0:	000a3503          	ld	a0,0(s4)
    800021e4:	e0a8                	sd	a0,64(s1)
      wakeup(initproc);
    800021e6:	f57ff0ef          	jal	8000213c <wakeup>
    800021ea:	b7e5                	j	800021d2 <reparent+0x2c>
}
    800021ec:	70a2                	ld	ra,40(sp)
    800021ee:	7402                	ld	s0,32(sp)
    800021f0:	64e2                	ld	s1,24(sp)
    800021f2:	6942                	ld	s2,16(sp)
    800021f4:	69a2                	ld	s3,8(sp)
    800021f6:	6a02                	ld	s4,0(sp)
    800021f8:	6145                	addi	sp,sp,48
    800021fa:	8082                	ret

00000000800021fc <kexit>:
{
    800021fc:	7179                	addi	sp,sp,-48
    800021fe:	f406                	sd	ra,40(sp)
    80002200:	f022                	sd	s0,32(sp)
    80002202:	ec26                	sd	s1,24(sp)
    80002204:	e84a                	sd	s2,16(sp)
    80002206:	e44e                	sd	s3,8(sp)
    80002208:	e052                	sd	s4,0(sp)
    8000220a:	1800                	addi	s0,sp,48
    8000220c:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000220e:	87bff0ef          	jal	80001a88 <myproc>
    80002212:	89aa                	mv	s3,a0
  if(p == initproc)
    80002214:	00005797          	auipc	a5,0x5
    80002218:	6947b783          	ld	a5,1684(a5) # 800078a8 <initproc>
    8000221c:	0d850493          	addi	s1,a0,216
    80002220:	15850913          	addi	s2,a0,344
    80002224:	00a79b63          	bne	a5,a0,8000223a <kexit+0x3e>
    panic("init exiting");
    80002228:	00005517          	auipc	a0,0x5
    8000222c:	fe850513          	addi	a0,a0,-24 # 80007210 <etext+0x210>
    80002230:	df4fe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002234:	04a1                	addi	s1,s1,8
    80002236:	01248963          	beq	s1,s2,80002248 <kexit+0x4c>
    if(p->ofile[fd]){
    8000223a:	6088                	ld	a0,0(s1)
    8000223c:	dd65                	beqz	a0,80002234 <kexit+0x38>
      fileclose(f);
    8000223e:	1ec020ef          	jal	8000442a <fileclose>
      p->ofile[fd] = 0;
    80002242:	0004b023          	sd	zero,0(s1)
    80002246:	b7fd                	j	80002234 <kexit+0x38>
  begin_op();
    80002248:	5bf010ef          	jal	80004006 <begin_op>
  iput(p->cwd);
    8000224c:	1589b503          	ld	a0,344(s3)
    80002250:	52c010ef          	jal	8000377c <iput>
  end_op();
    80002254:	623010ef          	jal	80004076 <end_op>
  p->cwd = 0;
    80002258:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    8000225c:	0000d517          	auipc	a0,0xd
    80002260:	77450513          	addi	a0,a0,1908 # 8000f9d0 <wait_lock>
    80002264:	9c5fe0ef          	jal	80000c28 <acquire>
  reparent(p);
    80002268:	854e                	mv	a0,s3
    8000226a:	f3dff0ef          	jal	800021a6 <reparent>
  wakeup(p->parent);
    8000226e:	0409b503          	ld	a0,64(s3)
    80002272:	ecbff0ef          	jal	8000213c <wakeup>
  acquire(&p->lock);
    80002276:	854e                	mv	a0,s3
    80002278:	9b1fe0ef          	jal	80000c28 <acquire>
  p->xstate = status;
    8000227c:	0349aa23          	sw	s4,52(s3)
  p->state = ZOMBIE;
    80002280:	4795                	li	a5,5
    80002282:	02f9a223          	sw	a5,36(s3)
  release(&wait_lock);
    80002286:	0000d517          	auipc	a0,0xd
    8000228a:	74a50513          	addi	a0,a0,1866 # 8000f9d0 <wait_lock>
    8000228e:	a2ffe0ef          	jal	80000cbc <release>
  sched();
    80002292:	d77ff0ef          	jal	80002008 <sched>
  panic("zombie exit");
    80002296:	00005517          	auipc	a0,0x5
    8000229a:	f8a50513          	addi	a0,a0,-118 # 80007220 <etext+0x220>
    8000229e:	d86fe0ef          	jal	80000824 <panic>

00000000800022a2 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800022a2:	7179                	addi	sp,sp,-48
    800022a4:	f406                	sd	ra,40(sp)
    800022a6:	f022                	sd	s0,32(sp)
    800022a8:	ec26                	sd	s1,24(sp)
    800022aa:	e84a                	sd	s2,16(sp)
    800022ac:	e44e                	sd	s3,8(sp)
    800022ae:	1800                	addi	s0,sp,48
    800022b0:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800022b2:	0000e497          	auipc	s1,0xe
    800022b6:	b3648493          	addi	s1,s1,-1226 # 8000fde8 <proc>
    800022ba:	00013997          	auipc	s3,0x13
    800022be:	72e98993          	addi	s3,s3,1838 # 800159e8 <tickslock>
    acquire(&p->lock);
    800022c2:	8526                	mv	a0,s1
    800022c4:	965fe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    800022c8:	5c9c                	lw	a5,56(s1)
    800022ca:	01278b63          	beq	a5,s2,800022e0 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800022ce:	8526                	mv	a0,s1
    800022d0:	9edfe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800022d4:	17048493          	addi	s1,s1,368
    800022d8:	ff3495e3          	bne	s1,s3,800022c2 <kkill+0x20>
  }
  return -1;
    800022dc:	557d                	li	a0,-1
    800022de:	a819                	j	800022f4 <kkill+0x52>
      p->killed = 1;
    800022e0:	4785                	li	a5,1
    800022e2:	d89c                	sw	a5,48(s1)
      if(p->state == SLEEPING){
    800022e4:	50d8                	lw	a4,36(s1)
    800022e6:	4789                	li	a5,2
    800022e8:	00f70d63          	beq	a4,a5,80002302 <kkill+0x60>
      release(&p->lock);
    800022ec:	8526                	mv	a0,s1
    800022ee:	9cffe0ef          	jal	80000cbc <release>
      return 0;
    800022f2:	4501                	li	a0,0
}
    800022f4:	70a2                	ld	ra,40(sp)
    800022f6:	7402                	ld	s0,32(sp)
    800022f8:	64e2                	ld	s1,24(sp)
    800022fa:	6942                	ld	s2,16(sp)
    800022fc:	69a2                	ld	s3,8(sp)
    800022fe:	6145                	addi	sp,sp,48
    80002300:	8082                	ret
        p->state = RUNNABLE;
    80002302:	478d                	li	a5,3
    80002304:	d0dc                	sw	a5,36(s1)
    80002306:	b7dd                	j	800022ec <kkill+0x4a>

0000000080002308 <setkilled>:

void
setkilled(struct proc *p)
{
    80002308:	1101                	addi	sp,sp,-32
    8000230a:	ec06                	sd	ra,24(sp)
    8000230c:	e822                	sd	s0,16(sp)
    8000230e:	e426                	sd	s1,8(sp)
    80002310:	1000                	addi	s0,sp,32
    80002312:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002314:	915fe0ef          	jal	80000c28 <acquire>
  p->killed = 1;
    80002318:	4785                	li	a5,1
    8000231a:	d89c                	sw	a5,48(s1)
  release(&p->lock);
    8000231c:	8526                	mv	a0,s1
    8000231e:	99ffe0ef          	jal	80000cbc <release>
}
    80002322:	60e2                	ld	ra,24(sp)
    80002324:	6442                	ld	s0,16(sp)
    80002326:	64a2                	ld	s1,8(sp)
    80002328:	6105                	addi	sp,sp,32
    8000232a:	8082                	ret

000000008000232c <killed>:


int
killed(struct proc *p)
{
    8000232c:	1101                	addi	sp,sp,-32
    8000232e:	ec06                	sd	ra,24(sp)
    80002330:	e822                	sd	s0,16(sp)
    80002332:	e426                	sd	s1,8(sp)
    80002334:	e04a                	sd	s2,0(sp)
    80002336:	1000                	addi	s0,sp,32
    80002338:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000233a:	8effe0ef          	jal	80000c28 <acquire>
  k = p->killed;
    8000233e:	589c                	lw	a5,48(s1)
    80002340:	893e                	mv	s2,a5
  release(&p->lock);
    80002342:	8526                	mv	a0,s1
    80002344:	979fe0ef          	jal	80000cbc <release>
  return k;
}
    80002348:	854a                	mv	a0,s2
    8000234a:	60e2                	ld	ra,24(sp)
    8000234c:	6442                	ld	s0,16(sp)
    8000234e:	64a2                	ld	s1,8(sp)
    80002350:	6902                	ld	s2,0(sp)
    80002352:	6105                	addi	sp,sp,32
    80002354:	8082                	ret

0000000080002356 <kwait>:
{
    80002356:	715d                	addi	sp,sp,-80
    80002358:	e486                	sd	ra,72(sp)
    8000235a:	e0a2                	sd	s0,64(sp)
    8000235c:	fc26                	sd	s1,56(sp)
    8000235e:	f84a                	sd	s2,48(sp)
    80002360:	f44e                	sd	s3,40(sp)
    80002362:	f052                	sd	s4,32(sp)
    80002364:	ec56                	sd	s5,24(sp)
    80002366:	e85a                	sd	s6,16(sp)
    80002368:	e45e                	sd	s7,8(sp)
    8000236a:	0880                	addi	s0,sp,80
    8000236c:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000236e:	f1aff0ef          	jal	80001a88 <myproc>
    80002372:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002374:	0000d517          	auipc	a0,0xd
    80002378:	65c50513          	addi	a0,a0,1628 # 8000f9d0 <wait_lock>
    8000237c:	8adfe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    80002380:	4a15                	li	s4,5
        havekids = 1;
    80002382:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002384:	00013997          	auipc	s3,0x13
    80002388:	66498993          	addi	s3,s3,1636 # 800159e8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000238c:	0000db17          	auipc	s6,0xd
    80002390:	644b0b13          	addi	s6,s6,1604 # 8000f9d0 <wait_lock>
    80002394:	a869                	j	8000242e <kwait+0xd8>
          pid = pp->pid;
    80002396:	0384a983          	lw	s3,56(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000239a:	000b8c63          	beqz	s7,800023b2 <kwait+0x5c>
    8000239e:	4691                	li	a3,4
    800023a0:	03448613          	addi	a2,s1,52
    800023a4:	85de                	mv	a1,s7
    800023a6:	05893503          	ld	a0,88(s2)
    800023aa:	b44ff0ef          	jal	800016ee <copyout>
    800023ae:	02054a63          	bltz	a0,800023e2 <kwait+0x8c>
          freeproc(pp);
    800023b2:	8526                	mv	a0,s1
    800023b4:	8a9ff0ef          	jal	80001c5c <freeproc>
          release(&pp->lock);
    800023b8:	8526                	mv	a0,s1
    800023ba:	903fe0ef          	jal	80000cbc <release>
          release(&wait_lock);
    800023be:	0000d517          	auipc	a0,0xd
    800023c2:	61250513          	addi	a0,a0,1554 # 8000f9d0 <wait_lock>
    800023c6:	8f7fe0ef          	jal	80000cbc <release>
}
    800023ca:	854e                	mv	a0,s3
    800023cc:	60a6                	ld	ra,72(sp)
    800023ce:	6406                	ld	s0,64(sp)
    800023d0:	74e2                	ld	s1,56(sp)
    800023d2:	7942                	ld	s2,48(sp)
    800023d4:	79a2                	ld	s3,40(sp)
    800023d6:	7a02                	ld	s4,32(sp)
    800023d8:	6ae2                	ld	s5,24(sp)
    800023da:	6b42                	ld	s6,16(sp)
    800023dc:	6ba2                	ld	s7,8(sp)
    800023de:	6161                	addi	sp,sp,80
    800023e0:	8082                	ret
            release(&pp->lock);
    800023e2:	8526                	mv	a0,s1
    800023e4:	8d9fe0ef          	jal	80000cbc <release>
            release(&wait_lock);
    800023e8:	0000d517          	auipc	a0,0xd
    800023ec:	5e850513          	addi	a0,a0,1512 # 8000f9d0 <wait_lock>
    800023f0:	8cdfe0ef          	jal	80000cbc <release>
            return -1;
    800023f4:	59fd                	li	s3,-1
    800023f6:	bfd1                	j	800023ca <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800023f8:	17048493          	addi	s1,s1,368
    800023fc:	03348063          	beq	s1,s3,8000241c <kwait+0xc6>
      if(pp->parent == p){
    80002400:	60bc                	ld	a5,64(s1)
    80002402:	ff279be3          	bne	a5,s2,800023f8 <kwait+0xa2>
        acquire(&pp->lock);
    80002406:	8526                	mv	a0,s1
    80002408:	821fe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    8000240c:	50dc                	lw	a5,36(s1)
    8000240e:	f94784e3          	beq	a5,s4,80002396 <kwait+0x40>
        release(&pp->lock);
    80002412:	8526                	mv	a0,s1
    80002414:	8a9fe0ef          	jal	80000cbc <release>
        havekids = 1;
    80002418:	8756                	mv	a4,s5
    8000241a:	bff9                	j	800023f8 <kwait+0xa2>
    if(!havekids || killed(p)){
    8000241c:	cf19                	beqz	a4,8000243a <kwait+0xe4>
    8000241e:	854a                	mv	a0,s2
    80002420:	f0dff0ef          	jal	8000232c <killed>
    80002424:	e919                	bnez	a0,8000243a <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002426:	85da                	mv	a1,s6
    80002428:	854a                	mv	a0,s2
    8000242a:	cc7ff0ef          	jal	800020f0 <sleep>
    havekids = 0;
    8000242e:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002430:	0000e497          	auipc	s1,0xe
    80002434:	9b848493          	addi	s1,s1,-1608 # 8000fde8 <proc>
    80002438:	b7e1                	j	80002400 <kwait+0xaa>
      release(&wait_lock);
    8000243a:	0000d517          	auipc	a0,0xd
    8000243e:	59650513          	addi	a0,a0,1430 # 8000f9d0 <wait_lock>
    80002442:	87bfe0ef          	jal	80000cbc <release>
      return -1;
    80002446:	59fd                	li	s3,-1
    80002448:	b749                	j	800023ca <kwait+0x74>

000000008000244a <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000244a:	7179                	addi	sp,sp,-48
    8000244c:	f406                	sd	ra,40(sp)
    8000244e:	f022                	sd	s0,32(sp)
    80002450:	ec26                	sd	s1,24(sp)
    80002452:	e84a                	sd	s2,16(sp)
    80002454:	e44e                	sd	s3,8(sp)
    80002456:	e052                	sd	s4,0(sp)
    80002458:	1800                	addi	s0,sp,48
    8000245a:	84aa                	mv	s1,a0
    8000245c:	8a2e                	mv	s4,a1
    8000245e:	89b2                	mv	s3,a2
    80002460:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002462:	e26ff0ef          	jal	80001a88 <myproc>
  if(user_dst){
    80002466:	cc99                	beqz	s1,80002484 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002468:	86ca                	mv	a3,s2
    8000246a:	864e                	mv	a2,s3
    8000246c:	85d2                	mv	a1,s4
    8000246e:	6d28                	ld	a0,88(a0)
    80002470:	a7eff0ef          	jal	800016ee <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002474:	70a2                	ld	ra,40(sp)
    80002476:	7402                	ld	s0,32(sp)
    80002478:	64e2                	ld	s1,24(sp)
    8000247a:	6942                	ld	s2,16(sp)
    8000247c:	69a2                	ld	s3,8(sp)
    8000247e:	6a02                	ld	s4,0(sp)
    80002480:	6145                	addi	sp,sp,48
    80002482:	8082                	ret
    memmove((char *)dst, src, len);
    80002484:	0009061b          	sext.w	a2,s2
    80002488:	85ce                	mv	a1,s3
    8000248a:	8552                	mv	a0,s4
    8000248c:	8cdfe0ef          	jal	80000d58 <memmove>
    return 0;
    80002490:	8526                	mv	a0,s1
    80002492:	b7cd                	j	80002474 <either_copyout+0x2a>

0000000080002494 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002494:	7179                	addi	sp,sp,-48
    80002496:	f406                	sd	ra,40(sp)
    80002498:	f022                	sd	s0,32(sp)
    8000249a:	ec26                	sd	s1,24(sp)
    8000249c:	e84a                	sd	s2,16(sp)
    8000249e:	e44e                	sd	s3,8(sp)
    800024a0:	e052                	sd	s4,0(sp)
    800024a2:	1800                	addi	s0,sp,48
    800024a4:	8a2a                	mv	s4,a0
    800024a6:	84ae                	mv	s1,a1
    800024a8:	89b2                	mv	s3,a2
    800024aa:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800024ac:	ddcff0ef          	jal	80001a88 <myproc>
  if(user_src){
    800024b0:	cc99                	beqz	s1,800024ce <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800024b2:	86ca                	mv	a3,s2
    800024b4:	864e                	mv	a2,s3
    800024b6:	85d2                	mv	a1,s4
    800024b8:	6d28                	ld	a0,88(a0)
    800024ba:	af2ff0ef          	jal	800017ac <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800024be:	70a2                	ld	ra,40(sp)
    800024c0:	7402                	ld	s0,32(sp)
    800024c2:	64e2                	ld	s1,24(sp)
    800024c4:	6942                	ld	s2,16(sp)
    800024c6:	69a2                	ld	s3,8(sp)
    800024c8:	6a02                	ld	s4,0(sp)
    800024ca:	6145                	addi	sp,sp,48
    800024cc:	8082                	ret
    memmove(dst, (char*)src, len);
    800024ce:	0009061b          	sext.w	a2,s2
    800024d2:	85ce                	mv	a1,s3
    800024d4:	8552                	mv	a0,s4
    800024d6:	883fe0ef          	jal	80000d58 <memmove>
    return 0;
    800024da:	8526                	mv	a0,s1
    800024dc:	b7cd                	j	800024be <either_copyin+0x2a>

00000000800024de <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800024de:	715d                	addi	sp,sp,-80
    800024e0:	e486                	sd	ra,72(sp)
    800024e2:	e0a2                	sd	s0,64(sp)
    800024e4:	fc26                	sd	s1,56(sp)
    800024e6:	f84a                	sd	s2,48(sp)
    800024e8:	f44e                	sd	s3,40(sp)
    800024ea:	f052                	sd	s4,32(sp)
    800024ec:	ec56                	sd	s5,24(sp)
    800024ee:	e85a                	sd	s6,16(sp)
    800024f0:	e45e                	sd	s7,8(sp)
    800024f2:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800024f4:	00005517          	auipc	a0,0x5
    800024f8:	b8450513          	addi	a0,a0,-1148 # 80007078 <etext+0x78>
    800024fc:	ffffd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002500:	0000e497          	auipc	s1,0xe
    80002504:	a4848493          	addi	s1,s1,-1464 # 8000ff48 <proc+0x160>
    80002508:	00013917          	auipc	s2,0x13
    8000250c:	64090913          	addi	s2,s2,1600 # 80015b48 <bcache+0x148>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002510:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002512:	00005997          	auipc	s3,0x5
    80002516:	d1e98993          	addi	s3,s3,-738 # 80007230 <etext+0x230>
    printf("%d %s %s", p->pid, state, p->name);
    8000251a:	00005a97          	auipc	s5,0x5
    8000251e:	d1ea8a93          	addi	s5,s5,-738 # 80007238 <etext+0x238>
    printf("\n");
    80002522:	00005a17          	auipc	s4,0x5
    80002526:	b56a0a13          	addi	s4,s4,-1194 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000252a:	00005b97          	auipc	s7,0x5
    8000252e:	22eb8b93          	addi	s7,s7,558 # 80007758 <states.0>
    80002532:	a829                	j	8000254c <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002534:	ed86a583          	lw	a1,-296(a3)
    80002538:	8556                	mv	a0,s5
    8000253a:	fc1fd0ef          	jal	800004fa <printf>
    printf("\n");
    8000253e:	8552                	mv	a0,s4
    80002540:	fbbfd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002544:	17048493          	addi	s1,s1,368
    80002548:	03248263          	beq	s1,s2,8000256c <procdump+0x8e>
    if(p->state == UNUSED)
    8000254c:	86a6                	mv	a3,s1
    8000254e:	ec44a783          	lw	a5,-316(s1)
    80002552:	dbed                	beqz	a5,80002544 <procdump+0x66>
      state = "???";
    80002554:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002556:	fcfb6fe3          	bltu	s6,a5,80002534 <procdump+0x56>
    8000255a:	02079713          	slli	a4,a5,0x20
    8000255e:	01d75793          	srli	a5,a4,0x1d
    80002562:	97de                	add	a5,a5,s7
    80002564:	6390                	ld	a2,0(a5)
    80002566:	f679                	bnez	a2,80002534 <procdump+0x56>
      state = "???";
    80002568:	864e                	mv	a2,s3
    8000256a:	b7e9                	j	80002534 <procdump+0x56>
  }
}
    8000256c:	60a6                	ld	ra,72(sp)
    8000256e:	6406                	ld	s0,64(sp)
    80002570:	74e2                	ld	s1,56(sp)
    80002572:	7942                	ld	s2,48(sp)
    80002574:	79a2                	ld	s3,40(sp)
    80002576:	7a02                	ld	s4,32(sp)
    80002578:	6ae2                	ld	s5,24(sp)
    8000257a:	6b42                	ld	s6,16(sp)
    8000257c:	6ba2                	ld	s7,8(sp)
    8000257e:	6161                	addi	sp,sp,80
    80002580:	8082                	ret

0000000080002582 <getfilenum>:

int getfilenum(int pid){
    80002582:	7179                	addi	sp,sp,-48
    80002584:	f406                	sd	ra,40(sp)
    80002586:	f022                	sd	s0,32(sp)
    80002588:	ec26                	sd	s1,24(sp)
    8000258a:	e84a                	sd	s2,16(sp)
    8000258c:	e44e                	sd	s3,8(sp)
    8000258e:	1800                	addi	s0,sp,48
    80002590:	892a                	mv	s2,a0
  struct proc *p;
  int count = 0;
  for (p=proc; p <&proc[NPROC];p++){
    80002592:	0000e497          	auipc	s1,0xe
    80002596:	85648493          	addi	s1,s1,-1962 # 8000fde8 <proc>
    8000259a:	00013997          	auipc	s3,0x13
    8000259e:	44e98993          	addi	s3,s3,1102 # 800159e8 <tickslock>
    acquire(&p->lock);
    800025a2:	8526                	mv	a0,s1
    800025a4:	e84fe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    800025a8:	5c9c                	lw	a5,56(s1)
    800025aa:	01278b63          	beq	a5,s2,800025c0 <getfilenum+0x3e>
        }
      }
      release(&p->lock);
      return count;
    }
    release(&p->lock);
    800025ae:	8526                	mv	a0,s1
    800025b0:	f0cfe0ef          	jal	80000cbc <release>
  for (p=proc; p <&proc[NPROC];p++){
    800025b4:	17048493          	addi	s1,s1,368
    800025b8:	ff3495e3          	bne	s1,s3,800025a2 <getfilenum+0x20>
  }
  return count;
    800025bc:	4901                	li	s2,0
    800025be:	a00d                	j	800025e0 <getfilenum+0x5e>
    800025c0:	0d848793          	addi	a5,s1,216
    800025c4:	15848693          	addi	a3,s1,344
  int count = 0;
    800025c8:	4901                	li	s2,0
    800025ca:	a021                	j	800025d2 <getfilenum+0x50>
      for(int i = 0; i<NOFILE; i++){
    800025cc:	07a1                	addi	a5,a5,8
    800025ce:	00d78663          	beq	a5,a3,800025da <getfilenum+0x58>
        if(p->ofile[i] != 0){
    800025d2:	6398                	ld	a4,0(a5)
    800025d4:	df65                	beqz	a4,800025cc <getfilenum+0x4a>
          count++;
    800025d6:	2905                	addiw	s2,s2,1
    800025d8:	bfd5                	j	800025cc <getfilenum+0x4a>
      release(&p->lock);
    800025da:	8526                	mv	a0,s1
    800025dc:	ee0fe0ef          	jal	80000cbc <release>
}
    800025e0:	854a                	mv	a0,s2
    800025e2:	70a2                	ld	ra,40(sp)
    800025e4:	7402                	ld	s0,32(sp)
    800025e6:	64e2                	ld	s1,24(sp)
    800025e8:	6942                	ld	s2,16(sp)
    800025ea:	69a2                	ld	s3,8(sp)
    800025ec:	6145                	addi	sp,sp,48
    800025ee:	8082                	ret

00000000800025f0 <getpinfo>:

#include "pstat.h"   // make sure this is included near top of proc.c

int
getpinfo(struct pstat *up)
{
    800025f0:	bb010113          	addi	sp,sp,-1104
    800025f4:	44113423          	sd	ra,1096(sp)
    800025f8:	44813023          	sd	s0,1088(sp)
    800025fc:	42913c23          	sd	s1,1080(sp)
    80002600:	43213823          	sd	s2,1072(sp)
    80002604:	43313423          	sd	s3,1064(sp)
    80002608:	43413023          	sd	s4,1056(sp)
    8000260c:	41513c23          	sd	s5,1048(sp)
    80002610:	41613823          	sd	s6,1040(sp)
    80002614:	45010413          	addi	s0,sp,1104
    80002618:	8b2a                	mv	s6,a0
  struct pstat pinfo;

  // Initialize all slots to 0
  for (int i = 0; i < NPROC; i++) {
    8000261a:	bb840913          	addi	s2,s0,-1096
    8000261e:	cb840713          	addi	a4,s0,-840
{
    80002622:	87ca                	mv	a5,s2
    pinfo.inuse[i]  = 0;
    80002624:	0007a023          	sw	zero,0(a5)
    pinfo.pid[i]    = 0;
    80002628:	1007a023          	sw	zero,256(a5)
    pinfo.runtime[i]= 0;
    8000262c:	2007a023          	sw	zero,512(a5)
    pinfo.pass[i]   = 0;
    80002630:	3007a023          	sw	zero,768(a5)
  for (int i = 0; i < NPROC; i++) {
    80002634:	0791                	addi	a5,a5,4
    80002636:	fee797e3          	bne	a5,a4,80002624 <getpinfo+0x34>
  }
  pinfo.passTotal = passTotal;
    8000263a:	00005797          	auipc	a5,0x5
    8000263e:	2667a783          	lw	a5,614(a5) # 800078a0 <passTotal>
    80002642:	faf42c23          	sw	a5,-72(s0)
  for (int i = 0; i < NPROC; i++) {
    80002646:	0000d497          	auipc	s1,0xd
    8000264a:	7a248493          	addi	s1,s1,1954 # 8000fde8 <proc>
    8000264e:	00013a17          	auipc	s4,0x13
    80002652:	39aa0a13          	addi	s4,s4,922 # 800159e8 <tickslock>
    struct proc *p = &proc[i];
    acquire(&p->lock);
    if (p->state!=UNUSED) {
      pinfo.inuse[i]=1;
    80002656:	4a85                	li	s5,1
    80002658:	a809                	j	8000266a <getpinfo+0x7a>
      pinfo.pid[i]=p->pid;
      pinfo.runtime[i]=p->runtime;
      pinfo.pass[i]=p->pass;
    }
    release(&p->lock);
    8000265a:	854e                	mv	a0,s3
    8000265c:	e60fe0ef          	jal	80000cbc <release>
  for (int i = 0; i < NPROC; i++) {
    80002660:	17048493          	addi	s1,s1,368
    80002664:	0911                	addi	s2,s2,4
    80002666:	03448463          	beq	s1,s4,8000268e <getpinfo+0x9e>
    acquire(&p->lock);
    8000266a:	89a6                	mv	s3,s1
    8000266c:	8526                	mv	a0,s1
    8000266e:	dbafe0ef          	jal	80000c28 <acquire>
    if (p->state!=UNUSED) {
    80002672:	50dc                	lw	a5,36(s1)
    80002674:	d3fd                	beqz	a5,8000265a <getpinfo+0x6a>
      pinfo.inuse[i]=1;
    80002676:	01592023          	sw	s5,0(s2)
      pinfo.pid[i]=p->pid;
    8000267a:	5c9c                	lw	a5,56(s1)
    8000267c:	10f92023          	sw	a5,256(s2)
      pinfo.runtime[i]=p->runtime;
    80002680:	4c9c                	lw	a5,24(s1)
    80002682:	20f92023          	sw	a5,512(s2)
      pinfo.pass[i]=p->pass;
    80002686:	509c                	lw	a5,32(s1)
    80002688:	30f92023          	sw	a5,768(s2)
    8000268c:	b7f9                	j	8000265a <getpinfo+0x6a>
  }
  if (either_copyout(1, (uint64)up, &pinfo, sizeof(pinfo)) < 0) {
    8000268e:	40400693          	li	a3,1028
    80002692:	bb840613          	addi	a2,s0,-1096
    80002696:	85da                	mv	a1,s6
    80002698:	4505                	li	a0,1
    8000269a:	db1ff0ef          	jal	8000244a <either_copyout>
    return -1;
  }
  return 0;
}
    8000269e:	41f5551b          	sraiw	a0,a0,0x1f
    800026a2:	44813083          	ld	ra,1096(sp)
    800026a6:	44013403          	ld	s0,1088(sp)
    800026aa:	43813483          	ld	s1,1080(sp)
    800026ae:	43013903          	ld	s2,1072(sp)
    800026b2:	42813983          	ld	s3,1064(sp)
    800026b6:	42013a03          	ld	s4,1056(sp)
    800026ba:	41813a83          	ld	s5,1048(sp)
    800026be:	41013b03          	ld	s6,1040(sp)
    800026c2:	45010113          	addi	sp,sp,1104
    800026c6:	8082                	ret

00000000800026c8 <setStride>:


int setStride(int strideLength)
{
    800026c8:	1101                	addi	sp,sp,-32
    800026ca:	ec06                	sd	ra,24(sp)
    800026cc:	e822                	sd	s0,16(sp)
    800026ce:	e04a                	sd	s2,0(sp)
    800026d0:	1000                	addi	s0,sp,32
    800026d2:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800026d4:	bb4ff0ef          	jal	80001a88 <myproc>
  if (strideLength < 1) {
    800026d8:	03205263          	blez	s2,800026fc <setStride+0x34>
    800026dc:	e426                	sd	s1,8(sp)
    800026de:	84aa                	mv	s1,a0
    return -1;
  }
  acquire(&p->lock);
    800026e0:	d48fe0ef          	jal	80000c28 <acquire>
  p->stride = strideLength;
    800026e4:	0124ae23          	sw	s2,28(s1)
  release(&p->lock);
    800026e8:	8526                	mv	a0,s1
    800026ea:	dd2fe0ef          	jal	80000cbc <release>
  return 0;
    800026ee:	4501                	li	a0,0
    800026f0:	64a2                	ld	s1,8(sp)
}
    800026f2:	60e2                	ld	ra,24(sp)
    800026f4:	6442                	ld	s0,16(sp)
    800026f6:	6902                	ld	s2,0(sp)
    800026f8:	6105                	addi	sp,sp,32
    800026fa:	8082                	ret
    return -1;
    800026fc:	557d                	li	a0,-1
    800026fe:	bfd5                	j	800026f2 <setStride+0x2a>

0000000080002700 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002700:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002704:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002708:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    8000270a:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    8000270c:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002710:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002714:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002718:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    8000271c:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002720:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002724:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002728:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    8000272c:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002730:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002734:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002738:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    8000273c:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    8000273e:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002740:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002744:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002748:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000274c:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002750:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002754:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002758:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    8000275c:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002760:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002764:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002768:	8082                	ret

000000008000276a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000276a:	1141                	addi	sp,sp,-16
    8000276c:	e406                	sd	ra,8(sp)
    8000276e:	e022                	sd	s0,0(sp)
    80002770:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002772:	00005597          	auipc	a1,0x5
    80002776:	b0658593          	addi	a1,a1,-1274 # 80007278 <etext+0x278>
    8000277a:	00013517          	auipc	a0,0x13
    8000277e:	26e50513          	addi	a0,a0,622 # 800159e8 <tickslock>
    80002782:	c1cfe0ef          	jal	80000b9e <initlock>
}
    80002786:	60a2                	ld	ra,8(sp)
    80002788:	6402                	ld	s0,0(sp)
    8000278a:	0141                	addi	sp,sp,16
    8000278c:	8082                	ret

000000008000278e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000278e:	1141                	addi	sp,sp,-16
    80002790:	e406                	sd	ra,8(sp)
    80002792:	e022                	sd	s0,0(sp)
    80002794:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002796:	00003797          	auipc	a5,0x3
    8000279a:	06a78793          	addi	a5,a5,106 # 80005800 <kernelvec>
    8000279e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800027a2:	60a2                	ld	ra,8(sp)
    800027a4:	6402                	ld	s0,0(sp)
    800027a6:	0141                	addi	sp,sp,16
    800027a8:	8082                	ret

00000000800027aa <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800027aa:	1141                	addi	sp,sp,-16
    800027ac:	e406                	sd	ra,8(sp)
    800027ae:	e022                	sd	s0,0(sp)
    800027b0:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800027b2:	ad6ff0ef          	jal	80001a88 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027b6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800027ba:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800027bc:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800027c0:	04000737          	lui	a4,0x4000
    800027c4:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800027c6:	0732                	slli	a4,a4,0xc
    800027c8:	00004797          	auipc	a5,0x4
    800027cc:	83878793          	addi	a5,a5,-1992 # 80006000 <_trampoline>
    800027d0:	00004697          	auipc	a3,0x4
    800027d4:	83068693          	addi	a3,a3,-2000 # 80006000 <_trampoline>
    800027d8:	8f95                	sub	a5,a5,a3
    800027da:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800027dc:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800027e0:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800027e2:	18002773          	csrr	a4,satp
    800027e6:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800027e8:	7138                	ld	a4,96(a0)
    800027ea:	653c                	ld	a5,72(a0)
    800027ec:	6685                	lui	a3,0x1
    800027ee:	97b6                	add	a5,a5,a3
    800027f0:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800027f2:	713c                	ld	a5,96(a0)
    800027f4:	00000717          	auipc	a4,0x0
    800027f8:	0fc70713          	addi	a4,a4,252 # 800028f0 <usertrap>
    800027fc:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800027fe:	713c                	ld	a5,96(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002800:	8712                	mv	a4,tp
    80002802:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002804:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002808:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000280c:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002810:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002814:	713c                	ld	a5,96(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002816:	6f9c                	ld	a5,24(a5)
    80002818:	14179073          	csrw	sepc,a5
}
    8000281c:	60a2                	ld	ra,8(sp)
    8000281e:	6402                	ld	s0,0(sp)
    80002820:	0141                	addi	sp,sp,16
    80002822:	8082                	ret

0000000080002824 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002824:	1141                	addi	sp,sp,-16
    80002826:	e406                	sd	ra,8(sp)
    80002828:	e022                	sd	s0,0(sp)
    8000282a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000282c:	a28ff0ef          	jal	80001a54 <cpuid>
    80002830:	cd11                	beqz	a0,8000284c <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80002832:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002836:	000f4737          	lui	a4,0xf4
    8000283a:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000283e:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002840:	14d79073          	csrw	stimecmp,a5
}
    80002844:	60a2                	ld	ra,8(sp)
    80002846:	6402                	ld	s0,0(sp)
    80002848:	0141                	addi	sp,sp,16
    8000284a:	8082                	ret
    acquire(&tickslock);
    8000284c:	00013517          	auipc	a0,0x13
    80002850:	19c50513          	addi	a0,a0,412 # 800159e8 <tickslock>
    80002854:	bd4fe0ef          	jal	80000c28 <acquire>
    ticks++;
    80002858:	00005717          	auipc	a4,0x5
    8000285c:	05870713          	addi	a4,a4,88 # 800078b0 <ticks>
    80002860:	431c                	lw	a5,0(a4)
    80002862:	2785                	addiw	a5,a5,1
    80002864:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002866:	853a                	mv	a0,a4
    80002868:	8d5ff0ef          	jal	8000213c <wakeup>
    release(&tickslock);
    8000286c:	00013517          	auipc	a0,0x13
    80002870:	17c50513          	addi	a0,a0,380 # 800159e8 <tickslock>
    80002874:	c48fe0ef          	jal	80000cbc <release>
    80002878:	bf6d                	j	80002832 <clockintr+0xe>

000000008000287a <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000287a:	1101                	addi	sp,sp,-32
    8000287c:	ec06                	sd	ra,24(sp)
    8000287e:	e822                	sd	s0,16(sp)
    80002880:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002882:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002886:	57fd                	li	a5,-1
    80002888:	17fe                	slli	a5,a5,0x3f
    8000288a:	07a5                	addi	a5,a5,9
    8000288c:	00f70c63          	beq	a4,a5,800028a4 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002890:	57fd                	li	a5,-1
    80002892:	17fe                	slli	a5,a5,0x3f
    80002894:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002896:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002898:	04f70863          	beq	a4,a5,800028e8 <devintr+0x6e>
  }
}
    8000289c:	60e2                	ld	ra,24(sp)
    8000289e:	6442                	ld	s0,16(sp)
    800028a0:	6105                	addi	sp,sp,32
    800028a2:	8082                	ret
    800028a4:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800028a6:	006030ef          	jal	800058ac <plic_claim>
    800028aa:	872a                	mv	a4,a0
    800028ac:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800028ae:	47a9                	li	a5,10
    800028b0:	00f50963          	beq	a0,a5,800028c2 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    800028b4:	4785                	li	a5,1
    800028b6:	00f50963          	beq	a0,a5,800028c8 <devintr+0x4e>
    return 1;
    800028ba:	4505                	li	a0,1
    } else if(irq){
    800028bc:	eb09                	bnez	a4,800028ce <devintr+0x54>
    800028be:	64a2                	ld	s1,8(sp)
    800028c0:	bff1                	j	8000289c <devintr+0x22>
      uartintr();
    800028c2:	932fe0ef          	jal	800009f4 <uartintr>
    if(irq)
    800028c6:	a819                	j	800028dc <devintr+0x62>
      virtio_disk_intr();
    800028c8:	47a030ef          	jal	80005d42 <virtio_disk_intr>
    if(irq)
    800028cc:	a801                	j	800028dc <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800028ce:	85ba                	mv	a1,a4
    800028d0:	00005517          	auipc	a0,0x5
    800028d4:	9b050513          	addi	a0,a0,-1616 # 80007280 <etext+0x280>
    800028d8:	c23fd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    800028dc:	8526                	mv	a0,s1
    800028de:	7ef020ef          	jal	800058cc <plic_complete>
    return 1;
    800028e2:	4505                	li	a0,1
    800028e4:	64a2                	ld	s1,8(sp)
    800028e6:	bf5d                	j	8000289c <devintr+0x22>
    clockintr();
    800028e8:	f3dff0ef          	jal	80002824 <clockintr>
    return 2;
    800028ec:	4509                	li	a0,2
    800028ee:	b77d                	j	8000289c <devintr+0x22>

00000000800028f0 <usertrap>:
{
    800028f0:	1101                	addi	sp,sp,-32
    800028f2:	ec06                	sd	ra,24(sp)
    800028f4:	e822                	sd	s0,16(sp)
    800028f6:	e426                	sd	s1,8(sp)
    800028f8:	e04a                	sd	s2,0(sp)
    800028fa:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028fc:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80002900:	1007f793          	andi	a5,a5,256
    80002904:	eba5                	bnez	a5,80002974 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002906:	00003797          	auipc	a5,0x3
    8000290a:	efa78793          	addi	a5,a5,-262 # 80005800 <kernelvec>
    8000290e:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002912:	976ff0ef          	jal	80001a88 <myproc>
    80002916:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002918:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000291a:	14102773          	csrr	a4,sepc
    8000291e:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002920:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80002924:	47a1                	li	a5,8
    80002926:	04f70d63          	beq	a4,a5,80002980 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    8000292a:	f51ff0ef          	jal	8000287a <devintr>
    8000292e:	892a                	mv	s2,a0
    80002930:	e945                	bnez	a0,800029e0 <usertrap+0xf0>
    80002932:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002936:	47bd                	li	a5,15
    80002938:	08f70863          	beq	a4,a5,800029c8 <usertrap+0xd8>
    8000293c:	14202773          	csrr	a4,scause
    80002940:	47b5                	li	a5,13
    80002942:	08f70363          	beq	a4,a5,800029c8 <usertrap+0xd8>
    80002946:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    8000294a:	5c90                	lw	a2,56(s1)
    8000294c:	00005517          	auipc	a0,0x5
    80002950:	97450513          	addi	a0,a0,-1676 # 800072c0 <etext+0x2c0>
    80002954:	ba7fd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002958:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000295c:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002960:	00005517          	auipc	a0,0x5
    80002964:	99050513          	addi	a0,a0,-1648 # 800072f0 <etext+0x2f0>
    80002968:	b93fd0ef          	jal	800004fa <printf>
    setkilled(p);
    8000296c:	8526                	mv	a0,s1
    8000296e:	99bff0ef          	jal	80002308 <setkilled>
    80002972:	a035                	j	8000299e <usertrap+0xae>
    panic("usertrap: not from user mode");
    80002974:	00005517          	auipc	a0,0x5
    80002978:	92c50513          	addi	a0,a0,-1748 # 800072a0 <etext+0x2a0>
    8000297c:	ea9fd0ef          	jal	80000824 <panic>
    if(killed(p))
    80002980:	9adff0ef          	jal	8000232c <killed>
    80002984:	ed15                	bnez	a0,800029c0 <usertrap+0xd0>
    p->trapframe->epc += 4;
    80002986:	70b8                	ld	a4,96(s1)
    80002988:	6f1c                	ld	a5,24(a4)
    8000298a:	0791                	addi	a5,a5,4
    8000298c:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000298e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002992:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002996:	10079073          	csrw	sstatus,a5
    syscall();
    8000299a:	240000ef          	jal	80002bda <syscall>
  if(killed(p))
    8000299e:	8526                	mv	a0,s1
    800029a0:	98dff0ef          	jal	8000232c <killed>
    800029a4:	e139                	bnez	a0,800029ea <usertrap+0xfa>
  prepare_return();
    800029a6:	e05ff0ef          	jal	800027aa <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800029aa:	6ca8                	ld	a0,88(s1)
    800029ac:	8131                	srli	a0,a0,0xc
    800029ae:	57fd                	li	a5,-1
    800029b0:	17fe                	slli	a5,a5,0x3f
    800029b2:	8d5d                	or	a0,a0,a5
}
    800029b4:	60e2                	ld	ra,24(sp)
    800029b6:	6442                	ld	s0,16(sp)
    800029b8:	64a2                	ld	s1,8(sp)
    800029ba:	6902                	ld	s2,0(sp)
    800029bc:	6105                	addi	sp,sp,32
    800029be:	8082                	ret
      kexit(-1);
    800029c0:	557d                	li	a0,-1
    800029c2:	83bff0ef          	jal	800021fc <kexit>
    800029c6:	b7c1                	j	80002986 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800029c8:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029cc:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800029d0:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    800029d2:	00163613          	seqz	a2,a2
    800029d6:	6ca8                	ld	a0,88(s1)
    800029d8:	c93fe0ef          	jal	8000166a <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800029dc:	f169                	bnez	a0,8000299e <usertrap+0xae>
    800029de:	b7a5                	j	80002946 <usertrap+0x56>
  if(killed(p))
    800029e0:	8526                	mv	a0,s1
    800029e2:	94bff0ef          	jal	8000232c <killed>
    800029e6:	c511                	beqz	a0,800029f2 <usertrap+0x102>
    800029e8:	a011                	j	800029ec <usertrap+0xfc>
    800029ea:	4901                	li	s2,0
    kexit(-1);
    800029ec:	557d                	li	a0,-1
    800029ee:	80fff0ef          	jal	800021fc <kexit>
  if(which_dev == 2)
    800029f2:	4789                	li	a5,2
    800029f4:	faf919e3          	bne	s2,a5,800029a6 <usertrap+0xb6>
    yield();
    800029f8:	eccff0ef          	jal	800020c4 <yield>
    800029fc:	b76d                	j	800029a6 <usertrap+0xb6>

00000000800029fe <kerneltrap>:
{
    800029fe:	7179                	addi	sp,sp,-48
    80002a00:	f406                	sd	ra,40(sp)
    80002a02:	f022                	sd	s0,32(sp)
    80002a04:	ec26                	sd	s1,24(sp)
    80002a06:	e84a                	sd	s2,16(sp)
    80002a08:	e44e                	sd	s3,8(sp)
    80002a0a:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a0c:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a10:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002a14:	142027f3          	csrr	a5,scause
    80002a18:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80002a1a:	1004f793          	andi	a5,s1,256
    80002a1e:	c795                	beqz	a5,80002a4a <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a20:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002a24:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002a26:	eb85                	bnez	a5,80002a56 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80002a28:	e53ff0ef          	jal	8000287a <devintr>
    80002a2c:	c91d                	beqz	a0,80002a62 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002a2e:	4789                	li	a5,2
    80002a30:	04f50a63          	beq	a0,a5,80002a84 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002a34:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002a38:	10049073          	csrw	sstatus,s1
}
    80002a3c:	70a2                	ld	ra,40(sp)
    80002a3e:	7402                	ld	s0,32(sp)
    80002a40:	64e2                	ld	s1,24(sp)
    80002a42:	6942                	ld	s2,16(sp)
    80002a44:	69a2                	ld	s3,8(sp)
    80002a46:	6145                	addi	sp,sp,48
    80002a48:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002a4a:	00005517          	auipc	a0,0x5
    80002a4e:	8ce50513          	addi	a0,a0,-1842 # 80007318 <etext+0x318>
    80002a52:	dd3fd0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    80002a56:	00005517          	auipc	a0,0x5
    80002a5a:	8ea50513          	addi	a0,a0,-1814 # 80007340 <etext+0x340>
    80002a5e:	dc7fd0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a62:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a66:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002a6a:	85ce                	mv	a1,s3
    80002a6c:	00005517          	auipc	a0,0x5
    80002a70:	8f450513          	addi	a0,a0,-1804 # 80007360 <etext+0x360>
    80002a74:	a87fd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    80002a78:	00005517          	auipc	a0,0x5
    80002a7c:	91050513          	addi	a0,a0,-1776 # 80007388 <etext+0x388>
    80002a80:	da5fd0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    80002a84:	804ff0ef          	jal	80001a88 <myproc>
    80002a88:	d555                	beqz	a0,80002a34 <kerneltrap+0x36>
    yield();
    80002a8a:	e3aff0ef          	jal	800020c4 <yield>
    80002a8e:	b75d                	j	80002a34 <kerneltrap+0x36>

0000000080002a90 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002a90:	1101                	addi	sp,sp,-32
    80002a92:	ec06                	sd	ra,24(sp)
    80002a94:	e822                	sd	s0,16(sp)
    80002a96:	e426                	sd	s1,8(sp)
    80002a98:	1000                	addi	s0,sp,32
    80002a9a:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002a9c:	fedfe0ef          	jal	80001a88 <myproc>
  switch (n) {
    80002aa0:	4795                	li	a5,5
    80002aa2:	0497e163          	bltu	a5,s1,80002ae4 <argraw+0x54>
    80002aa6:	048a                	slli	s1,s1,0x2
    80002aa8:	00005717          	auipc	a4,0x5
    80002aac:	ce070713          	addi	a4,a4,-800 # 80007788 <states.0+0x30>
    80002ab0:	94ba                	add	s1,s1,a4
    80002ab2:	409c                	lw	a5,0(s1)
    80002ab4:	97ba                	add	a5,a5,a4
    80002ab6:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002ab8:	713c                	ld	a5,96(a0)
    80002aba:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002abc:	60e2                	ld	ra,24(sp)
    80002abe:	6442                	ld	s0,16(sp)
    80002ac0:	64a2                	ld	s1,8(sp)
    80002ac2:	6105                	addi	sp,sp,32
    80002ac4:	8082                	ret
    return p->trapframe->a1;
    80002ac6:	713c                	ld	a5,96(a0)
    80002ac8:	7fa8                	ld	a0,120(a5)
    80002aca:	bfcd                	j	80002abc <argraw+0x2c>
    return p->trapframe->a2;
    80002acc:	713c                	ld	a5,96(a0)
    80002ace:	63c8                	ld	a0,128(a5)
    80002ad0:	b7f5                	j	80002abc <argraw+0x2c>
    return p->trapframe->a3;
    80002ad2:	713c                	ld	a5,96(a0)
    80002ad4:	67c8                	ld	a0,136(a5)
    80002ad6:	b7dd                	j	80002abc <argraw+0x2c>
    return p->trapframe->a4;
    80002ad8:	713c                	ld	a5,96(a0)
    80002ada:	6bc8                	ld	a0,144(a5)
    80002adc:	b7c5                	j	80002abc <argraw+0x2c>
    return p->trapframe->a5;
    80002ade:	713c                	ld	a5,96(a0)
    80002ae0:	6fc8                	ld	a0,152(a5)
    80002ae2:	bfe9                	j	80002abc <argraw+0x2c>
  panic("argraw");
    80002ae4:	00005517          	auipc	a0,0x5
    80002ae8:	8b450513          	addi	a0,a0,-1868 # 80007398 <etext+0x398>
    80002aec:	d39fd0ef          	jal	80000824 <panic>

0000000080002af0 <fetchaddr>:
{
    80002af0:	1101                	addi	sp,sp,-32
    80002af2:	ec06                	sd	ra,24(sp)
    80002af4:	e822                	sd	s0,16(sp)
    80002af6:	e426                	sd	s1,8(sp)
    80002af8:	e04a                	sd	s2,0(sp)
    80002afa:	1000                	addi	s0,sp,32
    80002afc:	84aa                	mv	s1,a0
    80002afe:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002b00:	f89fe0ef          	jal	80001a88 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002b04:	693c                	ld	a5,80(a0)
    80002b06:	02f4f663          	bgeu	s1,a5,80002b32 <fetchaddr+0x42>
    80002b0a:	00848713          	addi	a4,s1,8
    80002b0e:	02e7e463          	bltu	a5,a4,80002b36 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002b12:	46a1                	li	a3,8
    80002b14:	8626                	mv	a2,s1
    80002b16:	85ca                	mv	a1,s2
    80002b18:	6d28                	ld	a0,88(a0)
    80002b1a:	c93fe0ef          	jal	800017ac <copyin>
    80002b1e:	00a03533          	snez	a0,a0
    80002b22:	40a0053b          	negw	a0,a0
}
    80002b26:	60e2                	ld	ra,24(sp)
    80002b28:	6442                	ld	s0,16(sp)
    80002b2a:	64a2                	ld	s1,8(sp)
    80002b2c:	6902                	ld	s2,0(sp)
    80002b2e:	6105                	addi	sp,sp,32
    80002b30:	8082                	ret
    return -1;
    80002b32:	557d                	li	a0,-1
    80002b34:	bfcd                	j	80002b26 <fetchaddr+0x36>
    80002b36:	557d                	li	a0,-1
    80002b38:	b7fd                	j	80002b26 <fetchaddr+0x36>

0000000080002b3a <fetchstr>:
{
    80002b3a:	7179                	addi	sp,sp,-48
    80002b3c:	f406                	sd	ra,40(sp)
    80002b3e:	f022                	sd	s0,32(sp)
    80002b40:	ec26                	sd	s1,24(sp)
    80002b42:	e84a                	sd	s2,16(sp)
    80002b44:	e44e                	sd	s3,8(sp)
    80002b46:	1800                	addi	s0,sp,48
    80002b48:	89aa                	mv	s3,a0
    80002b4a:	84ae                	mv	s1,a1
    80002b4c:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002b4e:	f3bfe0ef          	jal	80001a88 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002b52:	86ca                	mv	a3,s2
    80002b54:	864e                	mv	a2,s3
    80002b56:	85a6                	mv	a1,s1
    80002b58:	6d28                	ld	a0,88(a0)
    80002b5a:	a39fe0ef          	jal	80001592 <copyinstr>
    80002b5e:	00054c63          	bltz	a0,80002b76 <fetchstr+0x3c>
  return strlen(buf);
    80002b62:	8526                	mv	a0,s1
    80002b64:	b1efe0ef          	jal	80000e82 <strlen>
}
    80002b68:	70a2                	ld	ra,40(sp)
    80002b6a:	7402                	ld	s0,32(sp)
    80002b6c:	64e2                	ld	s1,24(sp)
    80002b6e:	6942                	ld	s2,16(sp)
    80002b70:	69a2                	ld	s3,8(sp)
    80002b72:	6145                	addi	sp,sp,48
    80002b74:	8082                	ret
    return -1;
    80002b76:	557d                	li	a0,-1
    80002b78:	bfc5                	j	80002b68 <fetchstr+0x2e>

0000000080002b7a <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002b7a:	1101                	addi	sp,sp,-32
    80002b7c:	ec06                	sd	ra,24(sp)
    80002b7e:	e822                	sd	s0,16(sp)
    80002b80:	e426                	sd	s1,8(sp)
    80002b82:	1000                	addi	s0,sp,32
    80002b84:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002b86:	f0bff0ef          	jal	80002a90 <argraw>
    80002b8a:	c088                	sw	a0,0(s1)
}
    80002b8c:	60e2                	ld	ra,24(sp)
    80002b8e:	6442                	ld	s0,16(sp)
    80002b90:	64a2                	ld	s1,8(sp)
    80002b92:	6105                	addi	sp,sp,32
    80002b94:	8082                	ret

0000000080002b96 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002b96:	1101                	addi	sp,sp,-32
    80002b98:	ec06                	sd	ra,24(sp)
    80002b9a:	e822                	sd	s0,16(sp)
    80002b9c:	e426                	sd	s1,8(sp)
    80002b9e:	1000                	addi	s0,sp,32
    80002ba0:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002ba2:	eefff0ef          	jal	80002a90 <argraw>
    80002ba6:	e088                	sd	a0,0(s1)
}
    80002ba8:	60e2                	ld	ra,24(sp)
    80002baa:	6442                	ld	s0,16(sp)
    80002bac:	64a2                	ld	s1,8(sp)
    80002bae:	6105                	addi	sp,sp,32
    80002bb0:	8082                	ret

0000000080002bb2 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002bb2:	1101                	addi	sp,sp,-32
    80002bb4:	ec06                	sd	ra,24(sp)
    80002bb6:	e822                	sd	s0,16(sp)
    80002bb8:	e426                	sd	s1,8(sp)
    80002bba:	e04a                	sd	s2,0(sp)
    80002bbc:	1000                	addi	s0,sp,32
    80002bbe:	892e                	mv	s2,a1
    80002bc0:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002bc2:	ecfff0ef          	jal	80002a90 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002bc6:	8626                	mv	a2,s1
    80002bc8:	85ca                	mv	a1,s2
    80002bca:	f71ff0ef          	jal	80002b3a <fetchstr>
}
    80002bce:	60e2                	ld	ra,24(sp)
    80002bd0:	6442                	ld	s0,16(sp)
    80002bd2:	64a2                	ld	s1,8(sp)
    80002bd4:	6902                	ld	s2,0(sp)
    80002bd6:	6105                	addi	sp,sp,32
    80002bd8:	8082                	ret

0000000080002bda <syscall>:
[SYS_pgaccess] sys_pgaccess,
};

void
syscall(void)
{
    80002bda:	1101                	addi	sp,sp,-32
    80002bdc:	ec06                	sd	ra,24(sp)
    80002bde:	e822                	sd	s0,16(sp)
    80002be0:	e426                	sd	s1,8(sp)
    80002be2:	e04a                	sd	s2,0(sp)
    80002be4:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002be6:	ea3fe0ef          	jal	80001a88 <myproc>
    80002bea:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002bec:	06053903          	ld	s2,96(a0)
    80002bf0:	0a893783          	ld	a5,168(s2)
    80002bf4:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002bf8:	37fd                	addiw	a5,a5,-1
    80002bfa:	4761                	li	a4,24
    80002bfc:	00f76f63          	bltu	a4,a5,80002c1a <syscall+0x40>
    80002c00:	00369713          	slli	a4,a3,0x3
    80002c04:	00005797          	auipc	a5,0x5
    80002c08:	b9c78793          	addi	a5,a5,-1124 # 800077a0 <syscalls>
    80002c0c:	97ba                	add	a5,a5,a4
    80002c0e:	639c                	ld	a5,0(a5)
    80002c10:	c789                	beqz	a5,80002c1a <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002c12:	9782                	jalr	a5
    80002c14:	06a93823          	sd	a0,112(s2)
    80002c18:	a829                	j	80002c32 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002c1a:	16048613          	addi	a2,s1,352
    80002c1e:	5c8c                	lw	a1,56(s1)
    80002c20:	00004517          	auipc	a0,0x4
    80002c24:	78050513          	addi	a0,a0,1920 # 800073a0 <etext+0x3a0>
    80002c28:	8d3fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002c2c:	70bc                	ld	a5,96(s1)
    80002c2e:	577d                	li	a4,-1
    80002c30:	fbb8                	sd	a4,112(a5)
  }
}
    80002c32:	60e2                	ld	ra,24(sp)
    80002c34:	6442                	ld	s0,16(sp)
    80002c36:	64a2                	ld	s1,8(sp)
    80002c38:	6902                	ld	s2,0(sp)
    80002c3a:	6105                	addi	sp,sp,32
    80002c3c:	8082                	ret

0000000080002c3e <sys_exit>:
#include "vm.h"
#include "pstat.h"

uint64
sys_exit(void)
{
    80002c3e:	1101                	addi	sp,sp,-32
    80002c40:	ec06                	sd	ra,24(sp)
    80002c42:	e822                	sd	s0,16(sp)
    80002c44:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002c46:	fec40593          	addi	a1,s0,-20
    80002c4a:	4501                	li	a0,0
    80002c4c:	f2fff0ef          	jal	80002b7a <argint>
  kexit(n);
    80002c50:	fec42503          	lw	a0,-20(s0)
    80002c54:	da8ff0ef          	jal	800021fc <kexit>
  return 0;  // not reached
}
    80002c58:	4501                	li	a0,0
    80002c5a:	60e2                	ld	ra,24(sp)
    80002c5c:	6442                	ld	s0,16(sp)
    80002c5e:	6105                	addi	sp,sp,32
    80002c60:	8082                	ret

0000000080002c62 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002c62:	1141                	addi	sp,sp,-16
    80002c64:	e406                	sd	ra,8(sp)
    80002c66:	e022                	sd	s0,0(sp)
    80002c68:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002c6a:	e1ffe0ef          	jal	80001a88 <myproc>
}
    80002c6e:	5d08                	lw	a0,56(a0)
    80002c70:	60a2                	ld	ra,8(sp)
    80002c72:	6402                	ld	s0,0(sp)
    80002c74:	0141                	addi	sp,sp,16
    80002c76:	8082                	ret

0000000080002c78 <sys_fork>:

uint64
sys_fork(void)
{
    80002c78:	1141                	addi	sp,sp,-16
    80002c7a:	e406                	sd	ra,8(sp)
    80002c7c:	e022                	sd	s0,0(sp)
    80002c7e:	0800                	addi	s0,sp,16
  return kfork();
    80002c80:	96cff0ef          	jal	80001dec <kfork>
}
    80002c84:	60a2                	ld	ra,8(sp)
    80002c86:	6402                	ld	s0,0(sp)
    80002c88:	0141                	addi	sp,sp,16
    80002c8a:	8082                	ret

0000000080002c8c <sys_wait>:

uint64
sys_wait(void)
{
    80002c8c:	1101                	addi	sp,sp,-32
    80002c8e:	ec06                	sd	ra,24(sp)
    80002c90:	e822                	sd	s0,16(sp)
    80002c92:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002c94:	fe840593          	addi	a1,s0,-24
    80002c98:	4501                	li	a0,0
    80002c9a:	efdff0ef          	jal	80002b96 <argaddr>
  return kwait(p);
    80002c9e:	fe843503          	ld	a0,-24(s0)
    80002ca2:	eb4ff0ef          	jal	80002356 <kwait>
}
    80002ca6:	60e2                	ld	ra,24(sp)
    80002ca8:	6442                	ld	s0,16(sp)
    80002caa:	6105                	addi	sp,sp,32
    80002cac:	8082                	ret

0000000080002cae <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002cae:	7179                	addi	sp,sp,-48
    80002cb0:	f406                	sd	ra,40(sp)
    80002cb2:	f022                	sd	s0,32(sp)
    80002cb4:	ec26                	sd	s1,24(sp)
    80002cb6:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002cb8:	fd840593          	addi	a1,s0,-40
    80002cbc:	4501                	li	a0,0
    80002cbe:	ebdff0ef          	jal	80002b7a <argint>
  argint(1, &t);
    80002cc2:	fdc40593          	addi	a1,s0,-36
    80002cc6:	4505                	li	a0,1
    80002cc8:	eb3ff0ef          	jal	80002b7a <argint>
  addr = myproc()->sz;
    80002ccc:	dbdfe0ef          	jal	80001a88 <myproc>
    80002cd0:	6924                	ld	s1,80(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002cd2:	fdc42703          	lw	a4,-36(s0)
    80002cd6:	4785                	li	a5,1
    80002cd8:	02f70163          	beq	a4,a5,80002cfa <sys_sbrk+0x4c>
    80002cdc:	fd842783          	lw	a5,-40(s0)
    80002ce0:	0007cd63          	bltz	a5,80002cfa <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002ce4:	97a6                	add	a5,a5,s1
    80002ce6:	0297e863          	bltu	a5,s1,80002d16 <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002cea:	d9ffe0ef          	jal	80001a88 <myproc>
    80002cee:	fd842703          	lw	a4,-40(s0)
    80002cf2:	693c                	ld	a5,80(a0)
    80002cf4:	97ba                	add	a5,a5,a4
    80002cf6:	e93c                	sd	a5,80(a0)
    80002cf8:	a039                	j	80002d06 <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002cfa:	fd842503          	lw	a0,-40(s0)
    80002cfe:	89eff0ef          	jal	80001d9c <growproc>
    80002d02:	00054863          	bltz	a0,80002d12 <sys_sbrk+0x64>
  }
  return addr;
}
    80002d06:	8526                	mv	a0,s1
    80002d08:	70a2                	ld	ra,40(sp)
    80002d0a:	7402                	ld	s0,32(sp)
    80002d0c:	64e2                	ld	s1,24(sp)
    80002d0e:	6145                	addi	sp,sp,48
    80002d10:	8082                	ret
      return -1;
    80002d12:	54fd                	li	s1,-1
    80002d14:	bfcd                	j	80002d06 <sys_sbrk+0x58>
      return -1;
    80002d16:	54fd                	li	s1,-1
    80002d18:	b7fd                	j	80002d06 <sys_sbrk+0x58>

0000000080002d1a <sys_pause>:

uint64
sys_pause(void)
{
    80002d1a:	7139                	addi	sp,sp,-64
    80002d1c:	fc06                	sd	ra,56(sp)
    80002d1e:	f822                	sd	s0,48(sp)
    80002d20:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002d22:	fcc40593          	addi	a1,s0,-52
    80002d26:	4501                	li	a0,0
    80002d28:	e53ff0ef          	jal	80002b7a <argint>
  if(n < 0)
    80002d2c:	fcc42783          	lw	a5,-52(s0)
    80002d30:	0607c863          	bltz	a5,80002da0 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002d34:	00013517          	auipc	a0,0x13
    80002d38:	cb450513          	addi	a0,a0,-844 # 800159e8 <tickslock>
    80002d3c:	eedfd0ef          	jal	80000c28 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002d40:	fcc42783          	lw	a5,-52(s0)
    80002d44:	c3b9                	beqz	a5,80002d8a <sys_pause+0x70>
    80002d46:	f426                	sd	s1,40(sp)
    80002d48:	f04a                	sd	s2,32(sp)
    80002d4a:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002d4c:	00005997          	auipc	s3,0x5
    80002d50:	b649a983          	lw	s3,-1180(s3) # 800078b0 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002d54:	00013917          	auipc	s2,0x13
    80002d58:	c9490913          	addi	s2,s2,-876 # 800159e8 <tickslock>
    80002d5c:	00005497          	auipc	s1,0x5
    80002d60:	b5448493          	addi	s1,s1,-1196 # 800078b0 <ticks>
    if(killed(myproc())){
    80002d64:	d25fe0ef          	jal	80001a88 <myproc>
    80002d68:	dc4ff0ef          	jal	8000232c <killed>
    80002d6c:	ed0d                	bnez	a0,80002da6 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002d6e:	85ca                	mv	a1,s2
    80002d70:	8526                	mv	a0,s1
    80002d72:	b7eff0ef          	jal	800020f0 <sleep>
  while(ticks - ticks0 < n){
    80002d76:	409c                	lw	a5,0(s1)
    80002d78:	413787bb          	subw	a5,a5,s3
    80002d7c:	fcc42703          	lw	a4,-52(s0)
    80002d80:	fee7e2e3          	bltu	a5,a4,80002d64 <sys_pause+0x4a>
    80002d84:	74a2                	ld	s1,40(sp)
    80002d86:	7902                	ld	s2,32(sp)
    80002d88:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002d8a:	00013517          	auipc	a0,0x13
    80002d8e:	c5e50513          	addi	a0,a0,-930 # 800159e8 <tickslock>
    80002d92:	f2bfd0ef          	jal	80000cbc <release>
  return 0;
    80002d96:	4501                	li	a0,0
}
    80002d98:	70e2                	ld	ra,56(sp)
    80002d9a:	7442                	ld	s0,48(sp)
    80002d9c:	6121                	addi	sp,sp,64
    80002d9e:	8082                	ret
    n = 0;
    80002da0:	fc042623          	sw	zero,-52(s0)
    80002da4:	bf41                	j	80002d34 <sys_pause+0x1a>
      release(&tickslock);
    80002da6:	00013517          	auipc	a0,0x13
    80002daa:	c4250513          	addi	a0,a0,-958 # 800159e8 <tickslock>
    80002dae:	f0ffd0ef          	jal	80000cbc <release>
      return -1;
    80002db2:	557d                	li	a0,-1
    80002db4:	74a2                	ld	s1,40(sp)
    80002db6:	7902                	ld	s2,32(sp)
    80002db8:	69e2                	ld	s3,24(sp)
    80002dba:	bff9                	j	80002d98 <sys_pause+0x7e>

0000000080002dbc <sys_kill>:

uint64
sys_kill(void)
{
    80002dbc:	1101                	addi	sp,sp,-32
    80002dbe:	ec06                	sd	ra,24(sp)
    80002dc0:	e822                	sd	s0,16(sp)
    80002dc2:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002dc4:	fec40593          	addi	a1,s0,-20
    80002dc8:	4501                	li	a0,0
    80002dca:	db1ff0ef          	jal	80002b7a <argint>
  return kkill(pid);
    80002dce:	fec42503          	lw	a0,-20(s0)
    80002dd2:	cd0ff0ef          	jal	800022a2 <kkill>
}
    80002dd6:	60e2                	ld	ra,24(sp)
    80002dd8:	6442                	ld	s0,16(sp)
    80002dda:	6105                	addi	sp,sp,32
    80002ddc:	8082                	ret

0000000080002dde <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002dde:	1101                	addi	sp,sp,-32
    80002de0:	ec06                	sd	ra,24(sp)
    80002de2:	e822                	sd	s0,16(sp)
    80002de4:	e426                	sd	s1,8(sp)
    80002de6:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002de8:	00013517          	auipc	a0,0x13
    80002dec:	c0050513          	addi	a0,a0,-1024 # 800159e8 <tickslock>
    80002df0:	e39fd0ef          	jal	80000c28 <acquire>
  xticks = ticks;
    80002df4:	00005797          	auipc	a5,0x5
    80002df8:	abc7a783          	lw	a5,-1348(a5) # 800078b0 <ticks>
    80002dfc:	84be                	mv	s1,a5
  release(&tickslock);
    80002dfe:	00013517          	auipc	a0,0x13
    80002e02:	bea50513          	addi	a0,a0,-1046 # 800159e8 <tickslock>
    80002e06:	eb7fd0ef          	jal	80000cbc <release>
  return xticks;
}
    80002e0a:	02049513          	slli	a0,s1,0x20
    80002e0e:	9101                	srli	a0,a0,0x20
    80002e10:	60e2                	ld	ra,24(sp)
    80002e12:	6442                	ld	s0,16(sp)
    80002e14:	64a2                	ld	s1,8(sp)
    80002e16:	6105                	addi	sp,sp,32
    80002e18:	8082                	ret

0000000080002e1a <sys_getfilenum>:

uint64 
sys_getfilenum(void){
    80002e1a:	1101                	addi	sp,sp,-32
    80002e1c:	ec06                	sd	ra,24(sp)
    80002e1e:	e822                	sd	s0,16(sp)
    80002e20:	1000                	addi	s0,sp,32
  int pid;
  argint(0,&pid);
    80002e22:	fec40593          	addi	a1,s0,-20
    80002e26:	4501                	li	a0,0
    80002e28:	d53ff0ef          	jal	80002b7a <argint>
  return 0;
}
    80002e2c:	4501                	li	a0,0
    80002e2e:	60e2                	ld	ra,24(sp)
    80002e30:	6442                	ld	s0,16(sp)
    80002e32:	6105                	addi	sp,sp,32
    80002e34:	8082                	ret

0000000080002e36 <sys_getpinfo>:

uint64
sys_getpinfo(void)
{
    80002e36:	1101                	addi	sp,sp,-32
    80002e38:	ec06                	sd	ra,24(sp)
    80002e3a:	e822                	sd	s0,16(sp)
    80002e3c:	1000                	addi	s0,sp,32
    uint64 uaddr;
    argaddr(0, &uaddr);   
    80002e3e:	fe840593          	addi	a1,s0,-24
    80002e42:	4501                	li	a0,0
    80002e44:	d53ff0ef          	jal	80002b96 <argaddr>
    return getpinfo((struct pstat *)uaddr);
    80002e48:	fe843503          	ld	a0,-24(s0)
    80002e4c:	fa4ff0ef          	jal	800025f0 <getpinfo>
}
    80002e50:	60e2                	ld	ra,24(sp)
    80002e52:	6442                	ld	s0,16(sp)
    80002e54:	6105                	addi	sp,sp,32
    80002e56:	8082                	ret

0000000080002e58 <sys_setStride>:

uint64
sys_setStride(void)
{
    80002e58:	1101                	addi	sp,sp,-32
    80002e5a:	ec06                	sd	ra,24(sp)
    80002e5c:	e822                	sd	s0,16(sp)
    80002e5e:	1000                	addi	s0,sp,32
    int strideLength;
    argint(0, &strideLength);  
    80002e60:	fec40593          	addi	a1,s0,-20
    80002e64:	4501                	li	a0,0
    80002e66:	d15ff0ef          	jal	80002b7a <argint>
    return setStride(strideLength);
    80002e6a:	fec42503          	lw	a0,-20(s0)
    80002e6e:	85bff0ef          	jal	800026c8 <setStride>
}
    80002e72:	60e2                	ld	ra,24(sp)
    80002e74:	6442                	ld	s0,16(sp)
    80002e76:	6105                	addi	sp,sp,32
    80002e78:	8082                	ret

0000000080002e7a <sys_pgaccess>:

uint64
sys_pgaccess(void)
{
    80002e7a:	7139                	addi	sp,sp,-64
    80002e7c:	fc06                	sd	ra,56(sp)
    80002e7e:	f822                	sd	s0,48(sp)
    80002e80:	f426                	sd	s1,40(sp)
    80002e82:	0080                	addi	s0,sp,64
  uint64 va, user_addr;
  int n;
  uint64 mask = 0;
    80002e84:	fc043023          	sd	zero,-64(s0)
  argaddr(0, &va);
    80002e88:	fd840593          	addi	a1,s0,-40
    80002e8c:	4501                	li	a0,0
    80002e8e:	d09ff0ef          	jal	80002b96 <argaddr>
  argint(1, &n);
    80002e92:	fcc40593          	addi	a1,s0,-52
    80002e96:	4505                	li	a0,1
    80002e98:	ce3ff0ef          	jal	80002b7a <argint>
  argaddr(2, &user_addr);
    80002e9c:	fd040593          	addi	a1,s0,-48
    80002ea0:	4509                	li	a0,2
    80002ea2:	cf5ff0ef          	jal	80002b96 <argaddr>
  pgaccess(myproc()->pagetable, va, n, &mask);
    80002ea6:	be3fe0ef          	jal	80001a88 <myproc>
    80002eaa:	fc040493          	addi	s1,s0,-64
    80002eae:	86a6                	mv	a3,s1
    80002eb0:	fcc42603          	lw	a2,-52(s0)
    80002eb4:	fd843583          	ld	a1,-40(s0)
    80002eb8:	6d28                	ld	a0,88(a0)
    80002eba:	9adfe0ef          	jal	80001866 <pgaccess>
  copyout(myproc()->pagetable, user_addr, (char*)&mask, sizeof(mask));
    80002ebe:	bcbfe0ef          	jal	80001a88 <myproc>
    80002ec2:	46a1                	li	a3,8
    80002ec4:	8626                	mv	a2,s1
    80002ec6:	fd043583          	ld	a1,-48(s0)
    80002eca:	6d28                	ld	a0,88(a0)
    80002ecc:	823fe0ef          	jal	800016ee <copyout>
  return 0;
}
    80002ed0:	4501                	li	a0,0
    80002ed2:	70e2                	ld	ra,56(sp)
    80002ed4:	7442                	ld	s0,48(sp)
    80002ed6:	74a2                	ld	s1,40(sp)
    80002ed8:	6121                	addi	sp,sp,64
    80002eda:	8082                	ret

0000000080002edc <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002edc:	7179                	addi	sp,sp,-48
    80002ede:	f406                	sd	ra,40(sp)
    80002ee0:	f022                	sd	s0,32(sp)
    80002ee2:	ec26                	sd	s1,24(sp)
    80002ee4:	e84a                	sd	s2,16(sp)
    80002ee6:	e44e                	sd	s3,8(sp)
    80002ee8:	e052                	sd	s4,0(sp)
    80002eea:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002eec:	00004597          	auipc	a1,0x4
    80002ef0:	4d458593          	addi	a1,a1,1236 # 800073c0 <etext+0x3c0>
    80002ef4:	00013517          	auipc	a0,0x13
    80002ef8:	b0c50513          	addi	a0,a0,-1268 # 80015a00 <bcache>
    80002efc:	ca3fd0ef          	jal	80000b9e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002f00:	0001b797          	auipc	a5,0x1b
    80002f04:	b0078793          	addi	a5,a5,-1280 # 8001da00 <bcache+0x8000>
    80002f08:	0001b717          	auipc	a4,0x1b
    80002f0c:	d6070713          	addi	a4,a4,-672 # 8001dc68 <bcache+0x8268>
    80002f10:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002f14:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f18:	00013497          	auipc	s1,0x13
    80002f1c:	b0048493          	addi	s1,s1,-1280 # 80015a18 <bcache+0x18>
    b->next = bcache.head.next;
    80002f20:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002f22:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002f24:	00004a17          	auipc	s4,0x4
    80002f28:	4a4a0a13          	addi	s4,s4,1188 # 800073c8 <etext+0x3c8>
    b->next = bcache.head.next;
    80002f2c:	2b893783          	ld	a5,696(s2)
    80002f30:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002f32:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002f36:	85d2                	mv	a1,s4
    80002f38:	01048513          	addi	a0,s1,16
    80002f3c:	328010ef          	jal	80004264 <initsleeplock>
    bcache.head.next->prev = b;
    80002f40:	2b893783          	ld	a5,696(s2)
    80002f44:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002f46:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f4a:	45848493          	addi	s1,s1,1112
    80002f4e:	fd349fe3          	bne	s1,s3,80002f2c <binit+0x50>
  }
}
    80002f52:	70a2                	ld	ra,40(sp)
    80002f54:	7402                	ld	s0,32(sp)
    80002f56:	64e2                	ld	s1,24(sp)
    80002f58:	6942                	ld	s2,16(sp)
    80002f5a:	69a2                	ld	s3,8(sp)
    80002f5c:	6a02                	ld	s4,0(sp)
    80002f5e:	6145                	addi	sp,sp,48
    80002f60:	8082                	ret

0000000080002f62 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002f62:	7179                	addi	sp,sp,-48
    80002f64:	f406                	sd	ra,40(sp)
    80002f66:	f022                	sd	s0,32(sp)
    80002f68:	ec26                	sd	s1,24(sp)
    80002f6a:	e84a                	sd	s2,16(sp)
    80002f6c:	e44e                	sd	s3,8(sp)
    80002f6e:	1800                	addi	s0,sp,48
    80002f70:	892a                	mv	s2,a0
    80002f72:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002f74:	00013517          	auipc	a0,0x13
    80002f78:	a8c50513          	addi	a0,a0,-1396 # 80015a00 <bcache>
    80002f7c:	cadfd0ef          	jal	80000c28 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002f80:	0001b497          	auipc	s1,0x1b
    80002f84:	d384b483          	ld	s1,-712(s1) # 8001dcb8 <bcache+0x82b8>
    80002f88:	0001b797          	auipc	a5,0x1b
    80002f8c:	ce078793          	addi	a5,a5,-800 # 8001dc68 <bcache+0x8268>
    80002f90:	02f48b63          	beq	s1,a5,80002fc6 <bread+0x64>
    80002f94:	873e                	mv	a4,a5
    80002f96:	a021                	j	80002f9e <bread+0x3c>
    80002f98:	68a4                	ld	s1,80(s1)
    80002f9a:	02e48663          	beq	s1,a4,80002fc6 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002f9e:	449c                	lw	a5,8(s1)
    80002fa0:	ff279ce3          	bne	a5,s2,80002f98 <bread+0x36>
    80002fa4:	44dc                	lw	a5,12(s1)
    80002fa6:	ff3799e3          	bne	a5,s3,80002f98 <bread+0x36>
      b->refcnt++;
    80002faa:	40bc                	lw	a5,64(s1)
    80002fac:	2785                	addiw	a5,a5,1
    80002fae:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002fb0:	00013517          	auipc	a0,0x13
    80002fb4:	a5050513          	addi	a0,a0,-1456 # 80015a00 <bcache>
    80002fb8:	d05fd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002fbc:	01048513          	addi	a0,s1,16
    80002fc0:	2da010ef          	jal	8000429a <acquiresleep>
      return b;
    80002fc4:	a889                	j	80003016 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002fc6:	0001b497          	auipc	s1,0x1b
    80002fca:	cea4b483          	ld	s1,-790(s1) # 8001dcb0 <bcache+0x82b0>
    80002fce:	0001b797          	auipc	a5,0x1b
    80002fd2:	c9a78793          	addi	a5,a5,-870 # 8001dc68 <bcache+0x8268>
    80002fd6:	00f48863          	beq	s1,a5,80002fe6 <bread+0x84>
    80002fda:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002fdc:	40bc                	lw	a5,64(s1)
    80002fde:	cb91                	beqz	a5,80002ff2 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002fe0:	64a4                	ld	s1,72(s1)
    80002fe2:	fee49de3          	bne	s1,a4,80002fdc <bread+0x7a>
  panic("bget: no buffers");
    80002fe6:	00004517          	auipc	a0,0x4
    80002fea:	3ea50513          	addi	a0,a0,1002 # 800073d0 <etext+0x3d0>
    80002fee:	837fd0ef          	jal	80000824 <panic>
      b->dev = dev;
    80002ff2:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002ff6:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002ffa:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002ffe:	4785                	li	a5,1
    80003000:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003002:	00013517          	auipc	a0,0x13
    80003006:	9fe50513          	addi	a0,a0,-1538 # 80015a00 <bcache>
    8000300a:	cb3fd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    8000300e:	01048513          	addi	a0,s1,16
    80003012:	288010ef          	jal	8000429a <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80003016:	409c                	lw	a5,0(s1)
    80003018:	cb89                	beqz	a5,8000302a <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000301a:	8526                	mv	a0,s1
    8000301c:	70a2                	ld	ra,40(sp)
    8000301e:	7402                	ld	s0,32(sp)
    80003020:	64e2                	ld	s1,24(sp)
    80003022:	6942                	ld	s2,16(sp)
    80003024:	69a2                	ld	s3,8(sp)
    80003026:	6145                	addi	sp,sp,48
    80003028:	8082                	ret
    virtio_disk_rw(b, 0);
    8000302a:	4581                	li	a1,0
    8000302c:	8526                	mv	a0,s1
    8000302e:	303020ef          	jal	80005b30 <virtio_disk_rw>
    b->valid = 1;
    80003032:	4785                	li	a5,1
    80003034:	c09c                	sw	a5,0(s1)
  return b;
    80003036:	b7d5                	j	8000301a <bread+0xb8>

0000000080003038 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80003038:	1101                	addi	sp,sp,-32
    8000303a:	ec06                	sd	ra,24(sp)
    8000303c:	e822                	sd	s0,16(sp)
    8000303e:	e426                	sd	s1,8(sp)
    80003040:	1000                	addi	s0,sp,32
    80003042:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003044:	0541                	addi	a0,a0,16
    80003046:	2d2010ef          	jal	80004318 <holdingsleep>
    8000304a:	c911                	beqz	a0,8000305e <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000304c:	4585                	li	a1,1
    8000304e:	8526                	mv	a0,s1
    80003050:	2e1020ef          	jal	80005b30 <virtio_disk_rw>
}
    80003054:	60e2                	ld	ra,24(sp)
    80003056:	6442                	ld	s0,16(sp)
    80003058:	64a2                	ld	s1,8(sp)
    8000305a:	6105                	addi	sp,sp,32
    8000305c:	8082                	ret
    panic("bwrite");
    8000305e:	00004517          	auipc	a0,0x4
    80003062:	38a50513          	addi	a0,a0,906 # 800073e8 <etext+0x3e8>
    80003066:	fbefd0ef          	jal	80000824 <panic>

000000008000306a <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000306a:	1101                	addi	sp,sp,-32
    8000306c:	ec06                	sd	ra,24(sp)
    8000306e:	e822                	sd	s0,16(sp)
    80003070:	e426                	sd	s1,8(sp)
    80003072:	e04a                	sd	s2,0(sp)
    80003074:	1000                	addi	s0,sp,32
    80003076:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003078:	01050913          	addi	s2,a0,16
    8000307c:	854a                	mv	a0,s2
    8000307e:	29a010ef          	jal	80004318 <holdingsleep>
    80003082:	c125                	beqz	a0,800030e2 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80003084:	854a                	mv	a0,s2
    80003086:	25a010ef          	jal	800042e0 <releasesleep>

  acquire(&bcache.lock);
    8000308a:	00013517          	auipc	a0,0x13
    8000308e:	97650513          	addi	a0,a0,-1674 # 80015a00 <bcache>
    80003092:	b97fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80003096:	40bc                	lw	a5,64(s1)
    80003098:	37fd                	addiw	a5,a5,-1
    8000309a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000309c:	e79d                	bnez	a5,800030ca <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000309e:	68b8                	ld	a4,80(s1)
    800030a0:	64bc                	ld	a5,72(s1)
    800030a2:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800030a4:	68b8                	ld	a4,80(s1)
    800030a6:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800030a8:	0001b797          	auipc	a5,0x1b
    800030ac:	95878793          	addi	a5,a5,-1704 # 8001da00 <bcache+0x8000>
    800030b0:	2b87b703          	ld	a4,696(a5)
    800030b4:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800030b6:	0001b717          	auipc	a4,0x1b
    800030ba:	bb270713          	addi	a4,a4,-1102 # 8001dc68 <bcache+0x8268>
    800030be:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800030c0:	2b87b703          	ld	a4,696(a5)
    800030c4:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800030c6:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800030ca:	00013517          	auipc	a0,0x13
    800030ce:	93650513          	addi	a0,a0,-1738 # 80015a00 <bcache>
    800030d2:	bebfd0ef          	jal	80000cbc <release>
}
    800030d6:	60e2                	ld	ra,24(sp)
    800030d8:	6442                	ld	s0,16(sp)
    800030da:	64a2                	ld	s1,8(sp)
    800030dc:	6902                	ld	s2,0(sp)
    800030de:	6105                	addi	sp,sp,32
    800030e0:	8082                	ret
    panic("brelse");
    800030e2:	00004517          	auipc	a0,0x4
    800030e6:	30e50513          	addi	a0,a0,782 # 800073f0 <etext+0x3f0>
    800030ea:	f3afd0ef          	jal	80000824 <panic>

00000000800030ee <bpin>:

void
bpin(struct buf *b) {
    800030ee:	1101                	addi	sp,sp,-32
    800030f0:	ec06                	sd	ra,24(sp)
    800030f2:	e822                	sd	s0,16(sp)
    800030f4:	e426                	sd	s1,8(sp)
    800030f6:	1000                	addi	s0,sp,32
    800030f8:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800030fa:	00013517          	auipc	a0,0x13
    800030fe:	90650513          	addi	a0,a0,-1786 # 80015a00 <bcache>
    80003102:	b27fd0ef          	jal	80000c28 <acquire>
  b->refcnt++;
    80003106:	40bc                	lw	a5,64(s1)
    80003108:	2785                	addiw	a5,a5,1
    8000310a:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000310c:	00013517          	auipc	a0,0x13
    80003110:	8f450513          	addi	a0,a0,-1804 # 80015a00 <bcache>
    80003114:	ba9fd0ef          	jal	80000cbc <release>
}
    80003118:	60e2                	ld	ra,24(sp)
    8000311a:	6442                	ld	s0,16(sp)
    8000311c:	64a2                	ld	s1,8(sp)
    8000311e:	6105                	addi	sp,sp,32
    80003120:	8082                	ret

0000000080003122 <bunpin>:

void
bunpin(struct buf *b) {
    80003122:	1101                	addi	sp,sp,-32
    80003124:	ec06                	sd	ra,24(sp)
    80003126:	e822                	sd	s0,16(sp)
    80003128:	e426                	sd	s1,8(sp)
    8000312a:	1000                	addi	s0,sp,32
    8000312c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000312e:	00013517          	auipc	a0,0x13
    80003132:	8d250513          	addi	a0,a0,-1838 # 80015a00 <bcache>
    80003136:	af3fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    8000313a:	40bc                	lw	a5,64(s1)
    8000313c:	37fd                	addiw	a5,a5,-1
    8000313e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003140:	00013517          	auipc	a0,0x13
    80003144:	8c050513          	addi	a0,a0,-1856 # 80015a00 <bcache>
    80003148:	b75fd0ef          	jal	80000cbc <release>
}
    8000314c:	60e2                	ld	ra,24(sp)
    8000314e:	6442                	ld	s0,16(sp)
    80003150:	64a2                	ld	s1,8(sp)
    80003152:	6105                	addi	sp,sp,32
    80003154:	8082                	ret

0000000080003156 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003156:	1101                	addi	sp,sp,-32
    80003158:	ec06                	sd	ra,24(sp)
    8000315a:	e822                	sd	s0,16(sp)
    8000315c:	e426                	sd	s1,8(sp)
    8000315e:	e04a                	sd	s2,0(sp)
    80003160:	1000                	addi	s0,sp,32
    80003162:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003164:	00d5d79b          	srliw	a5,a1,0xd
    80003168:	0001b597          	auipc	a1,0x1b
    8000316c:	f745a583          	lw	a1,-140(a1) # 8001e0dc <sb+0x1c>
    80003170:	9dbd                	addw	a1,a1,a5
    80003172:	df1ff0ef          	jal	80002f62 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003176:	0074f713          	andi	a4,s1,7
    8000317a:	4785                	li	a5,1
    8000317c:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80003180:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80003182:	90d9                	srli	s1,s1,0x36
    80003184:	00950733          	add	a4,a0,s1
    80003188:	05874703          	lbu	a4,88(a4)
    8000318c:	00e7f6b3          	and	a3,a5,a4
    80003190:	c29d                	beqz	a3,800031b6 <bfree+0x60>
    80003192:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003194:	94aa                	add	s1,s1,a0
    80003196:	fff7c793          	not	a5,a5
    8000319a:	8f7d                	and	a4,a4,a5
    8000319c:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800031a0:	000010ef          	jal	800041a0 <log_write>
  brelse(bp);
    800031a4:	854a                	mv	a0,s2
    800031a6:	ec5ff0ef          	jal	8000306a <brelse>
}
    800031aa:	60e2                	ld	ra,24(sp)
    800031ac:	6442                	ld	s0,16(sp)
    800031ae:	64a2                	ld	s1,8(sp)
    800031b0:	6902                	ld	s2,0(sp)
    800031b2:	6105                	addi	sp,sp,32
    800031b4:	8082                	ret
    panic("freeing free block");
    800031b6:	00004517          	auipc	a0,0x4
    800031ba:	24250513          	addi	a0,a0,578 # 800073f8 <etext+0x3f8>
    800031be:	e66fd0ef          	jal	80000824 <panic>

00000000800031c2 <balloc>:
{
    800031c2:	715d                	addi	sp,sp,-80
    800031c4:	e486                	sd	ra,72(sp)
    800031c6:	e0a2                	sd	s0,64(sp)
    800031c8:	fc26                	sd	s1,56(sp)
    800031ca:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800031cc:	0001b797          	auipc	a5,0x1b
    800031d0:	ef87a783          	lw	a5,-264(a5) # 8001e0c4 <sb+0x4>
    800031d4:	0e078263          	beqz	a5,800032b8 <balloc+0xf6>
    800031d8:	f84a                	sd	s2,48(sp)
    800031da:	f44e                	sd	s3,40(sp)
    800031dc:	f052                	sd	s4,32(sp)
    800031de:	ec56                	sd	s5,24(sp)
    800031e0:	e85a                	sd	s6,16(sp)
    800031e2:	e45e                	sd	s7,8(sp)
    800031e4:	e062                	sd	s8,0(sp)
    800031e6:	8baa                	mv	s7,a0
    800031e8:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800031ea:	0001bb17          	auipc	s6,0x1b
    800031ee:	ed6b0b13          	addi	s6,s6,-298 # 8001e0c0 <sb>
      m = 1 << (bi % 8);
    800031f2:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800031f4:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800031f6:	6c09                	lui	s8,0x2
    800031f8:	a09d                	j	8000325e <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    800031fa:	97ca                	add	a5,a5,s2
    800031fc:	8e55                	or	a2,a2,a3
    800031fe:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003202:	854a                	mv	a0,s2
    80003204:	79d000ef          	jal	800041a0 <log_write>
        brelse(bp);
    80003208:	854a                	mv	a0,s2
    8000320a:	e61ff0ef          	jal	8000306a <brelse>
  bp = bread(dev, bno);
    8000320e:	85a6                	mv	a1,s1
    80003210:	855e                	mv	a0,s7
    80003212:	d51ff0ef          	jal	80002f62 <bread>
    80003216:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003218:	40000613          	li	a2,1024
    8000321c:	4581                	li	a1,0
    8000321e:	05850513          	addi	a0,a0,88
    80003222:	ad7fd0ef          	jal	80000cf8 <memset>
  log_write(bp);
    80003226:	854a                	mv	a0,s2
    80003228:	779000ef          	jal	800041a0 <log_write>
  brelse(bp);
    8000322c:	854a                	mv	a0,s2
    8000322e:	e3dff0ef          	jal	8000306a <brelse>
}
    80003232:	7942                	ld	s2,48(sp)
    80003234:	79a2                	ld	s3,40(sp)
    80003236:	7a02                	ld	s4,32(sp)
    80003238:	6ae2                	ld	s5,24(sp)
    8000323a:	6b42                	ld	s6,16(sp)
    8000323c:	6ba2                	ld	s7,8(sp)
    8000323e:	6c02                	ld	s8,0(sp)
}
    80003240:	8526                	mv	a0,s1
    80003242:	60a6                	ld	ra,72(sp)
    80003244:	6406                	ld	s0,64(sp)
    80003246:	74e2                	ld	s1,56(sp)
    80003248:	6161                	addi	sp,sp,80
    8000324a:	8082                	ret
    brelse(bp);
    8000324c:	854a                	mv	a0,s2
    8000324e:	e1dff0ef          	jal	8000306a <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80003252:	015c0abb          	addw	s5,s8,s5
    80003256:	004b2783          	lw	a5,4(s6)
    8000325a:	04faf863          	bgeu	s5,a5,800032aa <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    8000325e:	40dad59b          	sraiw	a1,s5,0xd
    80003262:	01cb2783          	lw	a5,28(s6)
    80003266:	9dbd                	addw	a1,a1,a5
    80003268:	855e                	mv	a0,s7
    8000326a:	cf9ff0ef          	jal	80002f62 <bread>
    8000326e:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003270:	004b2503          	lw	a0,4(s6)
    80003274:	84d6                	mv	s1,s5
    80003276:	4701                	li	a4,0
    80003278:	fca4fae3          	bgeu	s1,a0,8000324c <balloc+0x8a>
      m = 1 << (bi % 8);
    8000327c:	00777693          	andi	a3,a4,7
    80003280:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80003284:	41f7579b          	sraiw	a5,a4,0x1f
    80003288:	01d7d79b          	srliw	a5,a5,0x1d
    8000328c:	9fb9                	addw	a5,a5,a4
    8000328e:	4037d79b          	sraiw	a5,a5,0x3
    80003292:	00f90633          	add	a2,s2,a5
    80003296:	05864603          	lbu	a2,88(a2)
    8000329a:	00c6f5b3          	and	a1,a3,a2
    8000329e:	ddb1                	beqz	a1,800031fa <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800032a0:	2705                	addiw	a4,a4,1
    800032a2:	2485                	addiw	s1,s1,1
    800032a4:	fd471ae3          	bne	a4,s4,80003278 <balloc+0xb6>
    800032a8:	b755                	j	8000324c <balloc+0x8a>
    800032aa:	7942                	ld	s2,48(sp)
    800032ac:	79a2                	ld	s3,40(sp)
    800032ae:	7a02                	ld	s4,32(sp)
    800032b0:	6ae2                	ld	s5,24(sp)
    800032b2:	6b42                	ld	s6,16(sp)
    800032b4:	6ba2                	ld	s7,8(sp)
    800032b6:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    800032b8:	00004517          	auipc	a0,0x4
    800032bc:	15850513          	addi	a0,a0,344 # 80007410 <etext+0x410>
    800032c0:	a3afd0ef          	jal	800004fa <printf>
  return 0;
    800032c4:	4481                	li	s1,0
    800032c6:	bfad                	j	80003240 <balloc+0x7e>

00000000800032c8 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800032c8:	7179                	addi	sp,sp,-48
    800032ca:	f406                	sd	ra,40(sp)
    800032cc:	f022                	sd	s0,32(sp)
    800032ce:	ec26                	sd	s1,24(sp)
    800032d0:	e84a                	sd	s2,16(sp)
    800032d2:	e44e                	sd	s3,8(sp)
    800032d4:	1800                	addi	s0,sp,48
    800032d6:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800032d8:	47ad                	li	a5,11
    800032da:	02b7e363          	bltu	a5,a1,80003300 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800032de:	02059793          	slli	a5,a1,0x20
    800032e2:	01e7d593          	srli	a1,a5,0x1e
    800032e6:	00b509b3          	add	s3,a0,a1
    800032ea:	0509a483          	lw	s1,80(s3)
    800032ee:	e0b5                	bnez	s1,80003352 <bmap+0x8a>
      addr = balloc(ip->dev);
    800032f0:	4108                	lw	a0,0(a0)
    800032f2:	ed1ff0ef          	jal	800031c2 <balloc>
    800032f6:	84aa                	mv	s1,a0
      if(addr == 0)
    800032f8:	cd29                	beqz	a0,80003352 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    800032fa:	04a9a823          	sw	a0,80(s3)
    800032fe:	a891                	j	80003352 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003300:	ff45879b          	addiw	a5,a1,-12
    80003304:	873e                	mv	a4,a5
    80003306:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80003308:	0ff00793          	li	a5,255
    8000330c:	06e7e763          	bltu	a5,a4,8000337a <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003310:	08052483          	lw	s1,128(a0)
    80003314:	e891                	bnez	s1,80003328 <bmap+0x60>
      addr = balloc(ip->dev);
    80003316:	4108                	lw	a0,0(a0)
    80003318:	eabff0ef          	jal	800031c2 <balloc>
    8000331c:	84aa                	mv	s1,a0
      if(addr == 0)
    8000331e:	c915                	beqz	a0,80003352 <bmap+0x8a>
    80003320:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003322:	08a92023          	sw	a0,128(s2)
    80003326:	a011                	j	8000332a <bmap+0x62>
    80003328:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000332a:	85a6                	mv	a1,s1
    8000332c:	00092503          	lw	a0,0(s2)
    80003330:	c33ff0ef          	jal	80002f62 <bread>
    80003334:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003336:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000333a:	02099713          	slli	a4,s3,0x20
    8000333e:	01e75593          	srli	a1,a4,0x1e
    80003342:	97ae                	add	a5,a5,a1
    80003344:	89be                	mv	s3,a5
    80003346:	4384                	lw	s1,0(a5)
    80003348:	cc89                	beqz	s1,80003362 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000334a:	8552                	mv	a0,s4
    8000334c:	d1fff0ef          	jal	8000306a <brelse>
    return addr;
    80003350:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003352:	8526                	mv	a0,s1
    80003354:	70a2                	ld	ra,40(sp)
    80003356:	7402                	ld	s0,32(sp)
    80003358:	64e2                	ld	s1,24(sp)
    8000335a:	6942                	ld	s2,16(sp)
    8000335c:	69a2                	ld	s3,8(sp)
    8000335e:	6145                	addi	sp,sp,48
    80003360:	8082                	ret
      addr = balloc(ip->dev);
    80003362:	00092503          	lw	a0,0(s2)
    80003366:	e5dff0ef          	jal	800031c2 <balloc>
    8000336a:	84aa                	mv	s1,a0
      if(addr){
    8000336c:	dd79                	beqz	a0,8000334a <bmap+0x82>
        a[bn] = addr;
    8000336e:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80003372:	8552                	mv	a0,s4
    80003374:	62d000ef          	jal	800041a0 <log_write>
    80003378:	bfc9                	j	8000334a <bmap+0x82>
    8000337a:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000337c:	00004517          	auipc	a0,0x4
    80003380:	0ac50513          	addi	a0,a0,172 # 80007428 <etext+0x428>
    80003384:	ca0fd0ef          	jal	80000824 <panic>

0000000080003388 <iget>:
{
    80003388:	7179                	addi	sp,sp,-48
    8000338a:	f406                	sd	ra,40(sp)
    8000338c:	f022                	sd	s0,32(sp)
    8000338e:	ec26                	sd	s1,24(sp)
    80003390:	e84a                	sd	s2,16(sp)
    80003392:	e44e                	sd	s3,8(sp)
    80003394:	e052                	sd	s4,0(sp)
    80003396:	1800                	addi	s0,sp,48
    80003398:	892a                	mv	s2,a0
    8000339a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000339c:	0001b517          	auipc	a0,0x1b
    800033a0:	d4450513          	addi	a0,a0,-700 # 8001e0e0 <itable>
    800033a4:	885fd0ef          	jal	80000c28 <acquire>
  empty = 0;
    800033a8:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800033aa:	0001b497          	auipc	s1,0x1b
    800033ae:	d4e48493          	addi	s1,s1,-690 # 8001e0f8 <itable+0x18>
    800033b2:	0001c697          	auipc	a3,0x1c
    800033b6:	7d668693          	addi	a3,a3,2006 # 8001fb88 <log>
    800033ba:	a809                	j	800033cc <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800033bc:	e781                	bnez	a5,800033c4 <iget+0x3c>
    800033be:	00099363          	bnez	s3,800033c4 <iget+0x3c>
      empty = ip;
    800033c2:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800033c4:	08848493          	addi	s1,s1,136
    800033c8:	02d48563          	beq	s1,a3,800033f2 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800033cc:	449c                	lw	a5,8(s1)
    800033ce:	fef057e3          	blez	a5,800033bc <iget+0x34>
    800033d2:	4098                	lw	a4,0(s1)
    800033d4:	ff2718e3          	bne	a4,s2,800033c4 <iget+0x3c>
    800033d8:	40d8                	lw	a4,4(s1)
    800033da:	ff4715e3          	bne	a4,s4,800033c4 <iget+0x3c>
      ip->ref++;
    800033de:	2785                	addiw	a5,a5,1
    800033e0:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800033e2:	0001b517          	auipc	a0,0x1b
    800033e6:	cfe50513          	addi	a0,a0,-770 # 8001e0e0 <itable>
    800033ea:	8d3fd0ef          	jal	80000cbc <release>
      return ip;
    800033ee:	89a6                	mv	s3,s1
    800033f0:	a015                	j	80003414 <iget+0x8c>
  if(empty == 0)
    800033f2:	02098a63          	beqz	s3,80003426 <iget+0x9e>
  ip->dev = dev;
    800033f6:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800033fa:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800033fe:	4785                	li	a5,1
    80003400:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80003404:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    80003408:	0001b517          	auipc	a0,0x1b
    8000340c:	cd850513          	addi	a0,a0,-808 # 8001e0e0 <itable>
    80003410:	8adfd0ef          	jal	80000cbc <release>
}
    80003414:	854e                	mv	a0,s3
    80003416:	70a2                	ld	ra,40(sp)
    80003418:	7402                	ld	s0,32(sp)
    8000341a:	64e2                	ld	s1,24(sp)
    8000341c:	6942                	ld	s2,16(sp)
    8000341e:	69a2                	ld	s3,8(sp)
    80003420:	6a02                	ld	s4,0(sp)
    80003422:	6145                	addi	sp,sp,48
    80003424:	8082                	ret
    panic("iget: no inodes");
    80003426:	00004517          	auipc	a0,0x4
    8000342a:	01a50513          	addi	a0,a0,26 # 80007440 <etext+0x440>
    8000342e:	bf6fd0ef          	jal	80000824 <panic>

0000000080003432 <iinit>:
{
    80003432:	7179                	addi	sp,sp,-48
    80003434:	f406                	sd	ra,40(sp)
    80003436:	f022                	sd	s0,32(sp)
    80003438:	ec26                	sd	s1,24(sp)
    8000343a:	e84a                	sd	s2,16(sp)
    8000343c:	e44e                	sd	s3,8(sp)
    8000343e:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003440:	00004597          	auipc	a1,0x4
    80003444:	01058593          	addi	a1,a1,16 # 80007450 <etext+0x450>
    80003448:	0001b517          	auipc	a0,0x1b
    8000344c:	c9850513          	addi	a0,a0,-872 # 8001e0e0 <itable>
    80003450:	f4efd0ef          	jal	80000b9e <initlock>
  for(i = 0; i < NINODE; i++) {
    80003454:	0001b497          	auipc	s1,0x1b
    80003458:	cb448493          	addi	s1,s1,-844 # 8001e108 <itable+0x28>
    8000345c:	0001c997          	auipc	s3,0x1c
    80003460:	73c98993          	addi	s3,s3,1852 # 8001fb98 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003464:	00004917          	auipc	s2,0x4
    80003468:	ff490913          	addi	s2,s2,-12 # 80007458 <etext+0x458>
    8000346c:	85ca                	mv	a1,s2
    8000346e:	8526                	mv	a0,s1
    80003470:	5f5000ef          	jal	80004264 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003474:	08848493          	addi	s1,s1,136
    80003478:	ff349ae3          	bne	s1,s3,8000346c <iinit+0x3a>
}
    8000347c:	70a2                	ld	ra,40(sp)
    8000347e:	7402                	ld	s0,32(sp)
    80003480:	64e2                	ld	s1,24(sp)
    80003482:	6942                	ld	s2,16(sp)
    80003484:	69a2                	ld	s3,8(sp)
    80003486:	6145                	addi	sp,sp,48
    80003488:	8082                	ret

000000008000348a <ialloc>:
{
    8000348a:	7139                	addi	sp,sp,-64
    8000348c:	fc06                	sd	ra,56(sp)
    8000348e:	f822                	sd	s0,48(sp)
    80003490:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003492:	0001b717          	auipc	a4,0x1b
    80003496:	c3a72703          	lw	a4,-966(a4) # 8001e0cc <sb+0xc>
    8000349a:	4785                	li	a5,1
    8000349c:	06e7f063          	bgeu	a5,a4,800034fc <ialloc+0x72>
    800034a0:	f426                	sd	s1,40(sp)
    800034a2:	f04a                	sd	s2,32(sp)
    800034a4:	ec4e                	sd	s3,24(sp)
    800034a6:	e852                	sd	s4,16(sp)
    800034a8:	e456                	sd	s5,8(sp)
    800034aa:	e05a                	sd	s6,0(sp)
    800034ac:	8aaa                	mv	s5,a0
    800034ae:	8b2e                	mv	s6,a1
    800034b0:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800034b2:	0001ba17          	auipc	s4,0x1b
    800034b6:	c0ea0a13          	addi	s4,s4,-1010 # 8001e0c0 <sb>
    800034ba:	00495593          	srli	a1,s2,0x4
    800034be:	018a2783          	lw	a5,24(s4)
    800034c2:	9dbd                	addw	a1,a1,a5
    800034c4:	8556                	mv	a0,s5
    800034c6:	a9dff0ef          	jal	80002f62 <bread>
    800034ca:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800034cc:	05850993          	addi	s3,a0,88
    800034d0:	00f97793          	andi	a5,s2,15
    800034d4:	079a                	slli	a5,a5,0x6
    800034d6:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800034d8:	00099783          	lh	a5,0(s3)
    800034dc:	cb9d                	beqz	a5,80003512 <ialloc+0x88>
    brelse(bp);
    800034de:	b8dff0ef          	jal	8000306a <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800034e2:	0905                	addi	s2,s2,1
    800034e4:	00ca2703          	lw	a4,12(s4)
    800034e8:	0009079b          	sext.w	a5,s2
    800034ec:	fce7e7e3          	bltu	a5,a4,800034ba <ialloc+0x30>
    800034f0:	74a2                	ld	s1,40(sp)
    800034f2:	7902                	ld	s2,32(sp)
    800034f4:	69e2                	ld	s3,24(sp)
    800034f6:	6a42                	ld	s4,16(sp)
    800034f8:	6aa2                	ld	s5,8(sp)
    800034fa:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800034fc:	00004517          	auipc	a0,0x4
    80003500:	f6450513          	addi	a0,a0,-156 # 80007460 <etext+0x460>
    80003504:	ff7fc0ef          	jal	800004fa <printf>
  return 0;
    80003508:	4501                	li	a0,0
}
    8000350a:	70e2                	ld	ra,56(sp)
    8000350c:	7442                	ld	s0,48(sp)
    8000350e:	6121                	addi	sp,sp,64
    80003510:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003512:	04000613          	li	a2,64
    80003516:	4581                	li	a1,0
    80003518:	854e                	mv	a0,s3
    8000351a:	fdefd0ef          	jal	80000cf8 <memset>
      dip->type = type;
    8000351e:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003522:	8526                	mv	a0,s1
    80003524:	47d000ef          	jal	800041a0 <log_write>
      brelse(bp);
    80003528:	8526                	mv	a0,s1
    8000352a:	b41ff0ef          	jal	8000306a <brelse>
      return iget(dev, inum);
    8000352e:	0009059b          	sext.w	a1,s2
    80003532:	8556                	mv	a0,s5
    80003534:	e55ff0ef          	jal	80003388 <iget>
    80003538:	74a2                	ld	s1,40(sp)
    8000353a:	7902                	ld	s2,32(sp)
    8000353c:	69e2                	ld	s3,24(sp)
    8000353e:	6a42                	ld	s4,16(sp)
    80003540:	6aa2                	ld	s5,8(sp)
    80003542:	6b02                	ld	s6,0(sp)
    80003544:	b7d9                	j	8000350a <ialloc+0x80>

0000000080003546 <iupdate>:
{
    80003546:	1101                	addi	sp,sp,-32
    80003548:	ec06                	sd	ra,24(sp)
    8000354a:	e822                	sd	s0,16(sp)
    8000354c:	e426                	sd	s1,8(sp)
    8000354e:	e04a                	sd	s2,0(sp)
    80003550:	1000                	addi	s0,sp,32
    80003552:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003554:	415c                	lw	a5,4(a0)
    80003556:	0047d79b          	srliw	a5,a5,0x4
    8000355a:	0001b597          	auipc	a1,0x1b
    8000355e:	b7e5a583          	lw	a1,-1154(a1) # 8001e0d8 <sb+0x18>
    80003562:	9dbd                	addw	a1,a1,a5
    80003564:	4108                	lw	a0,0(a0)
    80003566:	9fdff0ef          	jal	80002f62 <bread>
    8000356a:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000356c:	05850793          	addi	a5,a0,88
    80003570:	40d8                	lw	a4,4(s1)
    80003572:	8b3d                	andi	a4,a4,15
    80003574:	071a                	slli	a4,a4,0x6
    80003576:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003578:	04449703          	lh	a4,68(s1)
    8000357c:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003580:	04649703          	lh	a4,70(s1)
    80003584:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003588:	04849703          	lh	a4,72(s1)
    8000358c:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003590:	04a49703          	lh	a4,74(s1)
    80003594:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003598:	44f8                	lw	a4,76(s1)
    8000359a:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000359c:	03400613          	li	a2,52
    800035a0:	05048593          	addi	a1,s1,80
    800035a4:	00c78513          	addi	a0,a5,12
    800035a8:	fb0fd0ef          	jal	80000d58 <memmove>
  log_write(bp);
    800035ac:	854a                	mv	a0,s2
    800035ae:	3f3000ef          	jal	800041a0 <log_write>
  brelse(bp);
    800035b2:	854a                	mv	a0,s2
    800035b4:	ab7ff0ef          	jal	8000306a <brelse>
}
    800035b8:	60e2                	ld	ra,24(sp)
    800035ba:	6442                	ld	s0,16(sp)
    800035bc:	64a2                	ld	s1,8(sp)
    800035be:	6902                	ld	s2,0(sp)
    800035c0:	6105                	addi	sp,sp,32
    800035c2:	8082                	ret

00000000800035c4 <idup>:
{
    800035c4:	1101                	addi	sp,sp,-32
    800035c6:	ec06                	sd	ra,24(sp)
    800035c8:	e822                	sd	s0,16(sp)
    800035ca:	e426                	sd	s1,8(sp)
    800035cc:	1000                	addi	s0,sp,32
    800035ce:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800035d0:	0001b517          	auipc	a0,0x1b
    800035d4:	b1050513          	addi	a0,a0,-1264 # 8001e0e0 <itable>
    800035d8:	e50fd0ef          	jal	80000c28 <acquire>
  ip->ref++;
    800035dc:	449c                	lw	a5,8(s1)
    800035de:	2785                	addiw	a5,a5,1
    800035e0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800035e2:	0001b517          	auipc	a0,0x1b
    800035e6:	afe50513          	addi	a0,a0,-1282 # 8001e0e0 <itable>
    800035ea:	ed2fd0ef          	jal	80000cbc <release>
}
    800035ee:	8526                	mv	a0,s1
    800035f0:	60e2                	ld	ra,24(sp)
    800035f2:	6442                	ld	s0,16(sp)
    800035f4:	64a2                	ld	s1,8(sp)
    800035f6:	6105                	addi	sp,sp,32
    800035f8:	8082                	ret

00000000800035fa <ilock>:
{
    800035fa:	1101                	addi	sp,sp,-32
    800035fc:	ec06                	sd	ra,24(sp)
    800035fe:	e822                	sd	s0,16(sp)
    80003600:	e426                	sd	s1,8(sp)
    80003602:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003604:	cd19                	beqz	a0,80003622 <ilock+0x28>
    80003606:	84aa                	mv	s1,a0
    80003608:	451c                	lw	a5,8(a0)
    8000360a:	00f05c63          	blez	a5,80003622 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000360e:	0541                	addi	a0,a0,16
    80003610:	48b000ef          	jal	8000429a <acquiresleep>
  if(ip->valid == 0){
    80003614:	40bc                	lw	a5,64(s1)
    80003616:	cf89                	beqz	a5,80003630 <ilock+0x36>
}
    80003618:	60e2                	ld	ra,24(sp)
    8000361a:	6442                	ld	s0,16(sp)
    8000361c:	64a2                	ld	s1,8(sp)
    8000361e:	6105                	addi	sp,sp,32
    80003620:	8082                	ret
    80003622:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003624:	00004517          	auipc	a0,0x4
    80003628:	e5450513          	addi	a0,a0,-428 # 80007478 <etext+0x478>
    8000362c:	9f8fd0ef          	jal	80000824 <panic>
    80003630:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003632:	40dc                	lw	a5,4(s1)
    80003634:	0047d79b          	srliw	a5,a5,0x4
    80003638:	0001b597          	auipc	a1,0x1b
    8000363c:	aa05a583          	lw	a1,-1376(a1) # 8001e0d8 <sb+0x18>
    80003640:	9dbd                	addw	a1,a1,a5
    80003642:	4088                	lw	a0,0(s1)
    80003644:	91fff0ef          	jal	80002f62 <bread>
    80003648:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000364a:	05850593          	addi	a1,a0,88
    8000364e:	40dc                	lw	a5,4(s1)
    80003650:	8bbd                	andi	a5,a5,15
    80003652:	079a                	slli	a5,a5,0x6
    80003654:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003656:	00059783          	lh	a5,0(a1)
    8000365a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000365e:	00259783          	lh	a5,2(a1)
    80003662:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003666:	00459783          	lh	a5,4(a1)
    8000366a:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000366e:	00659783          	lh	a5,6(a1)
    80003672:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003676:	459c                	lw	a5,8(a1)
    80003678:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000367a:	03400613          	li	a2,52
    8000367e:	05b1                	addi	a1,a1,12
    80003680:	05048513          	addi	a0,s1,80
    80003684:	ed4fd0ef          	jal	80000d58 <memmove>
    brelse(bp);
    80003688:	854a                	mv	a0,s2
    8000368a:	9e1ff0ef          	jal	8000306a <brelse>
    ip->valid = 1;
    8000368e:	4785                	li	a5,1
    80003690:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003692:	04449783          	lh	a5,68(s1)
    80003696:	c399                	beqz	a5,8000369c <ilock+0xa2>
    80003698:	6902                	ld	s2,0(sp)
    8000369a:	bfbd                	j	80003618 <ilock+0x1e>
      panic("ilock: no type");
    8000369c:	00004517          	auipc	a0,0x4
    800036a0:	de450513          	addi	a0,a0,-540 # 80007480 <etext+0x480>
    800036a4:	980fd0ef          	jal	80000824 <panic>

00000000800036a8 <iunlock>:
{
    800036a8:	1101                	addi	sp,sp,-32
    800036aa:	ec06                	sd	ra,24(sp)
    800036ac:	e822                	sd	s0,16(sp)
    800036ae:	e426                	sd	s1,8(sp)
    800036b0:	e04a                	sd	s2,0(sp)
    800036b2:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800036b4:	c505                	beqz	a0,800036dc <iunlock+0x34>
    800036b6:	84aa                	mv	s1,a0
    800036b8:	01050913          	addi	s2,a0,16
    800036bc:	854a                	mv	a0,s2
    800036be:	45b000ef          	jal	80004318 <holdingsleep>
    800036c2:	cd09                	beqz	a0,800036dc <iunlock+0x34>
    800036c4:	449c                	lw	a5,8(s1)
    800036c6:	00f05b63          	blez	a5,800036dc <iunlock+0x34>
  releasesleep(&ip->lock);
    800036ca:	854a                	mv	a0,s2
    800036cc:	415000ef          	jal	800042e0 <releasesleep>
}
    800036d0:	60e2                	ld	ra,24(sp)
    800036d2:	6442                	ld	s0,16(sp)
    800036d4:	64a2                	ld	s1,8(sp)
    800036d6:	6902                	ld	s2,0(sp)
    800036d8:	6105                	addi	sp,sp,32
    800036da:	8082                	ret
    panic("iunlock");
    800036dc:	00004517          	auipc	a0,0x4
    800036e0:	db450513          	addi	a0,a0,-588 # 80007490 <etext+0x490>
    800036e4:	940fd0ef          	jal	80000824 <panic>

00000000800036e8 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800036e8:	7179                	addi	sp,sp,-48
    800036ea:	f406                	sd	ra,40(sp)
    800036ec:	f022                	sd	s0,32(sp)
    800036ee:	ec26                	sd	s1,24(sp)
    800036f0:	e84a                	sd	s2,16(sp)
    800036f2:	e44e                	sd	s3,8(sp)
    800036f4:	1800                	addi	s0,sp,48
    800036f6:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800036f8:	05050493          	addi	s1,a0,80
    800036fc:	08050913          	addi	s2,a0,128
    80003700:	a021                	j	80003708 <itrunc+0x20>
    80003702:	0491                	addi	s1,s1,4
    80003704:	01248b63          	beq	s1,s2,8000371a <itrunc+0x32>
    if(ip->addrs[i]){
    80003708:	408c                	lw	a1,0(s1)
    8000370a:	dde5                	beqz	a1,80003702 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000370c:	0009a503          	lw	a0,0(s3)
    80003710:	a47ff0ef          	jal	80003156 <bfree>
      ip->addrs[i] = 0;
    80003714:	0004a023          	sw	zero,0(s1)
    80003718:	b7ed                	j	80003702 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000371a:	0809a583          	lw	a1,128(s3)
    8000371e:	ed89                	bnez	a1,80003738 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003720:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003724:	854e                	mv	a0,s3
    80003726:	e21ff0ef          	jal	80003546 <iupdate>
}
    8000372a:	70a2                	ld	ra,40(sp)
    8000372c:	7402                	ld	s0,32(sp)
    8000372e:	64e2                	ld	s1,24(sp)
    80003730:	6942                	ld	s2,16(sp)
    80003732:	69a2                	ld	s3,8(sp)
    80003734:	6145                	addi	sp,sp,48
    80003736:	8082                	ret
    80003738:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000373a:	0009a503          	lw	a0,0(s3)
    8000373e:	825ff0ef          	jal	80002f62 <bread>
    80003742:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003744:	05850493          	addi	s1,a0,88
    80003748:	45850913          	addi	s2,a0,1112
    8000374c:	a021                	j	80003754 <itrunc+0x6c>
    8000374e:	0491                	addi	s1,s1,4
    80003750:	01248963          	beq	s1,s2,80003762 <itrunc+0x7a>
      if(a[j])
    80003754:	408c                	lw	a1,0(s1)
    80003756:	dde5                	beqz	a1,8000374e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003758:	0009a503          	lw	a0,0(s3)
    8000375c:	9fbff0ef          	jal	80003156 <bfree>
    80003760:	b7fd                	j	8000374e <itrunc+0x66>
    brelse(bp);
    80003762:	8552                	mv	a0,s4
    80003764:	907ff0ef          	jal	8000306a <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003768:	0809a583          	lw	a1,128(s3)
    8000376c:	0009a503          	lw	a0,0(s3)
    80003770:	9e7ff0ef          	jal	80003156 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003774:	0809a023          	sw	zero,128(s3)
    80003778:	6a02                	ld	s4,0(sp)
    8000377a:	b75d                	j	80003720 <itrunc+0x38>

000000008000377c <iput>:
{
    8000377c:	1101                	addi	sp,sp,-32
    8000377e:	ec06                	sd	ra,24(sp)
    80003780:	e822                	sd	s0,16(sp)
    80003782:	e426                	sd	s1,8(sp)
    80003784:	1000                	addi	s0,sp,32
    80003786:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003788:	0001b517          	auipc	a0,0x1b
    8000378c:	95850513          	addi	a0,a0,-1704 # 8001e0e0 <itable>
    80003790:	c98fd0ef          	jal	80000c28 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003794:	4498                	lw	a4,8(s1)
    80003796:	4785                	li	a5,1
    80003798:	02f70063          	beq	a4,a5,800037b8 <iput+0x3c>
  ip->ref--;
    8000379c:	449c                	lw	a5,8(s1)
    8000379e:	37fd                	addiw	a5,a5,-1
    800037a0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800037a2:	0001b517          	auipc	a0,0x1b
    800037a6:	93e50513          	addi	a0,a0,-1730 # 8001e0e0 <itable>
    800037aa:	d12fd0ef          	jal	80000cbc <release>
}
    800037ae:	60e2                	ld	ra,24(sp)
    800037b0:	6442                	ld	s0,16(sp)
    800037b2:	64a2                	ld	s1,8(sp)
    800037b4:	6105                	addi	sp,sp,32
    800037b6:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800037b8:	40bc                	lw	a5,64(s1)
    800037ba:	d3ed                	beqz	a5,8000379c <iput+0x20>
    800037bc:	04a49783          	lh	a5,74(s1)
    800037c0:	fff1                	bnez	a5,8000379c <iput+0x20>
    800037c2:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800037c4:	01048793          	addi	a5,s1,16
    800037c8:	893e                	mv	s2,a5
    800037ca:	853e                	mv	a0,a5
    800037cc:	2cf000ef          	jal	8000429a <acquiresleep>
    release(&itable.lock);
    800037d0:	0001b517          	auipc	a0,0x1b
    800037d4:	91050513          	addi	a0,a0,-1776 # 8001e0e0 <itable>
    800037d8:	ce4fd0ef          	jal	80000cbc <release>
    itrunc(ip);
    800037dc:	8526                	mv	a0,s1
    800037de:	f0bff0ef          	jal	800036e8 <itrunc>
    ip->type = 0;
    800037e2:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800037e6:	8526                	mv	a0,s1
    800037e8:	d5fff0ef          	jal	80003546 <iupdate>
    ip->valid = 0;
    800037ec:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800037f0:	854a                	mv	a0,s2
    800037f2:	2ef000ef          	jal	800042e0 <releasesleep>
    acquire(&itable.lock);
    800037f6:	0001b517          	auipc	a0,0x1b
    800037fa:	8ea50513          	addi	a0,a0,-1814 # 8001e0e0 <itable>
    800037fe:	c2afd0ef          	jal	80000c28 <acquire>
    80003802:	6902                	ld	s2,0(sp)
    80003804:	bf61                	j	8000379c <iput+0x20>

0000000080003806 <iunlockput>:
{
    80003806:	1101                	addi	sp,sp,-32
    80003808:	ec06                	sd	ra,24(sp)
    8000380a:	e822                	sd	s0,16(sp)
    8000380c:	e426                	sd	s1,8(sp)
    8000380e:	1000                	addi	s0,sp,32
    80003810:	84aa                	mv	s1,a0
  iunlock(ip);
    80003812:	e97ff0ef          	jal	800036a8 <iunlock>
  iput(ip);
    80003816:	8526                	mv	a0,s1
    80003818:	f65ff0ef          	jal	8000377c <iput>
}
    8000381c:	60e2                	ld	ra,24(sp)
    8000381e:	6442                	ld	s0,16(sp)
    80003820:	64a2                	ld	s1,8(sp)
    80003822:	6105                	addi	sp,sp,32
    80003824:	8082                	ret

0000000080003826 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003826:	0001b717          	auipc	a4,0x1b
    8000382a:	8a672703          	lw	a4,-1882(a4) # 8001e0cc <sb+0xc>
    8000382e:	4785                	li	a5,1
    80003830:	0ae7fe63          	bgeu	a5,a4,800038ec <ireclaim+0xc6>
{
    80003834:	7139                	addi	sp,sp,-64
    80003836:	fc06                	sd	ra,56(sp)
    80003838:	f822                	sd	s0,48(sp)
    8000383a:	f426                	sd	s1,40(sp)
    8000383c:	f04a                	sd	s2,32(sp)
    8000383e:	ec4e                	sd	s3,24(sp)
    80003840:	e852                	sd	s4,16(sp)
    80003842:	e456                	sd	s5,8(sp)
    80003844:	e05a                	sd	s6,0(sp)
    80003846:	0080                	addi	s0,sp,64
    80003848:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000384a:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000384c:	0001ba17          	auipc	s4,0x1b
    80003850:	874a0a13          	addi	s4,s4,-1932 # 8001e0c0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003854:	00004b17          	auipc	s6,0x4
    80003858:	c44b0b13          	addi	s6,s6,-956 # 80007498 <etext+0x498>
    8000385c:	a099                	j	800038a2 <ireclaim+0x7c>
    8000385e:	85ce                	mv	a1,s3
    80003860:	855a                	mv	a0,s6
    80003862:	c99fc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003866:	85ce                	mv	a1,s3
    80003868:	8556                	mv	a0,s5
    8000386a:	b1fff0ef          	jal	80003388 <iget>
    8000386e:	89aa                	mv	s3,a0
    brelse(bp);
    80003870:	854a                	mv	a0,s2
    80003872:	ff8ff0ef          	jal	8000306a <brelse>
    if (ip) {
    80003876:	00098f63          	beqz	s3,80003894 <ireclaim+0x6e>
      begin_op();
    8000387a:	78c000ef          	jal	80004006 <begin_op>
      ilock(ip);
    8000387e:	854e                	mv	a0,s3
    80003880:	d7bff0ef          	jal	800035fa <ilock>
      iunlock(ip);
    80003884:	854e                	mv	a0,s3
    80003886:	e23ff0ef          	jal	800036a8 <iunlock>
      iput(ip);
    8000388a:	854e                	mv	a0,s3
    8000388c:	ef1ff0ef          	jal	8000377c <iput>
      end_op();
    80003890:	7e6000ef          	jal	80004076 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003894:	0485                	addi	s1,s1,1
    80003896:	00ca2703          	lw	a4,12(s4)
    8000389a:	0004879b          	sext.w	a5,s1
    8000389e:	02e7fd63          	bgeu	a5,a4,800038d8 <ireclaim+0xb2>
    800038a2:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800038a6:	0044d593          	srli	a1,s1,0x4
    800038aa:	018a2783          	lw	a5,24(s4)
    800038ae:	9dbd                	addw	a1,a1,a5
    800038b0:	8556                	mv	a0,s5
    800038b2:	eb0ff0ef          	jal	80002f62 <bread>
    800038b6:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800038b8:	05850793          	addi	a5,a0,88
    800038bc:	00f9f713          	andi	a4,s3,15
    800038c0:	071a                	slli	a4,a4,0x6
    800038c2:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800038c4:	00079703          	lh	a4,0(a5)
    800038c8:	c701                	beqz	a4,800038d0 <ireclaim+0xaa>
    800038ca:	00679783          	lh	a5,6(a5)
    800038ce:	dbc1                	beqz	a5,8000385e <ireclaim+0x38>
    brelse(bp);
    800038d0:	854a                	mv	a0,s2
    800038d2:	f98ff0ef          	jal	8000306a <brelse>
    if (ip) {
    800038d6:	bf7d                	j	80003894 <ireclaim+0x6e>
}
    800038d8:	70e2                	ld	ra,56(sp)
    800038da:	7442                	ld	s0,48(sp)
    800038dc:	74a2                	ld	s1,40(sp)
    800038de:	7902                	ld	s2,32(sp)
    800038e0:	69e2                	ld	s3,24(sp)
    800038e2:	6a42                	ld	s4,16(sp)
    800038e4:	6aa2                	ld	s5,8(sp)
    800038e6:	6b02                	ld	s6,0(sp)
    800038e8:	6121                	addi	sp,sp,64
    800038ea:	8082                	ret
    800038ec:	8082                	ret

00000000800038ee <fsinit>:
fsinit(int dev) {
    800038ee:	1101                	addi	sp,sp,-32
    800038f0:	ec06                	sd	ra,24(sp)
    800038f2:	e822                	sd	s0,16(sp)
    800038f4:	e426                	sd	s1,8(sp)
    800038f6:	e04a                	sd	s2,0(sp)
    800038f8:	1000                	addi	s0,sp,32
    800038fa:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800038fc:	4585                	li	a1,1
    800038fe:	e64ff0ef          	jal	80002f62 <bread>
    80003902:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003904:	02000613          	li	a2,32
    80003908:	05850593          	addi	a1,a0,88
    8000390c:	0001a517          	auipc	a0,0x1a
    80003910:	7b450513          	addi	a0,a0,1972 # 8001e0c0 <sb>
    80003914:	c44fd0ef          	jal	80000d58 <memmove>
  brelse(bp);
    80003918:	8526                	mv	a0,s1
    8000391a:	f50ff0ef          	jal	8000306a <brelse>
  if(sb.magic != FSMAGIC)
    8000391e:	0001a717          	auipc	a4,0x1a
    80003922:	7a272703          	lw	a4,1954(a4) # 8001e0c0 <sb>
    80003926:	102037b7          	lui	a5,0x10203
    8000392a:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000392e:	02f71263          	bne	a4,a5,80003952 <fsinit+0x64>
  initlog(dev, &sb);
    80003932:	0001a597          	auipc	a1,0x1a
    80003936:	78e58593          	addi	a1,a1,1934 # 8001e0c0 <sb>
    8000393a:	854a                	mv	a0,s2
    8000393c:	648000ef          	jal	80003f84 <initlog>
  ireclaim(dev);
    80003940:	854a                	mv	a0,s2
    80003942:	ee5ff0ef          	jal	80003826 <ireclaim>
}
    80003946:	60e2                	ld	ra,24(sp)
    80003948:	6442                	ld	s0,16(sp)
    8000394a:	64a2                	ld	s1,8(sp)
    8000394c:	6902                	ld	s2,0(sp)
    8000394e:	6105                	addi	sp,sp,32
    80003950:	8082                	ret
    panic("invalid file system");
    80003952:	00004517          	auipc	a0,0x4
    80003956:	b6650513          	addi	a0,a0,-1178 # 800074b8 <etext+0x4b8>
    8000395a:	ecbfc0ef          	jal	80000824 <panic>

000000008000395e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000395e:	1141                	addi	sp,sp,-16
    80003960:	e406                	sd	ra,8(sp)
    80003962:	e022                	sd	s0,0(sp)
    80003964:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003966:	411c                	lw	a5,0(a0)
    80003968:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000396a:	415c                	lw	a5,4(a0)
    8000396c:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000396e:	04451783          	lh	a5,68(a0)
    80003972:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003976:	04a51783          	lh	a5,74(a0)
    8000397a:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000397e:	04c56783          	lwu	a5,76(a0)
    80003982:	e99c                	sd	a5,16(a1)
}
    80003984:	60a2                	ld	ra,8(sp)
    80003986:	6402                	ld	s0,0(sp)
    80003988:	0141                	addi	sp,sp,16
    8000398a:	8082                	ret

000000008000398c <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000398c:	457c                	lw	a5,76(a0)
    8000398e:	0ed7e663          	bltu	a5,a3,80003a7a <readi+0xee>
{
    80003992:	7159                	addi	sp,sp,-112
    80003994:	f486                	sd	ra,104(sp)
    80003996:	f0a2                	sd	s0,96(sp)
    80003998:	eca6                	sd	s1,88(sp)
    8000399a:	e0d2                	sd	s4,64(sp)
    8000399c:	fc56                	sd	s5,56(sp)
    8000399e:	f85a                	sd	s6,48(sp)
    800039a0:	f45e                	sd	s7,40(sp)
    800039a2:	1880                	addi	s0,sp,112
    800039a4:	8b2a                	mv	s6,a0
    800039a6:	8bae                	mv	s7,a1
    800039a8:	8a32                	mv	s4,a2
    800039aa:	84b6                	mv	s1,a3
    800039ac:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800039ae:	9f35                	addw	a4,a4,a3
    return 0;
    800039b0:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800039b2:	0ad76b63          	bltu	a4,a3,80003a68 <readi+0xdc>
    800039b6:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800039b8:	00e7f463          	bgeu	a5,a4,800039c0 <readi+0x34>
    n = ip->size - off;
    800039bc:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800039c0:	080a8b63          	beqz	s5,80003a56 <readi+0xca>
    800039c4:	e8ca                	sd	s2,80(sp)
    800039c6:	f062                	sd	s8,32(sp)
    800039c8:	ec66                	sd	s9,24(sp)
    800039ca:	e86a                	sd	s10,16(sp)
    800039cc:	e46e                	sd	s11,8(sp)
    800039ce:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800039d0:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800039d4:	5c7d                	li	s8,-1
    800039d6:	a80d                	j	80003a08 <readi+0x7c>
    800039d8:	020d1d93          	slli	s11,s10,0x20
    800039dc:	020ddd93          	srli	s11,s11,0x20
    800039e0:	05890613          	addi	a2,s2,88
    800039e4:	86ee                	mv	a3,s11
    800039e6:	963e                	add	a2,a2,a5
    800039e8:	85d2                	mv	a1,s4
    800039ea:	855e                	mv	a0,s7
    800039ec:	a5ffe0ef          	jal	8000244a <either_copyout>
    800039f0:	05850363          	beq	a0,s8,80003a36 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800039f4:	854a                	mv	a0,s2
    800039f6:	e74ff0ef          	jal	8000306a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800039fa:	013d09bb          	addw	s3,s10,s3
    800039fe:	009d04bb          	addw	s1,s10,s1
    80003a02:	9a6e                	add	s4,s4,s11
    80003a04:	0559f363          	bgeu	s3,s5,80003a4a <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003a08:	00a4d59b          	srliw	a1,s1,0xa
    80003a0c:	855a                	mv	a0,s6
    80003a0e:	8bbff0ef          	jal	800032c8 <bmap>
    80003a12:	85aa                	mv	a1,a0
    if(addr == 0)
    80003a14:	c139                	beqz	a0,80003a5a <readi+0xce>
    bp = bread(ip->dev, addr);
    80003a16:	000b2503          	lw	a0,0(s6)
    80003a1a:	d48ff0ef          	jal	80002f62 <bread>
    80003a1e:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a20:	3ff4f793          	andi	a5,s1,1023
    80003a24:	40fc873b          	subw	a4,s9,a5
    80003a28:	413a86bb          	subw	a3,s5,s3
    80003a2c:	8d3a                	mv	s10,a4
    80003a2e:	fae6f5e3          	bgeu	a3,a4,800039d8 <readi+0x4c>
    80003a32:	8d36                	mv	s10,a3
    80003a34:	b755                	j	800039d8 <readi+0x4c>
      brelse(bp);
    80003a36:	854a                	mv	a0,s2
    80003a38:	e32ff0ef          	jal	8000306a <brelse>
      tot = -1;
    80003a3c:	59fd                	li	s3,-1
      break;
    80003a3e:	6946                	ld	s2,80(sp)
    80003a40:	7c02                	ld	s8,32(sp)
    80003a42:	6ce2                	ld	s9,24(sp)
    80003a44:	6d42                	ld	s10,16(sp)
    80003a46:	6da2                	ld	s11,8(sp)
    80003a48:	a831                	j	80003a64 <readi+0xd8>
    80003a4a:	6946                	ld	s2,80(sp)
    80003a4c:	7c02                	ld	s8,32(sp)
    80003a4e:	6ce2                	ld	s9,24(sp)
    80003a50:	6d42                	ld	s10,16(sp)
    80003a52:	6da2                	ld	s11,8(sp)
    80003a54:	a801                	j	80003a64 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a56:	89d6                	mv	s3,s5
    80003a58:	a031                	j	80003a64 <readi+0xd8>
    80003a5a:	6946                	ld	s2,80(sp)
    80003a5c:	7c02                	ld	s8,32(sp)
    80003a5e:	6ce2                	ld	s9,24(sp)
    80003a60:	6d42                	ld	s10,16(sp)
    80003a62:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003a64:	854e                	mv	a0,s3
    80003a66:	69a6                	ld	s3,72(sp)
}
    80003a68:	70a6                	ld	ra,104(sp)
    80003a6a:	7406                	ld	s0,96(sp)
    80003a6c:	64e6                	ld	s1,88(sp)
    80003a6e:	6a06                	ld	s4,64(sp)
    80003a70:	7ae2                	ld	s5,56(sp)
    80003a72:	7b42                	ld	s6,48(sp)
    80003a74:	7ba2                	ld	s7,40(sp)
    80003a76:	6165                	addi	sp,sp,112
    80003a78:	8082                	ret
    return 0;
    80003a7a:	4501                	li	a0,0
}
    80003a7c:	8082                	ret

0000000080003a7e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003a7e:	457c                	lw	a5,76(a0)
    80003a80:	0ed7eb63          	bltu	a5,a3,80003b76 <writei+0xf8>
{
    80003a84:	7159                	addi	sp,sp,-112
    80003a86:	f486                	sd	ra,104(sp)
    80003a88:	f0a2                	sd	s0,96(sp)
    80003a8a:	e8ca                	sd	s2,80(sp)
    80003a8c:	e0d2                	sd	s4,64(sp)
    80003a8e:	fc56                	sd	s5,56(sp)
    80003a90:	f85a                	sd	s6,48(sp)
    80003a92:	f45e                	sd	s7,40(sp)
    80003a94:	1880                	addi	s0,sp,112
    80003a96:	8aaa                	mv	s5,a0
    80003a98:	8bae                	mv	s7,a1
    80003a9a:	8a32                	mv	s4,a2
    80003a9c:	8936                	mv	s2,a3
    80003a9e:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003aa0:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003aa4:	00043737          	lui	a4,0x43
    80003aa8:	0cf76963          	bltu	a4,a5,80003b7a <writei+0xfc>
    80003aac:	0cd7e763          	bltu	a5,a3,80003b7a <writei+0xfc>
    80003ab0:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003ab2:	0a0b0a63          	beqz	s6,80003b66 <writei+0xe8>
    80003ab6:	eca6                	sd	s1,88(sp)
    80003ab8:	f062                	sd	s8,32(sp)
    80003aba:	ec66                	sd	s9,24(sp)
    80003abc:	e86a                	sd	s10,16(sp)
    80003abe:	e46e                	sd	s11,8(sp)
    80003ac0:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003ac2:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003ac6:	5c7d                	li	s8,-1
    80003ac8:	a825                	j	80003b00 <writei+0x82>
    80003aca:	020d1d93          	slli	s11,s10,0x20
    80003ace:	020ddd93          	srli	s11,s11,0x20
    80003ad2:	05848513          	addi	a0,s1,88
    80003ad6:	86ee                	mv	a3,s11
    80003ad8:	8652                	mv	a2,s4
    80003ada:	85de                	mv	a1,s7
    80003adc:	953e                	add	a0,a0,a5
    80003ade:	9b7fe0ef          	jal	80002494 <either_copyin>
    80003ae2:	05850663          	beq	a0,s8,80003b2e <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003ae6:	8526                	mv	a0,s1
    80003ae8:	6b8000ef          	jal	800041a0 <log_write>
    brelse(bp);
    80003aec:	8526                	mv	a0,s1
    80003aee:	d7cff0ef          	jal	8000306a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003af2:	013d09bb          	addw	s3,s10,s3
    80003af6:	012d093b          	addw	s2,s10,s2
    80003afa:	9a6e                	add	s4,s4,s11
    80003afc:	0369fc63          	bgeu	s3,s6,80003b34 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003b00:	00a9559b          	srliw	a1,s2,0xa
    80003b04:	8556                	mv	a0,s5
    80003b06:	fc2ff0ef          	jal	800032c8 <bmap>
    80003b0a:	85aa                	mv	a1,a0
    if(addr == 0)
    80003b0c:	c505                	beqz	a0,80003b34 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80003b0e:	000aa503          	lw	a0,0(s5)
    80003b12:	c50ff0ef          	jal	80002f62 <bread>
    80003b16:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b18:	3ff97793          	andi	a5,s2,1023
    80003b1c:	40fc873b          	subw	a4,s9,a5
    80003b20:	413b06bb          	subw	a3,s6,s3
    80003b24:	8d3a                	mv	s10,a4
    80003b26:	fae6f2e3          	bgeu	a3,a4,80003aca <writei+0x4c>
    80003b2a:	8d36                	mv	s10,a3
    80003b2c:	bf79                	j	80003aca <writei+0x4c>
      brelse(bp);
    80003b2e:	8526                	mv	a0,s1
    80003b30:	d3aff0ef          	jal	8000306a <brelse>
  }

  if(off > ip->size)
    80003b34:	04caa783          	lw	a5,76(s5)
    80003b38:	0327f963          	bgeu	a5,s2,80003b6a <writei+0xec>
    ip->size = off;
    80003b3c:	052aa623          	sw	s2,76(s5)
    80003b40:	64e6                	ld	s1,88(sp)
    80003b42:	7c02                	ld	s8,32(sp)
    80003b44:	6ce2                	ld	s9,24(sp)
    80003b46:	6d42                	ld	s10,16(sp)
    80003b48:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003b4a:	8556                	mv	a0,s5
    80003b4c:	9fbff0ef          	jal	80003546 <iupdate>

  return tot;
    80003b50:	854e                	mv	a0,s3
    80003b52:	69a6                	ld	s3,72(sp)
}
    80003b54:	70a6                	ld	ra,104(sp)
    80003b56:	7406                	ld	s0,96(sp)
    80003b58:	6946                	ld	s2,80(sp)
    80003b5a:	6a06                	ld	s4,64(sp)
    80003b5c:	7ae2                	ld	s5,56(sp)
    80003b5e:	7b42                	ld	s6,48(sp)
    80003b60:	7ba2                	ld	s7,40(sp)
    80003b62:	6165                	addi	sp,sp,112
    80003b64:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003b66:	89da                	mv	s3,s6
    80003b68:	b7cd                	j	80003b4a <writei+0xcc>
    80003b6a:	64e6                	ld	s1,88(sp)
    80003b6c:	7c02                	ld	s8,32(sp)
    80003b6e:	6ce2                	ld	s9,24(sp)
    80003b70:	6d42                	ld	s10,16(sp)
    80003b72:	6da2                	ld	s11,8(sp)
    80003b74:	bfd9                	j	80003b4a <writei+0xcc>
    return -1;
    80003b76:	557d                	li	a0,-1
}
    80003b78:	8082                	ret
    return -1;
    80003b7a:	557d                	li	a0,-1
    80003b7c:	bfe1                	j	80003b54 <writei+0xd6>

0000000080003b7e <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003b7e:	1141                	addi	sp,sp,-16
    80003b80:	e406                	sd	ra,8(sp)
    80003b82:	e022                	sd	s0,0(sp)
    80003b84:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003b86:	4639                	li	a2,14
    80003b88:	a44fd0ef          	jal	80000dcc <strncmp>
}
    80003b8c:	60a2                	ld	ra,8(sp)
    80003b8e:	6402                	ld	s0,0(sp)
    80003b90:	0141                	addi	sp,sp,16
    80003b92:	8082                	ret

0000000080003b94 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003b94:	711d                	addi	sp,sp,-96
    80003b96:	ec86                	sd	ra,88(sp)
    80003b98:	e8a2                	sd	s0,80(sp)
    80003b9a:	e4a6                	sd	s1,72(sp)
    80003b9c:	e0ca                	sd	s2,64(sp)
    80003b9e:	fc4e                	sd	s3,56(sp)
    80003ba0:	f852                	sd	s4,48(sp)
    80003ba2:	f456                	sd	s5,40(sp)
    80003ba4:	f05a                	sd	s6,32(sp)
    80003ba6:	ec5e                	sd	s7,24(sp)
    80003ba8:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003baa:	04451703          	lh	a4,68(a0)
    80003bae:	4785                	li	a5,1
    80003bb0:	00f71f63          	bne	a4,a5,80003bce <dirlookup+0x3a>
    80003bb4:	892a                	mv	s2,a0
    80003bb6:	8aae                	mv	s5,a1
    80003bb8:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003bba:	457c                	lw	a5,76(a0)
    80003bbc:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003bbe:	fa040a13          	addi	s4,s0,-96
    80003bc2:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80003bc4:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003bc8:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003bca:	e39d                	bnez	a5,80003bf0 <dirlookup+0x5c>
    80003bcc:	a8b9                	j	80003c2a <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003bce:	00004517          	auipc	a0,0x4
    80003bd2:	90250513          	addi	a0,a0,-1790 # 800074d0 <etext+0x4d0>
    80003bd6:	c4ffc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    80003bda:	00004517          	auipc	a0,0x4
    80003bde:	90e50513          	addi	a0,a0,-1778 # 800074e8 <etext+0x4e8>
    80003be2:	c43fc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003be6:	24c1                	addiw	s1,s1,16
    80003be8:	04c92783          	lw	a5,76(s2)
    80003bec:	02f4fe63          	bgeu	s1,a5,80003c28 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003bf0:	874e                	mv	a4,s3
    80003bf2:	86a6                	mv	a3,s1
    80003bf4:	8652                	mv	a2,s4
    80003bf6:	4581                	li	a1,0
    80003bf8:	854a                	mv	a0,s2
    80003bfa:	d93ff0ef          	jal	8000398c <readi>
    80003bfe:	fd351ee3          	bne	a0,s3,80003bda <dirlookup+0x46>
    if(de.inum == 0)
    80003c02:	fa045783          	lhu	a5,-96(s0)
    80003c06:	d3e5                	beqz	a5,80003be6 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80003c08:	85da                	mv	a1,s6
    80003c0a:	8556                	mv	a0,s5
    80003c0c:	f73ff0ef          	jal	80003b7e <namecmp>
    80003c10:	f979                	bnez	a0,80003be6 <dirlookup+0x52>
      if(poff)
    80003c12:	000b8463          	beqz	s7,80003c1a <dirlookup+0x86>
        *poff = off;
    80003c16:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003c1a:	fa045583          	lhu	a1,-96(s0)
    80003c1e:	00092503          	lw	a0,0(s2)
    80003c22:	f66ff0ef          	jal	80003388 <iget>
    80003c26:	a011                	j	80003c2a <dirlookup+0x96>
  return 0;
    80003c28:	4501                	li	a0,0
}
    80003c2a:	60e6                	ld	ra,88(sp)
    80003c2c:	6446                	ld	s0,80(sp)
    80003c2e:	64a6                	ld	s1,72(sp)
    80003c30:	6906                	ld	s2,64(sp)
    80003c32:	79e2                	ld	s3,56(sp)
    80003c34:	7a42                	ld	s4,48(sp)
    80003c36:	7aa2                	ld	s5,40(sp)
    80003c38:	7b02                	ld	s6,32(sp)
    80003c3a:	6be2                	ld	s7,24(sp)
    80003c3c:	6125                	addi	sp,sp,96
    80003c3e:	8082                	ret

0000000080003c40 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003c40:	711d                	addi	sp,sp,-96
    80003c42:	ec86                	sd	ra,88(sp)
    80003c44:	e8a2                	sd	s0,80(sp)
    80003c46:	e4a6                	sd	s1,72(sp)
    80003c48:	e0ca                	sd	s2,64(sp)
    80003c4a:	fc4e                	sd	s3,56(sp)
    80003c4c:	f852                	sd	s4,48(sp)
    80003c4e:	f456                	sd	s5,40(sp)
    80003c50:	f05a                	sd	s6,32(sp)
    80003c52:	ec5e                	sd	s7,24(sp)
    80003c54:	e862                	sd	s8,16(sp)
    80003c56:	e466                	sd	s9,8(sp)
    80003c58:	e06a                	sd	s10,0(sp)
    80003c5a:	1080                	addi	s0,sp,96
    80003c5c:	84aa                	mv	s1,a0
    80003c5e:	8b2e                	mv	s6,a1
    80003c60:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003c62:	00054703          	lbu	a4,0(a0)
    80003c66:	02f00793          	li	a5,47
    80003c6a:	00f70f63          	beq	a4,a5,80003c88 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003c6e:	e1bfd0ef          	jal	80001a88 <myproc>
    80003c72:	15853503          	ld	a0,344(a0)
    80003c76:	94fff0ef          	jal	800035c4 <idup>
    80003c7a:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003c7c:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003c80:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003c82:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003c84:	4b85                	li	s7,1
    80003c86:	a879                	j	80003d24 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003c88:	4585                	li	a1,1
    80003c8a:	852e                	mv	a0,a1
    80003c8c:	efcff0ef          	jal	80003388 <iget>
    80003c90:	8a2a                	mv	s4,a0
    80003c92:	b7ed                	j	80003c7c <namex+0x3c>
      iunlockput(ip);
    80003c94:	8552                	mv	a0,s4
    80003c96:	b71ff0ef          	jal	80003806 <iunlockput>
      return 0;
    80003c9a:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003c9c:	8552                	mv	a0,s4
    80003c9e:	60e6                	ld	ra,88(sp)
    80003ca0:	6446                	ld	s0,80(sp)
    80003ca2:	64a6                	ld	s1,72(sp)
    80003ca4:	6906                	ld	s2,64(sp)
    80003ca6:	79e2                	ld	s3,56(sp)
    80003ca8:	7a42                	ld	s4,48(sp)
    80003caa:	7aa2                	ld	s5,40(sp)
    80003cac:	7b02                	ld	s6,32(sp)
    80003cae:	6be2                	ld	s7,24(sp)
    80003cb0:	6c42                	ld	s8,16(sp)
    80003cb2:	6ca2                	ld	s9,8(sp)
    80003cb4:	6d02                	ld	s10,0(sp)
    80003cb6:	6125                	addi	sp,sp,96
    80003cb8:	8082                	ret
      iunlock(ip);
    80003cba:	8552                	mv	a0,s4
    80003cbc:	9edff0ef          	jal	800036a8 <iunlock>
      return ip;
    80003cc0:	bff1                	j	80003c9c <namex+0x5c>
      iunlockput(ip);
    80003cc2:	8552                	mv	a0,s4
    80003cc4:	b43ff0ef          	jal	80003806 <iunlockput>
      return 0;
    80003cc8:	8a4a                	mv	s4,s2
    80003cca:	bfc9                	j	80003c9c <namex+0x5c>
  len = path - s;
    80003ccc:	40990633          	sub	a2,s2,s1
    80003cd0:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003cd4:	09ac5463          	bge	s8,s10,80003d5c <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80003cd8:	8666                	mv	a2,s9
    80003cda:	85a6                	mv	a1,s1
    80003cdc:	8556                	mv	a0,s5
    80003cde:	87afd0ef          	jal	80000d58 <memmove>
    80003ce2:	84ca                	mv	s1,s2
  while(*path == '/')
    80003ce4:	0004c783          	lbu	a5,0(s1)
    80003ce8:	01379763          	bne	a5,s3,80003cf6 <namex+0xb6>
    path++;
    80003cec:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003cee:	0004c783          	lbu	a5,0(s1)
    80003cf2:	ff378de3          	beq	a5,s3,80003cec <namex+0xac>
    ilock(ip);
    80003cf6:	8552                	mv	a0,s4
    80003cf8:	903ff0ef          	jal	800035fa <ilock>
    if(ip->type != T_DIR){
    80003cfc:	044a1783          	lh	a5,68(s4)
    80003d00:	f9779ae3          	bne	a5,s7,80003c94 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80003d04:	000b0563          	beqz	s6,80003d0e <namex+0xce>
    80003d08:	0004c783          	lbu	a5,0(s1)
    80003d0c:	d7dd                	beqz	a5,80003cba <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003d0e:	4601                	li	a2,0
    80003d10:	85d6                	mv	a1,s5
    80003d12:	8552                	mv	a0,s4
    80003d14:	e81ff0ef          	jal	80003b94 <dirlookup>
    80003d18:	892a                	mv	s2,a0
    80003d1a:	d545                	beqz	a0,80003cc2 <namex+0x82>
    iunlockput(ip);
    80003d1c:	8552                	mv	a0,s4
    80003d1e:	ae9ff0ef          	jal	80003806 <iunlockput>
    ip = next;
    80003d22:	8a4a                	mv	s4,s2
  while(*path == '/')
    80003d24:	0004c783          	lbu	a5,0(s1)
    80003d28:	01379763          	bne	a5,s3,80003d36 <namex+0xf6>
    path++;
    80003d2c:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003d2e:	0004c783          	lbu	a5,0(s1)
    80003d32:	ff378de3          	beq	a5,s3,80003d2c <namex+0xec>
  if(*path == 0)
    80003d36:	cf8d                	beqz	a5,80003d70 <namex+0x130>
  while(*path != '/' && *path != 0)
    80003d38:	0004c783          	lbu	a5,0(s1)
    80003d3c:	fd178713          	addi	a4,a5,-47
    80003d40:	cb19                	beqz	a4,80003d56 <namex+0x116>
    80003d42:	cb91                	beqz	a5,80003d56 <namex+0x116>
    80003d44:	8926                	mv	s2,s1
    path++;
    80003d46:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80003d48:	00094783          	lbu	a5,0(s2)
    80003d4c:	fd178713          	addi	a4,a5,-47
    80003d50:	df35                	beqz	a4,80003ccc <namex+0x8c>
    80003d52:	fbf5                	bnez	a5,80003d46 <namex+0x106>
    80003d54:	bfa5                	j	80003ccc <namex+0x8c>
    80003d56:	8926                	mv	s2,s1
  len = path - s;
    80003d58:	4d01                	li	s10,0
    80003d5a:	4601                	li	a2,0
    memmove(name, s, len);
    80003d5c:	2601                	sext.w	a2,a2
    80003d5e:	85a6                	mv	a1,s1
    80003d60:	8556                	mv	a0,s5
    80003d62:	ff7fc0ef          	jal	80000d58 <memmove>
    name[len] = 0;
    80003d66:	9d56                	add	s10,s10,s5
    80003d68:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde238>
    80003d6c:	84ca                	mv	s1,s2
    80003d6e:	bf9d                	j	80003ce4 <namex+0xa4>
  if(nameiparent){
    80003d70:	f20b06e3          	beqz	s6,80003c9c <namex+0x5c>
    iput(ip);
    80003d74:	8552                	mv	a0,s4
    80003d76:	a07ff0ef          	jal	8000377c <iput>
    return 0;
    80003d7a:	4a01                	li	s4,0
    80003d7c:	b705                	j	80003c9c <namex+0x5c>

0000000080003d7e <dirlink>:
{
    80003d7e:	715d                	addi	sp,sp,-80
    80003d80:	e486                	sd	ra,72(sp)
    80003d82:	e0a2                	sd	s0,64(sp)
    80003d84:	f84a                	sd	s2,48(sp)
    80003d86:	ec56                	sd	s5,24(sp)
    80003d88:	e85a                	sd	s6,16(sp)
    80003d8a:	0880                	addi	s0,sp,80
    80003d8c:	892a                	mv	s2,a0
    80003d8e:	8aae                	mv	s5,a1
    80003d90:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003d92:	4601                	li	a2,0
    80003d94:	e01ff0ef          	jal	80003b94 <dirlookup>
    80003d98:	ed1d                	bnez	a0,80003dd6 <dirlink+0x58>
    80003d9a:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d9c:	04c92483          	lw	s1,76(s2)
    80003da0:	c4b9                	beqz	s1,80003dee <dirlink+0x70>
    80003da2:	f44e                	sd	s3,40(sp)
    80003da4:	f052                	sd	s4,32(sp)
    80003da6:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003da8:	fb040a13          	addi	s4,s0,-80
    80003dac:	49c1                	li	s3,16
    80003dae:	874e                	mv	a4,s3
    80003db0:	86a6                	mv	a3,s1
    80003db2:	8652                	mv	a2,s4
    80003db4:	4581                	li	a1,0
    80003db6:	854a                	mv	a0,s2
    80003db8:	bd5ff0ef          	jal	8000398c <readi>
    80003dbc:	03351163          	bne	a0,s3,80003dde <dirlink+0x60>
    if(de.inum == 0)
    80003dc0:	fb045783          	lhu	a5,-80(s0)
    80003dc4:	c39d                	beqz	a5,80003dea <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003dc6:	24c1                	addiw	s1,s1,16
    80003dc8:	04c92783          	lw	a5,76(s2)
    80003dcc:	fef4e1e3          	bltu	s1,a5,80003dae <dirlink+0x30>
    80003dd0:	79a2                	ld	s3,40(sp)
    80003dd2:	7a02                	ld	s4,32(sp)
    80003dd4:	a829                	j	80003dee <dirlink+0x70>
    iput(ip);
    80003dd6:	9a7ff0ef          	jal	8000377c <iput>
    return -1;
    80003dda:	557d                	li	a0,-1
    80003ddc:	a83d                	j	80003e1a <dirlink+0x9c>
      panic("dirlink read");
    80003dde:	00003517          	auipc	a0,0x3
    80003de2:	71a50513          	addi	a0,a0,1818 # 800074f8 <etext+0x4f8>
    80003de6:	a3ffc0ef          	jal	80000824 <panic>
    80003dea:	79a2                	ld	s3,40(sp)
    80003dec:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003dee:	4639                	li	a2,14
    80003df0:	85d6                	mv	a1,s5
    80003df2:	fb240513          	addi	a0,s0,-78
    80003df6:	810fd0ef          	jal	80000e06 <strncpy>
  de.inum = inum;
    80003dfa:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003dfe:	4741                	li	a4,16
    80003e00:	86a6                	mv	a3,s1
    80003e02:	fb040613          	addi	a2,s0,-80
    80003e06:	4581                	li	a1,0
    80003e08:	854a                	mv	a0,s2
    80003e0a:	c75ff0ef          	jal	80003a7e <writei>
    80003e0e:	1541                	addi	a0,a0,-16
    80003e10:	00a03533          	snez	a0,a0
    80003e14:	40a0053b          	negw	a0,a0
    80003e18:	74e2                	ld	s1,56(sp)
}
    80003e1a:	60a6                	ld	ra,72(sp)
    80003e1c:	6406                	ld	s0,64(sp)
    80003e1e:	7942                	ld	s2,48(sp)
    80003e20:	6ae2                	ld	s5,24(sp)
    80003e22:	6b42                	ld	s6,16(sp)
    80003e24:	6161                	addi	sp,sp,80
    80003e26:	8082                	ret

0000000080003e28 <namei>:

struct inode*
namei(char *path)
{
    80003e28:	1101                	addi	sp,sp,-32
    80003e2a:	ec06                	sd	ra,24(sp)
    80003e2c:	e822                	sd	s0,16(sp)
    80003e2e:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003e30:	fe040613          	addi	a2,s0,-32
    80003e34:	4581                	li	a1,0
    80003e36:	e0bff0ef          	jal	80003c40 <namex>
}
    80003e3a:	60e2                	ld	ra,24(sp)
    80003e3c:	6442                	ld	s0,16(sp)
    80003e3e:	6105                	addi	sp,sp,32
    80003e40:	8082                	ret

0000000080003e42 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003e42:	1141                	addi	sp,sp,-16
    80003e44:	e406                	sd	ra,8(sp)
    80003e46:	e022                	sd	s0,0(sp)
    80003e48:	0800                	addi	s0,sp,16
    80003e4a:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003e4c:	4585                	li	a1,1
    80003e4e:	df3ff0ef          	jal	80003c40 <namex>
}
    80003e52:	60a2                	ld	ra,8(sp)
    80003e54:	6402                	ld	s0,0(sp)
    80003e56:	0141                	addi	sp,sp,16
    80003e58:	8082                	ret

0000000080003e5a <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003e5a:	1101                	addi	sp,sp,-32
    80003e5c:	ec06                	sd	ra,24(sp)
    80003e5e:	e822                	sd	s0,16(sp)
    80003e60:	e426                	sd	s1,8(sp)
    80003e62:	e04a                	sd	s2,0(sp)
    80003e64:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003e66:	0001c917          	auipc	s2,0x1c
    80003e6a:	d2290913          	addi	s2,s2,-734 # 8001fb88 <log>
    80003e6e:	01892583          	lw	a1,24(s2)
    80003e72:	02492503          	lw	a0,36(s2)
    80003e76:	8ecff0ef          	jal	80002f62 <bread>
    80003e7a:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003e7c:	02892603          	lw	a2,40(s2)
    80003e80:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003e82:	00c05f63          	blez	a2,80003ea0 <write_head+0x46>
    80003e86:	0001c717          	auipc	a4,0x1c
    80003e8a:	d2e70713          	addi	a4,a4,-722 # 8001fbb4 <log+0x2c>
    80003e8e:	87aa                	mv	a5,a0
    80003e90:	060a                	slli	a2,a2,0x2
    80003e92:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003e94:	4314                	lw	a3,0(a4)
    80003e96:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003e98:	0711                	addi	a4,a4,4
    80003e9a:	0791                	addi	a5,a5,4
    80003e9c:	fec79ce3          	bne	a5,a2,80003e94 <write_head+0x3a>
  }
  bwrite(buf);
    80003ea0:	8526                	mv	a0,s1
    80003ea2:	996ff0ef          	jal	80003038 <bwrite>
  brelse(buf);
    80003ea6:	8526                	mv	a0,s1
    80003ea8:	9c2ff0ef          	jal	8000306a <brelse>
}
    80003eac:	60e2                	ld	ra,24(sp)
    80003eae:	6442                	ld	s0,16(sp)
    80003eb0:	64a2                	ld	s1,8(sp)
    80003eb2:	6902                	ld	s2,0(sp)
    80003eb4:	6105                	addi	sp,sp,32
    80003eb6:	8082                	ret

0000000080003eb8 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003eb8:	0001c797          	auipc	a5,0x1c
    80003ebc:	cf87a783          	lw	a5,-776(a5) # 8001fbb0 <log+0x28>
    80003ec0:	0cf05163          	blez	a5,80003f82 <install_trans+0xca>
{
    80003ec4:	715d                	addi	sp,sp,-80
    80003ec6:	e486                	sd	ra,72(sp)
    80003ec8:	e0a2                	sd	s0,64(sp)
    80003eca:	fc26                	sd	s1,56(sp)
    80003ecc:	f84a                	sd	s2,48(sp)
    80003ece:	f44e                	sd	s3,40(sp)
    80003ed0:	f052                	sd	s4,32(sp)
    80003ed2:	ec56                	sd	s5,24(sp)
    80003ed4:	e85a                	sd	s6,16(sp)
    80003ed6:	e45e                	sd	s7,8(sp)
    80003ed8:	e062                	sd	s8,0(sp)
    80003eda:	0880                	addi	s0,sp,80
    80003edc:	8b2a                	mv	s6,a0
    80003ede:	0001ca97          	auipc	s5,0x1c
    80003ee2:	cd6a8a93          	addi	s5,s5,-810 # 8001fbb4 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ee6:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003ee8:	00003c17          	auipc	s8,0x3
    80003eec:	620c0c13          	addi	s8,s8,1568 # 80007508 <etext+0x508>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ef0:	0001ca17          	auipc	s4,0x1c
    80003ef4:	c98a0a13          	addi	s4,s4,-872 # 8001fb88 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003ef8:	40000b93          	li	s7,1024
    80003efc:	a025                	j	80003f24 <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003efe:	000aa603          	lw	a2,0(s5)
    80003f02:	85ce                	mv	a1,s3
    80003f04:	8562                	mv	a0,s8
    80003f06:	df4fc0ef          	jal	800004fa <printf>
    80003f0a:	a839                	j	80003f28 <install_trans+0x70>
    brelse(lbuf);
    80003f0c:	854a                	mv	a0,s2
    80003f0e:	95cff0ef          	jal	8000306a <brelse>
    brelse(dbuf);
    80003f12:	8526                	mv	a0,s1
    80003f14:	956ff0ef          	jal	8000306a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f18:	2985                	addiw	s3,s3,1
    80003f1a:	0a91                	addi	s5,s5,4
    80003f1c:	028a2783          	lw	a5,40(s4)
    80003f20:	04f9d563          	bge	s3,a5,80003f6a <install_trans+0xb2>
    if(recovering) {
    80003f24:	fc0b1de3          	bnez	s6,80003efe <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003f28:	018a2583          	lw	a1,24(s4)
    80003f2c:	013585bb          	addw	a1,a1,s3
    80003f30:	2585                	addiw	a1,a1,1
    80003f32:	024a2503          	lw	a0,36(s4)
    80003f36:	82cff0ef          	jal	80002f62 <bread>
    80003f3a:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003f3c:	000aa583          	lw	a1,0(s5)
    80003f40:	024a2503          	lw	a0,36(s4)
    80003f44:	81eff0ef          	jal	80002f62 <bread>
    80003f48:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003f4a:	865e                	mv	a2,s7
    80003f4c:	05890593          	addi	a1,s2,88
    80003f50:	05850513          	addi	a0,a0,88
    80003f54:	e05fc0ef          	jal	80000d58 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003f58:	8526                	mv	a0,s1
    80003f5a:	8deff0ef          	jal	80003038 <bwrite>
    if(recovering == 0)
    80003f5e:	fa0b17e3          	bnez	s6,80003f0c <install_trans+0x54>
      bunpin(dbuf);
    80003f62:	8526                	mv	a0,s1
    80003f64:	9beff0ef          	jal	80003122 <bunpin>
    80003f68:	b755                	j	80003f0c <install_trans+0x54>
}
    80003f6a:	60a6                	ld	ra,72(sp)
    80003f6c:	6406                	ld	s0,64(sp)
    80003f6e:	74e2                	ld	s1,56(sp)
    80003f70:	7942                	ld	s2,48(sp)
    80003f72:	79a2                	ld	s3,40(sp)
    80003f74:	7a02                	ld	s4,32(sp)
    80003f76:	6ae2                	ld	s5,24(sp)
    80003f78:	6b42                	ld	s6,16(sp)
    80003f7a:	6ba2                	ld	s7,8(sp)
    80003f7c:	6c02                	ld	s8,0(sp)
    80003f7e:	6161                	addi	sp,sp,80
    80003f80:	8082                	ret
    80003f82:	8082                	ret

0000000080003f84 <initlog>:
{
    80003f84:	7179                	addi	sp,sp,-48
    80003f86:	f406                	sd	ra,40(sp)
    80003f88:	f022                	sd	s0,32(sp)
    80003f8a:	ec26                	sd	s1,24(sp)
    80003f8c:	e84a                	sd	s2,16(sp)
    80003f8e:	e44e                	sd	s3,8(sp)
    80003f90:	1800                	addi	s0,sp,48
    80003f92:	84aa                	mv	s1,a0
    80003f94:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003f96:	0001c917          	auipc	s2,0x1c
    80003f9a:	bf290913          	addi	s2,s2,-1038 # 8001fb88 <log>
    80003f9e:	00003597          	auipc	a1,0x3
    80003fa2:	58a58593          	addi	a1,a1,1418 # 80007528 <etext+0x528>
    80003fa6:	854a                	mv	a0,s2
    80003fa8:	bf7fc0ef          	jal	80000b9e <initlock>
  log.start = sb->logstart;
    80003fac:	0149a583          	lw	a1,20(s3)
    80003fb0:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003fb4:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003fb8:	8526                	mv	a0,s1
    80003fba:	fa9fe0ef          	jal	80002f62 <bread>
  log.lh.n = lh->n;
    80003fbe:	4d30                	lw	a2,88(a0)
    80003fc0:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003fc4:	00c05f63          	blez	a2,80003fe2 <initlog+0x5e>
    80003fc8:	87aa                	mv	a5,a0
    80003fca:	0001c717          	auipc	a4,0x1c
    80003fce:	bea70713          	addi	a4,a4,-1046 # 8001fbb4 <log+0x2c>
    80003fd2:	060a                	slli	a2,a2,0x2
    80003fd4:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003fd6:	4ff4                	lw	a3,92(a5)
    80003fd8:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003fda:	0791                	addi	a5,a5,4
    80003fdc:	0711                	addi	a4,a4,4
    80003fde:	fec79ce3          	bne	a5,a2,80003fd6 <initlog+0x52>
  brelse(buf);
    80003fe2:	888ff0ef          	jal	8000306a <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003fe6:	4505                	li	a0,1
    80003fe8:	ed1ff0ef          	jal	80003eb8 <install_trans>
  log.lh.n = 0;
    80003fec:	0001c797          	auipc	a5,0x1c
    80003ff0:	bc07a223          	sw	zero,-1084(a5) # 8001fbb0 <log+0x28>
  write_head(); // clear the log
    80003ff4:	e67ff0ef          	jal	80003e5a <write_head>
}
    80003ff8:	70a2                	ld	ra,40(sp)
    80003ffa:	7402                	ld	s0,32(sp)
    80003ffc:	64e2                	ld	s1,24(sp)
    80003ffe:	6942                	ld	s2,16(sp)
    80004000:	69a2                	ld	s3,8(sp)
    80004002:	6145                	addi	sp,sp,48
    80004004:	8082                	ret

0000000080004006 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80004006:	1101                	addi	sp,sp,-32
    80004008:	ec06                	sd	ra,24(sp)
    8000400a:	e822                	sd	s0,16(sp)
    8000400c:	e426                	sd	s1,8(sp)
    8000400e:	e04a                	sd	s2,0(sp)
    80004010:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004012:	0001c517          	auipc	a0,0x1c
    80004016:	b7650513          	addi	a0,a0,-1162 # 8001fb88 <log>
    8000401a:	c0ffc0ef          	jal	80000c28 <acquire>
  while(1){
    if(log.committing){
    8000401e:	0001c497          	auipc	s1,0x1c
    80004022:	b6a48493          	addi	s1,s1,-1174 # 8001fb88 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80004026:	4979                	li	s2,30
    80004028:	a029                	j	80004032 <begin_op+0x2c>
      sleep(&log, &log.lock);
    8000402a:	85a6                	mv	a1,s1
    8000402c:	8526                	mv	a0,s1
    8000402e:	8c2fe0ef          	jal	800020f0 <sleep>
    if(log.committing){
    80004032:	509c                	lw	a5,32(s1)
    80004034:	fbfd                	bnez	a5,8000402a <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80004036:	4cd8                	lw	a4,28(s1)
    80004038:	2705                	addiw	a4,a4,1
    8000403a:	0027179b          	slliw	a5,a4,0x2
    8000403e:	9fb9                	addw	a5,a5,a4
    80004040:	0017979b          	slliw	a5,a5,0x1
    80004044:	5494                	lw	a3,40(s1)
    80004046:	9fb5                	addw	a5,a5,a3
    80004048:	00f95763          	bge	s2,a5,80004056 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000404c:	85a6                	mv	a1,s1
    8000404e:	8526                	mv	a0,s1
    80004050:	8a0fe0ef          	jal	800020f0 <sleep>
    80004054:	bff9                	j	80004032 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80004056:	0001c797          	auipc	a5,0x1c
    8000405a:	b4e7a723          	sw	a4,-1202(a5) # 8001fba4 <log+0x1c>
      release(&log.lock);
    8000405e:	0001c517          	auipc	a0,0x1c
    80004062:	b2a50513          	addi	a0,a0,-1238 # 8001fb88 <log>
    80004066:	c57fc0ef          	jal	80000cbc <release>
      break;
    }
  }
}
    8000406a:	60e2                	ld	ra,24(sp)
    8000406c:	6442                	ld	s0,16(sp)
    8000406e:	64a2                	ld	s1,8(sp)
    80004070:	6902                	ld	s2,0(sp)
    80004072:	6105                	addi	sp,sp,32
    80004074:	8082                	ret

0000000080004076 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004076:	7139                	addi	sp,sp,-64
    80004078:	fc06                	sd	ra,56(sp)
    8000407a:	f822                	sd	s0,48(sp)
    8000407c:	f426                	sd	s1,40(sp)
    8000407e:	f04a                	sd	s2,32(sp)
    80004080:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004082:	0001c497          	auipc	s1,0x1c
    80004086:	b0648493          	addi	s1,s1,-1274 # 8001fb88 <log>
    8000408a:	8526                	mv	a0,s1
    8000408c:	b9dfc0ef          	jal	80000c28 <acquire>
  log.outstanding -= 1;
    80004090:	4cdc                	lw	a5,28(s1)
    80004092:	37fd                	addiw	a5,a5,-1
    80004094:	893e                	mv	s2,a5
    80004096:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80004098:	509c                	lw	a5,32(s1)
    8000409a:	e7b1                	bnez	a5,800040e6 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    8000409c:	04091e63          	bnez	s2,800040f8 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    800040a0:	0001c497          	auipc	s1,0x1c
    800040a4:	ae848493          	addi	s1,s1,-1304 # 8001fb88 <log>
    800040a8:	4785                	li	a5,1
    800040aa:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800040ac:	8526                	mv	a0,s1
    800040ae:	c0ffc0ef          	jal	80000cbc <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800040b2:	549c                	lw	a5,40(s1)
    800040b4:	06f04463          	bgtz	a5,8000411c <end_op+0xa6>
    acquire(&log.lock);
    800040b8:	0001c517          	auipc	a0,0x1c
    800040bc:	ad050513          	addi	a0,a0,-1328 # 8001fb88 <log>
    800040c0:	b69fc0ef          	jal	80000c28 <acquire>
    log.committing = 0;
    800040c4:	0001c797          	auipc	a5,0x1c
    800040c8:	ae07a223          	sw	zero,-1308(a5) # 8001fba8 <log+0x20>
    wakeup(&log);
    800040cc:	0001c517          	auipc	a0,0x1c
    800040d0:	abc50513          	addi	a0,a0,-1348 # 8001fb88 <log>
    800040d4:	868fe0ef          	jal	8000213c <wakeup>
    release(&log.lock);
    800040d8:	0001c517          	auipc	a0,0x1c
    800040dc:	ab050513          	addi	a0,a0,-1360 # 8001fb88 <log>
    800040e0:	bddfc0ef          	jal	80000cbc <release>
}
    800040e4:	a035                	j	80004110 <end_op+0x9a>
    800040e6:	ec4e                	sd	s3,24(sp)
    800040e8:	e852                	sd	s4,16(sp)
    800040ea:	e456                	sd	s5,8(sp)
    panic("log.committing");
    800040ec:	00003517          	auipc	a0,0x3
    800040f0:	44450513          	addi	a0,a0,1092 # 80007530 <etext+0x530>
    800040f4:	f30fc0ef          	jal	80000824 <panic>
    wakeup(&log);
    800040f8:	0001c517          	auipc	a0,0x1c
    800040fc:	a9050513          	addi	a0,a0,-1392 # 8001fb88 <log>
    80004100:	83cfe0ef          	jal	8000213c <wakeup>
  release(&log.lock);
    80004104:	0001c517          	auipc	a0,0x1c
    80004108:	a8450513          	addi	a0,a0,-1404 # 8001fb88 <log>
    8000410c:	bb1fc0ef          	jal	80000cbc <release>
}
    80004110:	70e2                	ld	ra,56(sp)
    80004112:	7442                	ld	s0,48(sp)
    80004114:	74a2                	ld	s1,40(sp)
    80004116:	7902                	ld	s2,32(sp)
    80004118:	6121                	addi	sp,sp,64
    8000411a:	8082                	ret
    8000411c:	ec4e                	sd	s3,24(sp)
    8000411e:	e852                	sd	s4,16(sp)
    80004120:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80004122:	0001ca97          	auipc	s5,0x1c
    80004126:	a92a8a93          	addi	s5,s5,-1390 # 8001fbb4 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    8000412a:	0001ca17          	auipc	s4,0x1c
    8000412e:	a5ea0a13          	addi	s4,s4,-1442 # 8001fb88 <log>
    80004132:	018a2583          	lw	a1,24(s4)
    80004136:	012585bb          	addw	a1,a1,s2
    8000413a:	2585                	addiw	a1,a1,1
    8000413c:	024a2503          	lw	a0,36(s4)
    80004140:	e23fe0ef          	jal	80002f62 <bread>
    80004144:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004146:	000aa583          	lw	a1,0(s5)
    8000414a:	024a2503          	lw	a0,36(s4)
    8000414e:	e15fe0ef          	jal	80002f62 <bread>
    80004152:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004154:	40000613          	li	a2,1024
    80004158:	05850593          	addi	a1,a0,88
    8000415c:	05848513          	addi	a0,s1,88
    80004160:	bf9fc0ef          	jal	80000d58 <memmove>
    bwrite(to);  // write the log
    80004164:	8526                	mv	a0,s1
    80004166:	ed3fe0ef          	jal	80003038 <bwrite>
    brelse(from);
    8000416a:	854e                	mv	a0,s3
    8000416c:	efffe0ef          	jal	8000306a <brelse>
    brelse(to);
    80004170:	8526                	mv	a0,s1
    80004172:	ef9fe0ef          	jal	8000306a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004176:	2905                	addiw	s2,s2,1
    80004178:	0a91                	addi	s5,s5,4
    8000417a:	028a2783          	lw	a5,40(s4)
    8000417e:	faf94ae3          	blt	s2,a5,80004132 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004182:	cd9ff0ef          	jal	80003e5a <write_head>
    install_trans(0); // Now install writes to home locations
    80004186:	4501                	li	a0,0
    80004188:	d31ff0ef          	jal	80003eb8 <install_trans>
    log.lh.n = 0;
    8000418c:	0001c797          	auipc	a5,0x1c
    80004190:	a207a223          	sw	zero,-1500(a5) # 8001fbb0 <log+0x28>
    write_head();    // Erase the transaction from the log
    80004194:	cc7ff0ef          	jal	80003e5a <write_head>
    80004198:	69e2                	ld	s3,24(sp)
    8000419a:	6a42                	ld	s4,16(sp)
    8000419c:	6aa2                	ld	s5,8(sp)
    8000419e:	bf29                	j	800040b8 <end_op+0x42>

00000000800041a0 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800041a0:	1101                	addi	sp,sp,-32
    800041a2:	ec06                	sd	ra,24(sp)
    800041a4:	e822                	sd	s0,16(sp)
    800041a6:	e426                	sd	s1,8(sp)
    800041a8:	1000                	addi	s0,sp,32
    800041aa:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800041ac:	0001c517          	auipc	a0,0x1c
    800041b0:	9dc50513          	addi	a0,a0,-1572 # 8001fb88 <log>
    800041b4:	a75fc0ef          	jal	80000c28 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    800041b8:	0001c617          	auipc	a2,0x1c
    800041bc:	9f862603          	lw	a2,-1544(a2) # 8001fbb0 <log+0x28>
    800041c0:	47f5                	li	a5,29
    800041c2:	04c7cd63          	blt	a5,a2,8000421c <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800041c6:	0001c797          	auipc	a5,0x1c
    800041ca:	9de7a783          	lw	a5,-1570(a5) # 8001fba4 <log+0x1c>
    800041ce:	04f05d63          	blez	a5,80004228 <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800041d2:	4781                	li	a5,0
    800041d4:	06c05063          	blez	a2,80004234 <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800041d8:	44cc                	lw	a1,12(s1)
    800041da:	0001c717          	auipc	a4,0x1c
    800041de:	9da70713          	addi	a4,a4,-1574 # 8001fbb4 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    800041e2:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800041e4:	4314                	lw	a3,0(a4)
    800041e6:	04b68763          	beq	a3,a1,80004234 <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    800041ea:	2785                	addiw	a5,a5,1
    800041ec:	0711                	addi	a4,a4,4
    800041ee:	fef61be3          	bne	a2,a5,800041e4 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800041f2:	060a                	slli	a2,a2,0x2
    800041f4:	02060613          	addi	a2,a2,32
    800041f8:	0001c797          	auipc	a5,0x1c
    800041fc:	99078793          	addi	a5,a5,-1648 # 8001fb88 <log>
    80004200:	97b2                	add	a5,a5,a2
    80004202:	44d8                	lw	a4,12(s1)
    80004204:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80004206:	8526                	mv	a0,s1
    80004208:	ee7fe0ef          	jal	800030ee <bpin>
    log.lh.n++;
    8000420c:	0001c717          	auipc	a4,0x1c
    80004210:	97c70713          	addi	a4,a4,-1668 # 8001fb88 <log>
    80004214:	571c                	lw	a5,40(a4)
    80004216:	2785                	addiw	a5,a5,1
    80004218:	d71c                	sw	a5,40(a4)
    8000421a:	a815                	j	8000424e <log_write+0xae>
    panic("too big a transaction");
    8000421c:	00003517          	auipc	a0,0x3
    80004220:	32450513          	addi	a0,a0,804 # 80007540 <etext+0x540>
    80004224:	e00fc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    80004228:	00003517          	auipc	a0,0x3
    8000422c:	33050513          	addi	a0,a0,816 # 80007558 <etext+0x558>
    80004230:	df4fc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    80004234:	00279693          	slli	a3,a5,0x2
    80004238:	02068693          	addi	a3,a3,32
    8000423c:	0001c717          	auipc	a4,0x1c
    80004240:	94c70713          	addi	a4,a4,-1716 # 8001fb88 <log>
    80004244:	9736                	add	a4,a4,a3
    80004246:	44d4                	lw	a3,12(s1)
    80004248:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000424a:	faf60ee3          	beq	a2,a5,80004206 <log_write+0x66>
  }
  release(&log.lock);
    8000424e:	0001c517          	auipc	a0,0x1c
    80004252:	93a50513          	addi	a0,a0,-1734 # 8001fb88 <log>
    80004256:	a67fc0ef          	jal	80000cbc <release>
}
    8000425a:	60e2                	ld	ra,24(sp)
    8000425c:	6442                	ld	s0,16(sp)
    8000425e:	64a2                	ld	s1,8(sp)
    80004260:	6105                	addi	sp,sp,32
    80004262:	8082                	ret

0000000080004264 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004264:	1101                	addi	sp,sp,-32
    80004266:	ec06                	sd	ra,24(sp)
    80004268:	e822                	sd	s0,16(sp)
    8000426a:	e426                	sd	s1,8(sp)
    8000426c:	e04a                	sd	s2,0(sp)
    8000426e:	1000                	addi	s0,sp,32
    80004270:	84aa                	mv	s1,a0
    80004272:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004274:	00003597          	auipc	a1,0x3
    80004278:	30458593          	addi	a1,a1,772 # 80007578 <etext+0x578>
    8000427c:	0521                	addi	a0,a0,8
    8000427e:	921fc0ef          	jal	80000b9e <initlock>
  lk->name = name;
    80004282:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004286:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000428a:	0204a423          	sw	zero,40(s1)
}
    8000428e:	60e2                	ld	ra,24(sp)
    80004290:	6442                	ld	s0,16(sp)
    80004292:	64a2                	ld	s1,8(sp)
    80004294:	6902                	ld	s2,0(sp)
    80004296:	6105                	addi	sp,sp,32
    80004298:	8082                	ret

000000008000429a <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000429a:	1101                	addi	sp,sp,-32
    8000429c:	ec06                	sd	ra,24(sp)
    8000429e:	e822                	sd	s0,16(sp)
    800042a0:	e426                	sd	s1,8(sp)
    800042a2:	e04a                	sd	s2,0(sp)
    800042a4:	1000                	addi	s0,sp,32
    800042a6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800042a8:	00850913          	addi	s2,a0,8
    800042ac:	854a                	mv	a0,s2
    800042ae:	97bfc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    800042b2:	409c                	lw	a5,0(s1)
    800042b4:	c799                	beqz	a5,800042c2 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800042b6:	85ca                	mv	a1,s2
    800042b8:	8526                	mv	a0,s1
    800042ba:	e37fd0ef          	jal	800020f0 <sleep>
  while (lk->locked) {
    800042be:	409c                	lw	a5,0(s1)
    800042c0:	fbfd                	bnez	a5,800042b6 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800042c2:	4785                	li	a5,1
    800042c4:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800042c6:	fc2fd0ef          	jal	80001a88 <myproc>
    800042ca:	5d1c                	lw	a5,56(a0)
    800042cc:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800042ce:	854a                	mv	a0,s2
    800042d0:	9edfc0ef          	jal	80000cbc <release>
}
    800042d4:	60e2                	ld	ra,24(sp)
    800042d6:	6442                	ld	s0,16(sp)
    800042d8:	64a2                	ld	s1,8(sp)
    800042da:	6902                	ld	s2,0(sp)
    800042dc:	6105                	addi	sp,sp,32
    800042de:	8082                	ret

00000000800042e0 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800042e0:	1101                	addi	sp,sp,-32
    800042e2:	ec06                	sd	ra,24(sp)
    800042e4:	e822                	sd	s0,16(sp)
    800042e6:	e426                	sd	s1,8(sp)
    800042e8:	e04a                	sd	s2,0(sp)
    800042ea:	1000                	addi	s0,sp,32
    800042ec:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800042ee:	00850913          	addi	s2,a0,8
    800042f2:	854a                	mv	a0,s2
    800042f4:	935fc0ef          	jal	80000c28 <acquire>
  lk->locked = 0;
    800042f8:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800042fc:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004300:	8526                	mv	a0,s1
    80004302:	e3bfd0ef          	jal	8000213c <wakeup>
  release(&lk->lk);
    80004306:	854a                	mv	a0,s2
    80004308:	9b5fc0ef          	jal	80000cbc <release>
}
    8000430c:	60e2                	ld	ra,24(sp)
    8000430e:	6442                	ld	s0,16(sp)
    80004310:	64a2                	ld	s1,8(sp)
    80004312:	6902                	ld	s2,0(sp)
    80004314:	6105                	addi	sp,sp,32
    80004316:	8082                	ret

0000000080004318 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004318:	7179                	addi	sp,sp,-48
    8000431a:	f406                	sd	ra,40(sp)
    8000431c:	f022                	sd	s0,32(sp)
    8000431e:	ec26                	sd	s1,24(sp)
    80004320:	e84a                	sd	s2,16(sp)
    80004322:	1800                	addi	s0,sp,48
    80004324:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80004326:	00850913          	addi	s2,a0,8
    8000432a:	854a                	mv	a0,s2
    8000432c:	8fdfc0ef          	jal	80000c28 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004330:	409c                	lw	a5,0(s1)
    80004332:	ef81                	bnez	a5,8000434a <holdingsleep+0x32>
    80004334:	4481                	li	s1,0
  release(&lk->lk);
    80004336:	854a                	mv	a0,s2
    80004338:	985fc0ef          	jal	80000cbc <release>
  return r;
}
    8000433c:	8526                	mv	a0,s1
    8000433e:	70a2                	ld	ra,40(sp)
    80004340:	7402                	ld	s0,32(sp)
    80004342:	64e2                	ld	s1,24(sp)
    80004344:	6942                	ld	s2,16(sp)
    80004346:	6145                	addi	sp,sp,48
    80004348:	8082                	ret
    8000434a:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000434c:	0284a983          	lw	s3,40(s1)
    80004350:	f38fd0ef          	jal	80001a88 <myproc>
    80004354:	5d04                	lw	s1,56(a0)
    80004356:	413484b3          	sub	s1,s1,s3
    8000435a:	0014b493          	seqz	s1,s1
    8000435e:	69a2                	ld	s3,8(sp)
    80004360:	bfd9                	j	80004336 <holdingsleep+0x1e>

0000000080004362 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004362:	1141                	addi	sp,sp,-16
    80004364:	e406                	sd	ra,8(sp)
    80004366:	e022                	sd	s0,0(sp)
    80004368:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000436a:	00003597          	auipc	a1,0x3
    8000436e:	21e58593          	addi	a1,a1,542 # 80007588 <etext+0x588>
    80004372:	0001c517          	auipc	a0,0x1c
    80004376:	95e50513          	addi	a0,a0,-1698 # 8001fcd0 <ftable>
    8000437a:	825fc0ef          	jal	80000b9e <initlock>
}
    8000437e:	60a2                	ld	ra,8(sp)
    80004380:	6402                	ld	s0,0(sp)
    80004382:	0141                	addi	sp,sp,16
    80004384:	8082                	ret

0000000080004386 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004386:	1101                	addi	sp,sp,-32
    80004388:	ec06                	sd	ra,24(sp)
    8000438a:	e822                	sd	s0,16(sp)
    8000438c:	e426                	sd	s1,8(sp)
    8000438e:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004390:	0001c517          	auipc	a0,0x1c
    80004394:	94050513          	addi	a0,a0,-1728 # 8001fcd0 <ftable>
    80004398:	891fc0ef          	jal	80000c28 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000439c:	0001c497          	auipc	s1,0x1c
    800043a0:	94c48493          	addi	s1,s1,-1716 # 8001fce8 <ftable+0x18>
    800043a4:	0001d717          	auipc	a4,0x1d
    800043a8:	8e470713          	addi	a4,a4,-1820 # 80020c88 <disk>
    if(f->ref == 0){
    800043ac:	40dc                	lw	a5,4(s1)
    800043ae:	cf89                	beqz	a5,800043c8 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800043b0:	02848493          	addi	s1,s1,40
    800043b4:	fee49ce3          	bne	s1,a4,800043ac <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800043b8:	0001c517          	auipc	a0,0x1c
    800043bc:	91850513          	addi	a0,a0,-1768 # 8001fcd0 <ftable>
    800043c0:	8fdfc0ef          	jal	80000cbc <release>
  return 0;
    800043c4:	4481                	li	s1,0
    800043c6:	a809                	j	800043d8 <filealloc+0x52>
      f->ref = 1;
    800043c8:	4785                	li	a5,1
    800043ca:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800043cc:	0001c517          	auipc	a0,0x1c
    800043d0:	90450513          	addi	a0,a0,-1788 # 8001fcd0 <ftable>
    800043d4:	8e9fc0ef          	jal	80000cbc <release>
}
    800043d8:	8526                	mv	a0,s1
    800043da:	60e2                	ld	ra,24(sp)
    800043dc:	6442                	ld	s0,16(sp)
    800043de:	64a2                	ld	s1,8(sp)
    800043e0:	6105                	addi	sp,sp,32
    800043e2:	8082                	ret

00000000800043e4 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800043e4:	1101                	addi	sp,sp,-32
    800043e6:	ec06                	sd	ra,24(sp)
    800043e8:	e822                	sd	s0,16(sp)
    800043ea:	e426                	sd	s1,8(sp)
    800043ec:	1000                	addi	s0,sp,32
    800043ee:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800043f0:	0001c517          	auipc	a0,0x1c
    800043f4:	8e050513          	addi	a0,a0,-1824 # 8001fcd0 <ftable>
    800043f8:	831fc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    800043fc:	40dc                	lw	a5,4(s1)
    800043fe:	02f05063          	blez	a5,8000441e <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004402:	2785                	addiw	a5,a5,1
    80004404:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004406:	0001c517          	auipc	a0,0x1c
    8000440a:	8ca50513          	addi	a0,a0,-1846 # 8001fcd0 <ftable>
    8000440e:	8affc0ef          	jal	80000cbc <release>
  return f;
}
    80004412:	8526                	mv	a0,s1
    80004414:	60e2                	ld	ra,24(sp)
    80004416:	6442                	ld	s0,16(sp)
    80004418:	64a2                	ld	s1,8(sp)
    8000441a:	6105                	addi	sp,sp,32
    8000441c:	8082                	ret
    panic("filedup");
    8000441e:	00003517          	auipc	a0,0x3
    80004422:	17250513          	addi	a0,a0,370 # 80007590 <etext+0x590>
    80004426:	bfefc0ef          	jal	80000824 <panic>

000000008000442a <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000442a:	7139                	addi	sp,sp,-64
    8000442c:	fc06                	sd	ra,56(sp)
    8000442e:	f822                	sd	s0,48(sp)
    80004430:	f426                	sd	s1,40(sp)
    80004432:	0080                	addi	s0,sp,64
    80004434:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004436:	0001c517          	auipc	a0,0x1c
    8000443a:	89a50513          	addi	a0,a0,-1894 # 8001fcd0 <ftable>
    8000443e:	feafc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    80004442:	40dc                	lw	a5,4(s1)
    80004444:	04f05a63          	blez	a5,80004498 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80004448:	37fd                	addiw	a5,a5,-1
    8000444a:	c0dc                	sw	a5,4(s1)
    8000444c:	06f04063          	bgtz	a5,800044ac <fileclose+0x82>
    80004450:	f04a                	sd	s2,32(sp)
    80004452:	ec4e                	sd	s3,24(sp)
    80004454:	e852                	sd	s4,16(sp)
    80004456:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004458:	0004a903          	lw	s2,0(s1)
    8000445c:	0094c783          	lbu	a5,9(s1)
    80004460:	89be                	mv	s3,a5
    80004462:	689c                	ld	a5,16(s1)
    80004464:	8a3e                	mv	s4,a5
    80004466:	6c9c                	ld	a5,24(s1)
    80004468:	8abe                	mv	s5,a5
  f->ref = 0;
    8000446a:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000446e:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004472:	0001c517          	auipc	a0,0x1c
    80004476:	85e50513          	addi	a0,a0,-1954 # 8001fcd0 <ftable>
    8000447a:	843fc0ef          	jal	80000cbc <release>

  if(ff.type == FD_PIPE){
    8000447e:	4785                	li	a5,1
    80004480:	04f90163          	beq	s2,a5,800044c2 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004484:	ffe9079b          	addiw	a5,s2,-2
    80004488:	4705                	li	a4,1
    8000448a:	04f77563          	bgeu	a4,a5,800044d4 <fileclose+0xaa>
    8000448e:	7902                	ld	s2,32(sp)
    80004490:	69e2                	ld	s3,24(sp)
    80004492:	6a42                	ld	s4,16(sp)
    80004494:	6aa2                	ld	s5,8(sp)
    80004496:	a00d                	j	800044b8 <fileclose+0x8e>
    80004498:	f04a                	sd	s2,32(sp)
    8000449a:	ec4e                	sd	s3,24(sp)
    8000449c:	e852                	sd	s4,16(sp)
    8000449e:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800044a0:	00003517          	auipc	a0,0x3
    800044a4:	0f850513          	addi	a0,a0,248 # 80007598 <etext+0x598>
    800044a8:	b7cfc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    800044ac:	0001c517          	auipc	a0,0x1c
    800044b0:	82450513          	addi	a0,a0,-2012 # 8001fcd0 <ftable>
    800044b4:	809fc0ef          	jal	80000cbc <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800044b8:	70e2                	ld	ra,56(sp)
    800044ba:	7442                	ld	s0,48(sp)
    800044bc:	74a2                	ld	s1,40(sp)
    800044be:	6121                	addi	sp,sp,64
    800044c0:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800044c2:	85ce                	mv	a1,s3
    800044c4:	8552                	mv	a0,s4
    800044c6:	348000ef          	jal	8000480e <pipeclose>
    800044ca:	7902                	ld	s2,32(sp)
    800044cc:	69e2                	ld	s3,24(sp)
    800044ce:	6a42                	ld	s4,16(sp)
    800044d0:	6aa2                	ld	s5,8(sp)
    800044d2:	b7dd                	j	800044b8 <fileclose+0x8e>
    begin_op();
    800044d4:	b33ff0ef          	jal	80004006 <begin_op>
    iput(ff.ip);
    800044d8:	8556                	mv	a0,s5
    800044da:	aa2ff0ef          	jal	8000377c <iput>
    end_op();
    800044de:	b99ff0ef          	jal	80004076 <end_op>
    800044e2:	7902                	ld	s2,32(sp)
    800044e4:	69e2                	ld	s3,24(sp)
    800044e6:	6a42                	ld	s4,16(sp)
    800044e8:	6aa2                	ld	s5,8(sp)
    800044ea:	b7f9                	j	800044b8 <fileclose+0x8e>

00000000800044ec <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800044ec:	715d                	addi	sp,sp,-80
    800044ee:	e486                	sd	ra,72(sp)
    800044f0:	e0a2                	sd	s0,64(sp)
    800044f2:	fc26                	sd	s1,56(sp)
    800044f4:	f052                	sd	s4,32(sp)
    800044f6:	0880                	addi	s0,sp,80
    800044f8:	84aa                	mv	s1,a0
    800044fa:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    800044fc:	d8cfd0ef          	jal	80001a88 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004500:	409c                	lw	a5,0(s1)
    80004502:	37f9                	addiw	a5,a5,-2
    80004504:	4705                	li	a4,1
    80004506:	04f76263          	bltu	a4,a5,8000454a <filestat+0x5e>
    8000450a:	f84a                	sd	s2,48(sp)
    8000450c:	f44e                	sd	s3,40(sp)
    8000450e:	89aa                	mv	s3,a0
    ilock(f->ip);
    80004510:	6c88                	ld	a0,24(s1)
    80004512:	8e8ff0ef          	jal	800035fa <ilock>
    stati(f->ip, &st);
    80004516:	fb840913          	addi	s2,s0,-72
    8000451a:	85ca                	mv	a1,s2
    8000451c:	6c88                	ld	a0,24(s1)
    8000451e:	c40ff0ef          	jal	8000395e <stati>
    iunlock(f->ip);
    80004522:	6c88                	ld	a0,24(s1)
    80004524:	984ff0ef          	jal	800036a8 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80004528:	46e1                	li	a3,24
    8000452a:	864a                	mv	a2,s2
    8000452c:	85d2                	mv	a1,s4
    8000452e:	0589b503          	ld	a0,88(s3)
    80004532:	9bcfd0ef          	jal	800016ee <copyout>
    80004536:	41f5551b          	sraiw	a0,a0,0x1f
    8000453a:	7942                	ld	s2,48(sp)
    8000453c:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    8000453e:	60a6                	ld	ra,72(sp)
    80004540:	6406                	ld	s0,64(sp)
    80004542:	74e2                	ld	s1,56(sp)
    80004544:	7a02                	ld	s4,32(sp)
    80004546:	6161                	addi	sp,sp,80
    80004548:	8082                	ret
  return -1;
    8000454a:	557d                	li	a0,-1
    8000454c:	bfcd                	j	8000453e <filestat+0x52>

000000008000454e <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000454e:	7179                	addi	sp,sp,-48
    80004550:	f406                	sd	ra,40(sp)
    80004552:	f022                	sd	s0,32(sp)
    80004554:	e84a                	sd	s2,16(sp)
    80004556:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004558:	00854783          	lbu	a5,8(a0)
    8000455c:	cfd1                	beqz	a5,800045f8 <fileread+0xaa>
    8000455e:	ec26                	sd	s1,24(sp)
    80004560:	e44e                	sd	s3,8(sp)
    80004562:	84aa                	mv	s1,a0
    80004564:	892e                	mv	s2,a1
    80004566:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80004568:	411c                	lw	a5,0(a0)
    8000456a:	4705                	li	a4,1
    8000456c:	04e78363          	beq	a5,a4,800045b2 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004570:	470d                	li	a4,3
    80004572:	04e78763          	beq	a5,a4,800045c0 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004576:	4709                	li	a4,2
    80004578:	06e79a63          	bne	a5,a4,800045ec <fileread+0x9e>
    ilock(f->ip);
    8000457c:	6d08                	ld	a0,24(a0)
    8000457e:	87cff0ef          	jal	800035fa <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004582:	874e                	mv	a4,s3
    80004584:	5094                	lw	a3,32(s1)
    80004586:	864a                	mv	a2,s2
    80004588:	4585                	li	a1,1
    8000458a:	6c88                	ld	a0,24(s1)
    8000458c:	c00ff0ef          	jal	8000398c <readi>
    80004590:	892a                	mv	s2,a0
    80004592:	00a05563          	blez	a0,8000459c <fileread+0x4e>
      f->off += r;
    80004596:	509c                	lw	a5,32(s1)
    80004598:	9fa9                	addw	a5,a5,a0
    8000459a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000459c:	6c88                	ld	a0,24(s1)
    8000459e:	90aff0ef          	jal	800036a8 <iunlock>
    800045a2:	64e2                	ld	s1,24(sp)
    800045a4:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800045a6:	854a                	mv	a0,s2
    800045a8:	70a2                	ld	ra,40(sp)
    800045aa:	7402                	ld	s0,32(sp)
    800045ac:	6942                	ld	s2,16(sp)
    800045ae:	6145                	addi	sp,sp,48
    800045b0:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800045b2:	6908                	ld	a0,16(a0)
    800045b4:	3b0000ef          	jal	80004964 <piperead>
    800045b8:	892a                	mv	s2,a0
    800045ba:	64e2                	ld	s1,24(sp)
    800045bc:	69a2                	ld	s3,8(sp)
    800045be:	b7e5                	j	800045a6 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800045c0:	02451783          	lh	a5,36(a0)
    800045c4:	03079693          	slli	a3,a5,0x30
    800045c8:	92c1                	srli	a3,a3,0x30
    800045ca:	4725                	li	a4,9
    800045cc:	02d76963          	bltu	a4,a3,800045fe <fileread+0xb0>
    800045d0:	0792                	slli	a5,a5,0x4
    800045d2:	0001b717          	auipc	a4,0x1b
    800045d6:	65e70713          	addi	a4,a4,1630 # 8001fc30 <devsw>
    800045da:	97ba                	add	a5,a5,a4
    800045dc:	639c                	ld	a5,0(a5)
    800045de:	c78d                	beqz	a5,80004608 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    800045e0:	4505                	li	a0,1
    800045e2:	9782                	jalr	a5
    800045e4:	892a                	mv	s2,a0
    800045e6:	64e2                	ld	s1,24(sp)
    800045e8:	69a2                	ld	s3,8(sp)
    800045ea:	bf75                	j	800045a6 <fileread+0x58>
    panic("fileread");
    800045ec:	00003517          	auipc	a0,0x3
    800045f0:	fbc50513          	addi	a0,a0,-68 # 800075a8 <etext+0x5a8>
    800045f4:	a30fc0ef          	jal	80000824 <panic>
    return -1;
    800045f8:	57fd                	li	a5,-1
    800045fa:	893e                	mv	s2,a5
    800045fc:	b76d                	j	800045a6 <fileread+0x58>
      return -1;
    800045fe:	57fd                	li	a5,-1
    80004600:	893e                	mv	s2,a5
    80004602:	64e2                	ld	s1,24(sp)
    80004604:	69a2                	ld	s3,8(sp)
    80004606:	b745                	j	800045a6 <fileread+0x58>
    80004608:	57fd                	li	a5,-1
    8000460a:	893e                	mv	s2,a5
    8000460c:	64e2                	ld	s1,24(sp)
    8000460e:	69a2                	ld	s3,8(sp)
    80004610:	bf59                	j	800045a6 <fileread+0x58>

0000000080004612 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004612:	00954783          	lbu	a5,9(a0)
    80004616:	10078f63          	beqz	a5,80004734 <filewrite+0x122>
{
    8000461a:	711d                	addi	sp,sp,-96
    8000461c:	ec86                	sd	ra,88(sp)
    8000461e:	e8a2                	sd	s0,80(sp)
    80004620:	e0ca                	sd	s2,64(sp)
    80004622:	f456                	sd	s5,40(sp)
    80004624:	f05a                	sd	s6,32(sp)
    80004626:	1080                	addi	s0,sp,96
    80004628:	892a                	mv	s2,a0
    8000462a:	8b2e                	mv	s6,a1
    8000462c:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    8000462e:	411c                	lw	a5,0(a0)
    80004630:	4705                	li	a4,1
    80004632:	02e78a63          	beq	a5,a4,80004666 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004636:	470d                	li	a4,3
    80004638:	02e78b63          	beq	a5,a4,8000466e <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    8000463c:	4709                	li	a4,2
    8000463e:	0ce79f63          	bne	a5,a4,8000471c <filewrite+0x10a>
    80004642:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80004644:	0ac05a63          	blez	a2,800046f8 <filewrite+0xe6>
    80004648:	e4a6                	sd	s1,72(sp)
    8000464a:	fc4e                	sd	s3,56(sp)
    8000464c:	ec5e                	sd	s7,24(sp)
    8000464e:	e862                	sd	s8,16(sp)
    80004650:	e466                	sd	s9,8(sp)
    int i = 0;
    80004652:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80004654:	6b85                	lui	s7,0x1
    80004656:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000465a:	6785                	lui	a5,0x1
    8000465c:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004660:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004662:	4c05                	li	s8,1
    80004664:	a8ad                	j	800046de <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004666:	6908                	ld	a0,16(a0)
    80004668:	204000ef          	jal	8000486c <pipewrite>
    8000466c:	a04d                	j	8000470e <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000466e:	02451783          	lh	a5,36(a0)
    80004672:	03079693          	slli	a3,a5,0x30
    80004676:	92c1                	srli	a3,a3,0x30
    80004678:	4725                	li	a4,9
    8000467a:	0ad76f63          	bltu	a4,a3,80004738 <filewrite+0x126>
    8000467e:	0792                	slli	a5,a5,0x4
    80004680:	0001b717          	auipc	a4,0x1b
    80004684:	5b070713          	addi	a4,a4,1456 # 8001fc30 <devsw>
    80004688:	97ba                	add	a5,a5,a4
    8000468a:	679c                	ld	a5,8(a5)
    8000468c:	cbc5                	beqz	a5,8000473c <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    8000468e:	4505                	li	a0,1
    80004690:	9782                	jalr	a5
    80004692:	a8b5                	j	8000470e <filewrite+0xfc>
      if(n1 > max)
    80004694:	2981                	sext.w	s3,s3
      begin_op();
    80004696:	971ff0ef          	jal	80004006 <begin_op>
      ilock(f->ip);
    8000469a:	01893503          	ld	a0,24(s2)
    8000469e:	f5dfe0ef          	jal	800035fa <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800046a2:	874e                	mv	a4,s3
    800046a4:	02092683          	lw	a3,32(s2)
    800046a8:	016a0633          	add	a2,s4,s6
    800046ac:	85e2                	mv	a1,s8
    800046ae:	01893503          	ld	a0,24(s2)
    800046b2:	bccff0ef          	jal	80003a7e <writei>
    800046b6:	84aa                	mv	s1,a0
    800046b8:	00a05763          	blez	a0,800046c6 <filewrite+0xb4>
        f->off += r;
    800046bc:	02092783          	lw	a5,32(s2)
    800046c0:	9fa9                	addw	a5,a5,a0
    800046c2:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800046c6:	01893503          	ld	a0,24(s2)
    800046ca:	fdffe0ef          	jal	800036a8 <iunlock>
      end_op();
    800046ce:	9a9ff0ef          	jal	80004076 <end_op>

      if(r != n1){
    800046d2:	02999563          	bne	s3,s1,800046fc <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800046d6:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    800046da:	015a5963          	bge	s4,s5,800046ec <filewrite+0xda>
      int n1 = n - i;
    800046de:	414a87bb          	subw	a5,s5,s4
    800046e2:	89be                	mv	s3,a5
      if(n1 > max)
    800046e4:	fafbd8e3          	bge	s7,a5,80004694 <filewrite+0x82>
    800046e8:	89e6                	mv	s3,s9
    800046ea:	b76d                	j	80004694 <filewrite+0x82>
    800046ec:	64a6                	ld	s1,72(sp)
    800046ee:	79e2                	ld	s3,56(sp)
    800046f0:	6be2                	ld	s7,24(sp)
    800046f2:	6c42                	ld	s8,16(sp)
    800046f4:	6ca2                	ld	s9,8(sp)
    800046f6:	a801                	j	80004706 <filewrite+0xf4>
    int i = 0;
    800046f8:	4a01                	li	s4,0
    800046fa:	a031                	j	80004706 <filewrite+0xf4>
    800046fc:	64a6                	ld	s1,72(sp)
    800046fe:	79e2                	ld	s3,56(sp)
    80004700:	6be2                	ld	s7,24(sp)
    80004702:	6c42                	ld	s8,16(sp)
    80004704:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80004706:	034a9d63          	bne	s5,s4,80004740 <filewrite+0x12e>
    8000470a:	8556                	mv	a0,s5
    8000470c:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000470e:	60e6                	ld	ra,88(sp)
    80004710:	6446                	ld	s0,80(sp)
    80004712:	6906                	ld	s2,64(sp)
    80004714:	7aa2                	ld	s5,40(sp)
    80004716:	7b02                	ld	s6,32(sp)
    80004718:	6125                	addi	sp,sp,96
    8000471a:	8082                	ret
    8000471c:	e4a6                	sd	s1,72(sp)
    8000471e:	fc4e                	sd	s3,56(sp)
    80004720:	f852                	sd	s4,48(sp)
    80004722:	ec5e                	sd	s7,24(sp)
    80004724:	e862                	sd	s8,16(sp)
    80004726:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80004728:	00003517          	auipc	a0,0x3
    8000472c:	e9050513          	addi	a0,a0,-368 # 800075b8 <etext+0x5b8>
    80004730:	8f4fc0ef          	jal	80000824 <panic>
    return -1;
    80004734:	557d                	li	a0,-1
}
    80004736:	8082                	ret
      return -1;
    80004738:	557d                	li	a0,-1
    8000473a:	bfd1                	j	8000470e <filewrite+0xfc>
    8000473c:	557d                	li	a0,-1
    8000473e:	bfc1                	j	8000470e <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80004740:	557d                	li	a0,-1
    80004742:	7a42                	ld	s4,48(sp)
    80004744:	b7e9                	j	8000470e <filewrite+0xfc>

0000000080004746 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004746:	7179                	addi	sp,sp,-48
    80004748:	f406                	sd	ra,40(sp)
    8000474a:	f022                	sd	s0,32(sp)
    8000474c:	ec26                	sd	s1,24(sp)
    8000474e:	e052                	sd	s4,0(sp)
    80004750:	1800                	addi	s0,sp,48
    80004752:	84aa                	mv	s1,a0
    80004754:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004756:	0005b023          	sd	zero,0(a1)
    8000475a:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000475e:	c29ff0ef          	jal	80004386 <filealloc>
    80004762:	e088                	sd	a0,0(s1)
    80004764:	c549                	beqz	a0,800047ee <pipealloc+0xa8>
    80004766:	c21ff0ef          	jal	80004386 <filealloc>
    8000476a:	00aa3023          	sd	a0,0(s4)
    8000476e:	cd25                	beqz	a0,800047e6 <pipealloc+0xa0>
    80004770:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004772:	bd2fc0ef          	jal	80000b44 <kalloc>
    80004776:	892a                	mv	s2,a0
    80004778:	c12d                	beqz	a0,800047da <pipealloc+0x94>
    8000477a:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000477c:	4985                	li	s3,1
    8000477e:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004782:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004786:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000478a:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000478e:	00003597          	auipc	a1,0x3
    80004792:	e3a58593          	addi	a1,a1,-454 # 800075c8 <etext+0x5c8>
    80004796:	c08fc0ef          	jal	80000b9e <initlock>
  (*f0)->type = FD_PIPE;
    8000479a:	609c                	ld	a5,0(s1)
    8000479c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800047a0:	609c                	ld	a5,0(s1)
    800047a2:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800047a6:	609c                	ld	a5,0(s1)
    800047a8:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800047ac:	609c                	ld	a5,0(s1)
    800047ae:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800047b2:	000a3783          	ld	a5,0(s4)
    800047b6:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800047ba:	000a3783          	ld	a5,0(s4)
    800047be:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800047c2:	000a3783          	ld	a5,0(s4)
    800047c6:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800047ca:	000a3783          	ld	a5,0(s4)
    800047ce:	0127b823          	sd	s2,16(a5)
  return 0;
    800047d2:	4501                	li	a0,0
    800047d4:	6942                	ld	s2,16(sp)
    800047d6:	69a2                	ld	s3,8(sp)
    800047d8:	a01d                	j	800047fe <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800047da:	6088                	ld	a0,0(s1)
    800047dc:	c119                	beqz	a0,800047e2 <pipealloc+0x9c>
    800047de:	6942                	ld	s2,16(sp)
    800047e0:	a029                	j	800047ea <pipealloc+0xa4>
    800047e2:	6942                	ld	s2,16(sp)
    800047e4:	a029                	j	800047ee <pipealloc+0xa8>
    800047e6:	6088                	ld	a0,0(s1)
    800047e8:	c10d                	beqz	a0,8000480a <pipealloc+0xc4>
    fileclose(*f0);
    800047ea:	c41ff0ef          	jal	8000442a <fileclose>
  if(*f1)
    800047ee:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800047f2:	557d                	li	a0,-1
  if(*f1)
    800047f4:	c789                	beqz	a5,800047fe <pipealloc+0xb8>
    fileclose(*f1);
    800047f6:	853e                	mv	a0,a5
    800047f8:	c33ff0ef          	jal	8000442a <fileclose>
  return -1;
    800047fc:	557d                	li	a0,-1
}
    800047fe:	70a2                	ld	ra,40(sp)
    80004800:	7402                	ld	s0,32(sp)
    80004802:	64e2                	ld	s1,24(sp)
    80004804:	6a02                	ld	s4,0(sp)
    80004806:	6145                	addi	sp,sp,48
    80004808:	8082                	ret
  return -1;
    8000480a:	557d                	li	a0,-1
    8000480c:	bfcd                	j	800047fe <pipealloc+0xb8>

000000008000480e <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000480e:	1101                	addi	sp,sp,-32
    80004810:	ec06                	sd	ra,24(sp)
    80004812:	e822                	sd	s0,16(sp)
    80004814:	e426                	sd	s1,8(sp)
    80004816:	e04a                	sd	s2,0(sp)
    80004818:	1000                	addi	s0,sp,32
    8000481a:	84aa                	mv	s1,a0
    8000481c:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000481e:	c0afc0ef          	jal	80000c28 <acquire>
  if(writable){
    80004822:	02090763          	beqz	s2,80004850 <pipeclose+0x42>
    pi->writeopen = 0;
    80004826:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000482a:	21848513          	addi	a0,s1,536
    8000482e:	90ffd0ef          	jal	8000213c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004832:	2204a783          	lw	a5,544(s1)
    80004836:	e781                	bnez	a5,8000483e <pipeclose+0x30>
    80004838:	2244a783          	lw	a5,548(s1)
    8000483c:	c38d                	beqz	a5,8000485e <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    8000483e:	8526                	mv	a0,s1
    80004840:	c7cfc0ef          	jal	80000cbc <release>
}
    80004844:	60e2                	ld	ra,24(sp)
    80004846:	6442                	ld	s0,16(sp)
    80004848:	64a2                	ld	s1,8(sp)
    8000484a:	6902                	ld	s2,0(sp)
    8000484c:	6105                	addi	sp,sp,32
    8000484e:	8082                	ret
    pi->readopen = 0;
    80004850:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004854:	21c48513          	addi	a0,s1,540
    80004858:	8e5fd0ef          	jal	8000213c <wakeup>
    8000485c:	bfd9                	j	80004832 <pipeclose+0x24>
    release(&pi->lock);
    8000485e:	8526                	mv	a0,s1
    80004860:	c5cfc0ef          	jal	80000cbc <release>
    kfree((char*)pi);
    80004864:	8526                	mv	a0,s1
    80004866:	9f6fc0ef          	jal	80000a5c <kfree>
    8000486a:	bfe9                	j	80004844 <pipeclose+0x36>

000000008000486c <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    8000486c:	7159                	addi	sp,sp,-112
    8000486e:	f486                	sd	ra,104(sp)
    80004870:	f0a2                	sd	s0,96(sp)
    80004872:	eca6                	sd	s1,88(sp)
    80004874:	e8ca                	sd	s2,80(sp)
    80004876:	e4ce                	sd	s3,72(sp)
    80004878:	e0d2                	sd	s4,64(sp)
    8000487a:	fc56                	sd	s5,56(sp)
    8000487c:	1880                	addi	s0,sp,112
    8000487e:	84aa                	mv	s1,a0
    80004880:	8aae                	mv	s5,a1
    80004882:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004884:	a04fd0ef          	jal	80001a88 <myproc>
    80004888:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000488a:	8526                	mv	a0,s1
    8000488c:	b9cfc0ef          	jal	80000c28 <acquire>
  while(i < n){
    80004890:	0d405263          	blez	s4,80004954 <pipewrite+0xe8>
    80004894:	f85a                	sd	s6,48(sp)
    80004896:	f45e                	sd	s7,40(sp)
    80004898:	f062                	sd	s8,32(sp)
    8000489a:	ec66                	sd	s9,24(sp)
    8000489c:	e86a                	sd	s10,16(sp)
  int i = 0;
    8000489e:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800048a0:	f9f40c13          	addi	s8,s0,-97
    800048a4:	4b85                	li	s7,1
    800048a6:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800048a8:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800048ac:	21c48c93          	addi	s9,s1,540
    800048b0:	a82d                	j	800048ea <pipewrite+0x7e>
      release(&pi->lock);
    800048b2:	8526                	mv	a0,s1
    800048b4:	c08fc0ef          	jal	80000cbc <release>
      return -1;
    800048b8:	597d                	li	s2,-1
    800048ba:	7b42                	ld	s6,48(sp)
    800048bc:	7ba2                	ld	s7,40(sp)
    800048be:	7c02                	ld	s8,32(sp)
    800048c0:	6ce2                	ld	s9,24(sp)
    800048c2:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800048c4:	854a                	mv	a0,s2
    800048c6:	70a6                	ld	ra,104(sp)
    800048c8:	7406                	ld	s0,96(sp)
    800048ca:	64e6                	ld	s1,88(sp)
    800048cc:	6946                	ld	s2,80(sp)
    800048ce:	69a6                	ld	s3,72(sp)
    800048d0:	6a06                	ld	s4,64(sp)
    800048d2:	7ae2                	ld	s5,56(sp)
    800048d4:	6165                	addi	sp,sp,112
    800048d6:	8082                	ret
      wakeup(&pi->nread);
    800048d8:	856a                	mv	a0,s10
    800048da:	863fd0ef          	jal	8000213c <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800048de:	85a6                	mv	a1,s1
    800048e0:	8566                	mv	a0,s9
    800048e2:	80ffd0ef          	jal	800020f0 <sleep>
  while(i < n){
    800048e6:	05495a63          	bge	s2,s4,8000493a <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    800048ea:	2204a783          	lw	a5,544(s1)
    800048ee:	d3f1                	beqz	a5,800048b2 <pipewrite+0x46>
    800048f0:	854e                	mv	a0,s3
    800048f2:	a3bfd0ef          	jal	8000232c <killed>
    800048f6:	fd55                	bnez	a0,800048b2 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800048f8:	2184a783          	lw	a5,536(s1)
    800048fc:	21c4a703          	lw	a4,540(s1)
    80004900:	2007879b          	addiw	a5,a5,512
    80004904:	fcf70ae3          	beq	a4,a5,800048d8 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004908:	86de                	mv	a3,s7
    8000490a:	01590633          	add	a2,s2,s5
    8000490e:	85e2                	mv	a1,s8
    80004910:	0589b503          	ld	a0,88(s3)
    80004914:	e99fc0ef          	jal	800017ac <copyin>
    80004918:	05650063          	beq	a0,s6,80004958 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000491c:	21c4a783          	lw	a5,540(s1)
    80004920:	0017871b          	addiw	a4,a5,1
    80004924:	20e4ae23          	sw	a4,540(s1)
    80004928:	1ff7f793          	andi	a5,a5,511
    8000492c:	97a6                	add	a5,a5,s1
    8000492e:	f9f44703          	lbu	a4,-97(s0)
    80004932:	00e78c23          	sb	a4,24(a5)
      i++;
    80004936:	2905                	addiw	s2,s2,1
    80004938:	b77d                	j	800048e6 <pipewrite+0x7a>
    8000493a:	7b42                	ld	s6,48(sp)
    8000493c:	7ba2                	ld	s7,40(sp)
    8000493e:	7c02                	ld	s8,32(sp)
    80004940:	6ce2                	ld	s9,24(sp)
    80004942:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004944:	21848513          	addi	a0,s1,536
    80004948:	ff4fd0ef          	jal	8000213c <wakeup>
  release(&pi->lock);
    8000494c:	8526                	mv	a0,s1
    8000494e:	b6efc0ef          	jal	80000cbc <release>
  return i;
    80004952:	bf8d                	j	800048c4 <pipewrite+0x58>
  int i = 0;
    80004954:	4901                	li	s2,0
    80004956:	b7fd                	j	80004944 <pipewrite+0xd8>
    80004958:	7b42                	ld	s6,48(sp)
    8000495a:	7ba2                	ld	s7,40(sp)
    8000495c:	7c02                	ld	s8,32(sp)
    8000495e:	6ce2                	ld	s9,24(sp)
    80004960:	6d42                	ld	s10,16(sp)
    80004962:	b7cd                	j	80004944 <pipewrite+0xd8>

0000000080004964 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004964:	711d                	addi	sp,sp,-96
    80004966:	ec86                	sd	ra,88(sp)
    80004968:	e8a2                	sd	s0,80(sp)
    8000496a:	e4a6                	sd	s1,72(sp)
    8000496c:	e0ca                	sd	s2,64(sp)
    8000496e:	fc4e                	sd	s3,56(sp)
    80004970:	f852                	sd	s4,48(sp)
    80004972:	f456                	sd	s5,40(sp)
    80004974:	1080                	addi	s0,sp,96
    80004976:	84aa                	mv	s1,a0
    80004978:	892e                	mv	s2,a1
    8000497a:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000497c:	90cfd0ef          	jal	80001a88 <myproc>
    80004980:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004982:	8526                	mv	a0,s1
    80004984:	aa4fc0ef          	jal	80000c28 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004988:	2184a703          	lw	a4,536(s1)
    8000498c:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004990:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004994:	02f71763          	bne	a4,a5,800049c2 <piperead+0x5e>
    80004998:	2244a783          	lw	a5,548(s1)
    8000499c:	cf85                	beqz	a5,800049d4 <piperead+0x70>
    if(killed(pr)){
    8000499e:	8552                	mv	a0,s4
    800049a0:	98dfd0ef          	jal	8000232c <killed>
    800049a4:	e11d                	bnez	a0,800049ca <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800049a6:	85a6                	mv	a1,s1
    800049a8:	854e                	mv	a0,s3
    800049aa:	f46fd0ef          	jal	800020f0 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800049ae:	2184a703          	lw	a4,536(s1)
    800049b2:	21c4a783          	lw	a5,540(s1)
    800049b6:	fef701e3          	beq	a4,a5,80004998 <piperead+0x34>
    800049ba:	f05a                	sd	s6,32(sp)
    800049bc:	ec5e                	sd	s7,24(sp)
    800049be:	e862                	sd	s8,16(sp)
    800049c0:	a829                	j	800049da <piperead+0x76>
    800049c2:	f05a                	sd	s6,32(sp)
    800049c4:	ec5e                	sd	s7,24(sp)
    800049c6:	e862                	sd	s8,16(sp)
    800049c8:	a809                	j	800049da <piperead+0x76>
      release(&pi->lock);
    800049ca:	8526                	mv	a0,s1
    800049cc:	af0fc0ef          	jal	80000cbc <release>
      return -1;
    800049d0:	59fd                	li	s3,-1
    800049d2:	a09d                	j	80004a38 <piperead+0xd4>
    800049d4:	f05a                	sd	s6,32(sp)
    800049d6:	ec5e                	sd	s7,24(sp)
    800049d8:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800049da:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800049dc:	faf40c13          	addi	s8,s0,-81
    800049e0:	4b85                	li	s7,1
    800049e2:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800049e4:	05505063          	blez	s5,80004a24 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    800049e8:	2184a783          	lw	a5,536(s1)
    800049ec:	21c4a703          	lw	a4,540(s1)
    800049f0:	02f70a63          	beq	a4,a5,80004a24 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800049f4:	0017871b          	addiw	a4,a5,1
    800049f8:	20e4ac23          	sw	a4,536(s1)
    800049fc:	1ff7f793          	andi	a5,a5,511
    80004a00:	97a6                	add	a5,a5,s1
    80004a02:	0187c783          	lbu	a5,24(a5)
    80004a06:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004a0a:	86de                	mv	a3,s7
    80004a0c:	8662                	mv	a2,s8
    80004a0e:	85ca                	mv	a1,s2
    80004a10:	058a3503          	ld	a0,88(s4)
    80004a14:	cdbfc0ef          	jal	800016ee <copyout>
    80004a18:	01650663          	beq	a0,s6,80004a24 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a1c:	2985                	addiw	s3,s3,1
    80004a1e:	0905                	addi	s2,s2,1
    80004a20:	fd3a94e3          	bne	s5,s3,800049e8 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004a24:	21c48513          	addi	a0,s1,540
    80004a28:	f14fd0ef          	jal	8000213c <wakeup>
  release(&pi->lock);
    80004a2c:	8526                	mv	a0,s1
    80004a2e:	a8efc0ef          	jal	80000cbc <release>
    80004a32:	7b02                	ld	s6,32(sp)
    80004a34:	6be2                	ld	s7,24(sp)
    80004a36:	6c42                	ld	s8,16(sp)
  return i;
}
    80004a38:	854e                	mv	a0,s3
    80004a3a:	60e6                	ld	ra,88(sp)
    80004a3c:	6446                	ld	s0,80(sp)
    80004a3e:	64a6                	ld	s1,72(sp)
    80004a40:	6906                	ld	s2,64(sp)
    80004a42:	79e2                	ld	s3,56(sp)
    80004a44:	7a42                	ld	s4,48(sp)
    80004a46:	7aa2                	ld	s5,40(sp)
    80004a48:	6125                	addi	sp,sp,96
    80004a4a:	8082                	ret

0000000080004a4c <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    80004a4c:	1141                	addi	sp,sp,-16
    80004a4e:	e406                	sd	ra,8(sp)
    80004a50:	e022                	sd	s0,0(sp)
    80004a52:	0800                	addi	s0,sp,16
    80004a54:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004a56:	0035151b          	slliw	a0,a0,0x3
    80004a5a:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80004a5c:	8b89                	andi	a5,a5,2
    80004a5e:	c399                	beqz	a5,80004a64 <flags2perm+0x18>
      perm |= PTE_W;
    80004a60:	00456513          	ori	a0,a0,4
    return perm;
}
    80004a64:	60a2                	ld	ra,8(sp)
    80004a66:	6402                	ld	s0,0(sp)
    80004a68:	0141                	addi	sp,sp,16
    80004a6a:	8082                	ret

0000000080004a6c <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004a6c:	de010113          	addi	sp,sp,-544
    80004a70:	20113c23          	sd	ra,536(sp)
    80004a74:	20813823          	sd	s0,528(sp)
    80004a78:	20913423          	sd	s1,520(sp)
    80004a7c:	21213023          	sd	s2,512(sp)
    80004a80:	1400                	addi	s0,sp,544
    80004a82:	892a                	mv	s2,a0
    80004a84:	dea43823          	sd	a0,-528(s0)
    80004a88:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004a8c:	ffdfc0ef          	jal	80001a88 <myproc>
    80004a90:	84aa                	mv	s1,a0

  begin_op();
    80004a92:	d74ff0ef          	jal	80004006 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004a96:	854a                	mv	a0,s2
    80004a98:	b90ff0ef          	jal	80003e28 <namei>
    80004a9c:	cd21                	beqz	a0,80004af4 <kexec+0x88>
    80004a9e:	fbd2                	sd	s4,496(sp)
    80004aa0:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004aa2:	b59fe0ef          	jal	800035fa <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004aa6:	04000713          	li	a4,64
    80004aaa:	4681                	li	a3,0
    80004aac:	e5040613          	addi	a2,s0,-432
    80004ab0:	4581                	li	a1,0
    80004ab2:	8552                	mv	a0,s4
    80004ab4:	ed9fe0ef          	jal	8000398c <readi>
    80004ab8:	04000793          	li	a5,64
    80004abc:	00f51a63          	bne	a0,a5,80004ad0 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004ac0:	e5042703          	lw	a4,-432(s0)
    80004ac4:	464c47b7          	lui	a5,0x464c4
    80004ac8:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004acc:	02f70863          	beq	a4,a5,80004afc <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004ad0:	8552                	mv	a0,s4
    80004ad2:	d35fe0ef          	jal	80003806 <iunlockput>
    end_op();
    80004ad6:	da0ff0ef          	jal	80004076 <end_op>
  }
  return -1;
    80004ada:	557d                	li	a0,-1
    80004adc:	7a5e                	ld	s4,496(sp)
}
    80004ade:	21813083          	ld	ra,536(sp)
    80004ae2:	21013403          	ld	s0,528(sp)
    80004ae6:	20813483          	ld	s1,520(sp)
    80004aea:	20013903          	ld	s2,512(sp)
    80004aee:	22010113          	addi	sp,sp,544
    80004af2:	8082                	ret
    end_op();
    80004af4:	d82ff0ef          	jal	80004076 <end_op>
    return -1;
    80004af8:	557d                	li	a0,-1
    80004afa:	b7d5                	j	80004ade <kexec+0x72>
    80004afc:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004afe:	8526                	mv	a0,s1
    80004b00:	892fd0ef          	jal	80001b92 <proc_pagetable>
    80004b04:	8b2a                	mv	s6,a0
    80004b06:	28050963          	beqz	a0,80004d98 <kexec+0x32c>
    80004b0a:	ffce                	sd	s3,504(sp)
    80004b0c:	f7d6                	sd	s5,488(sp)
    80004b0e:	efde                	sd	s7,472(sp)
    80004b10:	ebe2                	sd	s8,464(sp)
    80004b12:	e7e6                	sd	s9,456(sp)
    80004b14:	e3ea                	sd	s10,448(sp)
    80004b16:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b18:	e8845783          	lhu	a5,-376(s0)
    80004b1c:	0e078963          	beqz	a5,80004c0e <kexec+0x1a2>
    80004b20:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b24:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b26:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004b28:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80004b2c:	6c85                	lui	s9,0x1
    80004b2e:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004b32:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004b36:	6a85                	lui	s5,0x1
    80004b38:	a085                	j	80004b98 <kexec+0x12c>
      panic("loadseg: address should exist");
    80004b3a:	00003517          	auipc	a0,0x3
    80004b3e:	a9650513          	addi	a0,a0,-1386 # 800075d0 <etext+0x5d0>
    80004b42:	ce3fb0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    80004b46:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004b48:	874a                	mv	a4,s2
    80004b4a:	009b86bb          	addw	a3,s7,s1
    80004b4e:	4581                	li	a1,0
    80004b50:	8552                	mv	a0,s4
    80004b52:	e3bfe0ef          	jal	8000398c <readi>
    80004b56:	24a91563          	bne	s2,a0,80004da0 <kexec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    80004b5a:	009a84bb          	addw	s1,s5,s1
    80004b5e:	0334f263          	bgeu	s1,s3,80004b82 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    80004b62:	02049593          	slli	a1,s1,0x20
    80004b66:	9181                	srli	a1,a1,0x20
    80004b68:	95e2                	add	a1,a1,s8
    80004b6a:	855a                	mv	a0,s6
    80004b6c:	d54fc0ef          	jal	800010c0 <walkaddr>
    80004b70:	862a                	mv	a2,a0
    if(pa == 0)
    80004b72:	d561                	beqz	a0,80004b3a <kexec+0xce>
    if(sz - i < PGSIZE)
    80004b74:	409987bb          	subw	a5,s3,s1
    80004b78:	893e                	mv	s2,a5
    80004b7a:	fcfcf6e3          	bgeu	s9,a5,80004b46 <kexec+0xda>
    80004b7e:	8956                	mv	s2,s5
    80004b80:	b7d9                	j	80004b46 <kexec+0xda>
    sz = sz1;
    80004b82:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b86:	2d05                	addiw	s10,s10,1
    80004b88:	e0843783          	ld	a5,-504(s0)
    80004b8c:	0387869b          	addiw	a3,a5,56
    80004b90:	e8845783          	lhu	a5,-376(s0)
    80004b94:	06fd5e63          	bge	s10,a5,80004c10 <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004b98:	e0d43423          	sd	a3,-504(s0)
    80004b9c:	876e                	mv	a4,s11
    80004b9e:	e1840613          	addi	a2,s0,-488
    80004ba2:	4581                	li	a1,0
    80004ba4:	8552                	mv	a0,s4
    80004ba6:	de7fe0ef          	jal	8000398c <readi>
    80004baa:	1fb51963          	bne	a0,s11,80004d9c <kexec+0x330>
    if(ph.type != ELF_PROG_LOAD)
    80004bae:	e1842783          	lw	a5,-488(s0)
    80004bb2:	4705                	li	a4,1
    80004bb4:	fce799e3          	bne	a5,a4,80004b86 <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    80004bb8:	e4043483          	ld	s1,-448(s0)
    80004bbc:	e3843783          	ld	a5,-456(s0)
    80004bc0:	1ef4ee63          	bltu	s1,a5,80004dbc <kexec+0x350>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004bc4:	e2843783          	ld	a5,-472(s0)
    80004bc8:	94be                	add	s1,s1,a5
    80004bca:	1ef4ec63          	bltu	s1,a5,80004dc2 <kexec+0x356>
    if(ph.vaddr % PGSIZE != 0)
    80004bce:	de843703          	ld	a4,-536(s0)
    80004bd2:	8ff9                	and	a5,a5,a4
    80004bd4:	1e079a63          	bnez	a5,80004dc8 <kexec+0x35c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004bd8:	e1c42503          	lw	a0,-484(s0)
    80004bdc:	e71ff0ef          	jal	80004a4c <flags2perm>
    80004be0:	86aa                	mv	a3,a0
    80004be2:	8626                	mv	a2,s1
    80004be4:	85ca                	mv	a1,s2
    80004be6:	855a                	mv	a0,s6
    80004be8:	faefc0ef          	jal	80001396 <uvmalloc>
    80004bec:	dea43c23          	sd	a0,-520(s0)
    80004bf0:	1c050f63          	beqz	a0,80004dce <kexec+0x362>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004bf4:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004bf8:	00098863          	beqz	s3,80004c08 <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004bfc:	e2843c03          	ld	s8,-472(s0)
    80004c00:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004c04:	4481                	li	s1,0
    80004c06:	bfb1                	j	80004b62 <kexec+0xf6>
    sz = sz1;
    80004c08:	df843903          	ld	s2,-520(s0)
    80004c0c:	bfad                	j	80004b86 <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004c0e:	4901                	li	s2,0
  iunlockput(ip);
    80004c10:	8552                	mv	a0,s4
    80004c12:	bf5fe0ef          	jal	80003806 <iunlockput>
  end_op();
    80004c16:	c60ff0ef          	jal	80004076 <end_op>
  p = myproc();
    80004c1a:	e6ffc0ef          	jal	80001a88 <myproc>
    80004c1e:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004c20:	05053d03          	ld	s10,80(a0)
  sz = PGROUNDUP(sz);
    80004c24:	6985                	lui	s3,0x1
    80004c26:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004c28:	99ca                	add	s3,s3,s2
    80004c2a:	77fd                	lui	a5,0xfffff
    80004c2c:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004c30:	4691                	li	a3,4
    80004c32:	6609                	lui	a2,0x2
    80004c34:	964e                	add	a2,a2,s3
    80004c36:	85ce                	mv	a1,s3
    80004c38:	855a                	mv	a0,s6
    80004c3a:	f5cfc0ef          	jal	80001396 <uvmalloc>
    80004c3e:	8a2a                	mv	s4,a0
    80004c40:	e105                	bnez	a0,80004c60 <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80004c42:	85ce                	mv	a1,s3
    80004c44:	855a                	mv	a0,s6
    80004c46:	fd1fc0ef          	jal	80001c16 <proc_freepagetable>
  return -1;
    80004c4a:	557d                	li	a0,-1
    80004c4c:	79fe                	ld	s3,504(sp)
    80004c4e:	7a5e                	ld	s4,496(sp)
    80004c50:	7abe                	ld	s5,488(sp)
    80004c52:	7b1e                	ld	s6,480(sp)
    80004c54:	6bfe                	ld	s7,472(sp)
    80004c56:	6c5e                	ld	s8,464(sp)
    80004c58:	6cbe                	ld	s9,456(sp)
    80004c5a:	6d1e                	ld	s10,448(sp)
    80004c5c:	7dfa                	ld	s11,440(sp)
    80004c5e:	b541                	j	80004ade <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004c60:	75f9                	lui	a1,0xffffe
    80004c62:	95aa                	add	a1,a1,a0
    80004c64:	855a                	mv	a0,s6
    80004c66:	903fc0ef          	jal	80001568 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004c6a:	800a0b93          	addi	s7,s4,-2048
    80004c6e:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80004c72:	e0043783          	ld	a5,-512(s0)
    80004c76:	6388                	ld	a0,0(a5)
  sp = sz;
    80004c78:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80004c7a:	4481                	li	s1,0
    ustack[argc] = sp;
    80004c7c:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004c80:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80004c84:	cd21                	beqz	a0,80004cdc <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80004c86:	9fcfc0ef          	jal	80000e82 <strlen>
    80004c8a:	0015079b          	addiw	a5,a0,1
    80004c8e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004c92:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004c96:	13796f63          	bltu	s2,s7,80004dd4 <kexec+0x368>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004c9a:	e0043d83          	ld	s11,-512(s0)
    80004c9e:	000db983          	ld	s3,0(s11)
    80004ca2:	854e                	mv	a0,s3
    80004ca4:	9defc0ef          	jal	80000e82 <strlen>
    80004ca8:	0015069b          	addiw	a3,a0,1
    80004cac:	864e                	mv	a2,s3
    80004cae:	85ca                	mv	a1,s2
    80004cb0:	855a                	mv	a0,s6
    80004cb2:	a3dfc0ef          	jal	800016ee <copyout>
    80004cb6:	12054163          	bltz	a0,80004dd8 <kexec+0x36c>
    ustack[argc] = sp;
    80004cba:	00349793          	slli	a5,s1,0x3
    80004cbe:	97e6                	add	a5,a5,s9
    80004cc0:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde238>
  for(argc = 0; argv[argc]; argc++) {
    80004cc4:	0485                	addi	s1,s1,1
    80004cc6:	008d8793          	addi	a5,s11,8
    80004cca:	e0f43023          	sd	a5,-512(s0)
    80004cce:	008db503          	ld	a0,8(s11)
    80004cd2:	c509                	beqz	a0,80004cdc <kexec+0x270>
    if(argc >= MAXARG)
    80004cd4:	fb8499e3          	bne	s1,s8,80004c86 <kexec+0x21a>
  sz = sz1;
    80004cd8:	89d2                	mv	s3,s4
    80004cda:	b7a5                	j	80004c42 <kexec+0x1d6>
  ustack[argc] = 0;
    80004cdc:	00349793          	slli	a5,s1,0x3
    80004ce0:	f9078793          	addi	a5,a5,-112
    80004ce4:	97a2                	add	a5,a5,s0
    80004ce6:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004cea:	00349693          	slli	a3,s1,0x3
    80004cee:	06a1                	addi	a3,a3,8
    80004cf0:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004cf4:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004cf8:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80004cfa:	f57964e3          	bltu	s2,s7,80004c42 <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004cfe:	e9040613          	addi	a2,s0,-368
    80004d02:	85ca                	mv	a1,s2
    80004d04:	855a                	mv	a0,s6
    80004d06:	9e9fc0ef          	jal	800016ee <copyout>
    80004d0a:	f2054ce3          	bltz	a0,80004c42 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004d0e:	060ab783          	ld	a5,96(s5) # 1060 <_entry-0x7fffefa0>
    80004d12:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004d16:	df043783          	ld	a5,-528(s0)
    80004d1a:	0007c703          	lbu	a4,0(a5)
    80004d1e:	cf11                	beqz	a4,80004d3a <kexec+0x2ce>
    80004d20:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004d22:	02f00693          	li	a3,47
    80004d26:	a029                	j	80004d30 <kexec+0x2c4>
  for(last=s=path; *s; s++)
    80004d28:	0785                	addi	a5,a5,1
    80004d2a:	fff7c703          	lbu	a4,-1(a5)
    80004d2e:	c711                	beqz	a4,80004d3a <kexec+0x2ce>
    if(*s == '/')
    80004d30:	fed71ce3          	bne	a4,a3,80004d28 <kexec+0x2bc>
      last = s+1;
    80004d34:	def43823          	sd	a5,-528(s0)
    80004d38:	bfc5                	j	80004d28 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004d3a:	4641                	li	a2,16
    80004d3c:	df043583          	ld	a1,-528(s0)
    80004d40:	160a8513          	addi	a0,s5,352
    80004d44:	908fc0ef          	jal	80000e4c <safestrcpy>
  oldpagetable = p->pagetable;
    80004d48:	058ab503          	ld	a0,88(s5)
  p->pagetable = pagetable;
    80004d4c:	056abc23          	sd	s6,88(s5)
  p->sz = sz;
    80004d50:	054ab823          	sd	s4,80(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004d54:	060ab783          	ld	a5,96(s5)
    80004d58:	e6843703          	ld	a4,-408(s0)
    80004d5c:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004d5e:	060ab783          	ld	a5,96(s5)
    80004d62:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004d66:	85ea                	mv	a1,s10
    80004d68:	eaffc0ef          	jal	80001c16 <proc_freepagetable>
  if(p->pid == 1){
    80004d6c:	038aa703          	lw	a4,56(s5)
    80004d70:	4785                	li	a5,1
    80004d72:	00f70e63          	beq	a4,a5,80004d8e <kexec+0x322>
  return argc;
    80004d76:	0004851b          	sext.w	a0,s1
    80004d7a:	79fe                	ld	s3,504(sp)
    80004d7c:	7a5e                	ld	s4,496(sp)
    80004d7e:	7abe                	ld	s5,488(sp)
    80004d80:	7b1e                	ld	s6,480(sp)
    80004d82:	6bfe                	ld	s7,472(sp)
    80004d84:	6c5e                	ld	s8,464(sp)
    80004d86:	6cbe                	ld	s9,456(sp)
    80004d88:	6d1e                	ld	s10,448(sp)
    80004d8a:	7dfa                	ld	s11,440(sp)
    80004d8c:	bb89                	j	80004ade <kexec+0x72>
    vmprint(p->pagetable);
    80004d8e:	058ab503          	ld	a0,88(s5)
    80004d92:	aa9fc0ef          	jal	8000183a <vmprint>
    80004d96:	b7c5                	j	80004d76 <kexec+0x30a>
    80004d98:	7b1e                	ld	s6,480(sp)
    80004d9a:	bb1d                	j	80004ad0 <kexec+0x64>
    80004d9c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004da0:	df843583          	ld	a1,-520(s0)
    80004da4:	855a                	mv	a0,s6
    80004da6:	e71fc0ef          	jal	80001c16 <proc_freepagetable>
  if(ip){
    80004daa:	79fe                	ld	s3,504(sp)
    80004dac:	7abe                	ld	s5,488(sp)
    80004dae:	7b1e                	ld	s6,480(sp)
    80004db0:	6bfe                	ld	s7,472(sp)
    80004db2:	6c5e                	ld	s8,464(sp)
    80004db4:	6cbe                	ld	s9,456(sp)
    80004db6:	6d1e                	ld	s10,448(sp)
    80004db8:	7dfa                	ld	s11,440(sp)
    80004dba:	bb19                	j	80004ad0 <kexec+0x64>
    80004dbc:	df243c23          	sd	s2,-520(s0)
    80004dc0:	b7c5                	j	80004da0 <kexec+0x334>
    80004dc2:	df243c23          	sd	s2,-520(s0)
    80004dc6:	bfe9                	j	80004da0 <kexec+0x334>
    80004dc8:	df243c23          	sd	s2,-520(s0)
    80004dcc:	bfd1                	j	80004da0 <kexec+0x334>
    80004dce:	df243c23          	sd	s2,-520(s0)
    80004dd2:	b7f9                	j	80004da0 <kexec+0x334>
  sz = sz1;
    80004dd4:	89d2                	mv	s3,s4
    80004dd6:	b5b5                	j	80004c42 <kexec+0x1d6>
    80004dd8:	89d2                	mv	s3,s4
    80004dda:	b5a5                	j	80004c42 <kexec+0x1d6>

0000000080004ddc <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004ddc:	7179                	addi	sp,sp,-48
    80004dde:	f406                	sd	ra,40(sp)
    80004de0:	f022                	sd	s0,32(sp)
    80004de2:	ec26                	sd	s1,24(sp)
    80004de4:	e84a                	sd	s2,16(sp)
    80004de6:	1800                	addi	s0,sp,48
    80004de8:	892e                	mv	s2,a1
    80004dea:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004dec:	fdc40593          	addi	a1,s0,-36
    80004df0:	d8bfd0ef          	jal	80002b7a <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004df4:	fdc42703          	lw	a4,-36(s0)
    80004df8:	47bd                	li	a5,15
    80004dfa:	02e7ea63          	bltu	a5,a4,80004e2e <argfd+0x52>
    80004dfe:	c8bfc0ef          	jal	80001a88 <myproc>
    80004e02:	fdc42703          	lw	a4,-36(s0)
    80004e06:	00371793          	slli	a5,a4,0x3
    80004e0a:	0d078793          	addi	a5,a5,208
    80004e0e:	953e                	add	a0,a0,a5
    80004e10:	651c                	ld	a5,8(a0)
    80004e12:	c385                	beqz	a5,80004e32 <argfd+0x56>
    return -1;
  if(pfd)
    80004e14:	00090463          	beqz	s2,80004e1c <argfd+0x40>
    *pfd = fd;
    80004e18:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004e1c:	4501                	li	a0,0
  if(pf)
    80004e1e:	c091                	beqz	s1,80004e22 <argfd+0x46>
    *pf = f;
    80004e20:	e09c                	sd	a5,0(s1)
}
    80004e22:	70a2                	ld	ra,40(sp)
    80004e24:	7402                	ld	s0,32(sp)
    80004e26:	64e2                	ld	s1,24(sp)
    80004e28:	6942                	ld	s2,16(sp)
    80004e2a:	6145                	addi	sp,sp,48
    80004e2c:	8082                	ret
    return -1;
    80004e2e:	557d                	li	a0,-1
    80004e30:	bfcd                	j	80004e22 <argfd+0x46>
    80004e32:	557d                	li	a0,-1
    80004e34:	b7fd                	j	80004e22 <argfd+0x46>

0000000080004e36 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004e36:	1101                	addi	sp,sp,-32
    80004e38:	ec06                	sd	ra,24(sp)
    80004e3a:	e822                	sd	s0,16(sp)
    80004e3c:	e426                	sd	s1,8(sp)
    80004e3e:	1000                	addi	s0,sp,32
    80004e40:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004e42:	c47fc0ef          	jal	80001a88 <myproc>
    80004e46:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004e48:	0d850793          	addi	a5,a0,216
    80004e4c:	4501                	li	a0,0
    80004e4e:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004e50:	6398                	ld	a4,0(a5)
    80004e52:	cb19                	beqz	a4,80004e68 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004e54:	2505                	addiw	a0,a0,1
    80004e56:	07a1                	addi	a5,a5,8
    80004e58:	fed51ce3          	bne	a0,a3,80004e50 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004e5c:	557d                	li	a0,-1
}
    80004e5e:	60e2                	ld	ra,24(sp)
    80004e60:	6442                	ld	s0,16(sp)
    80004e62:	64a2                	ld	s1,8(sp)
    80004e64:	6105                	addi	sp,sp,32
    80004e66:	8082                	ret
      p->ofile[fd] = f;
    80004e68:	00351793          	slli	a5,a0,0x3
    80004e6c:	0d078793          	addi	a5,a5,208
    80004e70:	963e                	add	a2,a2,a5
    80004e72:	e604                	sd	s1,8(a2)
      return fd;
    80004e74:	b7ed                	j	80004e5e <fdalloc+0x28>

0000000080004e76 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004e76:	715d                	addi	sp,sp,-80
    80004e78:	e486                	sd	ra,72(sp)
    80004e7a:	e0a2                	sd	s0,64(sp)
    80004e7c:	fc26                	sd	s1,56(sp)
    80004e7e:	f84a                	sd	s2,48(sp)
    80004e80:	f44e                	sd	s3,40(sp)
    80004e82:	f052                	sd	s4,32(sp)
    80004e84:	ec56                	sd	s5,24(sp)
    80004e86:	e85a                	sd	s6,16(sp)
    80004e88:	0880                	addi	s0,sp,80
    80004e8a:	892e                	mv	s2,a1
    80004e8c:	8a2e                	mv	s4,a1
    80004e8e:	8ab2                	mv	s5,a2
    80004e90:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004e92:	fb040593          	addi	a1,s0,-80
    80004e96:	fadfe0ef          	jal	80003e42 <nameiparent>
    80004e9a:	84aa                	mv	s1,a0
    80004e9c:	10050763          	beqz	a0,80004faa <create+0x134>
    return 0;

  ilock(dp);
    80004ea0:	f5afe0ef          	jal	800035fa <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004ea4:	4601                	li	a2,0
    80004ea6:	fb040593          	addi	a1,s0,-80
    80004eaa:	8526                	mv	a0,s1
    80004eac:	ce9fe0ef          	jal	80003b94 <dirlookup>
    80004eb0:	89aa                	mv	s3,a0
    80004eb2:	c131                	beqz	a0,80004ef6 <create+0x80>
    iunlockput(dp);
    80004eb4:	8526                	mv	a0,s1
    80004eb6:	951fe0ef          	jal	80003806 <iunlockput>
    ilock(ip);
    80004eba:	854e                	mv	a0,s3
    80004ebc:	f3efe0ef          	jal	800035fa <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004ec0:	4789                	li	a5,2
    80004ec2:	02f91563          	bne	s2,a5,80004eec <create+0x76>
    80004ec6:	0449d783          	lhu	a5,68(s3)
    80004eca:	37f9                	addiw	a5,a5,-2
    80004ecc:	17c2                	slli	a5,a5,0x30
    80004ece:	93c1                	srli	a5,a5,0x30
    80004ed0:	4705                	li	a4,1
    80004ed2:	00f76d63          	bltu	a4,a5,80004eec <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004ed6:	854e                	mv	a0,s3
    80004ed8:	60a6                	ld	ra,72(sp)
    80004eda:	6406                	ld	s0,64(sp)
    80004edc:	74e2                	ld	s1,56(sp)
    80004ede:	7942                	ld	s2,48(sp)
    80004ee0:	79a2                	ld	s3,40(sp)
    80004ee2:	7a02                	ld	s4,32(sp)
    80004ee4:	6ae2                	ld	s5,24(sp)
    80004ee6:	6b42                	ld	s6,16(sp)
    80004ee8:	6161                	addi	sp,sp,80
    80004eea:	8082                	ret
    iunlockput(ip);
    80004eec:	854e                	mv	a0,s3
    80004eee:	919fe0ef          	jal	80003806 <iunlockput>
    return 0;
    80004ef2:	4981                	li	s3,0
    80004ef4:	b7cd                	j	80004ed6 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004ef6:	85ca                	mv	a1,s2
    80004ef8:	4088                	lw	a0,0(s1)
    80004efa:	d90fe0ef          	jal	8000348a <ialloc>
    80004efe:	892a                	mv	s2,a0
    80004f00:	cd15                	beqz	a0,80004f3c <create+0xc6>
  ilock(ip);
    80004f02:	ef8fe0ef          	jal	800035fa <ilock>
  ip->major = major;
    80004f06:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004f0a:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004f0e:	4785                	li	a5,1
    80004f10:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004f14:	854a                	mv	a0,s2
    80004f16:	e30fe0ef          	jal	80003546 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004f1a:	4705                	li	a4,1
    80004f1c:	02ea0463          	beq	s4,a4,80004f44 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004f20:	00492603          	lw	a2,4(s2)
    80004f24:	fb040593          	addi	a1,s0,-80
    80004f28:	8526                	mv	a0,s1
    80004f2a:	e55fe0ef          	jal	80003d7e <dirlink>
    80004f2e:	06054263          	bltz	a0,80004f92 <create+0x11c>
  iunlockput(dp);
    80004f32:	8526                	mv	a0,s1
    80004f34:	8d3fe0ef          	jal	80003806 <iunlockput>
  return ip;
    80004f38:	89ca                	mv	s3,s2
    80004f3a:	bf71                	j	80004ed6 <create+0x60>
    iunlockput(dp);
    80004f3c:	8526                	mv	a0,s1
    80004f3e:	8c9fe0ef          	jal	80003806 <iunlockput>
    return 0;
    80004f42:	bf51                	j	80004ed6 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004f44:	00492603          	lw	a2,4(s2)
    80004f48:	00002597          	auipc	a1,0x2
    80004f4c:	6a858593          	addi	a1,a1,1704 # 800075f0 <etext+0x5f0>
    80004f50:	854a                	mv	a0,s2
    80004f52:	e2dfe0ef          	jal	80003d7e <dirlink>
    80004f56:	02054e63          	bltz	a0,80004f92 <create+0x11c>
    80004f5a:	40d0                	lw	a2,4(s1)
    80004f5c:	00002597          	auipc	a1,0x2
    80004f60:	69c58593          	addi	a1,a1,1692 # 800075f8 <etext+0x5f8>
    80004f64:	854a                	mv	a0,s2
    80004f66:	e19fe0ef          	jal	80003d7e <dirlink>
    80004f6a:	02054463          	bltz	a0,80004f92 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004f6e:	00492603          	lw	a2,4(s2)
    80004f72:	fb040593          	addi	a1,s0,-80
    80004f76:	8526                	mv	a0,s1
    80004f78:	e07fe0ef          	jal	80003d7e <dirlink>
    80004f7c:	00054b63          	bltz	a0,80004f92 <create+0x11c>
    dp->nlink++;  // for ".."
    80004f80:	04a4d783          	lhu	a5,74(s1)
    80004f84:	2785                	addiw	a5,a5,1
    80004f86:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004f8a:	8526                	mv	a0,s1
    80004f8c:	dbafe0ef          	jal	80003546 <iupdate>
    80004f90:	b74d                	j	80004f32 <create+0xbc>
  ip->nlink = 0;
    80004f92:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004f96:	854a                	mv	a0,s2
    80004f98:	daefe0ef          	jal	80003546 <iupdate>
  iunlockput(ip);
    80004f9c:	854a                	mv	a0,s2
    80004f9e:	869fe0ef          	jal	80003806 <iunlockput>
  iunlockput(dp);
    80004fa2:	8526                	mv	a0,s1
    80004fa4:	863fe0ef          	jal	80003806 <iunlockput>
  return 0;
    80004fa8:	b73d                	j	80004ed6 <create+0x60>
    return 0;
    80004faa:	89aa                	mv	s3,a0
    80004fac:	b72d                	j	80004ed6 <create+0x60>

0000000080004fae <sys_dup>:
{
    80004fae:	7179                	addi	sp,sp,-48
    80004fb0:	f406                	sd	ra,40(sp)
    80004fb2:	f022                	sd	s0,32(sp)
    80004fb4:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004fb6:	fd840613          	addi	a2,s0,-40
    80004fba:	4581                	li	a1,0
    80004fbc:	4501                	li	a0,0
    80004fbe:	e1fff0ef          	jal	80004ddc <argfd>
    return -1;
    80004fc2:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004fc4:	02054363          	bltz	a0,80004fea <sys_dup+0x3c>
    80004fc8:	ec26                	sd	s1,24(sp)
    80004fca:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004fcc:	fd843483          	ld	s1,-40(s0)
    80004fd0:	8526                	mv	a0,s1
    80004fd2:	e65ff0ef          	jal	80004e36 <fdalloc>
    80004fd6:	892a                	mv	s2,a0
    return -1;
    80004fd8:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004fda:	00054d63          	bltz	a0,80004ff4 <sys_dup+0x46>
  filedup(f);
    80004fde:	8526                	mv	a0,s1
    80004fe0:	c04ff0ef          	jal	800043e4 <filedup>
  return fd;
    80004fe4:	87ca                	mv	a5,s2
    80004fe6:	64e2                	ld	s1,24(sp)
    80004fe8:	6942                	ld	s2,16(sp)
}
    80004fea:	853e                	mv	a0,a5
    80004fec:	70a2                	ld	ra,40(sp)
    80004fee:	7402                	ld	s0,32(sp)
    80004ff0:	6145                	addi	sp,sp,48
    80004ff2:	8082                	ret
    80004ff4:	64e2                	ld	s1,24(sp)
    80004ff6:	6942                	ld	s2,16(sp)
    80004ff8:	bfcd                	j	80004fea <sys_dup+0x3c>

0000000080004ffa <sys_read>:
{
    80004ffa:	7179                	addi	sp,sp,-48
    80004ffc:	f406                	sd	ra,40(sp)
    80004ffe:	f022                	sd	s0,32(sp)
    80005000:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005002:	fd840593          	addi	a1,s0,-40
    80005006:	4505                	li	a0,1
    80005008:	b8ffd0ef          	jal	80002b96 <argaddr>
  argint(2, &n);
    8000500c:	fe440593          	addi	a1,s0,-28
    80005010:	4509                	li	a0,2
    80005012:	b69fd0ef          	jal	80002b7a <argint>
  if(argfd(0, 0, &f) < 0)
    80005016:	fe840613          	addi	a2,s0,-24
    8000501a:	4581                	li	a1,0
    8000501c:	4501                	li	a0,0
    8000501e:	dbfff0ef          	jal	80004ddc <argfd>
    80005022:	87aa                	mv	a5,a0
    return -1;
    80005024:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005026:	0007ca63          	bltz	a5,8000503a <sys_read+0x40>
  return fileread(f, p, n);
    8000502a:	fe442603          	lw	a2,-28(s0)
    8000502e:	fd843583          	ld	a1,-40(s0)
    80005032:	fe843503          	ld	a0,-24(s0)
    80005036:	d18ff0ef          	jal	8000454e <fileread>
}
    8000503a:	70a2                	ld	ra,40(sp)
    8000503c:	7402                	ld	s0,32(sp)
    8000503e:	6145                	addi	sp,sp,48
    80005040:	8082                	ret

0000000080005042 <sys_write>:
{
    80005042:	7179                	addi	sp,sp,-48
    80005044:	f406                	sd	ra,40(sp)
    80005046:	f022                	sd	s0,32(sp)
    80005048:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000504a:	fd840593          	addi	a1,s0,-40
    8000504e:	4505                	li	a0,1
    80005050:	b47fd0ef          	jal	80002b96 <argaddr>
  argint(2, &n);
    80005054:	fe440593          	addi	a1,s0,-28
    80005058:	4509                	li	a0,2
    8000505a:	b21fd0ef          	jal	80002b7a <argint>
  if(argfd(0, 0, &f) < 0)
    8000505e:	fe840613          	addi	a2,s0,-24
    80005062:	4581                	li	a1,0
    80005064:	4501                	li	a0,0
    80005066:	d77ff0ef          	jal	80004ddc <argfd>
    8000506a:	87aa                	mv	a5,a0
    return -1;
    8000506c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000506e:	0007ca63          	bltz	a5,80005082 <sys_write+0x40>
  return filewrite(f, p, n);
    80005072:	fe442603          	lw	a2,-28(s0)
    80005076:	fd843583          	ld	a1,-40(s0)
    8000507a:	fe843503          	ld	a0,-24(s0)
    8000507e:	d94ff0ef          	jal	80004612 <filewrite>
}
    80005082:	70a2                	ld	ra,40(sp)
    80005084:	7402                	ld	s0,32(sp)
    80005086:	6145                	addi	sp,sp,48
    80005088:	8082                	ret

000000008000508a <sys_close>:
{
    8000508a:	1101                	addi	sp,sp,-32
    8000508c:	ec06                	sd	ra,24(sp)
    8000508e:	e822                	sd	s0,16(sp)
    80005090:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80005092:	fe040613          	addi	a2,s0,-32
    80005096:	fec40593          	addi	a1,s0,-20
    8000509a:	4501                	li	a0,0
    8000509c:	d41ff0ef          	jal	80004ddc <argfd>
    return -1;
    800050a0:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800050a2:	02054163          	bltz	a0,800050c4 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    800050a6:	9e3fc0ef          	jal	80001a88 <myproc>
    800050aa:	fec42783          	lw	a5,-20(s0)
    800050ae:	078e                	slli	a5,a5,0x3
    800050b0:	0d078793          	addi	a5,a5,208
    800050b4:	953e                	add	a0,a0,a5
    800050b6:	00053423          	sd	zero,8(a0)
  fileclose(f);
    800050ba:	fe043503          	ld	a0,-32(s0)
    800050be:	b6cff0ef          	jal	8000442a <fileclose>
  return 0;
    800050c2:	4781                	li	a5,0
}
    800050c4:	853e                	mv	a0,a5
    800050c6:	60e2                	ld	ra,24(sp)
    800050c8:	6442                	ld	s0,16(sp)
    800050ca:	6105                	addi	sp,sp,32
    800050cc:	8082                	ret

00000000800050ce <sys_fstat>:
{
    800050ce:	1101                	addi	sp,sp,-32
    800050d0:	ec06                	sd	ra,24(sp)
    800050d2:	e822                	sd	s0,16(sp)
    800050d4:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800050d6:	fe040593          	addi	a1,s0,-32
    800050da:	4505                	li	a0,1
    800050dc:	abbfd0ef          	jal	80002b96 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800050e0:	fe840613          	addi	a2,s0,-24
    800050e4:	4581                	li	a1,0
    800050e6:	4501                	li	a0,0
    800050e8:	cf5ff0ef          	jal	80004ddc <argfd>
    800050ec:	87aa                	mv	a5,a0
    return -1;
    800050ee:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800050f0:	0007c863          	bltz	a5,80005100 <sys_fstat+0x32>
  return filestat(f, st);
    800050f4:	fe043583          	ld	a1,-32(s0)
    800050f8:	fe843503          	ld	a0,-24(s0)
    800050fc:	bf0ff0ef          	jal	800044ec <filestat>
}
    80005100:	60e2                	ld	ra,24(sp)
    80005102:	6442                	ld	s0,16(sp)
    80005104:	6105                	addi	sp,sp,32
    80005106:	8082                	ret

0000000080005108 <sys_link>:
{
    80005108:	7169                	addi	sp,sp,-304
    8000510a:	f606                	sd	ra,296(sp)
    8000510c:	f222                	sd	s0,288(sp)
    8000510e:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005110:	08000613          	li	a2,128
    80005114:	ed040593          	addi	a1,s0,-304
    80005118:	4501                	li	a0,0
    8000511a:	a99fd0ef          	jal	80002bb2 <argstr>
    return -1;
    8000511e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005120:	0c054e63          	bltz	a0,800051fc <sys_link+0xf4>
    80005124:	08000613          	li	a2,128
    80005128:	f5040593          	addi	a1,s0,-176
    8000512c:	4505                	li	a0,1
    8000512e:	a85fd0ef          	jal	80002bb2 <argstr>
    return -1;
    80005132:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005134:	0c054463          	bltz	a0,800051fc <sys_link+0xf4>
    80005138:	ee26                	sd	s1,280(sp)
  begin_op();
    8000513a:	ecdfe0ef          	jal	80004006 <begin_op>
  if((ip = namei(old)) == 0){
    8000513e:	ed040513          	addi	a0,s0,-304
    80005142:	ce7fe0ef          	jal	80003e28 <namei>
    80005146:	84aa                	mv	s1,a0
    80005148:	c53d                	beqz	a0,800051b6 <sys_link+0xae>
  ilock(ip);
    8000514a:	cb0fe0ef          	jal	800035fa <ilock>
  if(ip->type == T_DIR){
    8000514e:	04449703          	lh	a4,68(s1)
    80005152:	4785                	li	a5,1
    80005154:	06f70663          	beq	a4,a5,800051c0 <sys_link+0xb8>
    80005158:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    8000515a:	04a4d783          	lhu	a5,74(s1)
    8000515e:	2785                	addiw	a5,a5,1
    80005160:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005164:	8526                	mv	a0,s1
    80005166:	be0fe0ef          	jal	80003546 <iupdate>
  iunlock(ip);
    8000516a:	8526                	mv	a0,s1
    8000516c:	d3cfe0ef          	jal	800036a8 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005170:	fd040593          	addi	a1,s0,-48
    80005174:	f5040513          	addi	a0,s0,-176
    80005178:	ccbfe0ef          	jal	80003e42 <nameiparent>
    8000517c:	892a                	mv	s2,a0
    8000517e:	cd21                	beqz	a0,800051d6 <sys_link+0xce>
  ilock(dp);
    80005180:	c7afe0ef          	jal	800035fa <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005184:	854a                	mv	a0,s2
    80005186:	00092703          	lw	a4,0(s2)
    8000518a:	409c                	lw	a5,0(s1)
    8000518c:	04f71263          	bne	a4,a5,800051d0 <sys_link+0xc8>
    80005190:	40d0                	lw	a2,4(s1)
    80005192:	fd040593          	addi	a1,s0,-48
    80005196:	be9fe0ef          	jal	80003d7e <dirlink>
    8000519a:	02054b63          	bltz	a0,800051d0 <sys_link+0xc8>
  iunlockput(dp);
    8000519e:	854a                	mv	a0,s2
    800051a0:	e66fe0ef          	jal	80003806 <iunlockput>
  iput(ip);
    800051a4:	8526                	mv	a0,s1
    800051a6:	dd6fe0ef          	jal	8000377c <iput>
  end_op();
    800051aa:	ecdfe0ef          	jal	80004076 <end_op>
  return 0;
    800051ae:	4781                	li	a5,0
    800051b0:	64f2                	ld	s1,280(sp)
    800051b2:	6952                	ld	s2,272(sp)
    800051b4:	a0a1                	j	800051fc <sys_link+0xf4>
    end_op();
    800051b6:	ec1fe0ef          	jal	80004076 <end_op>
    return -1;
    800051ba:	57fd                	li	a5,-1
    800051bc:	64f2                	ld	s1,280(sp)
    800051be:	a83d                	j	800051fc <sys_link+0xf4>
    iunlockput(ip);
    800051c0:	8526                	mv	a0,s1
    800051c2:	e44fe0ef          	jal	80003806 <iunlockput>
    end_op();
    800051c6:	eb1fe0ef          	jal	80004076 <end_op>
    return -1;
    800051ca:	57fd                	li	a5,-1
    800051cc:	64f2                	ld	s1,280(sp)
    800051ce:	a03d                	j	800051fc <sys_link+0xf4>
    iunlockput(dp);
    800051d0:	854a                	mv	a0,s2
    800051d2:	e34fe0ef          	jal	80003806 <iunlockput>
  ilock(ip);
    800051d6:	8526                	mv	a0,s1
    800051d8:	c22fe0ef          	jal	800035fa <ilock>
  ip->nlink--;
    800051dc:	04a4d783          	lhu	a5,74(s1)
    800051e0:	37fd                	addiw	a5,a5,-1
    800051e2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800051e6:	8526                	mv	a0,s1
    800051e8:	b5efe0ef          	jal	80003546 <iupdate>
  iunlockput(ip);
    800051ec:	8526                	mv	a0,s1
    800051ee:	e18fe0ef          	jal	80003806 <iunlockput>
  end_op();
    800051f2:	e85fe0ef          	jal	80004076 <end_op>
  return -1;
    800051f6:	57fd                	li	a5,-1
    800051f8:	64f2                	ld	s1,280(sp)
    800051fa:	6952                	ld	s2,272(sp)
}
    800051fc:	853e                	mv	a0,a5
    800051fe:	70b2                	ld	ra,296(sp)
    80005200:	7412                	ld	s0,288(sp)
    80005202:	6155                	addi	sp,sp,304
    80005204:	8082                	ret

0000000080005206 <sys_unlink>:
{
    80005206:	7151                	addi	sp,sp,-240
    80005208:	f586                	sd	ra,232(sp)
    8000520a:	f1a2                	sd	s0,224(sp)
    8000520c:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000520e:	08000613          	li	a2,128
    80005212:	f3040593          	addi	a1,s0,-208
    80005216:	4501                	li	a0,0
    80005218:	99bfd0ef          	jal	80002bb2 <argstr>
    8000521c:	14054d63          	bltz	a0,80005376 <sys_unlink+0x170>
    80005220:	eda6                	sd	s1,216(sp)
  begin_op();
    80005222:	de5fe0ef          	jal	80004006 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005226:	fb040593          	addi	a1,s0,-80
    8000522a:	f3040513          	addi	a0,s0,-208
    8000522e:	c15fe0ef          	jal	80003e42 <nameiparent>
    80005232:	84aa                	mv	s1,a0
    80005234:	c955                	beqz	a0,800052e8 <sys_unlink+0xe2>
  ilock(dp);
    80005236:	bc4fe0ef          	jal	800035fa <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000523a:	00002597          	auipc	a1,0x2
    8000523e:	3b658593          	addi	a1,a1,950 # 800075f0 <etext+0x5f0>
    80005242:	fb040513          	addi	a0,s0,-80
    80005246:	939fe0ef          	jal	80003b7e <namecmp>
    8000524a:	10050b63          	beqz	a0,80005360 <sys_unlink+0x15a>
    8000524e:	00002597          	auipc	a1,0x2
    80005252:	3aa58593          	addi	a1,a1,938 # 800075f8 <etext+0x5f8>
    80005256:	fb040513          	addi	a0,s0,-80
    8000525a:	925fe0ef          	jal	80003b7e <namecmp>
    8000525e:	10050163          	beqz	a0,80005360 <sys_unlink+0x15a>
    80005262:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80005264:	f2c40613          	addi	a2,s0,-212
    80005268:	fb040593          	addi	a1,s0,-80
    8000526c:	8526                	mv	a0,s1
    8000526e:	927fe0ef          	jal	80003b94 <dirlookup>
    80005272:	892a                	mv	s2,a0
    80005274:	0e050563          	beqz	a0,8000535e <sys_unlink+0x158>
    80005278:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    8000527a:	b80fe0ef          	jal	800035fa <ilock>
  if(ip->nlink < 1)
    8000527e:	04a91783          	lh	a5,74(s2)
    80005282:	06f05863          	blez	a5,800052f2 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80005286:	04491703          	lh	a4,68(s2)
    8000528a:	4785                	li	a5,1
    8000528c:	06f70963          	beq	a4,a5,800052fe <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80005290:	fc040993          	addi	s3,s0,-64
    80005294:	4641                	li	a2,16
    80005296:	4581                	li	a1,0
    80005298:	854e                	mv	a0,s3
    8000529a:	a5ffb0ef          	jal	80000cf8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000529e:	4741                	li	a4,16
    800052a0:	f2c42683          	lw	a3,-212(s0)
    800052a4:	864e                	mv	a2,s3
    800052a6:	4581                	li	a1,0
    800052a8:	8526                	mv	a0,s1
    800052aa:	fd4fe0ef          	jal	80003a7e <writei>
    800052ae:	47c1                	li	a5,16
    800052b0:	08f51863          	bne	a0,a5,80005340 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    800052b4:	04491703          	lh	a4,68(s2)
    800052b8:	4785                	li	a5,1
    800052ba:	08f70963          	beq	a4,a5,8000534c <sys_unlink+0x146>
  iunlockput(dp);
    800052be:	8526                	mv	a0,s1
    800052c0:	d46fe0ef          	jal	80003806 <iunlockput>
  ip->nlink--;
    800052c4:	04a95783          	lhu	a5,74(s2)
    800052c8:	37fd                	addiw	a5,a5,-1
    800052ca:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800052ce:	854a                	mv	a0,s2
    800052d0:	a76fe0ef          	jal	80003546 <iupdate>
  iunlockput(ip);
    800052d4:	854a                	mv	a0,s2
    800052d6:	d30fe0ef          	jal	80003806 <iunlockput>
  end_op();
    800052da:	d9dfe0ef          	jal	80004076 <end_op>
  return 0;
    800052de:	4501                	li	a0,0
    800052e0:	64ee                	ld	s1,216(sp)
    800052e2:	694e                	ld	s2,208(sp)
    800052e4:	69ae                	ld	s3,200(sp)
    800052e6:	a061                	j	8000536e <sys_unlink+0x168>
    end_op();
    800052e8:	d8ffe0ef          	jal	80004076 <end_op>
    return -1;
    800052ec:	557d                	li	a0,-1
    800052ee:	64ee                	ld	s1,216(sp)
    800052f0:	a8bd                	j	8000536e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800052f2:	00002517          	auipc	a0,0x2
    800052f6:	30e50513          	addi	a0,a0,782 # 80007600 <etext+0x600>
    800052fa:	d2afb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800052fe:	04c92703          	lw	a4,76(s2)
    80005302:	02000793          	li	a5,32
    80005306:	f8e7f5e3          	bgeu	a5,a4,80005290 <sys_unlink+0x8a>
    8000530a:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000530c:	4741                	li	a4,16
    8000530e:	86ce                	mv	a3,s3
    80005310:	f1840613          	addi	a2,s0,-232
    80005314:	4581                	li	a1,0
    80005316:	854a                	mv	a0,s2
    80005318:	e74fe0ef          	jal	8000398c <readi>
    8000531c:	47c1                	li	a5,16
    8000531e:	00f51b63          	bne	a0,a5,80005334 <sys_unlink+0x12e>
    if(de.inum != 0)
    80005322:	f1845783          	lhu	a5,-232(s0)
    80005326:	ebb1                	bnez	a5,8000537a <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005328:	29c1                	addiw	s3,s3,16
    8000532a:	04c92783          	lw	a5,76(s2)
    8000532e:	fcf9efe3          	bltu	s3,a5,8000530c <sys_unlink+0x106>
    80005332:	bfb9                	j	80005290 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80005334:	00002517          	auipc	a0,0x2
    80005338:	2e450513          	addi	a0,a0,740 # 80007618 <etext+0x618>
    8000533c:	ce8fb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    80005340:	00002517          	auipc	a0,0x2
    80005344:	2f050513          	addi	a0,a0,752 # 80007630 <etext+0x630>
    80005348:	cdcfb0ef          	jal	80000824 <panic>
    dp->nlink--;
    8000534c:	04a4d783          	lhu	a5,74(s1)
    80005350:	37fd                	addiw	a5,a5,-1
    80005352:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005356:	8526                	mv	a0,s1
    80005358:	9eefe0ef          	jal	80003546 <iupdate>
    8000535c:	b78d                	j	800052be <sys_unlink+0xb8>
    8000535e:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005360:	8526                	mv	a0,s1
    80005362:	ca4fe0ef          	jal	80003806 <iunlockput>
  end_op();
    80005366:	d11fe0ef          	jal	80004076 <end_op>
  return -1;
    8000536a:	557d                	li	a0,-1
    8000536c:	64ee                	ld	s1,216(sp)
}
    8000536e:	70ae                	ld	ra,232(sp)
    80005370:	740e                	ld	s0,224(sp)
    80005372:	616d                	addi	sp,sp,240
    80005374:	8082                	ret
    return -1;
    80005376:	557d                	li	a0,-1
    80005378:	bfdd                	j	8000536e <sys_unlink+0x168>
    iunlockput(ip);
    8000537a:	854a                	mv	a0,s2
    8000537c:	c8afe0ef          	jal	80003806 <iunlockput>
    goto bad;
    80005380:	694e                	ld	s2,208(sp)
    80005382:	69ae                	ld	s3,200(sp)
    80005384:	bff1                	j	80005360 <sys_unlink+0x15a>

0000000080005386 <sys_open>:

uint64
sys_open(void)
{
    80005386:	7131                	addi	sp,sp,-192
    80005388:	fd06                	sd	ra,184(sp)
    8000538a:	f922                	sd	s0,176(sp)
    8000538c:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000538e:	f4c40593          	addi	a1,s0,-180
    80005392:	4505                	li	a0,1
    80005394:	fe6fd0ef          	jal	80002b7a <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005398:	08000613          	li	a2,128
    8000539c:	f5040593          	addi	a1,s0,-176
    800053a0:	4501                	li	a0,0
    800053a2:	811fd0ef          	jal	80002bb2 <argstr>
    800053a6:	87aa                	mv	a5,a0
    return -1;
    800053a8:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800053aa:	0a07c363          	bltz	a5,80005450 <sys_open+0xca>
    800053ae:	f526                	sd	s1,168(sp)

  begin_op();
    800053b0:	c57fe0ef          	jal	80004006 <begin_op>

  if(omode & O_CREATE){
    800053b4:	f4c42783          	lw	a5,-180(s0)
    800053b8:	2007f793          	andi	a5,a5,512
    800053bc:	c3dd                	beqz	a5,80005462 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800053be:	4681                	li	a3,0
    800053c0:	4601                	li	a2,0
    800053c2:	4589                	li	a1,2
    800053c4:	f5040513          	addi	a0,s0,-176
    800053c8:	aafff0ef          	jal	80004e76 <create>
    800053cc:	84aa                	mv	s1,a0
    if(ip == 0){
    800053ce:	c549                	beqz	a0,80005458 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800053d0:	04449703          	lh	a4,68(s1)
    800053d4:	478d                	li	a5,3
    800053d6:	00f71763          	bne	a4,a5,800053e4 <sys_open+0x5e>
    800053da:	0464d703          	lhu	a4,70(s1)
    800053de:	47a5                	li	a5,9
    800053e0:	0ae7ee63          	bltu	a5,a4,8000549c <sys_open+0x116>
    800053e4:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800053e6:	fa1fe0ef          	jal	80004386 <filealloc>
    800053ea:	892a                	mv	s2,a0
    800053ec:	c561                	beqz	a0,800054b4 <sys_open+0x12e>
    800053ee:	ed4e                	sd	s3,152(sp)
    800053f0:	a47ff0ef          	jal	80004e36 <fdalloc>
    800053f4:	89aa                	mv	s3,a0
    800053f6:	0a054b63          	bltz	a0,800054ac <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800053fa:	04449703          	lh	a4,68(s1)
    800053fe:	478d                	li	a5,3
    80005400:	0cf70363          	beq	a4,a5,800054c6 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005404:	4789                	li	a5,2
    80005406:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000540a:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000540e:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005412:	f4c42783          	lw	a5,-180(s0)
    80005416:	0017f713          	andi	a4,a5,1
    8000541a:	00174713          	xori	a4,a4,1
    8000541e:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005422:	0037f713          	andi	a4,a5,3
    80005426:	00e03733          	snez	a4,a4
    8000542a:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000542e:	4007f793          	andi	a5,a5,1024
    80005432:	c791                	beqz	a5,8000543e <sys_open+0xb8>
    80005434:	04449703          	lh	a4,68(s1)
    80005438:	4789                	li	a5,2
    8000543a:	08f70d63          	beq	a4,a5,800054d4 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000543e:	8526                	mv	a0,s1
    80005440:	a68fe0ef          	jal	800036a8 <iunlock>
  end_op();
    80005444:	c33fe0ef          	jal	80004076 <end_op>

  return fd;
    80005448:	854e                	mv	a0,s3
    8000544a:	74aa                	ld	s1,168(sp)
    8000544c:	790a                	ld	s2,160(sp)
    8000544e:	69ea                	ld	s3,152(sp)
}
    80005450:	70ea                	ld	ra,184(sp)
    80005452:	744a                	ld	s0,176(sp)
    80005454:	6129                	addi	sp,sp,192
    80005456:	8082                	ret
      end_op();
    80005458:	c1ffe0ef          	jal	80004076 <end_op>
      return -1;
    8000545c:	557d                	li	a0,-1
    8000545e:	74aa                	ld	s1,168(sp)
    80005460:	bfc5                	j	80005450 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    80005462:	f5040513          	addi	a0,s0,-176
    80005466:	9c3fe0ef          	jal	80003e28 <namei>
    8000546a:	84aa                	mv	s1,a0
    8000546c:	c11d                	beqz	a0,80005492 <sys_open+0x10c>
    ilock(ip);
    8000546e:	98cfe0ef          	jal	800035fa <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80005472:	04449703          	lh	a4,68(s1)
    80005476:	4785                	li	a5,1
    80005478:	f4f71ce3          	bne	a4,a5,800053d0 <sys_open+0x4a>
    8000547c:	f4c42783          	lw	a5,-180(s0)
    80005480:	d3b5                	beqz	a5,800053e4 <sys_open+0x5e>
      iunlockput(ip);
    80005482:	8526                	mv	a0,s1
    80005484:	b82fe0ef          	jal	80003806 <iunlockput>
      end_op();
    80005488:	beffe0ef          	jal	80004076 <end_op>
      return -1;
    8000548c:	557d                	li	a0,-1
    8000548e:	74aa                	ld	s1,168(sp)
    80005490:	b7c1                	j	80005450 <sys_open+0xca>
      end_op();
    80005492:	be5fe0ef          	jal	80004076 <end_op>
      return -1;
    80005496:	557d                	li	a0,-1
    80005498:	74aa                	ld	s1,168(sp)
    8000549a:	bf5d                	j	80005450 <sys_open+0xca>
    iunlockput(ip);
    8000549c:	8526                	mv	a0,s1
    8000549e:	b68fe0ef          	jal	80003806 <iunlockput>
    end_op();
    800054a2:	bd5fe0ef          	jal	80004076 <end_op>
    return -1;
    800054a6:	557d                	li	a0,-1
    800054a8:	74aa                	ld	s1,168(sp)
    800054aa:	b75d                	j	80005450 <sys_open+0xca>
      fileclose(f);
    800054ac:	854a                	mv	a0,s2
    800054ae:	f7dfe0ef          	jal	8000442a <fileclose>
    800054b2:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800054b4:	8526                	mv	a0,s1
    800054b6:	b50fe0ef          	jal	80003806 <iunlockput>
    end_op();
    800054ba:	bbdfe0ef          	jal	80004076 <end_op>
    return -1;
    800054be:	557d                	li	a0,-1
    800054c0:	74aa                	ld	s1,168(sp)
    800054c2:	790a                	ld	s2,160(sp)
    800054c4:	b771                	j	80005450 <sys_open+0xca>
    f->type = FD_DEVICE;
    800054c6:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800054ca:	04649783          	lh	a5,70(s1)
    800054ce:	02f91223          	sh	a5,36(s2)
    800054d2:	bf35                	j	8000540e <sys_open+0x88>
    itrunc(ip);
    800054d4:	8526                	mv	a0,s1
    800054d6:	a12fe0ef          	jal	800036e8 <itrunc>
    800054da:	b795                	j	8000543e <sys_open+0xb8>

00000000800054dc <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800054dc:	7175                	addi	sp,sp,-144
    800054de:	e506                	sd	ra,136(sp)
    800054e0:	e122                	sd	s0,128(sp)
    800054e2:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800054e4:	b23fe0ef          	jal	80004006 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800054e8:	08000613          	li	a2,128
    800054ec:	f7040593          	addi	a1,s0,-144
    800054f0:	4501                	li	a0,0
    800054f2:	ec0fd0ef          	jal	80002bb2 <argstr>
    800054f6:	02054363          	bltz	a0,8000551c <sys_mkdir+0x40>
    800054fa:	4681                	li	a3,0
    800054fc:	4601                	li	a2,0
    800054fe:	4585                	li	a1,1
    80005500:	f7040513          	addi	a0,s0,-144
    80005504:	973ff0ef          	jal	80004e76 <create>
    80005508:	c911                	beqz	a0,8000551c <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000550a:	afcfe0ef          	jal	80003806 <iunlockput>
  end_op();
    8000550e:	b69fe0ef          	jal	80004076 <end_op>
  return 0;
    80005512:	4501                	li	a0,0
}
    80005514:	60aa                	ld	ra,136(sp)
    80005516:	640a                	ld	s0,128(sp)
    80005518:	6149                	addi	sp,sp,144
    8000551a:	8082                	ret
    end_op();
    8000551c:	b5bfe0ef          	jal	80004076 <end_op>
    return -1;
    80005520:	557d                	li	a0,-1
    80005522:	bfcd                	j	80005514 <sys_mkdir+0x38>

0000000080005524 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005524:	7135                	addi	sp,sp,-160
    80005526:	ed06                	sd	ra,152(sp)
    80005528:	e922                	sd	s0,144(sp)
    8000552a:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000552c:	adbfe0ef          	jal	80004006 <begin_op>
  argint(1, &major);
    80005530:	f6c40593          	addi	a1,s0,-148
    80005534:	4505                	li	a0,1
    80005536:	e44fd0ef          	jal	80002b7a <argint>
  argint(2, &minor);
    8000553a:	f6840593          	addi	a1,s0,-152
    8000553e:	4509                	li	a0,2
    80005540:	e3afd0ef          	jal	80002b7a <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005544:	08000613          	li	a2,128
    80005548:	f7040593          	addi	a1,s0,-144
    8000554c:	4501                	li	a0,0
    8000554e:	e64fd0ef          	jal	80002bb2 <argstr>
    80005552:	02054563          	bltz	a0,8000557c <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005556:	f6841683          	lh	a3,-152(s0)
    8000555a:	f6c41603          	lh	a2,-148(s0)
    8000555e:	458d                	li	a1,3
    80005560:	f7040513          	addi	a0,s0,-144
    80005564:	913ff0ef          	jal	80004e76 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005568:	c911                	beqz	a0,8000557c <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000556a:	a9cfe0ef          	jal	80003806 <iunlockput>
  end_op();
    8000556e:	b09fe0ef          	jal	80004076 <end_op>
  return 0;
    80005572:	4501                	li	a0,0
}
    80005574:	60ea                	ld	ra,152(sp)
    80005576:	644a                	ld	s0,144(sp)
    80005578:	610d                	addi	sp,sp,160
    8000557a:	8082                	ret
    end_op();
    8000557c:	afbfe0ef          	jal	80004076 <end_op>
    return -1;
    80005580:	557d                	li	a0,-1
    80005582:	bfcd                	j	80005574 <sys_mknod+0x50>

0000000080005584 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005584:	7135                	addi	sp,sp,-160
    80005586:	ed06                	sd	ra,152(sp)
    80005588:	e922                	sd	s0,144(sp)
    8000558a:	e14a                	sd	s2,128(sp)
    8000558c:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    8000558e:	cfafc0ef          	jal	80001a88 <myproc>
    80005592:	892a                	mv	s2,a0
  
  begin_op();
    80005594:	a73fe0ef          	jal	80004006 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005598:	08000613          	li	a2,128
    8000559c:	f6040593          	addi	a1,s0,-160
    800055a0:	4501                	li	a0,0
    800055a2:	e10fd0ef          	jal	80002bb2 <argstr>
    800055a6:	04054363          	bltz	a0,800055ec <sys_chdir+0x68>
    800055aa:	e526                	sd	s1,136(sp)
    800055ac:	f6040513          	addi	a0,s0,-160
    800055b0:	879fe0ef          	jal	80003e28 <namei>
    800055b4:	84aa                	mv	s1,a0
    800055b6:	c915                	beqz	a0,800055ea <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800055b8:	842fe0ef          	jal	800035fa <ilock>
  if(ip->type != T_DIR){
    800055bc:	04449703          	lh	a4,68(s1)
    800055c0:	4785                	li	a5,1
    800055c2:	02f71963          	bne	a4,a5,800055f4 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800055c6:	8526                	mv	a0,s1
    800055c8:	8e0fe0ef          	jal	800036a8 <iunlock>
  iput(p->cwd);
    800055cc:	15893503          	ld	a0,344(s2)
    800055d0:	9acfe0ef          	jal	8000377c <iput>
  end_op();
    800055d4:	aa3fe0ef          	jal	80004076 <end_op>
  p->cwd = ip;
    800055d8:	14993c23          	sd	s1,344(s2)
  return 0;
    800055dc:	4501                	li	a0,0
    800055de:	64aa                	ld	s1,136(sp)
}
    800055e0:	60ea                	ld	ra,152(sp)
    800055e2:	644a                	ld	s0,144(sp)
    800055e4:	690a                	ld	s2,128(sp)
    800055e6:	610d                	addi	sp,sp,160
    800055e8:	8082                	ret
    800055ea:	64aa                	ld	s1,136(sp)
    end_op();
    800055ec:	a8bfe0ef          	jal	80004076 <end_op>
    return -1;
    800055f0:	557d                	li	a0,-1
    800055f2:	b7fd                	j	800055e0 <sys_chdir+0x5c>
    iunlockput(ip);
    800055f4:	8526                	mv	a0,s1
    800055f6:	a10fe0ef          	jal	80003806 <iunlockput>
    end_op();
    800055fa:	a7dfe0ef          	jal	80004076 <end_op>
    return -1;
    800055fe:	557d                	li	a0,-1
    80005600:	64aa                	ld	s1,136(sp)
    80005602:	bff9                	j	800055e0 <sys_chdir+0x5c>

0000000080005604 <sys_exec>:

uint64
sys_exec(void)
{
    80005604:	7105                	addi	sp,sp,-480
    80005606:	ef86                	sd	ra,472(sp)
    80005608:	eba2                	sd	s0,464(sp)
    8000560a:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000560c:	e2840593          	addi	a1,s0,-472
    80005610:	4505                	li	a0,1
    80005612:	d84fd0ef          	jal	80002b96 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005616:	08000613          	li	a2,128
    8000561a:	f3040593          	addi	a1,s0,-208
    8000561e:	4501                	li	a0,0
    80005620:	d92fd0ef          	jal	80002bb2 <argstr>
    80005624:	87aa                	mv	a5,a0
    return -1;
    80005626:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005628:	0e07c063          	bltz	a5,80005708 <sys_exec+0x104>
    8000562c:	e7a6                	sd	s1,456(sp)
    8000562e:	e3ca                	sd	s2,448(sp)
    80005630:	ff4e                	sd	s3,440(sp)
    80005632:	fb52                	sd	s4,432(sp)
    80005634:	f756                	sd	s5,424(sp)
    80005636:	f35a                	sd	s6,416(sp)
    80005638:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000563a:	e3040a13          	addi	s4,s0,-464
    8000563e:	10000613          	li	a2,256
    80005642:	4581                	li	a1,0
    80005644:	8552                	mv	a0,s4
    80005646:	eb2fb0ef          	jal	80000cf8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000564a:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000564c:	89d2                	mv	s3,s4
    8000564e:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005650:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005654:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80005656:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000565a:	00391513          	slli	a0,s2,0x3
    8000565e:	85d6                	mv	a1,s5
    80005660:	e2843783          	ld	a5,-472(s0)
    80005664:	953e                	add	a0,a0,a5
    80005666:	c8afd0ef          	jal	80002af0 <fetchaddr>
    8000566a:	02054663          	bltz	a0,80005696 <sys_exec+0x92>
    if(uarg == 0){
    8000566e:	e2043783          	ld	a5,-480(s0)
    80005672:	c7a1                	beqz	a5,800056ba <sys_exec+0xb6>
    argv[i] = kalloc();
    80005674:	cd0fb0ef          	jal	80000b44 <kalloc>
    80005678:	85aa                	mv	a1,a0
    8000567a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000567e:	cd01                	beqz	a0,80005696 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005680:	865a                	mv	a2,s6
    80005682:	e2043503          	ld	a0,-480(s0)
    80005686:	cb4fd0ef          	jal	80002b3a <fetchstr>
    8000568a:	00054663          	bltz	a0,80005696 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    8000568e:	0905                	addi	s2,s2,1
    80005690:	09a1                	addi	s3,s3,8
    80005692:	fd7914e3          	bne	s2,s7,8000565a <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005696:	100a0a13          	addi	s4,s4,256
    8000569a:	6088                	ld	a0,0(s1)
    8000569c:	cd31                	beqz	a0,800056f8 <sys_exec+0xf4>
    kfree(argv[i]);
    8000569e:	bbefb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056a2:	04a1                	addi	s1,s1,8
    800056a4:	ff449be3          	bne	s1,s4,8000569a <sys_exec+0x96>
  return -1;
    800056a8:	557d                	li	a0,-1
    800056aa:	64be                	ld	s1,456(sp)
    800056ac:	691e                	ld	s2,448(sp)
    800056ae:	79fa                	ld	s3,440(sp)
    800056b0:	7a5a                	ld	s4,432(sp)
    800056b2:	7aba                	ld	s5,424(sp)
    800056b4:	7b1a                	ld	s6,416(sp)
    800056b6:	6bfa                	ld	s7,408(sp)
    800056b8:	a881                	j	80005708 <sys_exec+0x104>
      argv[i] = 0;
    800056ba:	0009079b          	sext.w	a5,s2
    800056be:	e3040593          	addi	a1,s0,-464
    800056c2:	078e                	slli	a5,a5,0x3
    800056c4:	97ae                	add	a5,a5,a1
    800056c6:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    800056ca:	f3040513          	addi	a0,s0,-208
    800056ce:	b9eff0ef          	jal	80004a6c <kexec>
    800056d2:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056d4:	100a0a13          	addi	s4,s4,256
    800056d8:	6088                	ld	a0,0(s1)
    800056da:	c511                	beqz	a0,800056e6 <sys_exec+0xe2>
    kfree(argv[i]);
    800056dc:	b80fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056e0:	04a1                	addi	s1,s1,8
    800056e2:	ff449be3          	bne	s1,s4,800056d8 <sys_exec+0xd4>
  return ret;
    800056e6:	854a                	mv	a0,s2
    800056e8:	64be                	ld	s1,456(sp)
    800056ea:	691e                	ld	s2,448(sp)
    800056ec:	79fa                	ld	s3,440(sp)
    800056ee:	7a5a                	ld	s4,432(sp)
    800056f0:	7aba                	ld	s5,424(sp)
    800056f2:	7b1a                	ld	s6,416(sp)
    800056f4:	6bfa                	ld	s7,408(sp)
    800056f6:	a809                	j	80005708 <sys_exec+0x104>
  return -1;
    800056f8:	557d                	li	a0,-1
    800056fa:	64be                	ld	s1,456(sp)
    800056fc:	691e                	ld	s2,448(sp)
    800056fe:	79fa                	ld	s3,440(sp)
    80005700:	7a5a                	ld	s4,432(sp)
    80005702:	7aba                	ld	s5,424(sp)
    80005704:	7b1a                	ld	s6,416(sp)
    80005706:	6bfa                	ld	s7,408(sp)
}
    80005708:	60fe                	ld	ra,472(sp)
    8000570a:	645e                	ld	s0,464(sp)
    8000570c:	613d                	addi	sp,sp,480
    8000570e:	8082                	ret

0000000080005710 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005710:	7139                	addi	sp,sp,-64
    80005712:	fc06                	sd	ra,56(sp)
    80005714:	f822                	sd	s0,48(sp)
    80005716:	f426                	sd	s1,40(sp)
    80005718:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000571a:	b6efc0ef          	jal	80001a88 <myproc>
    8000571e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005720:	fd840593          	addi	a1,s0,-40
    80005724:	4501                	li	a0,0
    80005726:	c70fd0ef          	jal	80002b96 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000572a:	fc840593          	addi	a1,s0,-56
    8000572e:	fd040513          	addi	a0,s0,-48
    80005732:	814ff0ef          	jal	80004746 <pipealloc>
    return -1;
    80005736:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005738:	0a054763          	bltz	a0,800057e6 <sys_pipe+0xd6>
  fd0 = -1;
    8000573c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005740:	fd043503          	ld	a0,-48(s0)
    80005744:	ef2ff0ef          	jal	80004e36 <fdalloc>
    80005748:	fca42223          	sw	a0,-60(s0)
    8000574c:	08054463          	bltz	a0,800057d4 <sys_pipe+0xc4>
    80005750:	fc843503          	ld	a0,-56(s0)
    80005754:	ee2ff0ef          	jal	80004e36 <fdalloc>
    80005758:	fca42023          	sw	a0,-64(s0)
    8000575c:	06054263          	bltz	a0,800057c0 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005760:	4691                	li	a3,4
    80005762:	fc440613          	addi	a2,s0,-60
    80005766:	fd843583          	ld	a1,-40(s0)
    8000576a:	6ca8                	ld	a0,88(s1)
    8000576c:	f83fb0ef          	jal	800016ee <copyout>
    80005770:	00054e63          	bltz	a0,8000578c <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005774:	4691                	li	a3,4
    80005776:	fc040613          	addi	a2,s0,-64
    8000577a:	fd843583          	ld	a1,-40(s0)
    8000577e:	95b6                	add	a1,a1,a3
    80005780:	6ca8                	ld	a0,88(s1)
    80005782:	f6dfb0ef          	jal	800016ee <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005786:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005788:	04055f63          	bgez	a0,800057e6 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    8000578c:	fc442783          	lw	a5,-60(s0)
    80005790:	078e                	slli	a5,a5,0x3
    80005792:	0d078793          	addi	a5,a5,208
    80005796:	97a6                	add	a5,a5,s1
    80005798:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    8000579c:	fc042783          	lw	a5,-64(s0)
    800057a0:	078e                	slli	a5,a5,0x3
    800057a2:	0d078793          	addi	a5,a5,208
    800057a6:	97a6                	add	a5,a5,s1
    800057a8:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    800057ac:	fd043503          	ld	a0,-48(s0)
    800057b0:	c7bfe0ef          	jal	8000442a <fileclose>
    fileclose(wf);
    800057b4:	fc843503          	ld	a0,-56(s0)
    800057b8:	c73fe0ef          	jal	8000442a <fileclose>
    return -1;
    800057bc:	57fd                	li	a5,-1
    800057be:	a025                	j	800057e6 <sys_pipe+0xd6>
    if(fd0 >= 0)
    800057c0:	fc442783          	lw	a5,-60(s0)
    800057c4:	0007c863          	bltz	a5,800057d4 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800057c8:	078e                	slli	a5,a5,0x3
    800057ca:	0d078793          	addi	a5,a5,208
    800057ce:	97a6                	add	a5,a5,s1
    800057d0:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    800057d4:	fd043503          	ld	a0,-48(s0)
    800057d8:	c53fe0ef          	jal	8000442a <fileclose>
    fileclose(wf);
    800057dc:	fc843503          	ld	a0,-56(s0)
    800057e0:	c4bfe0ef          	jal	8000442a <fileclose>
    return -1;
    800057e4:	57fd                	li	a5,-1
}
    800057e6:	853e                	mv	a0,a5
    800057e8:	70e2                	ld	ra,56(sp)
    800057ea:	7442                	ld	s0,48(sp)
    800057ec:	74a2                	ld	s1,40(sp)
    800057ee:	6121                	addi	sp,sp,64
    800057f0:	8082                	ret
	...

0000000080005800 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005800:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005802:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005804:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005806:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005808:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000580a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000580c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000580e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005810:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005812:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005814:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005816:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005818:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000581a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000581c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000581e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005820:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005822:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005824:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005826:	9d8fd0ef          	jal	800029fe <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000582a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000582c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000582e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005830:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005832:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005834:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005836:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005838:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000583a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000583c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000583e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005840:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005842:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005844:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005846:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005848:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000584a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000584c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000584e:	10200073          	sret
    80005852:	00000013          	nop
    80005856:	00000013          	nop
    8000585a:	00000013          	nop

000000008000585e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000585e:	1141                	addi	sp,sp,-16
    80005860:	e406                	sd	ra,8(sp)
    80005862:	e022                	sd	s0,0(sp)
    80005864:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005866:	0c000737          	lui	a4,0xc000
    8000586a:	4785                	li	a5,1
    8000586c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000586e:	c35c                	sw	a5,4(a4)
}
    80005870:	60a2                	ld	ra,8(sp)
    80005872:	6402                	ld	s0,0(sp)
    80005874:	0141                	addi	sp,sp,16
    80005876:	8082                	ret

0000000080005878 <plicinithart>:

void
plicinithart(void)
{
    80005878:	1141                	addi	sp,sp,-16
    8000587a:	e406                	sd	ra,8(sp)
    8000587c:	e022                	sd	s0,0(sp)
    8000587e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005880:	9d4fc0ef          	jal	80001a54 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005884:	0085171b          	slliw	a4,a0,0x8
    80005888:	0c0027b7          	lui	a5,0xc002
    8000588c:	97ba                	add	a5,a5,a4
    8000588e:	40200713          	li	a4,1026
    80005892:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005896:	00d5151b          	slliw	a0,a0,0xd
    8000589a:	0c2017b7          	lui	a5,0xc201
    8000589e:	97aa                	add	a5,a5,a0
    800058a0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800058a4:	60a2                	ld	ra,8(sp)
    800058a6:	6402                	ld	s0,0(sp)
    800058a8:	0141                	addi	sp,sp,16
    800058aa:	8082                	ret

00000000800058ac <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800058ac:	1141                	addi	sp,sp,-16
    800058ae:	e406                	sd	ra,8(sp)
    800058b0:	e022                	sd	s0,0(sp)
    800058b2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800058b4:	9a0fc0ef          	jal	80001a54 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800058b8:	00d5151b          	slliw	a0,a0,0xd
    800058bc:	0c2017b7          	lui	a5,0xc201
    800058c0:	97aa                	add	a5,a5,a0
  return irq;
}
    800058c2:	43c8                	lw	a0,4(a5)
    800058c4:	60a2                	ld	ra,8(sp)
    800058c6:	6402                	ld	s0,0(sp)
    800058c8:	0141                	addi	sp,sp,16
    800058ca:	8082                	ret

00000000800058cc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800058cc:	1101                	addi	sp,sp,-32
    800058ce:	ec06                	sd	ra,24(sp)
    800058d0:	e822                	sd	s0,16(sp)
    800058d2:	e426                	sd	s1,8(sp)
    800058d4:	1000                	addi	s0,sp,32
    800058d6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800058d8:	97cfc0ef          	jal	80001a54 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800058dc:	00d5179b          	slliw	a5,a0,0xd
    800058e0:	0c201737          	lui	a4,0xc201
    800058e4:	97ba                	add	a5,a5,a4
    800058e6:	c3c4                	sw	s1,4(a5)
}
    800058e8:	60e2                	ld	ra,24(sp)
    800058ea:	6442                	ld	s0,16(sp)
    800058ec:	64a2                	ld	s1,8(sp)
    800058ee:	6105                	addi	sp,sp,32
    800058f0:	8082                	ret

00000000800058f2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800058f2:	1141                	addi	sp,sp,-16
    800058f4:	e406                	sd	ra,8(sp)
    800058f6:	e022                	sd	s0,0(sp)
    800058f8:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800058fa:	479d                	li	a5,7
    800058fc:	04a7ca63          	blt	a5,a0,80005950 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005900:	0001b797          	auipc	a5,0x1b
    80005904:	38878793          	addi	a5,a5,904 # 80020c88 <disk>
    80005908:	97aa                	add	a5,a5,a0
    8000590a:	0187c783          	lbu	a5,24(a5)
    8000590e:	e7b9                	bnez	a5,8000595c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005910:	00451693          	slli	a3,a0,0x4
    80005914:	0001b797          	auipc	a5,0x1b
    80005918:	37478793          	addi	a5,a5,884 # 80020c88 <disk>
    8000591c:	6398                	ld	a4,0(a5)
    8000591e:	9736                	add	a4,a4,a3
    80005920:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005924:	6398                	ld	a4,0(a5)
    80005926:	9736                	add	a4,a4,a3
    80005928:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000592c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005930:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005934:	97aa                	add	a5,a5,a0
    80005936:	4705                	li	a4,1
    80005938:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000593c:	0001b517          	auipc	a0,0x1b
    80005940:	36450513          	addi	a0,a0,868 # 80020ca0 <disk+0x18>
    80005944:	ff8fc0ef          	jal	8000213c <wakeup>
}
    80005948:	60a2                	ld	ra,8(sp)
    8000594a:	6402                	ld	s0,0(sp)
    8000594c:	0141                	addi	sp,sp,16
    8000594e:	8082                	ret
    panic("free_desc 1");
    80005950:	00002517          	auipc	a0,0x2
    80005954:	cf050513          	addi	a0,a0,-784 # 80007640 <etext+0x640>
    80005958:	ecdfa0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    8000595c:	00002517          	auipc	a0,0x2
    80005960:	cf450513          	addi	a0,a0,-780 # 80007650 <etext+0x650>
    80005964:	ec1fa0ef          	jal	80000824 <panic>

0000000080005968 <virtio_disk_init>:
{
    80005968:	1101                	addi	sp,sp,-32
    8000596a:	ec06                	sd	ra,24(sp)
    8000596c:	e822                	sd	s0,16(sp)
    8000596e:	e426                	sd	s1,8(sp)
    80005970:	e04a                	sd	s2,0(sp)
    80005972:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005974:	00002597          	auipc	a1,0x2
    80005978:	cec58593          	addi	a1,a1,-788 # 80007660 <etext+0x660>
    8000597c:	0001b517          	auipc	a0,0x1b
    80005980:	43450513          	addi	a0,a0,1076 # 80020db0 <disk+0x128>
    80005984:	a1afb0ef          	jal	80000b9e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005988:	100017b7          	lui	a5,0x10001
    8000598c:	4398                	lw	a4,0(a5)
    8000598e:	2701                	sext.w	a4,a4
    80005990:	747277b7          	lui	a5,0x74727
    80005994:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005998:	14f71863          	bne	a4,a5,80005ae8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000599c:	100017b7          	lui	a5,0x10001
    800059a0:	43dc                	lw	a5,4(a5)
    800059a2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800059a4:	4709                	li	a4,2
    800059a6:	14e79163          	bne	a5,a4,80005ae8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800059aa:	100017b7          	lui	a5,0x10001
    800059ae:	479c                	lw	a5,8(a5)
    800059b0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800059b2:	12e79b63          	bne	a5,a4,80005ae8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800059b6:	100017b7          	lui	a5,0x10001
    800059ba:	47d8                	lw	a4,12(a5)
    800059bc:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800059be:	554d47b7          	lui	a5,0x554d4
    800059c2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800059c6:	12f71163          	bne	a4,a5,80005ae8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    800059ca:	100017b7          	lui	a5,0x10001
    800059ce:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800059d2:	4705                	li	a4,1
    800059d4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059d6:	470d                	li	a4,3
    800059d8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800059da:	10001737          	lui	a4,0x10001
    800059de:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800059e0:	c7ffe6b7          	lui	a3,0xc7ffe
    800059e4:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd997>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800059e8:	8f75                	and	a4,a4,a3
    800059ea:	100016b7          	lui	a3,0x10001
    800059ee:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059f0:	472d                	li	a4,11
    800059f2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059f4:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    800059f8:	439c                	lw	a5,0(a5)
    800059fa:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800059fe:	8ba1                	andi	a5,a5,8
    80005a00:	0e078a63          	beqz	a5,80005af4 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005a04:	100017b7          	lui	a5,0x10001
    80005a08:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005a0c:	43fc                	lw	a5,68(a5)
    80005a0e:	2781                	sext.w	a5,a5
    80005a10:	0e079863          	bnez	a5,80005b00 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005a14:	100017b7          	lui	a5,0x10001
    80005a18:	5bdc                	lw	a5,52(a5)
    80005a1a:	2781                	sext.w	a5,a5
  if(max == 0)
    80005a1c:	0e078863          	beqz	a5,80005b0c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005a20:	471d                	li	a4,7
    80005a22:	0ef77b63          	bgeu	a4,a5,80005b18 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005a26:	91efb0ef          	jal	80000b44 <kalloc>
    80005a2a:	0001b497          	auipc	s1,0x1b
    80005a2e:	25e48493          	addi	s1,s1,606 # 80020c88 <disk>
    80005a32:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005a34:	910fb0ef          	jal	80000b44 <kalloc>
    80005a38:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005a3a:	90afb0ef          	jal	80000b44 <kalloc>
    80005a3e:	87aa                	mv	a5,a0
    80005a40:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005a42:	6088                	ld	a0,0(s1)
    80005a44:	0e050063          	beqz	a0,80005b24 <virtio_disk_init+0x1bc>
    80005a48:	0001b717          	auipc	a4,0x1b
    80005a4c:	24873703          	ld	a4,584(a4) # 80020c90 <disk+0x8>
    80005a50:	cb71                	beqz	a4,80005b24 <virtio_disk_init+0x1bc>
    80005a52:	cbe9                	beqz	a5,80005b24 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80005a54:	6605                	lui	a2,0x1
    80005a56:	4581                	li	a1,0
    80005a58:	aa0fb0ef          	jal	80000cf8 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005a5c:	0001b497          	auipc	s1,0x1b
    80005a60:	22c48493          	addi	s1,s1,556 # 80020c88 <disk>
    80005a64:	6605                	lui	a2,0x1
    80005a66:	4581                	li	a1,0
    80005a68:	6488                	ld	a0,8(s1)
    80005a6a:	a8efb0ef          	jal	80000cf8 <memset>
  memset(disk.used, 0, PGSIZE);
    80005a6e:	6605                	lui	a2,0x1
    80005a70:	4581                	li	a1,0
    80005a72:	6888                	ld	a0,16(s1)
    80005a74:	a84fb0ef          	jal	80000cf8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005a78:	100017b7          	lui	a5,0x10001
    80005a7c:	4721                	li	a4,8
    80005a7e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005a80:	4098                	lw	a4,0(s1)
    80005a82:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005a86:	40d8                	lw	a4,4(s1)
    80005a88:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005a8c:	649c                	ld	a5,8(s1)
    80005a8e:	0007869b          	sext.w	a3,a5
    80005a92:	10001737          	lui	a4,0x10001
    80005a96:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005a9a:	9781                	srai	a5,a5,0x20
    80005a9c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005aa0:	689c                	ld	a5,16(s1)
    80005aa2:	0007869b          	sext.w	a3,a5
    80005aa6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005aaa:	9781                	srai	a5,a5,0x20
    80005aac:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005ab0:	4785                	li	a5,1
    80005ab2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005ab4:	00f48c23          	sb	a5,24(s1)
    80005ab8:	00f48ca3          	sb	a5,25(s1)
    80005abc:	00f48d23          	sb	a5,26(s1)
    80005ac0:	00f48da3          	sb	a5,27(s1)
    80005ac4:	00f48e23          	sb	a5,28(s1)
    80005ac8:	00f48ea3          	sb	a5,29(s1)
    80005acc:	00f48f23          	sb	a5,30(s1)
    80005ad0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005ad4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005ad8:	07272823          	sw	s2,112(a4)
}
    80005adc:	60e2                	ld	ra,24(sp)
    80005ade:	6442                	ld	s0,16(sp)
    80005ae0:	64a2                	ld	s1,8(sp)
    80005ae2:	6902                	ld	s2,0(sp)
    80005ae4:	6105                	addi	sp,sp,32
    80005ae6:	8082                	ret
    panic("could not find virtio disk");
    80005ae8:	00002517          	auipc	a0,0x2
    80005aec:	b8850513          	addi	a0,a0,-1144 # 80007670 <etext+0x670>
    80005af0:	d35fa0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005af4:	00002517          	auipc	a0,0x2
    80005af8:	b9c50513          	addi	a0,a0,-1124 # 80007690 <etext+0x690>
    80005afc:	d29fa0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    80005b00:	00002517          	auipc	a0,0x2
    80005b04:	bb050513          	addi	a0,a0,-1104 # 800076b0 <etext+0x6b0>
    80005b08:	d1dfa0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    80005b0c:	00002517          	auipc	a0,0x2
    80005b10:	bc450513          	addi	a0,a0,-1084 # 800076d0 <etext+0x6d0>
    80005b14:	d11fa0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    80005b18:	00002517          	auipc	a0,0x2
    80005b1c:	bd850513          	addi	a0,a0,-1064 # 800076f0 <etext+0x6f0>
    80005b20:	d05fa0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    80005b24:	00002517          	auipc	a0,0x2
    80005b28:	bec50513          	addi	a0,a0,-1044 # 80007710 <etext+0x710>
    80005b2c:	cf9fa0ef          	jal	80000824 <panic>

0000000080005b30 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005b30:	711d                	addi	sp,sp,-96
    80005b32:	ec86                	sd	ra,88(sp)
    80005b34:	e8a2                	sd	s0,80(sp)
    80005b36:	e4a6                	sd	s1,72(sp)
    80005b38:	e0ca                	sd	s2,64(sp)
    80005b3a:	fc4e                	sd	s3,56(sp)
    80005b3c:	f852                	sd	s4,48(sp)
    80005b3e:	f456                	sd	s5,40(sp)
    80005b40:	f05a                	sd	s6,32(sp)
    80005b42:	ec5e                	sd	s7,24(sp)
    80005b44:	e862                	sd	s8,16(sp)
    80005b46:	1080                	addi	s0,sp,96
    80005b48:	89aa                	mv	s3,a0
    80005b4a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005b4c:	00c52b83          	lw	s7,12(a0)
    80005b50:	001b9b9b          	slliw	s7,s7,0x1
    80005b54:	1b82                	slli	s7,s7,0x20
    80005b56:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80005b5a:	0001b517          	auipc	a0,0x1b
    80005b5e:	25650513          	addi	a0,a0,598 # 80020db0 <disk+0x128>
    80005b62:	8c6fb0ef          	jal	80000c28 <acquire>
  for(int i = 0; i < NUM; i++){
    80005b66:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005b68:	0001ba97          	auipc	s5,0x1b
    80005b6c:	120a8a93          	addi	s5,s5,288 # 80020c88 <disk>
  for(int i = 0; i < 3; i++){
    80005b70:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005b72:	5c7d                	li	s8,-1
    80005b74:	a095                	j	80005bd8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80005b76:	00fa8733          	add	a4,s5,a5
    80005b7a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005b7e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005b80:	0207c563          	bltz	a5,80005baa <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80005b84:	2905                	addiw	s2,s2,1
    80005b86:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005b88:	05490c63          	beq	s2,s4,80005be0 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80005b8c:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005b8e:	0001b717          	auipc	a4,0x1b
    80005b92:	0fa70713          	addi	a4,a4,250 # 80020c88 <disk>
    80005b96:	4781                	li	a5,0
    if(disk.free[i]){
    80005b98:	01874683          	lbu	a3,24(a4)
    80005b9c:	fee9                	bnez	a3,80005b76 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80005b9e:	2785                	addiw	a5,a5,1
    80005ba0:	0705                	addi	a4,a4,1
    80005ba2:	fe979be3          	bne	a5,s1,80005b98 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005ba6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80005baa:	01205d63          	blez	s2,80005bc4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005bae:	fa042503          	lw	a0,-96(s0)
    80005bb2:	d41ff0ef          	jal	800058f2 <free_desc>
      for(int j = 0; j < i; j++)
    80005bb6:	4785                	li	a5,1
    80005bb8:	0127d663          	bge	a5,s2,80005bc4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005bbc:	fa442503          	lw	a0,-92(s0)
    80005bc0:	d33ff0ef          	jal	800058f2 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005bc4:	0001b597          	auipc	a1,0x1b
    80005bc8:	1ec58593          	addi	a1,a1,492 # 80020db0 <disk+0x128>
    80005bcc:	0001b517          	auipc	a0,0x1b
    80005bd0:	0d450513          	addi	a0,a0,212 # 80020ca0 <disk+0x18>
    80005bd4:	d1cfc0ef          	jal	800020f0 <sleep>
  for(int i = 0; i < 3; i++){
    80005bd8:	fa040613          	addi	a2,s0,-96
    80005bdc:	4901                	li	s2,0
    80005bde:	b77d                	j	80005b8c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005be0:	fa042503          	lw	a0,-96(s0)
    80005be4:	00451693          	slli	a3,a0,0x4

  if(write)
    80005be8:	0001b797          	auipc	a5,0x1b
    80005bec:	0a078793          	addi	a5,a5,160 # 80020c88 <disk>
    80005bf0:	00451713          	slli	a4,a0,0x4
    80005bf4:	0a070713          	addi	a4,a4,160
    80005bf8:	973e                	add	a4,a4,a5
    80005bfa:	01603633          	snez	a2,s6
    80005bfe:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005c00:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005c04:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005c08:	6398                	ld	a4,0(a5)
    80005c0a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005c0c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005c10:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005c12:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005c14:	6390                	ld	a2,0(a5)
    80005c16:	00d60833          	add	a6,a2,a3
    80005c1a:	4741                	li	a4,16
    80005c1c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005c20:	4585                	li	a1,1
    80005c22:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005c26:	fa442703          	lw	a4,-92(s0)
    80005c2a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005c2e:	0712                	slli	a4,a4,0x4
    80005c30:	963a                	add	a2,a2,a4
    80005c32:	05898813          	addi	a6,s3,88
    80005c36:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005c3a:	0007b883          	ld	a7,0(a5)
    80005c3e:	9746                	add	a4,a4,a7
    80005c40:	40000613          	li	a2,1024
    80005c44:	c710                	sw	a2,8(a4)
  if(write)
    80005c46:	001b3613          	seqz	a2,s6
    80005c4a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005c4e:	8e4d                	or	a2,a2,a1
    80005c50:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005c54:	fa842603          	lw	a2,-88(s0)
    80005c58:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005c5c:	00451813          	slli	a6,a0,0x4
    80005c60:	02080813          	addi	a6,a6,32
    80005c64:	983e                	add	a6,a6,a5
    80005c66:	577d                	li	a4,-1
    80005c68:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005c6c:	0612                	slli	a2,a2,0x4
    80005c6e:	98b2                	add	a7,a7,a2
    80005c70:	03068713          	addi	a4,a3,48
    80005c74:	973e                	add	a4,a4,a5
    80005c76:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005c7a:	6398                	ld	a4,0(a5)
    80005c7c:	9732                	add	a4,a4,a2
    80005c7e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005c80:	4689                	li	a3,2
    80005c82:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005c86:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005c8a:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80005c8e:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005c92:	6794                	ld	a3,8(a5)
    80005c94:	0026d703          	lhu	a4,2(a3)
    80005c98:	8b1d                	andi	a4,a4,7
    80005c9a:	0706                	slli	a4,a4,0x1
    80005c9c:	96ba                	add	a3,a3,a4
    80005c9e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005ca2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005ca6:	6798                	ld	a4,8(a5)
    80005ca8:	00275783          	lhu	a5,2(a4)
    80005cac:	2785                	addiw	a5,a5,1
    80005cae:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005cb2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005cb6:	100017b7          	lui	a5,0x10001
    80005cba:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005cbe:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80005cc2:	0001b917          	auipc	s2,0x1b
    80005cc6:	0ee90913          	addi	s2,s2,238 # 80020db0 <disk+0x128>
  while(b->disk == 1) {
    80005cca:	84ae                	mv	s1,a1
    80005ccc:	00b79a63          	bne	a5,a1,80005ce0 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005cd0:	85ca                	mv	a1,s2
    80005cd2:	854e                	mv	a0,s3
    80005cd4:	c1cfc0ef          	jal	800020f0 <sleep>
  while(b->disk == 1) {
    80005cd8:	0049a783          	lw	a5,4(s3)
    80005cdc:	fe978ae3          	beq	a5,s1,80005cd0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005ce0:	fa042903          	lw	s2,-96(s0)
    80005ce4:	00491713          	slli	a4,s2,0x4
    80005ce8:	02070713          	addi	a4,a4,32
    80005cec:	0001b797          	auipc	a5,0x1b
    80005cf0:	f9c78793          	addi	a5,a5,-100 # 80020c88 <disk>
    80005cf4:	97ba                	add	a5,a5,a4
    80005cf6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005cfa:	0001b997          	auipc	s3,0x1b
    80005cfe:	f8e98993          	addi	s3,s3,-114 # 80020c88 <disk>
    80005d02:	00491713          	slli	a4,s2,0x4
    80005d06:	0009b783          	ld	a5,0(s3)
    80005d0a:	97ba                	add	a5,a5,a4
    80005d0c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005d10:	854a                	mv	a0,s2
    80005d12:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005d16:	bddff0ef          	jal	800058f2 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005d1a:	8885                	andi	s1,s1,1
    80005d1c:	f0fd                	bnez	s1,80005d02 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005d1e:	0001b517          	auipc	a0,0x1b
    80005d22:	09250513          	addi	a0,a0,146 # 80020db0 <disk+0x128>
    80005d26:	f97fa0ef          	jal	80000cbc <release>
}
    80005d2a:	60e6                	ld	ra,88(sp)
    80005d2c:	6446                	ld	s0,80(sp)
    80005d2e:	64a6                	ld	s1,72(sp)
    80005d30:	6906                	ld	s2,64(sp)
    80005d32:	79e2                	ld	s3,56(sp)
    80005d34:	7a42                	ld	s4,48(sp)
    80005d36:	7aa2                	ld	s5,40(sp)
    80005d38:	7b02                	ld	s6,32(sp)
    80005d3a:	6be2                	ld	s7,24(sp)
    80005d3c:	6c42                	ld	s8,16(sp)
    80005d3e:	6125                	addi	sp,sp,96
    80005d40:	8082                	ret

0000000080005d42 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005d42:	1101                	addi	sp,sp,-32
    80005d44:	ec06                	sd	ra,24(sp)
    80005d46:	e822                	sd	s0,16(sp)
    80005d48:	e426                	sd	s1,8(sp)
    80005d4a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005d4c:	0001b497          	auipc	s1,0x1b
    80005d50:	f3c48493          	addi	s1,s1,-196 # 80020c88 <disk>
    80005d54:	0001b517          	auipc	a0,0x1b
    80005d58:	05c50513          	addi	a0,a0,92 # 80020db0 <disk+0x128>
    80005d5c:	ecdfa0ef          	jal	80000c28 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005d60:	100017b7          	lui	a5,0x10001
    80005d64:	53bc                	lw	a5,96(a5)
    80005d66:	8b8d                	andi	a5,a5,3
    80005d68:	10001737          	lui	a4,0x10001
    80005d6c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005d6e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005d72:	689c                	ld	a5,16(s1)
    80005d74:	0204d703          	lhu	a4,32(s1)
    80005d78:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005d7c:	04f70863          	beq	a4,a5,80005dcc <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80005d80:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005d84:	6898                	ld	a4,16(s1)
    80005d86:	0204d783          	lhu	a5,32(s1)
    80005d8a:	8b9d                	andi	a5,a5,7
    80005d8c:	078e                	slli	a5,a5,0x3
    80005d8e:	97ba                	add	a5,a5,a4
    80005d90:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005d92:	00479713          	slli	a4,a5,0x4
    80005d96:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005d9a:	9726                	add	a4,a4,s1
    80005d9c:	01074703          	lbu	a4,16(a4)
    80005da0:	e329                	bnez	a4,80005de2 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005da2:	0792                	slli	a5,a5,0x4
    80005da4:	02078793          	addi	a5,a5,32
    80005da8:	97a6                	add	a5,a5,s1
    80005daa:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005dac:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005db0:	b8cfc0ef          	jal	8000213c <wakeup>

    disk.used_idx += 1;
    80005db4:	0204d783          	lhu	a5,32(s1)
    80005db8:	2785                	addiw	a5,a5,1
    80005dba:	17c2                	slli	a5,a5,0x30
    80005dbc:	93c1                	srli	a5,a5,0x30
    80005dbe:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005dc2:	6898                	ld	a4,16(s1)
    80005dc4:	00275703          	lhu	a4,2(a4)
    80005dc8:	faf71ce3          	bne	a4,a5,80005d80 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005dcc:	0001b517          	auipc	a0,0x1b
    80005dd0:	fe450513          	addi	a0,a0,-28 # 80020db0 <disk+0x128>
    80005dd4:	ee9fa0ef          	jal	80000cbc <release>
}
    80005dd8:	60e2                	ld	ra,24(sp)
    80005dda:	6442                	ld	s0,16(sp)
    80005ddc:	64a2                	ld	s1,8(sp)
    80005dde:	6105                	addi	sp,sp,32
    80005de0:	8082                	ret
      panic("virtio_disk_intr status");
    80005de2:	00002517          	auipc	a0,0x2
    80005de6:	94650513          	addi	a0,a0,-1722 # 80007728 <etext+0x728>
    80005dea:	a3bfa0ef          	jal	80000824 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
