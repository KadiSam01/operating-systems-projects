user/getpinfo.o: user/getpinfo.c kernel/pstat.h kernel/param.h \
 kernel/types.h kernel/stat.h user/user.h
