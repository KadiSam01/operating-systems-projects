user/hardwork.o: user/hardwork.c kernel/types.h user/user.h
