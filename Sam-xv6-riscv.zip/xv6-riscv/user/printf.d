user/printf.o: user/printf.c kernel/types.h kernel/stat.h user/user.h \
 /usr/local/Cellar/riscv-gnu-toolchain/main/lib/gcc/riscv64-unknown-elf/15.1.0/include/stdarg.h
