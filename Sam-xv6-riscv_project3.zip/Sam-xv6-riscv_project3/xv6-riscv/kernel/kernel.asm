
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	89010113          	addi	sp,sp,-1904 # 80007890 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdda67>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e2a78793          	addi	a5,a5,-470 # 80000eae <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	250020ef          	jal	8000236a <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	0000f517          	auipc	a0,0xf
    80000196:	6fe50513          	addi	a0,a0,1790 # 8000f890 <cons>
    8000019a:	28f000ef          	jal	80000c28 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	0000f497          	auipc	s1,0xf
    800001a2:	6f248493          	addi	s1,s1,1778 # 8000f890 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	0000f917          	auipc	s2,0xf
    800001aa:	78290913          	addi	s2,s2,1922 # 8000f928 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	770010ef          	jal	8000192e <myproc>
    800001c2:	040020ef          	jal	80002202 <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	5fb010ef          	jal	80001fc6 <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	0000f717          	auipc	a4,0xf
    800001e2:	6b270713          	addi	a4,a4,1714 # 8000f890 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	110020ef          	jal	80002320 <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	0000f517          	auipc	a0,0xf
    8000022c:	66850513          	addi	a0,a0,1640 # 8000f890 <cons>
    80000230:	28d000ef          	jal	80000cbc <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	0000f717          	auipc	a4,0xf
    80000252:	6cf72d23          	sw	a5,1754(a4) # 8000f928 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	0000f517          	auipc	a0,0xf
    80000268:	62c50513          	addi	a0,a0,1580 # 8000f890 <cons>
    8000026c:	251000ef          	jal	80000cbc <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	0000f517          	auipc	a0,0xf
    800002bc:	5d850513          	addi	a0,a0,1496 # 8000f890 <cons>
    800002c0:	169000ef          	jal	80000c28 <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	0da020ef          	jal	800023b4 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	0000f517          	auipc	a0,0xf
    800002e2:	5b250513          	addi	a0,a0,1458 # 8000f890 <cons>
    800002e6:	1d7000ef          	jal	80000cbc <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	0000f717          	auipc	a4,0xf
    80000300:	59470713          	addi	a4,a4,1428 # 8000f890 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	0000f717          	auipc	a4,0xf
    80000326:	56e70713          	addi	a4,a4,1390 # 8000f890 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	0000f717          	auipc	a4,0xf
    80000350:	5dc72703          	lw	a4,1500(a4) # 8000f928 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	0000f717          	auipc	a4,0xf
    80000366:	52e70713          	addi	a4,a4,1326 # 8000f890 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	0000f497          	auipc	s1,0xf
    80000376:	51e48493          	addi	s1,s1,1310 # 8000f890 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	0000f717          	auipc	a4,0xf
    800003b8:	4dc70713          	addi	a4,a4,1244 # 8000f890 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	0000f717          	auipc	a4,0xf
    800003ce:	56f72323          	sw	a5,1382(a4) # 8000f930 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	0000f797          	auipc	a5,0xf
    800003ec:	4a878793          	addi	a5,a5,1192 # 8000f890 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	0000f797          	auipc	a5,0xf
    8000040e:	52c7a123          	sw	a2,1314(a5) # 8000f92c <cons+0x9c>
        wakeup(&cons.r);
    80000412:	0000f517          	auipc	a0,0xf
    80000416:	51650513          	addi	a0,a0,1302 # 8000f928 <cons+0x98>
    8000041a:	3f9010ef          	jal	80002012 <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00007597          	auipc	a1,0x7
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80007000 <etext>
    80000430:	0000f517          	auipc	a0,0xf
    80000434:	46050513          	addi	a0,a0,1120 # 8000f890 <cons>
    80000438:	766000ef          	jal	80000b9e <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	0001f797          	auipc	a5,0x1f
    80000444:	7c078793          	addi	a5,a5,1984 # 8001fc00 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007817          	auipc	a6,0x7
    80000482:	29280813          	addi	a6,a6,658 # 80007710 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	33c7a783          	lw	a5,828(a5) # 80007854 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	0000f517          	auipc	a0,0xf
    80000562:	3da50513          	addi	a0,a0,986 # 8000f938 <pr>
    80000566:	6c2000ef          	jal	80000c28 <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00007c97          	auipc	s9,0x7
    800006d6:	03ec8c93          	addi	s9,s9,62 # 80007710 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00007a17          	auipc	s4,0x7
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80007008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	00007797          	auipc	a5,0x7
    8000075e:	0fa7a783          	lw	a5,250(a5) # 80007854 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
    release(&pr.lock);

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
    release(&pr.lock);
    80000784:	0000f517          	auipc	a0,0xf
    80000788:	1b450513          	addi	a0,a0,436 # 8000f938 <pr>
    8000078c:	530000ef          	jal	80000cbc <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	00007797          	auipc	a5,0x7
    80000838:	0297a023          	sw	s1,32(a5) # 80007854 <panicking>
  printf("panic: ");
    8000083c:	00006517          	auipc	a0,0x6
    80000840:	7dc50513          	addi	a0,a0,2012 # 80007018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7d650513          	addi	a0,a0,2006 # 80007020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	00007797          	auipc	a5,0x7
    8000085a:	fe97ad23          	sw	s1,-6(a5) # 80007850 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00006597          	auipc	a1,0x6
    8000086c:	7c058593          	addi	a1,a1,1984 # 80007028 <etext+0x28>
    80000870:	0000f517          	auipc	a0,0xf
    80000874:	0c850513          	addi	a0,a0,200 # 8000f938 <pr>
    80000878:	326000ef          	jal	80000b9e <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00006597          	auipc	a1,0x6
    800008c2:	77258593          	addi	a1,a1,1906 # 80007030 <etext+0x30>
    800008c6:	0000f517          	auipc	a0,0xf
    800008ca:	08a50513          	addi	a0,a0,138 # 8000f950 <tx_lock>
    800008ce:	2d0000ef          	jal	80000b9e <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	0000f517          	auipc	a0,0xf
    800008ee:	06650513          	addi	a0,a0,102 # 8000f950 <tx_lock>
    800008f2:	336000ef          	jal	80000c28 <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	00007497          	auipc	s1,0x7
    8000090c:	f5448493          	addi	s1,s1,-172 # 8000785c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	0000f997          	auipc	s3,0xf
    80000914:	04098993          	addi	s3,s3,64 # 8000f950 <tx_lock>
    80000918:	00007917          	auipc	s2,0x7
    8000091c:	f4090913          	addi	s2,s2,-192 # 80007858 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	69a010ef          	jal	80001fc6 <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	0000f517          	auipc	a0,0xf
    8000095a:	ffa50513          	addi	a0,a0,-6 # 8000f950 <tx_lock>
    8000095e:	35e000ef          	jal	80000cbc <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	00007797          	auipc	a5,0x7
    8000097e:	eda7a783          	lw	a5,-294(a5) # 80007854 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	00007797          	auipc	a5,0x7
    80000988:	ecc7a783          	lw	a5,-308(a5) # 80007850 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	00007797          	auipc	a5,0x7
    800009ae:	eaa7a783          	lw	a5,-342(a5) # 80007854 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	226000ef          	jal	80000be4 <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	2a6000ef          	jal	80000c6c <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	0000f517          	auipc	a0,0xf
    80000a0a:	f4a50513          	addi	a0,a0,-182 # 8000f950 <tx_lock>
    80000a0e:	21a000ef          	jal	80000c28 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	0000f517          	auipc	a0,0xf
    80000a24:	f3050513          	addi	a0,a0,-208 # 8000f950 <tx_lock>
    80000a28:	294000ef          	jal	80000cbc <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	00007797          	auipc	a5,0x7
    80000a40:	e207a023          	sw	zero,-480(a5) # 8000785c <tx_busy>
    wakeup(&tx_chan);
    80000a44:	00007517          	auipc	a0,0x7
    80000a48:	e1450513          	addi	a0,a0,-492 # 80007858 <tx_chan>
    80000a4c:	5c6010ef          	jal	80002012 <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	e04a                	sd	s2,0(sp)
    80000a66:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a68:	00020797          	auipc	a5,0x20
    80000a6c:	33078793          	addi	a5,a5,816 # 80020d98 <end>
    80000a70:	00f53733          	sltu	a4,a0,a5
    80000a74:	47c5                	li	a5,17
    80000a76:	07ee                	slli	a5,a5,0x1b
    80000a78:	17fd                	addi	a5,a5,-1
    80000a7a:	00a7b7b3          	sltu	a5,a5,a0
    80000a7e:	8fd9                	or	a5,a5,a4
    80000a80:	ef95                	bnez	a5,80000abc <kfree+0x60>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	03451793          	slli	a5,a0,0x34
    80000a88:	eb95                	bnez	a5,80000abc <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a8a:	6605                	lui	a2,0x1
    80000a8c:	4585                	li	a1,1
    80000a8e:	26a000ef          	jal	80000cf8 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a92:	0000f917          	auipc	s2,0xf
    80000a96:	ed690913          	addi	s2,s2,-298 # 8000f968 <kmem>
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	18c000ef          	jal	80000c28 <acquire>
  r->next = kmem.freelist;
    80000aa0:	01893783          	ld	a5,24(s2)
    80000aa4:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000aa6:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000aaa:	854a                	mv	a0,s2
    80000aac:	210000ef          	jal	80000cbc <release>
}
    80000ab0:	60e2                	ld	ra,24(sp)
    80000ab2:	6442                	ld	s0,16(sp)
    80000ab4:	64a2                	ld	s1,8(sp)
    80000ab6:	6902                	ld	s2,0(sp)
    80000ab8:	6105                	addi	sp,sp,32
    80000aba:	8082                	ret
    panic("kfree");
    80000abc:	00006517          	auipc	a0,0x6
    80000ac0:	57c50513          	addi	a0,a0,1404 # 80007038 <etext+0x38>
    80000ac4:	d61ff0ef          	jal	80000824 <panic>

0000000080000ac8 <freerange>:
{
    80000ac8:	7179                	addi	sp,sp,-48
    80000aca:	f406                	sd	ra,40(sp)
    80000acc:	f022                	sd	s0,32(sp)
    80000ace:	ec26                	sd	s1,24(sp)
    80000ad0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ad2:	6785                	lui	a5,0x1
    80000ad4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad8:	00e504b3          	add	s1,a0,a4
    80000adc:	777d                	lui	a4,0xfffff
    80000ade:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae0:	94be                	add	s1,s1,a5
    80000ae2:	0295e263          	bltu	a1,s1,80000b06 <freerange+0x3e>
    80000ae6:	e84a                	sd	s2,16(sp)
    80000ae8:	e44e                	sd	s3,8(sp)
    80000aea:	e052                	sd	s4,0(sp)
    80000aec:	892e                	mv	s2,a1
    kfree(p);
    80000aee:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af0:	89be                	mv	s3,a5
    kfree(p);
    80000af2:	01448533          	add	a0,s1,s4
    80000af6:	f67ff0ef          	jal	80000a5c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000afa:	94ce                	add	s1,s1,s3
    80000afc:	fe997be3          	bgeu	s2,s1,80000af2 <freerange+0x2a>
    80000b00:	6942                	ld	s2,16(sp)
    80000b02:	69a2                	ld	s3,8(sp)
    80000b04:	6a02                	ld	s4,0(sp)
}
    80000b06:	70a2                	ld	ra,40(sp)
    80000b08:	7402                	ld	s0,32(sp)
    80000b0a:	64e2                	ld	s1,24(sp)
    80000b0c:	6145                	addi	sp,sp,48
    80000b0e:	8082                	ret

0000000080000b10 <kinit>:
{
    80000b10:	1141                	addi	sp,sp,-16
    80000b12:	e406                	sd	ra,8(sp)
    80000b14:	e022                	sd	s0,0(sp)
    80000b16:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b18:	00006597          	auipc	a1,0x6
    80000b1c:	52858593          	addi	a1,a1,1320 # 80007040 <etext+0x40>
    80000b20:	0000f517          	auipc	a0,0xf
    80000b24:	e4850513          	addi	a0,a0,-440 # 8000f968 <kmem>
    80000b28:	076000ef          	jal	80000b9e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00020517          	auipc	a0,0x20
    80000b34:	26850513          	addi	a0,a0,616 # 80020d98 <end>
    80000b38:	f91ff0ef          	jal	80000ac8 <freerange>
}
    80000b3c:	60a2                	ld	ra,8(sp)
    80000b3e:	6402                	ld	s0,0(sp)
    80000b40:	0141                	addi	sp,sp,16
    80000b42:	8082                	ret

0000000080000b44 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b44:	1101                	addi	sp,sp,-32
    80000b46:	ec06                	sd	ra,24(sp)
    80000b48:	e822                	sd	s0,16(sp)
    80000b4a:	e426                	sd	s1,8(sp)
    80000b4c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4e:	0000f517          	auipc	a0,0xf
    80000b52:	e1a50513          	addi	a0,a0,-486 # 8000f968 <kmem>
    80000b56:	0d2000ef          	jal	80000c28 <acquire>
  r = kmem.freelist;
    80000b5a:	0000f497          	auipc	s1,0xf
    80000b5e:	e264b483          	ld	s1,-474(s1) # 8000f980 <kmem+0x18>
  if(r)
    80000b62:	c49d                	beqz	s1,80000b90 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b64:	609c                	ld	a5,0(s1)
    80000b66:	0000f717          	auipc	a4,0xf
    80000b6a:	e0f73d23          	sd	a5,-486(a4) # 8000f980 <kmem+0x18>
  release(&kmem.lock);
    80000b6e:	0000f517          	auipc	a0,0xf
    80000b72:	dfa50513          	addi	a0,a0,-518 # 8000f968 <kmem>
    80000b76:	146000ef          	jal	80000cbc <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	178000ef          	jal	80000cf8 <memset>
  return (void*)r;
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	0000f517          	auipc	a0,0xf
    80000b94:	dd850513          	addi	a0,a0,-552 # 8000f968 <kmem>
    80000b98:	124000ef          	jal	80000cbc <release>
  if(r)
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x40>

0000000080000b9e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b9e:	1141                	addi	sp,sp,-16
    80000ba0:	e406                	sd	ra,8(sp)
    80000ba2:	e022                	sd	s0,0(sp)
    80000ba4:	0800                	addi	s0,sp,16
  lk->name = name;
    80000ba6:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000ba8:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bac:	00053823          	sd	zero,16(a0)
}
    80000bb0:	60a2                	ld	ra,8(sp)
    80000bb2:	6402                	ld	s0,0(sp)
    80000bb4:	0141                	addi	sp,sp,16
    80000bb6:	8082                	ret

0000000080000bb8 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bb8:	411c                	lw	a5,0(a0)
    80000bba:	e399                	bnez	a5,80000bc0 <holding+0x8>
    80000bbc:	4501                	li	a0,0
  return r;
}
    80000bbe:	8082                	ret
{
    80000bc0:	1101                	addi	sp,sp,-32
    80000bc2:	ec06                	sd	ra,24(sp)
    80000bc4:	e822                	sd	s0,16(sp)
    80000bc6:	e426                	sd	s1,8(sp)
    80000bc8:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bca:	691c                	ld	a5,16(a0)
    80000bcc:	84be                	mv	s1,a5
    80000bce:	541000ef          	jal	8000190e <mycpu>
    80000bd2:	40a48533          	sub	a0,s1,a0
    80000bd6:	00153513          	seqz	a0,a0
}
    80000bda:	60e2                	ld	ra,24(sp)
    80000bdc:	6442                	ld	s0,16(sp)
    80000bde:	64a2                	ld	s1,8(sp)
    80000be0:	6105                	addi	sp,sp,32
    80000be2:	8082                	ret

0000000080000be4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000be4:	1101                	addi	sp,sp,-32
    80000be6:	ec06                	sd	ra,24(sp)
    80000be8:	e822                	sd	s0,16(sp)
    80000bea:	e426                	sd	s1,8(sp)
    80000bec:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bee:	100027f3          	csrr	a5,sstatus
    80000bf2:	84be                	mv	s1,a5
    80000bf4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bf8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bfa:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000bfe:	511000ef          	jal	8000190e <mycpu>
    80000c02:	5d3c                	lw	a5,120(a0)
    80000c04:	cb99                	beqz	a5,80000c1a <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c06:	509000ef          	jal	8000190e <mycpu>
    80000c0a:	5d3c                	lw	a5,120(a0)
    80000c0c:	2785                	addiw	a5,a5,1
    80000c0e:	dd3c                	sw	a5,120(a0)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    mycpu()->intena = old;
    80000c1a:	4f5000ef          	jal	8000190e <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c1e:	0014d793          	srli	a5,s1,0x1
    80000c22:	8b85                	andi	a5,a5,1
    80000c24:	dd7c                	sw	a5,124(a0)
    80000c26:	b7c5                	j	80000c06 <push_off+0x22>

0000000080000c28 <acquire>:
{
    80000c28:	1101                	addi	sp,sp,-32
    80000c2a:	ec06                	sd	ra,24(sp)
    80000c2c:	e822                	sd	s0,16(sp)
    80000c2e:	e426                	sd	s1,8(sp)
    80000c30:	1000                	addi	s0,sp,32
    80000c32:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c34:	fb1ff0ef          	jal	80000be4 <push_off>
  if(holding(lk))
    80000c38:	8526                	mv	a0,s1
    80000c3a:	f7fff0ef          	jal	80000bb8 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c3e:	4705                	li	a4,1
  if(holding(lk))
    80000c40:	e105                	bnez	a0,80000c60 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c42:	87ba                	mv	a5,a4
    80000c44:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c48:	2781                	sext.w	a5,a5
    80000c4a:	ffe5                	bnez	a5,80000c42 <acquire+0x1a>
  __sync_synchronize();
    80000c4c:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c50:	4bf000ef          	jal	8000190e <mycpu>
    80000c54:	e888                	sd	a0,16(s1)
}
    80000c56:	60e2                	ld	ra,24(sp)
    80000c58:	6442                	ld	s0,16(sp)
    80000c5a:	64a2                	ld	s1,8(sp)
    80000c5c:	6105                	addi	sp,sp,32
    80000c5e:	8082                	ret
    panic("acquire");
    80000c60:	00006517          	auipc	a0,0x6
    80000c64:	3e850513          	addi	a0,a0,1000 # 80007048 <etext+0x48>
    80000c68:	bbdff0ef          	jal	80000824 <panic>

0000000080000c6c <pop_off>:

void
pop_off(void)
{
    80000c6c:	1141                	addi	sp,sp,-16
    80000c6e:	e406                	sd	ra,8(sp)
    80000c70:	e022                	sd	s0,0(sp)
    80000c72:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c74:	49b000ef          	jal	8000190e <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c7c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c7e:	e39d                	bnez	a5,80000ca4 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c80:	5d3c                	lw	a5,120(a0)
    80000c82:	02f05763          	blez	a5,80000cb0 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000c86:	37fd                	addiw	a5,a5,-1
    80000c88:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c8a:	eb89                	bnez	a5,80000c9c <pop_off+0x30>
    80000c8c:	5d7c                	lw	a5,124(a0)
    80000c8e:	c799                	beqz	a5,80000c9c <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c90:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c94:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c98:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c9c:	60a2                	ld	ra,8(sp)
    80000c9e:	6402                	ld	s0,0(sp)
    80000ca0:	0141                	addi	sp,sp,16
    80000ca2:	8082                	ret
    panic("pop_off - interruptible");
    80000ca4:	00006517          	auipc	a0,0x6
    80000ca8:	3ac50513          	addi	a0,a0,940 # 80007050 <etext+0x50>
    80000cac:	b79ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000cb0:	00006517          	auipc	a0,0x6
    80000cb4:	3b850513          	addi	a0,a0,952 # 80007068 <etext+0x68>
    80000cb8:	b6dff0ef          	jal	80000824 <panic>

0000000080000cbc <release>:
{
    80000cbc:	1101                	addi	sp,sp,-32
    80000cbe:	ec06                	sd	ra,24(sp)
    80000cc0:	e822                	sd	s0,16(sp)
    80000cc2:	e426                	sd	s1,8(sp)
    80000cc4:	1000                	addi	s0,sp,32
    80000cc6:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cc8:	ef1ff0ef          	jal	80000bb8 <holding>
    80000ccc:	c105                	beqz	a0,80000cec <release+0x30>
  lk->cpu = 0;
    80000cce:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cd2:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000cd6:	0310000f          	fence	rw,w
    80000cda:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cde:	f8fff0ef          	jal	80000c6c <pop_off>
}
    80000ce2:	60e2                	ld	ra,24(sp)
    80000ce4:	6442                	ld	s0,16(sp)
    80000ce6:	64a2                	ld	s1,8(sp)
    80000ce8:	6105                	addi	sp,sp,32
    80000cea:	8082                	ret
    panic("release");
    80000cec:	00006517          	auipc	a0,0x6
    80000cf0:	38450513          	addi	a0,a0,900 # 80007070 <etext+0x70>
    80000cf4:	b31ff0ef          	jal	80000824 <panic>

0000000080000cf8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cf8:	1141                	addi	sp,sp,-16
    80000cfa:	e406                	sd	ra,8(sp)
    80000cfc:	e022                	sd	s0,0(sp)
    80000cfe:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d00:	ca19                	beqz	a2,80000d16 <memset+0x1e>
    80000d02:	87aa                	mv	a5,a0
    80000d04:	1602                	slli	a2,a2,0x20
    80000d06:	9201                	srli	a2,a2,0x20
    80000d08:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d0c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d10:	0785                	addi	a5,a5,1
    80000d12:	fee79de3          	bne	a5,a4,80000d0c <memset+0x14>
  }
  return dst;
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret

0000000080000d1e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e406                	sd	ra,8(sp)
    80000d22:	e022                	sd	s0,0(sp)
    80000d24:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d26:	c61d                	beqz	a2,80000d54 <memcmp+0x36>
    80000d28:	1602                	slli	a2,a2,0x20
    80000d2a:	9201                	srli	a2,a2,0x20
    80000d2c:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d30:	00054783          	lbu	a5,0(a0)
    80000d34:	0005c703          	lbu	a4,0(a1)
    80000d38:	00e79863          	bne	a5,a4,80000d48 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d3c:	0505                	addi	a0,a0,1
    80000d3e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d40:	fed518e3          	bne	a0,a3,80000d30 <memcmp+0x12>
  }

  return 0;
    80000d44:	4501                	li	a0,0
    80000d46:	a019                	j	80000d4c <memcmp+0x2e>
      return *s1 - *s2;
    80000d48:	40e7853b          	subw	a0,a5,a4
}
    80000d4c:	60a2                	ld	ra,8(sp)
    80000d4e:	6402                	ld	s0,0(sp)
    80000d50:	0141                	addi	sp,sp,16
    80000d52:	8082                	ret
  return 0;
    80000d54:	4501                	li	a0,0
    80000d56:	bfdd                	j	80000d4c <memcmp+0x2e>

0000000080000d58 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d58:	1141                	addi	sp,sp,-16
    80000d5a:	e406                	sd	ra,8(sp)
    80000d5c:	e022                	sd	s0,0(sp)
    80000d5e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d60:	c205                	beqz	a2,80000d80 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d62:	02a5e363          	bltu	a1,a0,80000d88 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d66:	1602                	slli	a2,a2,0x20
    80000d68:	9201                	srli	a2,a2,0x20
    80000d6a:	00c587b3          	add	a5,a1,a2
{
    80000d6e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	0705                	addi	a4,a4,1
    80000d74:	fff5c683          	lbu	a3,-1(a1)
    80000d78:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d7c:	feb79ae3          	bne	a5,a1,80000d70 <memmove+0x18>

  return dst;
}
    80000d80:	60a2                	ld	ra,8(sp)
    80000d82:	6402                	ld	s0,0(sp)
    80000d84:	0141                	addi	sp,sp,16
    80000d86:	8082                	ret
  if(s < d && s + n > d){
    80000d88:	02061693          	slli	a3,a2,0x20
    80000d8c:	9281                	srli	a3,a3,0x20
    80000d8e:	00d58733          	add	a4,a1,a3
    80000d92:	fce57ae3          	bgeu	a0,a4,80000d66 <memmove+0xe>
    d += n;
    80000d96:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d98:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d9c:	1782                	slli	a5,a5,0x20
    80000d9e:	9381                	srli	a5,a5,0x20
    80000da0:	fff7c793          	not	a5,a5
    80000da4:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000da6:	177d                	addi	a4,a4,-1
    80000da8:	16fd                	addi	a3,a3,-1
    80000daa:	00074603          	lbu	a2,0(a4)
    80000dae:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000db2:	fee79ae3          	bne	a5,a4,80000da6 <memmove+0x4e>
    80000db6:	b7e9                	j	80000d80 <memmove+0x28>

0000000080000db8 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000db8:	1141                	addi	sp,sp,-16
    80000dba:	e406                	sd	ra,8(sp)
    80000dbc:	e022                	sd	s0,0(sp)
    80000dbe:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dc0:	f99ff0ef          	jal	80000d58 <memmove>
}
    80000dc4:	60a2                	ld	ra,8(sp)
    80000dc6:	6402                	ld	s0,0(sp)
    80000dc8:	0141                	addi	sp,sp,16
    80000dca:	8082                	ret

0000000080000dcc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000dcc:	1141                	addi	sp,sp,-16
    80000dce:	e406                	sd	ra,8(sp)
    80000dd0:	e022                	sd	s0,0(sp)
    80000dd2:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dd4:	ce11                	beqz	a2,80000df0 <strncmp+0x24>
    80000dd6:	00054783          	lbu	a5,0(a0)
    80000dda:	cf89                	beqz	a5,80000df4 <strncmp+0x28>
    80000ddc:	0005c703          	lbu	a4,0(a1)
    80000de0:	00f71a63          	bne	a4,a5,80000df4 <strncmp+0x28>
    n--, p++, q++;
    80000de4:	367d                	addiw	a2,a2,-1
    80000de6:	0505                	addi	a0,a0,1
    80000de8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dea:	f675                	bnez	a2,80000dd6 <strncmp+0xa>
  if(n == 0)
    return 0;
    80000dec:	4501                	li	a0,0
    80000dee:	a801                	j	80000dfe <strncmp+0x32>
    80000df0:	4501                	li	a0,0
    80000df2:	a031                	j	80000dfe <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000df4:	00054503          	lbu	a0,0(a0)
    80000df8:	0005c783          	lbu	a5,0(a1)
    80000dfc:	9d1d                	subw	a0,a0,a5
}
    80000dfe:	60a2                	ld	ra,8(sp)
    80000e00:	6402                	ld	s0,0(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e406                	sd	ra,8(sp)
    80000e0a:	e022                	sd	s0,0(sp)
    80000e0c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e0e:	87aa                	mv	a5,a0
    80000e10:	a011                	j	80000e14 <strncpy+0xe>
    80000e12:	8636                	mv	a2,a3
    80000e14:	02c05863          	blez	a2,80000e44 <strncpy+0x3e>
    80000e18:	fff6069b          	addiw	a3,a2,-1
    80000e1c:	8836                	mv	a6,a3
    80000e1e:	0785                	addi	a5,a5,1
    80000e20:	0005c703          	lbu	a4,0(a1)
    80000e24:	fee78fa3          	sb	a4,-1(a5)
    80000e28:	0585                	addi	a1,a1,1
    80000e2a:	f765                	bnez	a4,80000e12 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e2c:	873e                	mv	a4,a5
    80000e2e:	01005b63          	blez	a6,80000e44 <strncpy+0x3e>
    80000e32:	9fb1                	addw	a5,a5,a2
    80000e34:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e36:	0705                	addi	a4,a4,1
    80000e38:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e3c:	40e786bb          	subw	a3,a5,a4
    80000e40:	fed04be3          	bgtz	a3,80000e36 <strncpy+0x30>
  return os;
}
    80000e44:	60a2                	ld	ra,8(sp)
    80000e46:	6402                	ld	s0,0(sp)
    80000e48:	0141                	addi	sp,sp,16
    80000e4a:	8082                	ret

0000000080000e4c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e4c:	1141                	addi	sp,sp,-16
    80000e4e:	e406                	sd	ra,8(sp)
    80000e50:	e022                	sd	s0,0(sp)
    80000e52:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e54:	02c05363          	blez	a2,80000e7a <safestrcpy+0x2e>
    80000e58:	fff6069b          	addiw	a3,a2,-1
    80000e5c:	1682                	slli	a3,a3,0x20
    80000e5e:	9281                	srli	a3,a3,0x20
    80000e60:	96ae                	add	a3,a3,a1
    80000e62:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e64:	00d58963          	beq	a1,a3,80000e76 <safestrcpy+0x2a>
    80000e68:	0585                	addi	a1,a1,1
    80000e6a:	0785                	addi	a5,a5,1
    80000e6c:	fff5c703          	lbu	a4,-1(a1)
    80000e70:	fee78fa3          	sb	a4,-1(a5)
    80000e74:	fb65                	bnez	a4,80000e64 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e76:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e7a:	60a2                	ld	ra,8(sp)
    80000e7c:	6402                	ld	s0,0(sp)
    80000e7e:	0141                	addi	sp,sp,16
    80000e80:	8082                	ret

0000000080000e82 <strlen>:

int
strlen(const char *s)
{
    80000e82:	1141                	addi	sp,sp,-16
    80000e84:	e406                	sd	ra,8(sp)
    80000e86:	e022                	sd	s0,0(sp)
    80000e88:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e8a:	00054783          	lbu	a5,0(a0)
    80000e8e:	cf91                	beqz	a5,80000eaa <strlen+0x28>
    80000e90:	00150793          	addi	a5,a0,1
    80000e94:	86be                	mv	a3,a5
    80000e96:	0785                	addi	a5,a5,1
    80000e98:	fff7c703          	lbu	a4,-1(a5)
    80000e9c:	ff65                	bnez	a4,80000e94 <strlen+0x12>
    80000e9e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ea2:	60a2                	ld	ra,8(sp)
    80000ea4:	6402                	ld	s0,0(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret
  for(n = 0; s[n]; n++)
    80000eaa:	4501                	li	a0,0
    80000eac:	bfdd                	j	80000ea2 <strlen+0x20>

0000000080000eae <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000eae:	1141                	addi	sp,sp,-16
    80000eb0:	e406                	sd	ra,8(sp)
    80000eb2:	e022                	sd	s0,0(sp)
    80000eb4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000eb6:	245000ef          	jal	800018fa <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000eba:	00007717          	auipc	a4,0x7
    80000ebe:	9a670713          	addi	a4,a4,-1626 # 80007860 <started>
  if(cpuid() == 0){
    80000ec2:	c51d                	beqz	a0,80000ef0 <main+0x42>
    while(started == 0)
    80000ec4:	431c                	lw	a5,0(a4)
    80000ec6:	2781                	sext.w	a5,a5
    80000ec8:	dff5                	beqz	a5,80000ec4 <main+0x16>
      ;
    __sync_synchronize();
    80000eca:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ece:	22d000ef          	jal	800018fa <cpuid>
    80000ed2:	85aa                	mv	a1,a0
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	1c450513          	addi	a0,a0,452 # 80007098 <etext+0x98>
    80000edc:	e1eff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000ee0:	080000ef          	jal	80000f60 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ee4:	780010ef          	jal	80002664 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ee8:	7f0040ef          	jal	800056d8 <plicinithart>
  }

  scheduler();        
    80000eec:	6b5000ef          	jal	80001da0 <scheduler>
    consoleinit();
    80000ef0:	d30ff0ef          	jal	80000420 <consoleinit>
    printfinit();
    80000ef4:	96dff0ef          	jal	80000860 <printfinit>
    printf("\n");
    80000ef8:	00006517          	auipc	a0,0x6
    80000efc:	18050513          	addi	a0,a0,384 # 80007078 <etext+0x78>
    80000f00:	dfaff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000f04:	00006517          	auipc	a0,0x6
    80000f08:	17c50513          	addi	a0,a0,380 # 80007080 <etext+0x80>
    80000f0c:	deeff0ef          	jal	800004fa <printf>
    printf("\n");
    80000f10:	00006517          	auipc	a0,0x6
    80000f14:	16850513          	addi	a0,a0,360 # 80007078 <etext+0x78>
    80000f18:	de2ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000f1c:	bf5ff0ef          	jal	80000b10 <kinit>
    kvminit();       // create kernel page table
    80000f20:	2cc000ef          	jal	800011ec <kvminit>
    kvminithart();   // turn on paging
    80000f24:	03c000ef          	jal	80000f60 <kvminithart>
    procinit();      // process table
    80000f28:	11d000ef          	jal	80001844 <procinit>
    trapinit();      // trap vectors
    80000f2c:	714010ef          	jal	80002640 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f30:	734010ef          	jal	80002664 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f34:	78a040ef          	jal	800056be <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f38:	7a0040ef          	jal	800056d8 <plicinithart>
    binit();         // buffer cache
    80000f3c:	615010ef          	jal	80002d50 <binit>
    iinit();         // inode table
    80000f40:	366020ef          	jal	800032a6 <iinit>
    fileinit();      // file table
    80000f44:	292030ef          	jal	800041d6 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f48:	081040ef          	jal	800057c8 <virtio_disk_init>
    userinit();      // first user process
    80000f4c:	4bb000ef          	jal	80001c06 <userinit>
    __sync_synchronize();
    80000f50:	0330000f          	fence	rw,rw
    started = 1;
    80000f54:	4785                	li	a5,1
    80000f56:	00007717          	auipc	a4,0x7
    80000f5a:	90f72523          	sw	a5,-1782(a4) # 80007860 <started>
    80000f5e:	b779                	j	80000eec <main+0x3e>

0000000080000f60 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f60:	1141                	addi	sp,sp,-16
    80000f62:	e406                	sd	ra,8(sp)
    80000f64:	e022                	sd	s0,0(sp)
    80000f66:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f68:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f6c:	00007797          	auipc	a5,0x7
    80000f70:	8fc7b783          	ld	a5,-1796(a5) # 80007868 <kernel_pagetable>
    80000f74:	83b1                	srli	a5,a5,0xc
    80000f76:	577d                	li	a4,-1
    80000f78:	177e                	slli	a4,a4,0x3f
    80000f7a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f7c:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f80:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f84:	60a2                	ld	ra,8(sp)
    80000f86:	6402                	ld	s0,0(sp)
    80000f88:	0141                	addi	sp,sp,16
    80000f8a:	8082                	ret

0000000080000f8c <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f8c:	7139                	addi	sp,sp,-64
    80000f8e:	fc06                	sd	ra,56(sp)
    80000f90:	f822                	sd	s0,48(sp)
    80000f92:	f426                	sd	s1,40(sp)
    80000f94:	f04a                	sd	s2,32(sp)
    80000f96:	ec4e                	sd	s3,24(sp)
    80000f98:	e852                	sd	s4,16(sp)
    80000f9a:	e456                	sd	s5,8(sp)
    80000f9c:	e05a                	sd	s6,0(sp)
    80000f9e:	0080                	addi	s0,sp,64
    80000fa0:	84aa                	mv	s1,a0
    80000fa2:	89ae                	mv	s3,a1
    80000fa4:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fa6:	57fd                	li	a5,-1
    80000fa8:	83e9                	srli	a5,a5,0x1a
    80000faa:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fac:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fae:	04b7e263          	bltu	a5,a1,80000ff2 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fb2:	0149d933          	srl	s2,s3,s4
    80000fb6:	1ff97913          	andi	s2,s2,511
    80000fba:	090e                	slli	s2,s2,0x3
    80000fbc:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fbe:	00093483          	ld	s1,0(s2)
    80000fc2:	0014f793          	andi	a5,s1,1
    80000fc6:	cf85                	beqz	a5,80000ffe <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fc8:	80a9                	srli	s1,s1,0xa
    80000fca:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000fcc:	3a5d                	addiw	s4,s4,-9
    80000fce:	ff5a12e3          	bne	s4,s5,80000fb2 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000fd2:	00c9d513          	srli	a0,s3,0xc
    80000fd6:	1ff57513          	andi	a0,a0,511
    80000fda:	050e                	slli	a0,a0,0x3
    80000fdc:	9526                	add	a0,a0,s1
}
    80000fde:	70e2                	ld	ra,56(sp)
    80000fe0:	7442                	ld	s0,48(sp)
    80000fe2:	74a2                	ld	s1,40(sp)
    80000fe4:	7902                	ld	s2,32(sp)
    80000fe6:	69e2                	ld	s3,24(sp)
    80000fe8:	6a42                	ld	s4,16(sp)
    80000fea:	6aa2                	ld	s5,8(sp)
    80000fec:	6b02                	ld	s6,0(sp)
    80000fee:	6121                	addi	sp,sp,64
    80000ff0:	8082                	ret
    panic("walk");
    80000ff2:	00006517          	auipc	a0,0x6
    80000ff6:	0be50513          	addi	a0,a0,190 # 800070b0 <etext+0xb0>
    80000ffa:	82bff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000ffe:	020b0263          	beqz	s6,80001022 <walk+0x96>
    80001002:	b43ff0ef          	jal	80000b44 <kalloc>
    80001006:	84aa                	mv	s1,a0
    80001008:	d979                	beqz	a0,80000fde <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    8000100a:	6605                	lui	a2,0x1
    8000100c:	4581                	li	a1,0
    8000100e:	cebff0ef          	jal	80000cf8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001012:	00c4d793          	srli	a5,s1,0xc
    80001016:	07aa                	slli	a5,a5,0xa
    80001018:	0017e793          	ori	a5,a5,1
    8000101c:	00f93023          	sd	a5,0(s2)
    80001020:	b775                	j	80000fcc <walk+0x40>
        return 0;
    80001022:	4501                	li	a0,0
    80001024:	bf6d                	j	80000fde <walk+0x52>

0000000080001026 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001026:	57fd                	li	a5,-1
    80001028:	83e9                	srli	a5,a5,0x1a
    8000102a:	00b7f463          	bgeu	a5,a1,80001032 <walkaddr+0xc>
    return 0;
    8000102e:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001030:	8082                	ret
{
    80001032:	1141                	addi	sp,sp,-16
    80001034:	e406                	sd	ra,8(sp)
    80001036:	e022                	sd	s0,0(sp)
    80001038:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000103a:	4601                	li	a2,0
    8000103c:	f51ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    80001040:	c901                	beqz	a0,80001050 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    80001042:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001044:	0117f693          	andi	a3,a5,17
    80001048:	4745                	li	a4,17
    return 0;
    8000104a:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    8000104c:	00e68663          	beq	a3,a4,80001058 <walkaddr+0x32>
}
    80001050:	60a2                	ld	ra,8(sp)
    80001052:	6402                	ld	s0,0(sp)
    80001054:	0141                	addi	sp,sp,16
    80001056:	8082                	ret
  pa = PTE2PA(*pte);
    80001058:	83a9                	srli	a5,a5,0xa
    8000105a:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000105e:	bfcd                	j	80001050 <walkaddr+0x2a>

0000000080001060 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001060:	715d                	addi	sp,sp,-80
    80001062:	e486                	sd	ra,72(sp)
    80001064:	e0a2                	sd	s0,64(sp)
    80001066:	fc26                	sd	s1,56(sp)
    80001068:	f84a                	sd	s2,48(sp)
    8000106a:	f44e                	sd	s3,40(sp)
    8000106c:	f052                	sd	s4,32(sp)
    8000106e:	ec56                	sd	s5,24(sp)
    80001070:	e85a                	sd	s6,16(sp)
    80001072:	e45e                	sd	s7,8(sp)
    80001074:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001076:	03459793          	slli	a5,a1,0x34
    8000107a:	eba1                	bnez	a5,800010ca <mappages+0x6a>
    8000107c:	8a2a                	mv	s4,a0
    8000107e:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001080:	03461793          	slli	a5,a2,0x34
    80001084:	eba9                	bnez	a5,800010d6 <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    80001086:	ce31                	beqz	a2,800010e2 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001088:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    8000108c:	80060613          	addi	a2,a2,-2048
    80001090:	00b60933          	add	s2,a2,a1
  a = va;
    80001094:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    80001096:	4b05                	li	s6,1
    80001098:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000109c:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    8000109e:	865a                	mv	a2,s6
    800010a0:	85a6                	mv	a1,s1
    800010a2:	8552                	mv	a0,s4
    800010a4:	ee9ff0ef          	jal	80000f8c <walk>
    800010a8:	c929                	beqz	a0,800010fa <mappages+0x9a>
    if(*pte & PTE_V)
    800010aa:	611c                	ld	a5,0(a0)
    800010ac:	8b85                	andi	a5,a5,1
    800010ae:	e3a1                	bnez	a5,800010ee <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010b0:	013487b3          	add	a5,s1,s3
    800010b4:	83b1                	srli	a5,a5,0xc
    800010b6:	07aa                	slli	a5,a5,0xa
    800010b8:	0157e7b3          	or	a5,a5,s5
    800010bc:	0017e793          	ori	a5,a5,1
    800010c0:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010c2:	05248863          	beq	s1,s2,80001112 <mappages+0xb2>
    a += PGSIZE;
    800010c6:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c8:	bfd9                	j	8000109e <mappages+0x3e>
    panic("mappages: va not aligned");
    800010ca:	00006517          	auipc	a0,0x6
    800010ce:	fee50513          	addi	a0,a0,-18 # 800070b8 <etext+0xb8>
    800010d2:	f52ff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    800010d6:	00006517          	auipc	a0,0x6
    800010da:	00250513          	addi	a0,a0,2 # 800070d8 <etext+0xd8>
    800010de:	f46ff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    800010e2:	00006517          	auipc	a0,0x6
    800010e6:	01650513          	addi	a0,a0,22 # 800070f8 <etext+0xf8>
    800010ea:	f3aff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    800010ee:	00006517          	auipc	a0,0x6
    800010f2:	01a50513          	addi	a0,a0,26 # 80007108 <etext+0x108>
    800010f6:	f2eff0ef          	jal	80000824 <panic>
      return -1;
    800010fa:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010fc:	60a6                	ld	ra,72(sp)
    800010fe:	6406                	ld	s0,64(sp)
    80001100:	74e2                	ld	s1,56(sp)
    80001102:	7942                	ld	s2,48(sp)
    80001104:	79a2                	ld	s3,40(sp)
    80001106:	7a02                	ld	s4,32(sp)
    80001108:	6ae2                	ld	s5,24(sp)
    8000110a:	6b42                	ld	s6,16(sp)
    8000110c:	6ba2                	ld	s7,8(sp)
    8000110e:	6161                	addi	sp,sp,80
    80001110:	8082                	ret
  return 0;
    80001112:	4501                	li	a0,0
    80001114:	b7e5                	j	800010fc <mappages+0x9c>

0000000080001116 <kvmmap>:
{
    80001116:	1141                	addi	sp,sp,-16
    80001118:	e406                	sd	ra,8(sp)
    8000111a:	e022                	sd	s0,0(sp)
    8000111c:	0800                	addi	s0,sp,16
    8000111e:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001120:	86b2                	mv	a3,a2
    80001122:	863e                	mv	a2,a5
    80001124:	f3dff0ef          	jal	80001060 <mappages>
    80001128:	e509                	bnez	a0,80001132 <kvmmap+0x1c>
}
    8000112a:	60a2                	ld	ra,8(sp)
    8000112c:	6402                	ld	s0,0(sp)
    8000112e:	0141                	addi	sp,sp,16
    80001130:	8082                	ret
    panic("kvmmap");
    80001132:	00006517          	auipc	a0,0x6
    80001136:	fe650513          	addi	a0,a0,-26 # 80007118 <etext+0x118>
    8000113a:	eeaff0ef          	jal	80000824 <panic>

000000008000113e <kvmmake>:
{
    8000113e:	1101                	addi	sp,sp,-32
    80001140:	ec06                	sd	ra,24(sp)
    80001142:	e822                	sd	s0,16(sp)
    80001144:	e426                	sd	s1,8(sp)
    80001146:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001148:	9fdff0ef          	jal	80000b44 <kalloc>
    8000114c:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000114e:	6605                	lui	a2,0x1
    80001150:	4581                	li	a1,0
    80001152:	ba7ff0ef          	jal	80000cf8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001156:	4719                	li	a4,6
    80001158:	6685                	lui	a3,0x1
    8000115a:	10000637          	lui	a2,0x10000
    8000115e:	85b2                	mv	a1,a2
    80001160:	8526                	mv	a0,s1
    80001162:	fb5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001166:	4719                	li	a4,6
    80001168:	6685                	lui	a3,0x1
    8000116a:	10001637          	lui	a2,0x10001
    8000116e:	85b2                	mv	a1,a2
    80001170:	8526                	mv	a0,s1
    80001172:	fa5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001176:	4719                	li	a4,6
    80001178:	040006b7          	lui	a3,0x4000
    8000117c:	0c000637          	lui	a2,0xc000
    80001180:	85b2                	mv	a1,a2
    80001182:	8526                	mv	a0,s1
    80001184:	f93ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001188:	4729                	li	a4,10
    8000118a:	80006697          	auipc	a3,0x80006
    8000118e:	e7668693          	addi	a3,a3,-394 # 7000 <_entry-0x7fff9000>
    80001192:	4605                	li	a2,1
    80001194:	067e                	slli	a2,a2,0x1f
    80001196:	85b2                	mv	a1,a2
    80001198:	8526                	mv	a0,s1
    8000119a:	f7dff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000119e:	4719                	li	a4,6
    800011a0:	00006697          	auipc	a3,0x6
    800011a4:	e6068693          	addi	a3,a3,-416 # 80007000 <etext>
    800011a8:	47c5                	li	a5,17
    800011aa:	07ee                	slli	a5,a5,0x1b
    800011ac:	40d786b3          	sub	a3,a5,a3
    800011b0:	00006617          	auipc	a2,0x6
    800011b4:	e5060613          	addi	a2,a2,-432 # 80007000 <etext>
    800011b8:	85b2                	mv	a1,a2
    800011ba:	8526                	mv	a0,s1
    800011bc:	f5bff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011c0:	4729                	li	a4,10
    800011c2:	6685                	lui	a3,0x1
    800011c4:	00005617          	auipc	a2,0x5
    800011c8:	e3c60613          	addi	a2,a2,-452 # 80006000 <_trampoline>
    800011cc:	040005b7          	lui	a1,0x4000
    800011d0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011d2:	05b2                	slli	a1,a1,0xc
    800011d4:	8526                	mv	a0,s1
    800011d6:	f41ff0ef          	jal	80001116 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011da:	8526                	mv	a0,s1
    800011dc:	5c4000ef          	jal	800017a0 <proc_mapstacks>
}
    800011e0:	8526                	mv	a0,s1
    800011e2:	60e2                	ld	ra,24(sp)
    800011e4:	6442                	ld	s0,16(sp)
    800011e6:	64a2                	ld	s1,8(sp)
    800011e8:	6105                	addi	sp,sp,32
    800011ea:	8082                	ret

00000000800011ec <kvminit>:
{
    800011ec:	1141                	addi	sp,sp,-16
    800011ee:	e406                	sd	ra,8(sp)
    800011f0:	e022                	sd	s0,0(sp)
    800011f2:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011f4:	f4bff0ef          	jal	8000113e <kvmmake>
    800011f8:	00006797          	auipc	a5,0x6
    800011fc:	66a7b823          	sd	a0,1648(a5) # 80007868 <kernel_pagetable>
}
    80001200:	60a2                	ld	ra,8(sp)
    80001202:	6402                	ld	s0,0(sp)
    80001204:	0141                	addi	sp,sp,16
    80001206:	8082                	ret

0000000080001208 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001208:	1101                	addi	sp,sp,-32
    8000120a:	ec06                	sd	ra,24(sp)
    8000120c:	e822                	sd	s0,16(sp)
    8000120e:	e426                	sd	s1,8(sp)
    80001210:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001212:	933ff0ef          	jal	80000b44 <kalloc>
    80001216:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001218:	c509                	beqz	a0,80001222 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000121a:	6605                	lui	a2,0x1
    8000121c:	4581                	li	a1,0
    8000121e:	adbff0ef          	jal	80000cf8 <memset>
  return pagetable;
}
    80001222:	8526                	mv	a0,s1
    80001224:	60e2                	ld	ra,24(sp)
    80001226:	6442                	ld	s0,16(sp)
    80001228:	64a2                	ld	s1,8(sp)
    8000122a:	6105                	addi	sp,sp,32
    8000122c:	8082                	ret

000000008000122e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000122e:	7139                	addi	sp,sp,-64
    80001230:	fc06                	sd	ra,56(sp)
    80001232:	f822                	sd	s0,48(sp)
    80001234:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001236:	03459793          	slli	a5,a1,0x34
    8000123a:	e38d                	bnez	a5,8000125c <uvmunmap+0x2e>
    8000123c:	f04a                	sd	s2,32(sp)
    8000123e:	ec4e                	sd	s3,24(sp)
    80001240:	e852                	sd	s4,16(sp)
    80001242:	e456                	sd	s5,8(sp)
    80001244:	e05a                	sd	s6,0(sp)
    80001246:	8a2a                	mv	s4,a0
    80001248:	892e                	mv	s2,a1
    8000124a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000124c:	0632                	slli	a2,a2,0xc
    8000124e:	00b609b3          	add	s3,a2,a1
    80001252:	6b05                	lui	s6,0x1
    80001254:	0535f963          	bgeu	a1,s3,800012a6 <uvmunmap+0x78>
    80001258:	f426                	sd	s1,40(sp)
    8000125a:	a015                	j	8000127e <uvmunmap+0x50>
    8000125c:	f426                	sd	s1,40(sp)
    8000125e:	f04a                	sd	s2,32(sp)
    80001260:	ec4e                	sd	s3,24(sp)
    80001262:	e852                	sd	s4,16(sp)
    80001264:	e456                	sd	s5,8(sp)
    80001266:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001268:	00006517          	auipc	a0,0x6
    8000126c:	eb850513          	addi	a0,a0,-328 # 80007120 <etext+0x120>
    80001270:	db4ff0ef          	jal	80000824 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001274:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001278:	995a                	add	s2,s2,s6
    8000127a:	03397563          	bgeu	s2,s3,800012a4 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000127e:	4601                	li	a2,0
    80001280:	85ca                	mv	a1,s2
    80001282:	8552                	mv	a0,s4
    80001284:	d09ff0ef          	jal	80000f8c <walk>
    80001288:	84aa                	mv	s1,a0
    8000128a:	d57d                	beqz	a0,80001278 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    8000128c:	611c                	ld	a5,0(a0)
    8000128e:	0017f713          	andi	a4,a5,1
    80001292:	d37d                	beqz	a4,80001278 <uvmunmap+0x4a>
    if(do_free){
    80001294:	fe0a80e3          	beqz	s5,80001274 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001298:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    8000129a:	00c79513          	slli	a0,a5,0xc
    8000129e:	fbeff0ef          	jal	80000a5c <kfree>
    800012a2:	bfc9                	j	80001274 <uvmunmap+0x46>
    800012a4:	74a2                	ld	s1,40(sp)
    800012a6:	7902                	ld	s2,32(sp)
    800012a8:	69e2                	ld	s3,24(sp)
    800012aa:	6a42                	ld	s4,16(sp)
    800012ac:	6aa2                	ld	s5,8(sp)
    800012ae:	6b02                	ld	s6,0(sp)
  }
}
    800012b0:	70e2                	ld	ra,56(sp)
    800012b2:	7442                	ld	s0,48(sp)
    800012b4:	6121                	addi	sp,sp,64
    800012b6:	8082                	ret

00000000800012b8 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012b8:	1101                	addi	sp,sp,-32
    800012ba:	ec06                	sd	ra,24(sp)
    800012bc:	e822                	sd	s0,16(sp)
    800012be:	e426                	sd	s1,8(sp)
    800012c0:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800012c2:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800012c4:	00b67d63          	bgeu	a2,a1,800012de <uvmdealloc+0x26>
    800012c8:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800012ca:	6785                	lui	a5,0x1
    800012cc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012ce:	00f60733          	add	a4,a2,a5
    800012d2:	76fd                	lui	a3,0xfffff
    800012d4:	8f75                	and	a4,a4,a3
    800012d6:	97ae                	add	a5,a5,a1
    800012d8:	8ff5                	and	a5,a5,a3
    800012da:	00f76863          	bltu	a4,a5,800012ea <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012de:	8526                	mv	a0,s1
    800012e0:	60e2                	ld	ra,24(sp)
    800012e2:	6442                	ld	s0,16(sp)
    800012e4:	64a2                	ld	s1,8(sp)
    800012e6:	6105                	addi	sp,sp,32
    800012e8:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012ea:	8f99                	sub	a5,a5,a4
    800012ec:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012ee:	4685                	li	a3,1
    800012f0:	0007861b          	sext.w	a2,a5
    800012f4:	85ba                	mv	a1,a4
    800012f6:	f39ff0ef          	jal	8000122e <uvmunmap>
    800012fa:	b7d5                	j	800012de <uvmdealloc+0x26>

00000000800012fc <uvmalloc>:
  if(newsz < oldsz)
    800012fc:	0ab66163          	bltu	a2,a1,8000139e <uvmalloc+0xa2>
{
    80001300:	715d                	addi	sp,sp,-80
    80001302:	e486                	sd	ra,72(sp)
    80001304:	e0a2                	sd	s0,64(sp)
    80001306:	f84a                	sd	s2,48(sp)
    80001308:	f052                	sd	s4,32(sp)
    8000130a:	ec56                	sd	s5,24(sp)
    8000130c:	e45e                	sd	s7,8(sp)
    8000130e:	0880                	addi	s0,sp,80
    80001310:	8aaa                	mv	s5,a0
    80001312:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001314:	6785                	lui	a5,0x1
    80001316:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001318:	95be                	add	a1,a1,a5
    8000131a:	77fd                	lui	a5,0xfffff
    8000131c:	00f5f933          	and	s2,a1,a5
    80001320:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001322:	08c97063          	bgeu	s2,a2,800013a2 <uvmalloc+0xa6>
    80001326:	fc26                	sd	s1,56(sp)
    80001328:	f44e                	sd	s3,40(sp)
    8000132a:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    8000132c:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000132e:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001332:	813ff0ef          	jal	80000b44 <kalloc>
    80001336:	84aa                	mv	s1,a0
    if(mem == 0){
    80001338:	c50d                	beqz	a0,80001362 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    8000133a:	864e                	mv	a2,s3
    8000133c:	4581                	li	a1,0
    8000133e:	9bbff0ef          	jal	80000cf8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001342:	875a                	mv	a4,s6
    80001344:	86a6                	mv	a3,s1
    80001346:	864e                	mv	a2,s3
    80001348:	85ca                	mv	a1,s2
    8000134a:	8556                	mv	a0,s5
    8000134c:	d15ff0ef          	jal	80001060 <mappages>
    80001350:	e915                	bnez	a0,80001384 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001352:	994e                	add	s2,s2,s3
    80001354:	fd496fe3          	bltu	s2,s4,80001332 <uvmalloc+0x36>
  return newsz;
    80001358:	8552                	mv	a0,s4
    8000135a:	74e2                	ld	s1,56(sp)
    8000135c:	79a2                	ld	s3,40(sp)
    8000135e:	6b42                	ld	s6,16(sp)
    80001360:	a811                	j	80001374 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001362:	865e                	mv	a2,s7
    80001364:	85ca                	mv	a1,s2
    80001366:	8556                	mv	a0,s5
    80001368:	f51ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    8000136c:	4501                	li	a0,0
    8000136e:	74e2                	ld	s1,56(sp)
    80001370:	79a2                	ld	s3,40(sp)
    80001372:	6b42                	ld	s6,16(sp)
}
    80001374:	60a6                	ld	ra,72(sp)
    80001376:	6406                	ld	s0,64(sp)
    80001378:	7942                	ld	s2,48(sp)
    8000137a:	7a02                	ld	s4,32(sp)
    8000137c:	6ae2                	ld	s5,24(sp)
    8000137e:	6ba2                	ld	s7,8(sp)
    80001380:	6161                	addi	sp,sp,80
    80001382:	8082                	ret
      kfree(mem);
    80001384:	8526                	mv	a0,s1
    80001386:	ed6ff0ef          	jal	80000a5c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000138a:	865e                	mv	a2,s7
    8000138c:	85ca                	mv	a1,s2
    8000138e:	8556                	mv	a0,s5
    80001390:	f29ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    80001394:	4501                	li	a0,0
    80001396:	74e2                	ld	s1,56(sp)
    80001398:	79a2                	ld	s3,40(sp)
    8000139a:	6b42                	ld	s6,16(sp)
    8000139c:	bfe1                	j	80001374 <uvmalloc+0x78>
    return oldsz;
    8000139e:	852e                	mv	a0,a1
}
    800013a0:	8082                	ret
  return newsz;
    800013a2:	8532                	mv	a0,a2
    800013a4:	bfc1                	j	80001374 <uvmalloc+0x78>

00000000800013a6 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013a6:	7179                	addi	sp,sp,-48
    800013a8:	f406                	sd	ra,40(sp)
    800013aa:	f022                	sd	s0,32(sp)
    800013ac:	ec26                	sd	s1,24(sp)
    800013ae:	e84a                	sd	s2,16(sp)
    800013b0:	e44e                	sd	s3,8(sp)
    800013b2:	1800                	addi	s0,sp,48
    800013b4:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013b6:	84aa                	mv	s1,a0
    800013b8:	6905                	lui	s2,0x1
    800013ba:	992a                	add	s2,s2,a0
    800013bc:	a811                	j	800013d0 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800013be:	00006517          	auipc	a0,0x6
    800013c2:	d7a50513          	addi	a0,a0,-646 # 80007138 <etext+0x138>
    800013c6:	c5eff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    800013ca:	04a1                	addi	s1,s1,8
    800013cc:	03248163          	beq	s1,s2,800013ee <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013d0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013d2:	0017f713          	andi	a4,a5,1
    800013d6:	db75                	beqz	a4,800013ca <freewalk+0x24>
    800013d8:	00e7f713          	andi	a4,a5,14
    800013dc:	f36d                	bnez	a4,800013be <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800013de:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013e0:	00c79513          	slli	a0,a5,0xc
    800013e4:	fc3ff0ef          	jal	800013a6 <freewalk>
      pagetable[i] = 0;
    800013e8:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013ec:	bff9                	j	800013ca <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800013ee:	854e                	mv	a0,s3
    800013f0:	e6cff0ef          	jal	80000a5c <kfree>
}
    800013f4:	70a2                	ld	ra,40(sp)
    800013f6:	7402                	ld	s0,32(sp)
    800013f8:	64e2                	ld	s1,24(sp)
    800013fa:	6942                	ld	s2,16(sp)
    800013fc:	69a2                	ld	s3,8(sp)
    800013fe:	6145                	addi	sp,sp,48
    80001400:	8082                	ret

0000000080001402 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001402:	1101                	addi	sp,sp,-32
    80001404:	ec06                	sd	ra,24(sp)
    80001406:	e822                	sd	s0,16(sp)
    80001408:	e426                	sd	s1,8(sp)
    8000140a:	1000                	addi	s0,sp,32
    8000140c:	84aa                	mv	s1,a0
  if(sz > 0)
    8000140e:	e989                	bnez	a1,80001420 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001410:	8526                	mv	a0,s1
    80001412:	f95ff0ef          	jal	800013a6 <freewalk>
}
    80001416:	60e2                	ld	ra,24(sp)
    80001418:	6442                	ld	s0,16(sp)
    8000141a:	64a2                	ld	s1,8(sp)
    8000141c:	6105                	addi	sp,sp,32
    8000141e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001420:	6785                	lui	a5,0x1
    80001422:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001424:	95be                	add	a1,a1,a5
    80001426:	4685                	li	a3,1
    80001428:	00c5d613          	srli	a2,a1,0xc
    8000142c:	4581                	li	a1,0
    8000142e:	e01ff0ef          	jal	8000122e <uvmunmap>
    80001432:	bff9                	j	80001410 <uvmfree+0xe>

0000000080001434 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001434:	ca59                	beqz	a2,800014ca <uvmcopy+0x96>
{
    80001436:	715d                	addi	sp,sp,-80
    80001438:	e486                	sd	ra,72(sp)
    8000143a:	e0a2                	sd	s0,64(sp)
    8000143c:	fc26                	sd	s1,56(sp)
    8000143e:	f84a                	sd	s2,48(sp)
    80001440:	f44e                	sd	s3,40(sp)
    80001442:	f052                	sd	s4,32(sp)
    80001444:	ec56                	sd	s5,24(sp)
    80001446:	e85a                	sd	s6,16(sp)
    80001448:	e45e                	sd	s7,8(sp)
    8000144a:	0880                	addi	s0,sp,80
    8000144c:	8b2a                	mv	s6,a0
    8000144e:	8bae                	mv	s7,a1
    80001450:	8ab2                	mv	s5,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001452:	4481                	li	s1,0
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001454:	6a05                	lui	s4,0x1
    80001456:	a021                	j	8000145e <uvmcopy+0x2a>
  for(i = 0; i < sz; i += PGSIZE){
    80001458:	94d2                	add	s1,s1,s4
    8000145a:	0554fc63          	bgeu	s1,s5,800014b2 <uvmcopy+0x7e>
    if((pte = walk(old, i, 0)) == 0)
    8000145e:	4601                	li	a2,0
    80001460:	85a6                	mv	a1,s1
    80001462:	855a                	mv	a0,s6
    80001464:	b29ff0ef          	jal	80000f8c <walk>
    80001468:	d965                	beqz	a0,80001458 <uvmcopy+0x24>
    if((*pte & PTE_V) == 0)
    8000146a:	00053983          	ld	s3,0(a0)
    8000146e:	0019f793          	andi	a5,s3,1
    80001472:	d3fd                	beqz	a5,80001458 <uvmcopy+0x24>
    if((mem = kalloc()) == 0)
    80001474:	ed0ff0ef          	jal	80000b44 <kalloc>
    80001478:	892a                	mv	s2,a0
    8000147a:	c11d                	beqz	a0,800014a0 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    8000147c:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80001480:	8652                	mv	a2,s4
    80001482:	05b2                	slli	a1,a1,0xc
    80001484:	8d5ff0ef          	jal	80000d58 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001488:	3ff9f713          	andi	a4,s3,1023
    8000148c:	86ca                	mv	a3,s2
    8000148e:	8652                	mv	a2,s4
    80001490:	85a6                	mv	a1,s1
    80001492:	855e                	mv	a0,s7
    80001494:	bcdff0ef          	jal	80001060 <mappages>
    80001498:	d161                	beqz	a0,80001458 <uvmcopy+0x24>
      kfree(mem);
    8000149a:	854a                	mv	a0,s2
    8000149c:	dc0ff0ef          	jal	80000a5c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014a0:	4685                	li	a3,1
    800014a2:	00c4d613          	srli	a2,s1,0xc
    800014a6:	4581                	li	a1,0
    800014a8:	855e                	mv	a0,s7
    800014aa:	d85ff0ef          	jal	8000122e <uvmunmap>
  return -1;
    800014ae:	557d                	li	a0,-1
    800014b0:	a011                	j	800014b4 <uvmcopy+0x80>
  return 0;
    800014b2:	4501                	li	a0,0
}
    800014b4:	60a6                	ld	ra,72(sp)
    800014b6:	6406                	ld	s0,64(sp)
    800014b8:	74e2                	ld	s1,56(sp)
    800014ba:	7942                	ld	s2,48(sp)
    800014bc:	79a2                	ld	s3,40(sp)
    800014be:	7a02                	ld	s4,32(sp)
    800014c0:	6ae2                	ld	s5,24(sp)
    800014c2:	6b42                	ld	s6,16(sp)
    800014c4:	6ba2                	ld	s7,8(sp)
    800014c6:	6161                	addi	sp,sp,80
    800014c8:	8082                	ret
  return 0;
    800014ca:	4501                	li	a0,0
}
    800014cc:	8082                	ret

00000000800014ce <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014ce:	1141                	addi	sp,sp,-16
    800014d0:	e406                	sd	ra,8(sp)
    800014d2:	e022                	sd	s0,0(sp)
    800014d4:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014d6:	4601                	li	a2,0
    800014d8:	ab5ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    800014dc:	c901                	beqz	a0,800014ec <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014de:	611c                	ld	a5,0(a0)
    800014e0:	9bbd                	andi	a5,a5,-17
    800014e2:	e11c                	sd	a5,0(a0)
}
    800014e4:	60a2                	ld	ra,8(sp)
    800014e6:	6402                	ld	s0,0(sp)
    800014e8:	0141                	addi	sp,sp,16
    800014ea:	8082                	ret
    panic("uvmclear");
    800014ec:	00006517          	auipc	a0,0x6
    800014f0:	c5c50513          	addi	a0,a0,-932 # 80007148 <etext+0x148>
    800014f4:	b30ff0ef          	jal	80000824 <panic>

00000000800014f8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800014f8:	cac5                	beqz	a3,800015a8 <copyinstr+0xb0>
{
    800014fa:	715d                	addi	sp,sp,-80
    800014fc:	e486                	sd	ra,72(sp)
    800014fe:	e0a2                	sd	s0,64(sp)
    80001500:	fc26                	sd	s1,56(sp)
    80001502:	f84a                	sd	s2,48(sp)
    80001504:	f44e                	sd	s3,40(sp)
    80001506:	f052                	sd	s4,32(sp)
    80001508:	ec56                	sd	s5,24(sp)
    8000150a:	e85a                	sd	s6,16(sp)
    8000150c:	e45e                	sd	s7,8(sp)
    8000150e:	0880                	addi	s0,sp,80
    80001510:	8aaa                	mv	s5,a0
    80001512:	84ae                	mv	s1,a1
    80001514:	8bb2                	mv	s7,a2
    80001516:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001518:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000151a:	6a05                	lui	s4,0x1
    8000151c:	a82d                	j	80001556 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000151e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001522:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001524:	0017c793          	xori	a5,a5,1
    80001528:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000152c:	60a6                	ld	ra,72(sp)
    8000152e:	6406                	ld	s0,64(sp)
    80001530:	74e2                	ld	s1,56(sp)
    80001532:	7942                	ld	s2,48(sp)
    80001534:	79a2                	ld	s3,40(sp)
    80001536:	7a02                	ld	s4,32(sp)
    80001538:	6ae2                	ld	s5,24(sp)
    8000153a:	6b42                	ld	s6,16(sp)
    8000153c:	6ba2                	ld	s7,8(sp)
    8000153e:	6161                	addi	sp,sp,80
    80001540:	8082                	ret
    80001542:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001546:	9726                	add	a4,a4,s1
      --max;
    80001548:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000154c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001550:	04e58463          	beq	a1,a4,80001598 <copyinstr+0xa0>
{
    80001554:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001556:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000155a:	85ca                	mv	a1,s2
    8000155c:	8556                	mv	a0,s5
    8000155e:	ac9ff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0)
    80001562:	cd0d                	beqz	a0,8000159c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001564:	417906b3          	sub	a3,s2,s7
    80001568:	96d2                	add	a3,a3,s4
    if(n > max)
    8000156a:	00d9f363          	bgeu	s3,a3,80001570 <copyinstr+0x78>
    8000156e:	86ce                	mv	a3,s3
    while(n > 0){
    80001570:	ca85                	beqz	a3,800015a0 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001572:	01750633          	add	a2,a0,s7
    80001576:	41260633          	sub	a2,a2,s2
    8000157a:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000157c:	8e05                	sub	a2,a2,s1
    while(n > 0){
    8000157e:	96a6                	add	a3,a3,s1
    80001580:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001582:	00f60733          	add	a4,a2,a5
    80001586:	00074703          	lbu	a4,0(a4)
    8000158a:	db51                	beqz	a4,8000151e <copyinstr+0x26>
        *dst = *p;
    8000158c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001590:	0785                	addi	a5,a5,1
    while(n > 0){
    80001592:	fed797e3          	bne	a5,a3,80001580 <copyinstr+0x88>
    80001596:	b775                	j	80001542 <copyinstr+0x4a>
    80001598:	4781                	li	a5,0
    8000159a:	b769                	j	80001524 <copyinstr+0x2c>
      return -1;
    8000159c:	557d                	li	a0,-1
    8000159e:	b779                	j	8000152c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    800015a0:	6b85                	lui	s7,0x1
    800015a2:	9bca                	add	s7,s7,s2
    800015a4:	87a6                	mv	a5,s1
    800015a6:	b77d                	j	80001554 <copyinstr+0x5c>
  int got_null = 0;
    800015a8:	4781                	li	a5,0
  if(got_null){
    800015aa:	0017c793          	xori	a5,a5,1
    800015ae:	40f0053b          	negw	a0,a5
}
    800015b2:	8082                	ret

00000000800015b4 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800015b4:	1141                	addi	sp,sp,-16
    800015b6:	e406                	sd	ra,8(sp)
    800015b8:	e022                	sd	s0,0(sp)
    800015ba:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800015bc:	4601                	li	a2,0
    800015be:	9cfff0ef          	jal	80000f8c <walk>
  if (pte == 0) {
    800015c2:	c119                	beqz	a0,800015c8 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V){
    800015c4:	6108                	ld	a0,0(a0)
    800015c6:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800015c8:	60a2                	ld	ra,8(sp)
    800015ca:	6402                	ld	s0,0(sp)
    800015cc:	0141                	addi	sp,sp,16
    800015ce:	8082                	ret

00000000800015d0 <vmfault>:
{
    800015d0:	7179                	addi	sp,sp,-48
    800015d2:	f406                	sd	ra,40(sp)
    800015d4:	f022                	sd	s0,32(sp)
    800015d6:	e84a                	sd	s2,16(sp)
    800015d8:	e44e                	sd	s3,8(sp)
    800015da:	1800                	addi	s0,sp,48
    800015dc:	89aa                	mv	s3,a0
    800015de:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800015e0:	34e000ef          	jal	8000192e <myproc>
  if (va >= p->sz)
    800015e4:	693c                	ld	a5,80(a0)
    800015e6:	00f96a63          	bltu	s2,a5,800015fa <vmfault+0x2a>
    return 0;
    800015ea:	4981                	li	s3,0
}
    800015ec:	854e                	mv	a0,s3
    800015ee:	70a2                	ld	ra,40(sp)
    800015f0:	7402                	ld	s0,32(sp)
    800015f2:	6942                	ld	s2,16(sp)
    800015f4:	69a2                	ld	s3,8(sp)
    800015f6:	6145                	addi	sp,sp,48
    800015f8:	8082                	ret
    800015fa:	ec26                	sd	s1,24(sp)
    800015fc:	e052                	sd	s4,0(sp)
    800015fe:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    80001600:	77fd                	lui	a5,0xfffff
    80001602:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    80001606:	85d2                	mv	a1,s4
    80001608:	854e                	mv	a0,s3
    8000160a:	fabff0ef          	jal	800015b4 <ismapped>
    return 0;
    8000160e:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001610:	c501                	beqz	a0,80001618 <vmfault+0x48>
    80001612:	64e2                	ld	s1,24(sp)
    80001614:	6a02                	ld	s4,0(sp)
    80001616:	bfd9                	j	800015ec <vmfault+0x1c>
  mem = (uint64) kalloc();
    80001618:	d2cff0ef          	jal	80000b44 <kalloc>
    8000161c:	892a                	mv	s2,a0
  if(mem == 0)
    8000161e:	c905                	beqz	a0,8000164e <vmfault+0x7e>
  mem = (uint64) kalloc();
    80001620:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    80001622:	6605                	lui	a2,0x1
    80001624:	4581                	li	a1,0
    80001626:	ed2ff0ef          	jal	80000cf8 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    8000162a:	4759                	li	a4,22
    8000162c:	86ca                	mv	a3,s2
    8000162e:	6605                	lui	a2,0x1
    80001630:	85d2                	mv	a1,s4
    80001632:	6ca8                	ld	a0,88(s1)
    80001634:	a2dff0ef          	jal	80001060 <mappages>
    80001638:	e501                	bnez	a0,80001640 <vmfault+0x70>
    8000163a:	64e2                	ld	s1,24(sp)
    8000163c:	6a02                	ld	s4,0(sp)
    8000163e:	b77d                	j	800015ec <vmfault+0x1c>
    kfree((void *)mem);
    80001640:	854a                	mv	a0,s2
    80001642:	c1aff0ef          	jal	80000a5c <kfree>
    return 0;
    80001646:	4981                	li	s3,0
    80001648:	64e2                	ld	s1,24(sp)
    8000164a:	6a02                	ld	s4,0(sp)
    8000164c:	b745                	j	800015ec <vmfault+0x1c>
    8000164e:	64e2                	ld	s1,24(sp)
    80001650:	6a02                	ld	s4,0(sp)
    80001652:	bf69                	j	800015ec <vmfault+0x1c>

0000000080001654 <copyout>:
  while(len > 0){
    80001654:	cad1                	beqz	a3,800016e8 <copyout+0x94>
{
    80001656:	711d                	addi	sp,sp,-96
    80001658:	ec86                	sd	ra,88(sp)
    8000165a:	e8a2                	sd	s0,80(sp)
    8000165c:	e4a6                	sd	s1,72(sp)
    8000165e:	e0ca                	sd	s2,64(sp)
    80001660:	fc4e                	sd	s3,56(sp)
    80001662:	f852                	sd	s4,48(sp)
    80001664:	f456                	sd	s5,40(sp)
    80001666:	f05a                	sd	s6,32(sp)
    80001668:	ec5e                	sd	s7,24(sp)
    8000166a:	e862                	sd	s8,16(sp)
    8000166c:	e466                	sd	s9,8(sp)
    8000166e:	e06a                	sd	s10,0(sp)
    80001670:	1080                	addi	s0,sp,96
    80001672:	8baa                	mv	s7,a0
    80001674:	8a2e                	mv	s4,a1
    80001676:	8b32                	mv	s6,a2
    80001678:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    8000167a:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    8000167c:	5cfd                	li	s9,-1
    8000167e:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001682:	6c05                	lui	s8,0x1
    80001684:	a005                	j	800016a4 <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001686:	409a0533          	sub	a0,s4,s1
    8000168a:	0009061b          	sext.w	a2,s2
    8000168e:	85da                	mv	a1,s6
    80001690:	954e                	add	a0,a0,s3
    80001692:	ec6ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001696:	412a8ab3          	sub	s5,s5,s2
    src += n;
    8000169a:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000169c:	01848a33          	add	s4,s1,s8
  while(len > 0){
    800016a0:	040a8263          	beqz	s5,800016e4 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    800016a4:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    800016a8:	049ce263          	bltu	s9,s1,800016ec <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    800016ac:	85a6                	mv	a1,s1
    800016ae:	855e                	mv	a0,s7
    800016b0:	977ff0ef          	jal	80001026 <walkaddr>
    800016b4:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    800016b6:	e901                	bnez	a0,800016c6 <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016b8:	4601                	li	a2,0
    800016ba:	85a6                	mv	a1,s1
    800016bc:	855e                	mv	a0,s7
    800016be:	f13ff0ef          	jal	800015d0 <vmfault>
    800016c2:	89aa                	mv	s3,a0
    800016c4:	c139                	beqz	a0,8000170a <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    800016c6:	4601                	li	a2,0
    800016c8:	85a6                	mv	a1,s1
    800016ca:	855e                	mv	a0,s7
    800016cc:	8c1ff0ef          	jal	80000f8c <walk>
    if((*pte & PTE_W) == 0)
    800016d0:	611c                	ld	a5,0(a0)
    800016d2:	8b91                	andi	a5,a5,4
    800016d4:	cf8d                	beqz	a5,8000170e <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    800016d6:	41448933          	sub	s2,s1,s4
    800016da:	9962                	add	s2,s2,s8
    if(n > len)
    800016dc:	fb2af5e3          	bgeu	s5,s2,80001686 <copyout+0x32>
    800016e0:	8956                	mv	s2,s5
    800016e2:	b755                	j	80001686 <copyout+0x32>
  return 0;
    800016e4:	4501                	li	a0,0
    800016e6:	a021                	j	800016ee <copyout+0x9a>
    800016e8:	4501                	li	a0,0
}
    800016ea:	8082                	ret
      return -1;
    800016ec:	557d                	li	a0,-1
}
    800016ee:	60e6                	ld	ra,88(sp)
    800016f0:	6446                	ld	s0,80(sp)
    800016f2:	64a6                	ld	s1,72(sp)
    800016f4:	6906                	ld	s2,64(sp)
    800016f6:	79e2                	ld	s3,56(sp)
    800016f8:	7a42                	ld	s4,48(sp)
    800016fa:	7aa2                	ld	s5,40(sp)
    800016fc:	7b02                	ld	s6,32(sp)
    800016fe:	6be2                	ld	s7,24(sp)
    80001700:	6c42                	ld	s8,16(sp)
    80001702:	6ca2                	ld	s9,8(sp)
    80001704:	6d02                	ld	s10,0(sp)
    80001706:	6125                	addi	sp,sp,96
    80001708:	8082                	ret
        return -1;
    8000170a:	557d                	li	a0,-1
    8000170c:	b7cd                	j	800016ee <copyout+0x9a>
      return -1;
    8000170e:	557d                	li	a0,-1
    80001710:	bff9                	j	800016ee <copyout+0x9a>

0000000080001712 <copyin>:
  while(len > 0){
    80001712:	c6c9                	beqz	a3,8000179c <copyin+0x8a>
{
    80001714:	715d                	addi	sp,sp,-80
    80001716:	e486                	sd	ra,72(sp)
    80001718:	e0a2                	sd	s0,64(sp)
    8000171a:	fc26                	sd	s1,56(sp)
    8000171c:	f84a                	sd	s2,48(sp)
    8000171e:	f44e                	sd	s3,40(sp)
    80001720:	f052                	sd	s4,32(sp)
    80001722:	ec56                	sd	s5,24(sp)
    80001724:	e85a                	sd	s6,16(sp)
    80001726:	e45e                	sd	s7,8(sp)
    80001728:	e062                	sd	s8,0(sp)
    8000172a:	0880                	addi	s0,sp,80
    8000172c:	8baa                	mv	s7,a0
    8000172e:	8aae                	mv	s5,a1
    80001730:	8932                	mv	s2,a2
    80001732:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001734:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001736:	6b05                	lui	s6,0x1
    80001738:	a035                	j	80001764 <copyin+0x52>
    8000173a:	412984b3          	sub	s1,s3,s2
    8000173e:	94da                	add	s1,s1,s6
    if(n > len)
    80001740:	009a7363          	bgeu	s4,s1,80001746 <copyin+0x34>
    80001744:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001746:	413905b3          	sub	a1,s2,s3
    8000174a:	0004861b          	sext.w	a2,s1
    8000174e:	95aa                	add	a1,a1,a0
    80001750:	8556                	mv	a0,s5
    80001752:	e06ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001756:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000175a:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000175c:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001760:	020a0163          	beqz	s4,80001782 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001764:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001768:	85ce                	mv	a1,s3
    8000176a:	855e                	mv	a0,s7
    8000176c:	8bbff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0) {
    80001770:	f569                	bnez	a0,8000173a <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001772:	4601                	li	a2,0
    80001774:	85ce                	mv	a1,s3
    80001776:	855e                	mv	a0,s7
    80001778:	e59ff0ef          	jal	800015d0 <vmfault>
    8000177c:	fd5d                	bnez	a0,8000173a <copyin+0x28>
        return -1;
    8000177e:	557d                	li	a0,-1
    80001780:	a011                	j	80001784 <copyin+0x72>
  return 0;
    80001782:	4501                	li	a0,0
}
    80001784:	60a6                	ld	ra,72(sp)
    80001786:	6406                	ld	s0,64(sp)
    80001788:	74e2                	ld	s1,56(sp)
    8000178a:	7942                	ld	s2,48(sp)
    8000178c:	79a2                	ld	s3,40(sp)
    8000178e:	7a02                	ld	s4,32(sp)
    80001790:	6ae2                	ld	s5,24(sp)
    80001792:	6b42                	ld	s6,16(sp)
    80001794:	6ba2                	ld	s7,8(sp)
    80001796:	6c02                	ld	s8,0(sp)
    80001798:	6161                	addi	sp,sp,80
    8000179a:	8082                	ret
  return 0;
    8000179c:	4501                	li	a0,0
}
    8000179e:	8082                	ret

00000000800017a0 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017a0:	715d                	addi	sp,sp,-80
    800017a2:	e486                	sd	ra,72(sp)
    800017a4:	e0a2                	sd	s0,64(sp)
    800017a6:	fc26                	sd	s1,56(sp)
    800017a8:	f84a                	sd	s2,48(sp)
    800017aa:	f44e                	sd	s3,40(sp)
    800017ac:	f052                	sd	s4,32(sp)
    800017ae:	ec56                	sd	s5,24(sp)
    800017b0:	e85a                	sd	s6,16(sp)
    800017b2:	e45e                	sd	s7,8(sp)
    800017b4:	e062                	sd	s8,0(sp)
    800017b6:	0880                	addi	s0,sp,80
    800017b8:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ba:	0000e497          	auipc	s1,0xe
    800017be:	5fe48493          	addi	s1,s1,1534 # 8000fdb8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017c2:	8c26                	mv	s8,s1
    800017c4:	ff4df937          	lui	s2,0xff4df
    800017c8:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdc25>
    800017cc:	0936                	slli	s2,s2,0xd
    800017ce:	6f590913          	addi	s2,s2,1781
    800017d2:	0936                	slli	s2,s2,0xd
    800017d4:	bd390913          	addi	s2,s2,-1069
    800017d8:	0932                	slli	s2,s2,0xc
    800017da:	7a790913          	addi	s2,s2,1959
    800017de:	040009b7          	lui	s3,0x4000
    800017e2:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017e4:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e6:	4b99                	li	s7,6
    800017e8:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ea:	00014a97          	auipc	s5,0x14
    800017ee:	1cea8a93          	addi	s5,s5,462 # 800159b8 <tickslock>
    char *pa = kalloc();
    800017f2:	b52ff0ef          	jal	80000b44 <kalloc>
    800017f6:	862a                	mv	a2,a0
    if(pa == 0)
    800017f8:	c121                	beqz	a0,80001838 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    800017fa:	418485b3          	sub	a1,s1,s8
    800017fe:	8591                	srai	a1,a1,0x4
    80001800:	032585b3          	mul	a1,a1,s2
    80001804:	05b6                	slli	a1,a1,0xd
    80001806:	6789                	lui	a5,0x2
    80001808:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000180a:	875e                	mv	a4,s7
    8000180c:	86da                	mv	a3,s6
    8000180e:	40b985b3          	sub	a1,s3,a1
    80001812:	8552                	mv	a0,s4
    80001814:	903ff0ef          	jal	80001116 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001818:	17048493          	addi	s1,s1,368
    8000181c:	fd549be3          	bne	s1,s5,800017f2 <proc_mapstacks+0x52>
  }
}
    80001820:	60a6                	ld	ra,72(sp)
    80001822:	6406                	ld	s0,64(sp)
    80001824:	74e2                	ld	s1,56(sp)
    80001826:	7942                	ld	s2,48(sp)
    80001828:	79a2                	ld	s3,40(sp)
    8000182a:	7a02                	ld	s4,32(sp)
    8000182c:	6ae2                	ld	s5,24(sp)
    8000182e:	6b42                	ld	s6,16(sp)
    80001830:	6ba2                	ld	s7,8(sp)
    80001832:	6c02                	ld	s8,0(sp)
    80001834:	6161                	addi	sp,sp,80
    80001836:	8082                	ret
      panic("kalloc");
    80001838:	00006517          	auipc	a0,0x6
    8000183c:	92050513          	addi	a0,a0,-1760 # 80007158 <etext+0x158>
    80001840:	fe5fe0ef          	jal	80000824 <panic>

0000000080001844 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001844:	7139                	addi	sp,sp,-64
    80001846:	fc06                	sd	ra,56(sp)
    80001848:	f822                	sd	s0,48(sp)
    8000184a:	f426                	sd	s1,40(sp)
    8000184c:	f04a                	sd	s2,32(sp)
    8000184e:	ec4e                	sd	s3,24(sp)
    80001850:	e852                	sd	s4,16(sp)
    80001852:	e456                	sd	s5,8(sp)
    80001854:	e05a                	sd	s6,0(sp)
    80001856:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001858:	00006597          	auipc	a1,0x6
    8000185c:	90858593          	addi	a1,a1,-1784 # 80007160 <etext+0x160>
    80001860:	0000e517          	auipc	a0,0xe
    80001864:	12850513          	addi	a0,a0,296 # 8000f988 <pid_lock>
    80001868:	b36ff0ef          	jal	80000b9e <initlock>
  initlock(&wait_lock, "wait_lock");
    8000186c:	00006597          	auipc	a1,0x6
    80001870:	8fc58593          	addi	a1,a1,-1796 # 80007168 <etext+0x168>
    80001874:	0000e517          	auipc	a0,0xe
    80001878:	12c50513          	addi	a0,a0,300 # 8000f9a0 <wait_lock>
    8000187c:	b22ff0ef          	jal	80000b9e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001880:	0000e497          	auipc	s1,0xe
    80001884:	53848493          	addi	s1,s1,1336 # 8000fdb8 <proc>
      initlock(&p->lock, "proc");
    80001888:	00006b17          	auipc	s6,0x6
    8000188c:	8f0b0b13          	addi	s6,s6,-1808 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001890:	8aa6                	mv	s5,s1
    80001892:	ff4df937          	lui	s2,0xff4df
    80001896:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdc25>
    8000189a:	0936                	slli	s2,s2,0xd
    8000189c:	6f590913          	addi	s2,s2,1781
    800018a0:	0936                	slli	s2,s2,0xd
    800018a2:	bd390913          	addi	s2,s2,-1069
    800018a6:	0932                	slli	s2,s2,0xc
    800018a8:	7a790913          	addi	s2,s2,1959
    800018ac:	040009b7          	lui	s3,0x4000
    800018b0:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018b2:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018b4:	00014a17          	auipc	s4,0x14
    800018b8:	104a0a13          	addi	s4,s4,260 # 800159b8 <tickslock>
      initlock(&p->lock, "proc");
    800018bc:	85da                	mv	a1,s6
    800018be:	8526                	mv	a0,s1
    800018c0:	adeff0ef          	jal	80000b9e <initlock>
      p->state = UNUSED;
    800018c4:	0204a223          	sw	zero,36(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018c8:	415487b3          	sub	a5,s1,s5
    800018cc:	8791                	srai	a5,a5,0x4
    800018ce:	032787b3          	mul	a5,a5,s2
    800018d2:	07b6                	slli	a5,a5,0xd
    800018d4:	6709                	lui	a4,0x2
    800018d6:	9fb9                	addw	a5,a5,a4
    800018d8:	40f987b3          	sub	a5,s3,a5
    800018dc:	e4bc                	sd	a5,72(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018de:	17048493          	addi	s1,s1,368
    800018e2:	fd449de3          	bne	s1,s4,800018bc <procinit+0x78>
  }
}
    800018e6:	70e2                	ld	ra,56(sp)
    800018e8:	7442                	ld	s0,48(sp)
    800018ea:	74a2                	ld	s1,40(sp)
    800018ec:	7902                	ld	s2,32(sp)
    800018ee:	69e2                	ld	s3,24(sp)
    800018f0:	6a42                	ld	s4,16(sp)
    800018f2:	6aa2                	ld	s5,8(sp)
    800018f4:	6b02                	ld	s6,0(sp)
    800018f6:	6121                	addi	sp,sp,64
    800018f8:	8082                	ret

00000000800018fa <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018fa:	1141                	addi	sp,sp,-16
    800018fc:	e406                	sd	ra,8(sp)
    800018fe:	e022                	sd	s0,0(sp)
    80001900:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001902:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001904:	2501                	sext.w	a0,a0
    80001906:	60a2                	ld	ra,8(sp)
    80001908:	6402                	ld	s0,0(sp)
    8000190a:	0141                	addi	sp,sp,16
    8000190c:	8082                	ret

000000008000190e <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    8000190e:	1141                	addi	sp,sp,-16
    80001910:	e406                	sd	ra,8(sp)
    80001912:	e022                	sd	s0,0(sp)
    80001914:	0800                	addi	s0,sp,16
    80001916:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001918:	2781                	sext.w	a5,a5
    8000191a:	079e                	slli	a5,a5,0x7
  return c;
}
    8000191c:	0000e517          	auipc	a0,0xe
    80001920:	09c50513          	addi	a0,a0,156 # 8000f9b8 <cpus>
    80001924:	953e                	add	a0,a0,a5
    80001926:	60a2                	ld	ra,8(sp)
    80001928:	6402                	ld	s0,0(sp)
    8000192a:	0141                	addi	sp,sp,16
    8000192c:	8082                	ret

000000008000192e <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    8000192e:	1101                	addi	sp,sp,-32
    80001930:	ec06                	sd	ra,24(sp)
    80001932:	e822                	sd	s0,16(sp)
    80001934:	e426                	sd	s1,8(sp)
    80001936:	1000                	addi	s0,sp,32
  push_off();
    80001938:	aacff0ef          	jal	80000be4 <push_off>
    8000193c:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    8000193e:	2781                	sext.w	a5,a5
    80001940:	079e                	slli	a5,a5,0x7
    80001942:	0000e717          	auipc	a4,0xe
    80001946:	04670713          	addi	a4,a4,70 # 8000f988 <pid_lock>
    8000194a:	97ba                	add	a5,a5,a4
    8000194c:	7b9c                	ld	a5,48(a5)
    8000194e:	84be                	mv	s1,a5
  pop_off();
    80001950:	b1cff0ef          	jal	80000c6c <pop_off>
  return p;
}
    80001954:	8526                	mv	a0,s1
    80001956:	60e2                	ld	ra,24(sp)
    80001958:	6442                	ld	s0,16(sp)
    8000195a:	64a2                	ld	s1,8(sp)
    8000195c:	6105                	addi	sp,sp,32
    8000195e:	8082                	ret

0000000080001960 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001960:	7179                	addi	sp,sp,-48
    80001962:	f406                	sd	ra,40(sp)
    80001964:	f022                	sd	s0,32(sp)
    80001966:	ec26                	sd	s1,24(sp)
    80001968:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    8000196a:	fc5ff0ef          	jal	8000192e <myproc>
    8000196e:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001970:	b4cff0ef          	jal	80000cbc <release>

  if (first) {
    80001974:	00006797          	auipc	a5,0x6
    80001978:	ecc7a783          	lw	a5,-308(a5) # 80007840 <first.1>
    8000197c:	cf95                	beqz	a5,800019b8 <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000197e:	4505                	li	a0,1
    80001980:	5e3010ef          	jal	80003762 <fsinit>

    first = 0;
    80001984:	00006797          	auipc	a5,0x6
    80001988:	ea07ae23          	sw	zero,-324(a5) # 80007840 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000198c:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001990:	00005797          	auipc	a5,0x5
    80001994:	7f078793          	addi	a5,a5,2032 # 80007180 <etext+0x180>
    80001998:	fcf43823          	sd	a5,-48(s0)
    8000199c:	fc043c23          	sd	zero,-40(s0)
    800019a0:	fd040593          	addi	a1,s0,-48
    800019a4:	853e                	mv	a0,a5
    800019a6:	73b020ef          	jal	800048e0 <kexec>
    800019aa:	70bc                	ld	a5,96(s1)
    800019ac:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800019ae:	70bc                	ld	a5,96(s1)
    800019b0:	7bb8                	ld	a4,112(a5)
    800019b2:	57fd                	li	a5,-1
    800019b4:	02f70d63          	beq	a4,a5,800019ee <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800019b8:	4c9000ef          	jal	80002680 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019bc:	6ca8                	ld	a0,88(s1)
    800019be:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019c0:	04000737          	lui	a4,0x4000
    800019c4:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019c6:	0732                	slli	a4,a4,0xc
    800019c8:	00004797          	auipc	a5,0x4
    800019cc:	6d478793          	addi	a5,a5,1748 # 8000609c <userret>
    800019d0:	00004697          	auipc	a3,0x4
    800019d4:	63068693          	addi	a3,a3,1584 # 80006000 <_trampoline>
    800019d8:	8f95                	sub	a5,a5,a3
    800019da:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019dc:	577d                	li	a4,-1
    800019de:	177e                	slli	a4,a4,0x3f
    800019e0:	8d59                	or	a0,a0,a4
    800019e2:	9782                	jalr	a5
}
    800019e4:	70a2                	ld	ra,40(sp)
    800019e6:	7402                	ld	s0,32(sp)
    800019e8:	64e2                	ld	s1,24(sp)
    800019ea:	6145                	addi	sp,sp,48
    800019ec:	8082                	ret
      panic("exec");
    800019ee:	00005517          	auipc	a0,0x5
    800019f2:	79a50513          	addi	a0,a0,1946 # 80007188 <etext+0x188>
    800019f6:	e2ffe0ef          	jal	80000824 <panic>

00000000800019fa <allocpid>:
{
    800019fa:	1101                	addi	sp,sp,-32
    800019fc:	ec06                	sd	ra,24(sp)
    800019fe:	e822                	sd	s0,16(sp)
    80001a00:	e426                	sd	s1,8(sp)
    80001a02:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a04:	0000e517          	auipc	a0,0xe
    80001a08:	f8450513          	addi	a0,a0,-124 # 8000f988 <pid_lock>
    80001a0c:	a1cff0ef          	jal	80000c28 <acquire>
  pid = nextpid;
    80001a10:	00006797          	auipc	a5,0x6
    80001a14:	e3478793          	addi	a5,a5,-460 # 80007844 <nextpid>
    80001a18:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a1a:	0014871b          	addiw	a4,s1,1
    80001a1e:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a20:	0000e517          	auipc	a0,0xe
    80001a24:	f6850513          	addi	a0,a0,-152 # 8000f988 <pid_lock>
    80001a28:	a94ff0ef          	jal	80000cbc <release>
}
    80001a2c:	8526                	mv	a0,s1
    80001a2e:	60e2                	ld	ra,24(sp)
    80001a30:	6442                	ld	s0,16(sp)
    80001a32:	64a2                	ld	s1,8(sp)
    80001a34:	6105                	addi	sp,sp,32
    80001a36:	8082                	ret

0000000080001a38 <proc_pagetable>:
{
    80001a38:	1101                	addi	sp,sp,-32
    80001a3a:	ec06                	sd	ra,24(sp)
    80001a3c:	e822                	sd	s0,16(sp)
    80001a3e:	e426                	sd	s1,8(sp)
    80001a40:	e04a                	sd	s2,0(sp)
    80001a42:	1000                	addi	s0,sp,32
    80001a44:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a46:	fc2ff0ef          	jal	80001208 <uvmcreate>
    80001a4a:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a4c:	cd05                	beqz	a0,80001a84 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a4e:	4729                	li	a4,10
    80001a50:	00004697          	auipc	a3,0x4
    80001a54:	5b068693          	addi	a3,a3,1456 # 80006000 <_trampoline>
    80001a58:	6605                	lui	a2,0x1
    80001a5a:	040005b7          	lui	a1,0x4000
    80001a5e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a60:	05b2                	slli	a1,a1,0xc
    80001a62:	dfeff0ef          	jal	80001060 <mappages>
    80001a66:	02054663          	bltz	a0,80001a92 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a6a:	4719                	li	a4,6
    80001a6c:	06093683          	ld	a3,96(s2)
    80001a70:	6605                	lui	a2,0x1
    80001a72:	020005b7          	lui	a1,0x2000
    80001a76:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a78:	05b6                	slli	a1,a1,0xd
    80001a7a:	8526                	mv	a0,s1
    80001a7c:	de4ff0ef          	jal	80001060 <mappages>
    80001a80:	00054f63          	bltz	a0,80001a9e <proc_pagetable+0x66>
}
    80001a84:	8526                	mv	a0,s1
    80001a86:	60e2                	ld	ra,24(sp)
    80001a88:	6442                	ld	s0,16(sp)
    80001a8a:	64a2                	ld	s1,8(sp)
    80001a8c:	6902                	ld	s2,0(sp)
    80001a8e:	6105                	addi	sp,sp,32
    80001a90:	8082                	ret
    uvmfree(pagetable, 0);
    80001a92:	4581                	li	a1,0
    80001a94:	8526                	mv	a0,s1
    80001a96:	96dff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001a9a:	4481                	li	s1,0
    80001a9c:	b7e5                	j	80001a84 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a9e:	4681                	li	a3,0
    80001aa0:	4605                	li	a2,1
    80001aa2:	040005b7          	lui	a1,0x4000
    80001aa6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aa8:	05b2                	slli	a1,a1,0xc
    80001aaa:	8526                	mv	a0,s1
    80001aac:	f82ff0ef          	jal	8000122e <uvmunmap>
    uvmfree(pagetable, 0);
    80001ab0:	4581                	li	a1,0
    80001ab2:	8526                	mv	a0,s1
    80001ab4:	94fff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001ab8:	4481                	li	s1,0
    80001aba:	b7e9                	j	80001a84 <proc_pagetable+0x4c>

0000000080001abc <proc_freepagetable>:
{
    80001abc:	1101                	addi	sp,sp,-32
    80001abe:	ec06                	sd	ra,24(sp)
    80001ac0:	e822                	sd	s0,16(sp)
    80001ac2:	e426                	sd	s1,8(sp)
    80001ac4:	e04a                	sd	s2,0(sp)
    80001ac6:	1000                	addi	s0,sp,32
    80001ac8:	84aa                	mv	s1,a0
    80001aca:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001acc:	4681                	li	a3,0
    80001ace:	4605                	li	a2,1
    80001ad0:	040005b7          	lui	a1,0x4000
    80001ad4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ad6:	05b2                	slli	a1,a1,0xc
    80001ad8:	f56ff0ef          	jal	8000122e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001adc:	4681                	li	a3,0
    80001ade:	4605                	li	a2,1
    80001ae0:	020005b7          	lui	a1,0x2000
    80001ae4:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ae6:	05b6                	slli	a1,a1,0xd
    80001ae8:	8526                	mv	a0,s1
    80001aea:	f44ff0ef          	jal	8000122e <uvmunmap>
  uvmfree(pagetable, sz);
    80001aee:	85ca                	mv	a1,s2
    80001af0:	8526                	mv	a0,s1
    80001af2:	911ff0ef          	jal	80001402 <uvmfree>
}
    80001af6:	60e2                	ld	ra,24(sp)
    80001af8:	6442                	ld	s0,16(sp)
    80001afa:	64a2                	ld	s1,8(sp)
    80001afc:	6902                	ld	s2,0(sp)
    80001afe:	6105                	addi	sp,sp,32
    80001b00:	8082                	ret

0000000080001b02 <freeproc>:
{
    80001b02:	1101                	addi	sp,sp,-32
    80001b04:	ec06                	sd	ra,24(sp)
    80001b06:	e822                	sd	s0,16(sp)
    80001b08:	e426                	sd	s1,8(sp)
    80001b0a:	1000                	addi	s0,sp,32
    80001b0c:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001b0e:	7128                	ld	a0,96(a0)
    80001b10:	c119                	beqz	a0,80001b16 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001b12:	f4bfe0ef          	jal	80000a5c <kfree>
  p->trapframe = 0;
    80001b16:	0604b023          	sd	zero,96(s1)
  if(p->pagetable)
    80001b1a:	6ca8                	ld	a0,88(s1)
    80001b1c:	c501                	beqz	a0,80001b24 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b1e:	68ac                	ld	a1,80(s1)
    80001b20:	f9dff0ef          	jal	80001abc <proc_freepagetable>
  p->pagetable = 0;
    80001b24:	0404bc23          	sd	zero,88(s1)
  p->sz = 0;
    80001b28:	0404b823          	sd	zero,80(s1)
  p->pid = 0;
    80001b2c:	0204ac23          	sw	zero,56(s1)
  p->parent = 0;
    80001b30:	0404b023          	sd	zero,64(s1)
  p->name[0] = 0;
    80001b34:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    80001b38:	0204b423          	sd	zero,40(s1)
  p->killed = 0;
    80001b3c:	0204a823          	sw	zero,48(s1)
  p->xstate = 0;
    80001b40:	0204aa23          	sw	zero,52(s1)
  p->state = UNUSED;
    80001b44:	0204a223          	sw	zero,36(s1)
}
    80001b48:	60e2                	ld	ra,24(sp)
    80001b4a:	6442                	ld	s0,16(sp)
    80001b4c:	64a2                	ld	s1,8(sp)
    80001b4e:	6105                	addi	sp,sp,32
    80001b50:	8082                	ret

0000000080001b52 <allocproc>:
{
    80001b52:	1101                	addi	sp,sp,-32
    80001b54:	ec06                	sd	ra,24(sp)
    80001b56:	e822                	sd	s0,16(sp)
    80001b58:	e426                	sd	s1,8(sp)
    80001b5a:	e04a                	sd	s2,0(sp)
    80001b5c:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b5e:	0000e497          	auipc	s1,0xe
    80001b62:	25a48493          	addi	s1,s1,602 # 8000fdb8 <proc>
    80001b66:	00014917          	auipc	s2,0x14
    80001b6a:	e5290913          	addi	s2,s2,-430 # 800159b8 <tickslock>
    acquire(&p->lock);
    80001b6e:	8526                	mv	a0,s1
    80001b70:	8b8ff0ef          	jal	80000c28 <acquire>
    if(p->state == UNUSED) {
    80001b74:	50dc                	lw	a5,36(s1)
    80001b76:	cb91                	beqz	a5,80001b8a <allocproc+0x38>
      release(&p->lock);
    80001b78:	8526                	mv	a0,s1
    80001b7a:	942ff0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b7e:	17048493          	addi	s1,s1,368
    80001b82:	ff2496e3          	bne	s1,s2,80001b6e <allocproc+0x1c>
  return 0;
    80001b86:	4481                	li	s1,0
    80001b88:	a881                	j	80001bd8 <allocproc+0x86>
      p->runtime = 0;
    80001b8a:	0004ac23          	sw	zero,24(s1)
  p->pid = allocpid();
    80001b8e:	e6dff0ef          	jal	800019fa <allocpid>
    80001b92:	dc88                	sw	a0,56(s1)
  p->state = USED;
    80001b94:	4785                	li	a5,1
    80001b96:	d0dc                	sw	a5,36(s1)
  p->runtime = 0;
    80001b98:	0004ac23          	sw	zero,24(s1)
  p->pass = 0;
    80001b9c:	0204a023          	sw	zero,32(s1)
  p->stride = 1;
    80001ba0:	ccdc                	sw	a5,28(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001ba2:	fa3fe0ef          	jal	80000b44 <kalloc>
    80001ba6:	892a                	mv	s2,a0
    80001ba8:	f0a8                	sd	a0,96(s1)
    80001baa:	cd15                	beqz	a0,80001be6 <allocproc+0x94>
  p->pagetable = proc_pagetable(p);
    80001bac:	8526                	mv	a0,s1
    80001bae:	e8bff0ef          	jal	80001a38 <proc_pagetable>
    80001bb2:	892a                	mv	s2,a0
    80001bb4:	eca8                	sd	a0,88(s1)
  if(p->pagetable == 0){
    80001bb6:	c121                	beqz	a0,80001bf6 <allocproc+0xa4>
  memset(&p->context, 0, sizeof(p->context));
    80001bb8:	07000613          	li	a2,112
    80001bbc:	4581                	li	a1,0
    80001bbe:	06848513          	addi	a0,s1,104
    80001bc2:	936ff0ef          	jal	80000cf8 <memset>
  p->context.ra = (uint64)forkret;
    80001bc6:	00000797          	auipc	a5,0x0
    80001bca:	d9a78793          	addi	a5,a5,-614 # 80001960 <forkret>
    80001bce:	f4bc                	sd	a5,104(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001bd0:	64bc                	ld	a5,72(s1)
    80001bd2:	6705                	lui	a4,0x1
    80001bd4:	97ba                	add	a5,a5,a4
    80001bd6:	f8bc                	sd	a5,112(s1)
}
    80001bd8:	8526                	mv	a0,s1
    80001bda:	60e2                	ld	ra,24(sp)
    80001bdc:	6442                	ld	s0,16(sp)
    80001bde:	64a2                	ld	s1,8(sp)
    80001be0:	6902                	ld	s2,0(sp)
    80001be2:	6105                	addi	sp,sp,32
    80001be4:	8082                	ret
    freeproc(p);
    80001be6:	8526                	mv	a0,s1
    80001be8:	f1bff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001bec:	8526                	mv	a0,s1
    80001bee:	8ceff0ef          	jal	80000cbc <release>
    return 0;
    80001bf2:	84ca                	mv	s1,s2
    80001bf4:	b7d5                	j	80001bd8 <allocproc+0x86>
    freeproc(p);
    80001bf6:	8526                	mv	a0,s1
    80001bf8:	f0bff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001bfc:	8526                	mv	a0,s1
    80001bfe:	8beff0ef          	jal	80000cbc <release>
    return 0;
    80001c02:	84ca                	mv	s1,s2
    80001c04:	bfd1                	j	80001bd8 <allocproc+0x86>

0000000080001c06 <userinit>:
{
    80001c06:	1101                	addi	sp,sp,-32
    80001c08:	ec06                	sd	ra,24(sp)
    80001c0a:	e822                	sd	s0,16(sp)
    80001c0c:	e426                	sd	s1,8(sp)
    80001c0e:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c10:	f43ff0ef          	jal	80001b52 <allocproc>
    80001c14:	84aa                	mv	s1,a0
  initproc = p;
    80001c16:	00006797          	auipc	a5,0x6
    80001c1a:	c6a7b123          	sd	a0,-926(a5) # 80007878 <initproc>
  p->cwd = namei("/");
    80001c1e:	00005517          	auipc	a0,0x5
    80001c22:	57250513          	addi	a0,a0,1394 # 80007190 <etext+0x190>
    80001c26:	076020ef          	jal	80003c9c <namei>
    80001c2a:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    80001c2e:	478d                	li	a5,3
    80001c30:	d0dc                	sw	a5,36(s1)
  release(&p->lock);
    80001c32:	8526                	mv	a0,s1
    80001c34:	888ff0ef          	jal	80000cbc <release>
}
    80001c38:	60e2                	ld	ra,24(sp)
    80001c3a:	6442                	ld	s0,16(sp)
    80001c3c:	64a2                	ld	s1,8(sp)
    80001c3e:	6105                	addi	sp,sp,32
    80001c40:	8082                	ret

0000000080001c42 <growproc>:
{
    80001c42:	1101                	addi	sp,sp,-32
    80001c44:	ec06                	sd	ra,24(sp)
    80001c46:	e822                	sd	s0,16(sp)
    80001c48:	e426                	sd	s1,8(sp)
    80001c4a:	e04a                	sd	s2,0(sp)
    80001c4c:	1000                	addi	s0,sp,32
    80001c4e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c50:	cdfff0ef          	jal	8000192e <myproc>
    80001c54:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c56:	692c                	ld	a1,80(a0)
  if(n > 0){
    80001c58:	01204c63          	bgtz	s2,80001c70 <growproc+0x2e>
  } else if(n < 0){
    80001c5c:	02094463          	bltz	s2,80001c84 <growproc+0x42>
  p->sz = sz;
    80001c60:	e8ac                	sd	a1,80(s1)
  return 0;
    80001c62:	4501                	li	a0,0
}
    80001c64:	60e2                	ld	ra,24(sp)
    80001c66:	6442                	ld	s0,16(sp)
    80001c68:	64a2                	ld	s1,8(sp)
    80001c6a:	6902                	ld	s2,0(sp)
    80001c6c:	6105                	addi	sp,sp,32
    80001c6e:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c70:	4691                	li	a3,4
    80001c72:	00b90633          	add	a2,s2,a1
    80001c76:	6d28                	ld	a0,88(a0)
    80001c78:	e84ff0ef          	jal	800012fc <uvmalloc>
    80001c7c:	85aa                	mv	a1,a0
    80001c7e:	f16d                	bnez	a0,80001c60 <growproc+0x1e>
      return -1;
    80001c80:	557d                	li	a0,-1
    80001c82:	b7cd                	j	80001c64 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c84:	00b90633          	add	a2,s2,a1
    80001c88:	6d28                	ld	a0,88(a0)
    80001c8a:	e2eff0ef          	jal	800012b8 <uvmdealloc>
    80001c8e:	85aa                	mv	a1,a0
    80001c90:	bfc1                	j	80001c60 <growproc+0x1e>

0000000080001c92 <kfork>:
{
    80001c92:	7139                	addi	sp,sp,-64
    80001c94:	fc06                	sd	ra,56(sp)
    80001c96:	f822                	sd	s0,48(sp)
    80001c98:	f426                	sd	s1,40(sp)
    80001c9a:	e456                	sd	s5,8(sp)
    80001c9c:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c9e:	c91ff0ef          	jal	8000192e <myproc>
    80001ca2:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001ca4:	eafff0ef          	jal	80001b52 <allocproc>
    80001ca8:	0e050a63          	beqz	a0,80001d9c <kfork+0x10a>
    80001cac:	e852                	sd	s4,16(sp)
    80001cae:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001cb0:	050ab603          	ld	a2,80(s5)
    80001cb4:	6d2c                	ld	a1,88(a0)
    80001cb6:	058ab503          	ld	a0,88(s5)
    80001cba:	f7aff0ef          	jal	80001434 <uvmcopy>
    80001cbe:	04054863          	bltz	a0,80001d0e <kfork+0x7c>
    80001cc2:	f04a                	sd	s2,32(sp)
    80001cc4:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001cc6:	050ab783          	ld	a5,80(s5)
    80001cca:	04fa3823          	sd	a5,80(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cce:	060ab683          	ld	a3,96(s5)
    80001cd2:	87b6                	mv	a5,a3
    80001cd4:	060a3703          	ld	a4,96(s4)
    80001cd8:	12068693          	addi	a3,a3,288
    80001cdc:	6388                	ld	a0,0(a5)
    80001cde:	678c                	ld	a1,8(a5)
    80001ce0:	6b90                	ld	a2,16(a5)
    80001ce2:	e308                	sd	a0,0(a4)
    80001ce4:	e70c                	sd	a1,8(a4)
    80001ce6:	eb10                	sd	a2,16(a4)
    80001ce8:	6f90                	ld	a2,24(a5)
    80001cea:	ef10                	sd	a2,24(a4)
    80001cec:	02078793          	addi	a5,a5,32
    80001cf0:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001cf4:	fed794e3          	bne	a5,a3,80001cdc <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001cf8:	060a3783          	ld	a5,96(s4)
    80001cfc:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001d00:	0d8a8493          	addi	s1,s5,216
    80001d04:	0d8a0913          	addi	s2,s4,216
    80001d08:	158a8993          	addi	s3,s5,344
    80001d0c:	a831                	j	80001d28 <kfork+0x96>
    freeproc(np);
    80001d0e:	8552                	mv	a0,s4
    80001d10:	df3ff0ef          	jal	80001b02 <freeproc>
    release(&np->lock);
    80001d14:	8552                	mv	a0,s4
    80001d16:	fa7fe0ef          	jal	80000cbc <release>
    return -1;
    80001d1a:	54fd                	li	s1,-1
    80001d1c:	6a42                	ld	s4,16(sp)
    80001d1e:	a885                	j	80001d8e <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001d20:	04a1                	addi	s1,s1,8
    80001d22:	0921                	addi	s2,s2,8
    80001d24:	01348963          	beq	s1,s3,80001d36 <kfork+0xa4>
    if(p->ofile[i])
    80001d28:	6088                	ld	a0,0(s1)
    80001d2a:	d97d                	beqz	a0,80001d20 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d2c:	52c020ef          	jal	80004258 <filedup>
    80001d30:	00a93023          	sd	a0,0(s2)
    80001d34:	b7f5                	j	80001d20 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001d36:	158ab503          	ld	a0,344(s5)
    80001d3a:	6fe010ef          	jal	80003438 <idup>
    80001d3e:	14aa3c23          	sd	a0,344(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d42:	4641                	li	a2,16
    80001d44:	160a8593          	addi	a1,s5,352
    80001d48:	160a0513          	addi	a0,s4,352
    80001d4c:	900ff0ef          	jal	80000e4c <safestrcpy>
  pid = np->pid;
    80001d50:	038a2483          	lw	s1,56(s4)
  release(&np->lock);
    80001d54:	8552                	mv	a0,s4
    80001d56:	f67fe0ef          	jal	80000cbc <release>
  acquire(&wait_lock);
    80001d5a:	0000e517          	auipc	a0,0xe
    80001d5e:	c4650513          	addi	a0,a0,-954 # 8000f9a0 <wait_lock>
    80001d62:	ec7fe0ef          	jal	80000c28 <acquire>
  np->parent = p;
    80001d66:	055a3023          	sd	s5,64(s4)
  release(&wait_lock);
    80001d6a:	0000e517          	auipc	a0,0xe
    80001d6e:	c3650513          	addi	a0,a0,-970 # 8000f9a0 <wait_lock>
    80001d72:	f4bfe0ef          	jal	80000cbc <release>
  acquire(&np->lock);
    80001d76:	8552                	mv	a0,s4
    80001d78:	eb1fe0ef          	jal	80000c28 <acquire>
  np->state = RUNNABLE;
    80001d7c:	478d                	li	a5,3
    80001d7e:	02fa2223          	sw	a5,36(s4)
  release(&np->lock);
    80001d82:	8552                	mv	a0,s4
    80001d84:	f39fe0ef          	jal	80000cbc <release>
  return pid;
    80001d88:	7902                	ld	s2,32(sp)
    80001d8a:	69e2                	ld	s3,24(sp)
    80001d8c:	6a42                	ld	s4,16(sp)
}
    80001d8e:	8526                	mv	a0,s1
    80001d90:	70e2                	ld	ra,56(sp)
    80001d92:	7442                	ld	s0,48(sp)
    80001d94:	74a2                	ld	s1,40(sp)
    80001d96:	6aa2                	ld	s5,8(sp)
    80001d98:	6121                	addi	sp,sp,64
    80001d9a:	8082                	ret
    return -1;
    80001d9c:	54fd                	li	s1,-1
    80001d9e:	bfc5                	j	80001d8e <kfork+0xfc>

0000000080001da0 <scheduler>:
{
    80001da0:	715d                	addi	sp,sp,-80
    80001da2:	e486                	sd	ra,72(sp)
    80001da4:	e0a2                	sd	s0,64(sp)
    80001da6:	fc26                	sd	s1,56(sp)
    80001da8:	f84a                	sd	s2,48(sp)
    80001daa:	f44e                	sd	s3,40(sp)
    80001dac:	f052                	sd	s4,32(sp)
    80001dae:	ec56                	sd	s5,24(sp)
    80001db0:	e85a                	sd	s6,16(sp)
    80001db2:	e45e                	sd	s7,8(sp)
    80001db4:	e062                	sd	s8,0(sp)
    80001db6:	0880                	addi	s0,sp,80
    80001db8:	8792                	mv	a5,tp
  int id = r_tp();
    80001dba:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001dbc:	00779c13          	slli	s8,a5,0x7
    80001dc0:	0000e717          	auipc	a4,0xe
    80001dc4:	bc870713          	addi	a4,a4,-1080 # 8000f988 <pid_lock>
    80001dc8:	9762                	add	a4,a4,s8
    80001dca:	02073823          	sd	zero,48(a4)
      swtch(&c->context, &p->context);
    80001dce:	0000e717          	auipc	a4,0xe
    80001dd2:	bf270713          	addi	a4,a4,-1038 # 8000f9c0 <cpus+0x8>
    80001dd6:	9c3a                	add	s8,s8,a4
    if(passTotal >=MaxPassTotal){
    80001dd8:	00006a97          	auipc	s5,0x6
    80001ddc:	a98a8a93          	addi	s5,s5,-1384 # 80007870 <passTotal>
    80001de0:	000f4bb7          	lui	s7,0xf4
    80001de4:	23fb8b93          	addi	s7,s7,575 # f423f <_entry-0x7ff0bdc1>
       for (current = proc; current < &proc[NPROC]; current++) {
    80001de8:	00014997          	auipc	s3,0x14
    80001dec:	bd098993          	addi	s3,s3,-1072 # 800159b8 <tickslock>
      if(p->state == RUNNABLE) {
    80001df0:	4a0d                	li	s4,3
      c->proc = p;
    80001df2:	079e                	slli	a5,a5,0x7
    80001df4:	0000eb17          	auipc	s6,0xe
    80001df8:	b94b0b13          	addi	s6,s6,-1132 # 8000f988 <pid_lock>
    80001dfc:	9b3e                	add	s6,s6,a5
    80001dfe:	a845                	j	80001eae <scheduler+0x10e>
      passTotal = 0;
    80001e00:	000aa023          	sw	zero,0(s5)
       for (current = proc; current < &proc[NPROC]; current++) {
    80001e04:	0000e497          	auipc	s1,0xe
    80001e08:	fb448493          	addi	s1,s1,-76 # 8000fdb8 <proc>
    80001e0c:	a801                	j	80001e1c <scheduler+0x7c>
        release(&current->lock);
    80001e0e:	8526                	mv	a0,s1
    80001e10:	eadfe0ef          	jal	80000cbc <release>
       for (current = proc; current < &proc[NPROC]; current++) {
    80001e14:	17048493          	addi	s1,s1,368
    80001e18:	0b348a63          	beq	s1,s3,80001ecc <scheduler+0x12c>
        acquire(&current->lock);
    80001e1c:	8526                	mv	a0,s1
    80001e1e:	e0bfe0ef          	jal	80000c28 <acquire>
        if (current->state != UNUSED) {
    80001e22:	50dc                	lw	a5,36(s1)
    80001e24:	d7ed                	beqz	a5,80001e0e <scheduler+0x6e>
            current->pass = 0;
    80001e26:	0204a023          	sw	zero,32(s1)
    80001e2a:	b7d5                	j	80001e0e <scheduler+0x6e>
          release(&p->lock);
    80001e2c:	8526                	mv	a0,s1
    80001e2e:	e8ffe0ef          	jal	80000cbc <release>
    80001e32:	a021                	j	80001e3a <scheduler+0x9a>
        release(&p->lock);
    80001e34:	8526                	mv	a0,s1
    80001e36:	e87fe0ef          	jal	80000cbc <release>
        for(p = proc; p < &proc[NPROC]; p++) {
    80001e3a:	17048493          	addi	s1,s1,368
    80001e3e:	03348663          	beq	s1,s3,80001e6a <scheduler+0xca>
      acquire(&p->lock);
    80001e42:	8526                	mv	a0,s1
    80001e44:	de5fe0ef          	jal	80000c28 <acquire>
      if(p->state == RUNNABLE) {
    80001e48:	50dc                	lw	a5,36(s1)
    80001e4a:	ff4795e3          	bne	a5,s4,80001e34 <scheduler+0x94>
        if (lowest_pass == 0 || p->pass < lowest_pass->pass){
    80001e4e:	00090c63          	beqz	s2,80001e66 <scheduler+0xc6>
    80001e52:	5098                	lw	a4,32(s1)
    80001e54:	02092783          	lw	a5,32(s2)
    80001e58:	fcf75ae3          	bge	a4,a5,80001e2c <scheduler+0x8c>
            release(&lowest_pass->lock);
    80001e5c:	854a                	mv	a0,s2
    80001e5e:	e5ffe0ef          	jal	80000cbc <release>
          lowest_pass = p; 
    80001e62:	8926                	mv	s2,s1
    80001e64:	bfd9                	j	80001e3a <scheduler+0x9a>
    80001e66:	8926                	mv	s2,s1
    80001e68:	bfc9                	j	80001e3a <scheduler+0x9a>
      if(lowest_pass != 0){
    80001e6a:	06090763          	beqz	s2,80001ed8 <scheduler+0x138>
      p->state = RUNNING;
    80001e6e:	4791                	li	a5,4
    80001e70:	02f92223          	sw	a5,36(s2)
      p->runtime++;
    80001e74:	01892783          	lw	a5,24(s2)
    80001e78:	2785                	addiw	a5,a5,1
    80001e7a:	00f92c23          	sw	a5,24(s2)
      p->pass += p->stride;
    80001e7e:	01c92703          	lw	a4,28(s2)
    80001e82:	02092783          	lw	a5,32(s2)
    80001e86:	9fb9                	addw	a5,a5,a4
    80001e88:	02f92023          	sw	a5,32(s2)
      passTotal += p->stride;
    80001e8c:	000aa783          	lw	a5,0(s5)
    80001e90:	9fb9                	addw	a5,a5,a4
    80001e92:	00faa023          	sw	a5,0(s5)
      c->proc = p;
    80001e96:	032b3823          	sd	s2,48(s6)
      swtch(&c->context, &p->context);
    80001e9a:	06890593          	addi	a1,s2,104
    80001e9e:	8562                	mv	a0,s8
    80001ea0:	736000ef          	jal	800025d6 <swtch>
      c->proc = 0;
    80001ea4:	020b3823          	sd	zero,48(s6)
      release(&p->lock);
    80001ea8:	854a                	mv	a0,s2
    80001eaa:	e13fe0ef          	jal	80000cbc <release>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001eae:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001eb2:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001eb6:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001eba:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001ebe:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001ec0:	10079073          	csrw	sstatus,a5
    if(passTotal >=MaxPassTotal){
    80001ec4:	000aa783          	lw	a5,0(s5)
    80001ec8:	f2fbcce3          	blt	s7,a5,80001e00 <scheduler+0x60>
       for (current = proc; current < &proc[NPROC]; current++) {
    80001ecc:	4901                	li	s2,0
    80001ece:	0000e497          	auipc	s1,0xe
    80001ed2:	eea48493          	addi	s1,s1,-278 # 8000fdb8 <proc>
    80001ed6:	b7b5                	j	80001e42 <scheduler+0xa2>
      asm volatile("wfi");
    80001ed8:	10500073          	wfi
    80001edc:	bfc9                	j	80001eae <scheduler+0x10e>

0000000080001ede <sched>:
{
    80001ede:	7179                	addi	sp,sp,-48
    80001ee0:	f406                	sd	ra,40(sp)
    80001ee2:	f022                	sd	s0,32(sp)
    80001ee4:	ec26                	sd	s1,24(sp)
    80001ee6:	e84a                	sd	s2,16(sp)
    80001ee8:	e44e                	sd	s3,8(sp)
    80001eea:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001eec:	a43ff0ef          	jal	8000192e <myproc>
    80001ef0:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001ef2:	cc7fe0ef          	jal	80000bb8 <holding>
    80001ef6:	c935                	beqz	a0,80001f6a <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001ef8:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001efa:	2781                	sext.w	a5,a5
    80001efc:	079e                	slli	a5,a5,0x7
    80001efe:	0000e717          	auipc	a4,0xe
    80001f02:	a8a70713          	addi	a4,a4,-1398 # 8000f988 <pid_lock>
    80001f06:	97ba                	add	a5,a5,a4
    80001f08:	0a87a703          	lw	a4,168(a5)
    80001f0c:	4785                	li	a5,1
    80001f0e:	06f71463          	bne	a4,a5,80001f76 <sched+0x98>
  if(p->state == RUNNING)
    80001f12:	50d8                	lw	a4,36(s1)
    80001f14:	4791                	li	a5,4
    80001f16:	06f70663          	beq	a4,a5,80001f82 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f1a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001f1e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001f20:	e7bd                	bnez	a5,80001f8e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001f22:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001f24:	0000e917          	auipc	s2,0xe
    80001f28:	a6490913          	addi	s2,s2,-1436 # 8000f988 <pid_lock>
    80001f2c:	2781                	sext.w	a5,a5
    80001f2e:	079e                	slli	a5,a5,0x7
    80001f30:	97ca                	add	a5,a5,s2
    80001f32:	0ac7a983          	lw	s3,172(a5)
    80001f36:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001f38:	2781                	sext.w	a5,a5
    80001f3a:	079e                	slli	a5,a5,0x7
    80001f3c:	07a1                	addi	a5,a5,8
    80001f3e:	0000e597          	auipc	a1,0xe
    80001f42:	a7a58593          	addi	a1,a1,-1414 # 8000f9b8 <cpus>
    80001f46:	95be                	add	a1,a1,a5
    80001f48:	06848513          	addi	a0,s1,104
    80001f4c:	68a000ef          	jal	800025d6 <swtch>
    80001f50:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001f52:	2781                	sext.w	a5,a5
    80001f54:	079e                	slli	a5,a5,0x7
    80001f56:	993e                	add	s2,s2,a5
    80001f58:	0b392623          	sw	s3,172(s2)
}
    80001f5c:	70a2                	ld	ra,40(sp)
    80001f5e:	7402                	ld	s0,32(sp)
    80001f60:	64e2                	ld	s1,24(sp)
    80001f62:	6942                	ld	s2,16(sp)
    80001f64:	69a2                	ld	s3,8(sp)
    80001f66:	6145                	addi	sp,sp,48
    80001f68:	8082                	ret
    panic("sched p->lock");
    80001f6a:	00005517          	auipc	a0,0x5
    80001f6e:	22e50513          	addi	a0,a0,558 # 80007198 <etext+0x198>
    80001f72:	8b3fe0ef          	jal	80000824 <panic>
    panic("sched locks");
    80001f76:	00005517          	auipc	a0,0x5
    80001f7a:	23250513          	addi	a0,a0,562 # 800071a8 <etext+0x1a8>
    80001f7e:	8a7fe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    80001f82:	00005517          	auipc	a0,0x5
    80001f86:	23650513          	addi	a0,a0,566 # 800071b8 <etext+0x1b8>
    80001f8a:	89bfe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    80001f8e:	00005517          	auipc	a0,0x5
    80001f92:	23a50513          	addi	a0,a0,570 # 800071c8 <etext+0x1c8>
    80001f96:	88ffe0ef          	jal	80000824 <panic>

0000000080001f9a <yield>:
{
    80001f9a:	1101                	addi	sp,sp,-32
    80001f9c:	ec06                	sd	ra,24(sp)
    80001f9e:	e822                	sd	s0,16(sp)
    80001fa0:	e426                	sd	s1,8(sp)
    80001fa2:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001fa4:	98bff0ef          	jal	8000192e <myproc>
    80001fa8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001faa:	c7ffe0ef          	jal	80000c28 <acquire>
  p->state = RUNNABLE;
    80001fae:	478d                	li	a5,3
    80001fb0:	d0dc                	sw	a5,36(s1)
  sched();
    80001fb2:	f2dff0ef          	jal	80001ede <sched>
  release(&p->lock);
    80001fb6:	8526                	mv	a0,s1
    80001fb8:	d05fe0ef          	jal	80000cbc <release>
}
    80001fbc:	60e2                	ld	ra,24(sp)
    80001fbe:	6442                	ld	s0,16(sp)
    80001fc0:	64a2                	ld	s1,8(sp)
    80001fc2:	6105                	addi	sp,sp,32
    80001fc4:	8082                	ret

0000000080001fc6 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001fc6:	7179                	addi	sp,sp,-48
    80001fc8:	f406                	sd	ra,40(sp)
    80001fca:	f022                	sd	s0,32(sp)
    80001fcc:	ec26                	sd	s1,24(sp)
    80001fce:	e84a                	sd	s2,16(sp)
    80001fd0:	e44e                	sd	s3,8(sp)
    80001fd2:	1800                	addi	s0,sp,48
    80001fd4:	89aa                	mv	s3,a0
    80001fd6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001fd8:	957ff0ef          	jal	8000192e <myproc>
    80001fdc:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001fde:	c4bfe0ef          	jal	80000c28 <acquire>
  release(lk);
    80001fe2:	854a                	mv	a0,s2
    80001fe4:	cd9fe0ef          	jal	80000cbc <release>

  // Go to sleep.
  p->chan = chan;
    80001fe8:	0334b423          	sd	s3,40(s1)
  p->state = SLEEPING;
    80001fec:	4789                	li	a5,2
    80001fee:	d0dc                	sw	a5,36(s1)

  sched();
    80001ff0:	eefff0ef          	jal	80001ede <sched>

  // Tidy up.
  p->chan = 0;
    80001ff4:	0204b423          	sd	zero,40(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001ff8:	8526                	mv	a0,s1
    80001ffa:	cc3fe0ef          	jal	80000cbc <release>
  acquire(lk);
    80001ffe:	854a                	mv	a0,s2
    80002000:	c29fe0ef          	jal	80000c28 <acquire>
}
    80002004:	70a2                	ld	ra,40(sp)
    80002006:	7402                	ld	s0,32(sp)
    80002008:	64e2                	ld	s1,24(sp)
    8000200a:	6942                	ld	s2,16(sp)
    8000200c:	69a2                	ld	s3,8(sp)
    8000200e:	6145                	addi	sp,sp,48
    80002010:	8082                	ret

0000000080002012 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80002012:	7139                	addi	sp,sp,-64
    80002014:	fc06                	sd	ra,56(sp)
    80002016:	f822                	sd	s0,48(sp)
    80002018:	f426                	sd	s1,40(sp)
    8000201a:	f04a                	sd	s2,32(sp)
    8000201c:	ec4e                	sd	s3,24(sp)
    8000201e:	e852                	sd	s4,16(sp)
    80002020:	e456                	sd	s5,8(sp)
    80002022:	0080                	addi	s0,sp,64
    80002024:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80002026:	0000e497          	auipc	s1,0xe
    8000202a:	d9248493          	addi	s1,s1,-622 # 8000fdb8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    8000202e:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002030:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80002032:	00014917          	auipc	s2,0x14
    80002036:	98690913          	addi	s2,s2,-1658 # 800159b8 <tickslock>
    8000203a:	a801                	j	8000204a <wakeup+0x38>
      }
      release(&p->lock);
    8000203c:	8526                	mv	a0,s1
    8000203e:	c7ffe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80002042:	17048493          	addi	s1,s1,368
    80002046:	03248263          	beq	s1,s2,8000206a <wakeup+0x58>
    if(p != myproc()){
    8000204a:	8e5ff0ef          	jal	8000192e <myproc>
    8000204e:	fe950ae3          	beq	a0,s1,80002042 <wakeup+0x30>
      acquire(&p->lock);
    80002052:	8526                	mv	a0,s1
    80002054:	bd5fe0ef          	jal	80000c28 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80002058:	50dc                	lw	a5,36(s1)
    8000205a:	ff3791e3          	bne	a5,s3,8000203c <wakeup+0x2a>
    8000205e:	749c                	ld	a5,40(s1)
    80002060:	fd479ee3          	bne	a5,s4,8000203c <wakeup+0x2a>
        p->state = RUNNABLE;
    80002064:	0354a223          	sw	s5,36(s1)
    80002068:	bfd1                	j	8000203c <wakeup+0x2a>
    }
  }
}
    8000206a:	70e2                	ld	ra,56(sp)
    8000206c:	7442                	ld	s0,48(sp)
    8000206e:	74a2                	ld	s1,40(sp)
    80002070:	7902                	ld	s2,32(sp)
    80002072:	69e2                	ld	s3,24(sp)
    80002074:	6a42                	ld	s4,16(sp)
    80002076:	6aa2                	ld	s5,8(sp)
    80002078:	6121                	addi	sp,sp,64
    8000207a:	8082                	ret

000000008000207c <reparent>:
{
    8000207c:	7179                	addi	sp,sp,-48
    8000207e:	f406                	sd	ra,40(sp)
    80002080:	f022                	sd	s0,32(sp)
    80002082:	ec26                	sd	s1,24(sp)
    80002084:	e84a                	sd	s2,16(sp)
    80002086:	e44e                	sd	s3,8(sp)
    80002088:	e052                	sd	s4,0(sp)
    8000208a:	1800                	addi	s0,sp,48
    8000208c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000208e:	0000e497          	auipc	s1,0xe
    80002092:	d2a48493          	addi	s1,s1,-726 # 8000fdb8 <proc>
      pp->parent = initproc;
    80002096:	00005a17          	auipc	s4,0x5
    8000209a:	7e2a0a13          	addi	s4,s4,2018 # 80007878 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000209e:	00014997          	auipc	s3,0x14
    800020a2:	91a98993          	addi	s3,s3,-1766 # 800159b8 <tickslock>
    800020a6:	a029                	j	800020b0 <reparent+0x34>
    800020a8:	17048493          	addi	s1,s1,368
    800020ac:	01348b63          	beq	s1,s3,800020c2 <reparent+0x46>
    if(pp->parent == p){
    800020b0:	60bc                	ld	a5,64(s1)
    800020b2:	ff279be3          	bne	a5,s2,800020a8 <reparent+0x2c>
      pp->parent = initproc;
    800020b6:	000a3503          	ld	a0,0(s4)
    800020ba:	e0a8                	sd	a0,64(s1)
      wakeup(initproc);
    800020bc:	f57ff0ef          	jal	80002012 <wakeup>
    800020c0:	b7e5                	j	800020a8 <reparent+0x2c>
}
    800020c2:	70a2                	ld	ra,40(sp)
    800020c4:	7402                	ld	s0,32(sp)
    800020c6:	64e2                	ld	s1,24(sp)
    800020c8:	6942                	ld	s2,16(sp)
    800020ca:	69a2                	ld	s3,8(sp)
    800020cc:	6a02                	ld	s4,0(sp)
    800020ce:	6145                	addi	sp,sp,48
    800020d0:	8082                	ret

00000000800020d2 <kexit>:
{
    800020d2:	7179                	addi	sp,sp,-48
    800020d4:	f406                	sd	ra,40(sp)
    800020d6:	f022                	sd	s0,32(sp)
    800020d8:	ec26                	sd	s1,24(sp)
    800020da:	e84a                	sd	s2,16(sp)
    800020dc:	e44e                	sd	s3,8(sp)
    800020de:	e052                	sd	s4,0(sp)
    800020e0:	1800                	addi	s0,sp,48
    800020e2:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800020e4:	84bff0ef          	jal	8000192e <myproc>
    800020e8:	89aa                	mv	s3,a0
  if(p == initproc)
    800020ea:	00005797          	auipc	a5,0x5
    800020ee:	78e7b783          	ld	a5,1934(a5) # 80007878 <initproc>
    800020f2:	0d850493          	addi	s1,a0,216
    800020f6:	15850913          	addi	s2,a0,344
    800020fa:	00a79b63          	bne	a5,a0,80002110 <kexit+0x3e>
    panic("init exiting");
    800020fe:	00005517          	auipc	a0,0x5
    80002102:	0e250513          	addi	a0,a0,226 # 800071e0 <etext+0x1e0>
    80002106:	f1efe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    8000210a:	04a1                	addi	s1,s1,8
    8000210c:	01248963          	beq	s1,s2,8000211e <kexit+0x4c>
    if(p->ofile[fd]){
    80002110:	6088                	ld	a0,0(s1)
    80002112:	dd65                	beqz	a0,8000210a <kexit+0x38>
      fileclose(f);
    80002114:	18a020ef          	jal	8000429e <fileclose>
      p->ofile[fd] = 0;
    80002118:	0004b023          	sd	zero,0(s1)
    8000211c:	b7fd                	j	8000210a <kexit+0x38>
  begin_op();
    8000211e:	55d010ef          	jal	80003e7a <begin_op>
  iput(p->cwd);
    80002122:	1589b503          	ld	a0,344(s3)
    80002126:	4ca010ef          	jal	800035f0 <iput>
  end_op();
    8000212a:	5c1010ef          	jal	80003eea <end_op>
  p->cwd = 0;
    8000212e:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    80002132:	0000e517          	auipc	a0,0xe
    80002136:	86e50513          	addi	a0,a0,-1938 # 8000f9a0 <wait_lock>
    8000213a:	aeffe0ef          	jal	80000c28 <acquire>
  reparent(p);
    8000213e:	854e                	mv	a0,s3
    80002140:	f3dff0ef          	jal	8000207c <reparent>
  wakeup(p->parent);
    80002144:	0409b503          	ld	a0,64(s3)
    80002148:	ecbff0ef          	jal	80002012 <wakeup>
  acquire(&p->lock);
    8000214c:	854e                	mv	a0,s3
    8000214e:	adbfe0ef          	jal	80000c28 <acquire>
  p->xstate = status;
    80002152:	0349aa23          	sw	s4,52(s3)
  p->state = ZOMBIE;
    80002156:	4795                	li	a5,5
    80002158:	02f9a223          	sw	a5,36(s3)
  release(&wait_lock);
    8000215c:	0000e517          	auipc	a0,0xe
    80002160:	84450513          	addi	a0,a0,-1980 # 8000f9a0 <wait_lock>
    80002164:	b59fe0ef          	jal	80000cbc <release>
  sched();
    80002168:	d77ff0ef          	jal	80001ede <sched>
  panic("zombie exit");
    8000216c:	00005517          	auipc	a0,0x5
    80002170:	08450513          	addi	a0,a0,132 # 800071f0 <etext+0x1f0>
    80002174:	eb0fe0ef          	jal	80000824 <panic>

0000000080002178 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    80002178:	7179                	addi	sp,sp,-48
    8000217a:	f406                	sd	ra,40(sp)
    8000217c:	f022                	sd	s0,32(sp)
    8000217e:	ec26                	sd	s1,24(sp)
    80002180:	e84a                	sd	s2,16(sp)
    80002182:	e44e                	sd	s3,8(sp)
    80002184:	1800                	addi	s0,sp,48
    80002186:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002188:	0000e497          	auipc	s1,0xe
    8000218c:	c3048493          	addi	s1,s1,-976 # 8000fdb8 <proc>
    80002190:	00014997          	auipc	s3,0x14
    80002194:	82898993          	addi	s3,s3,-2008 # 800159b8 <tickslock>
    acquire(&p->lock);
    80002198:	8526                	mv	a0,s1
    8000219a:	a8ffe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    8000219e:	5c9c                	lw	a5,56(s1)
    800021a0:	01278b63          	beq	a5,s2,800021b6 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800021a4:	8526                	mv	a0,s1
    800021a6:	b17fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800021aa:	17048493          	addi	s1,s1,368
    800021ae:	ff3495e3          	bne	s1,s3,80002198 <kkill+0x20>
  }
  return -1;
    800021b2:	557d                	li	a0,-1
    800021b4:	a819                	j	800021ca <kkill+0x52>
      p->killed = 1;
    800021b6:	4785                	li	a5,1
    800021b8:	d89c                	sw	a5,48(s1)
      if(p->state == SLEEPING){
    800021ba:	50d8                	lw	a4,36(s1)
    800021bc:	4789                	li	a5,2
    800021be:	00f70d63          	beq	a4,a5,800021d8 <kkill+0x60>
      release(&p->lock);
    800021c2:	8526                	mv	a0,s1
    800021c4:	af9fe0ef          	jal	80000cbc <release>
      return 0;
    800021c8:	4501                	li	a0,0
}
    800021ca:	70a2                	ld	ra,40(sp)
    800021cc:	7402                	ld	s0,32(sp)
    800021ce:	64e2                	ld	s1,24(sp)
    800021d0:	6942                	ld	s2,16(sp)
    800021d2:	69a2                	ld	s3,8(sp)
    800021d4:	6145                	addi	sp,sp,48
    800021d6:	8082                	ret
        p->state = RUNNABLE;
    800021d8:	478d                	li	a5,3
    800021da:	d0dc                	sw	a5,36(s1)
    800021dc:	b7dd                	j	800021c2 <kkill+0x4a>

00000000800021de <setkilled>:

void
setkilled(struct proc *p)
{
    800021de:	1101                	addi	sp,sp,-32
    800021e0:	ec06                	sd	ra,24(sp)
    800021e2:	e822                	sd	s0,16(sp)
    800021e4:	e426                	sd	s1,8(sp)
    800021e6:	1000                	addi	s0,sp,32
    800021e8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800021ea:	a3ffe0ef          	jal	80000c28 <acquire>
  p->killed = 1;
    800021ee:	4785                	li	a5,1
    800021f0:	d89c                	sw	a5,48(s1)
  release(&p->lock);
    800021f2:	8526                	mv	a0,s1
    800021f4:	ac9fe0ef          	jal	80000cbc <release>
}
    800021f8:	60e2                	ld	ra,24(sp)
    800021fa:	6442                	ld	s0,16(sp)
    800021fc:	64a2                	ld	s1,8(sp)
    800021fe:	6105                	addi	sp,sp,32
    80002200:	8082                	ret

0000000080002202 <killed>:


int
killed(struct proc *p)
{
    80002202:	1101                	addi	sp,sp,-32
    80002204:	ec06                	sd	ra,24(sp)
    80002206:	e822                	sd	s0,16(sp)
    80002208:	e426                	sd	s1,8(sp)
    8000220a:	e04a                	sd	s2,0(sp)
    8000220c:	1000                	addi	s0,sp,32
    8000220e:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002210:	a19fe0ef          	jal	80000c28 <acquire>
  k = p->killed;
    80002214:	589c                	lw	a5,48(s1)
    80002216:	893e                	mv	s2,a5
  release(&p->lock);
    80002218:	8526                	mv	a0,s1
    8000221a:	aa3fe0ef          	jal	80000cbc <release>
  return k;
}
    8000221e:	854a                	mv	a0,s2
    80002220:	60e2                	ld	ra,24(sp)
    80002222:	6442                	ld	s0,16(sp)
    80002224:	64a2                	ld	s1,8(sp)
    80002226:	6902                	ld	s2,0(sp)
    80002228:	6105                	addi	sp,sp,32
    8000222a:	8082                	ret

000000008000222c <kwait>:
{
    8000222c:	715d                	addi	sp,sp,-80
    8000222e:	e486                	sd	ra,72(sp)
    80002230:	e0a2                	sd	s0,64(sp)
    80002232:	fc26                	sd	s1,56(sp)
    80002234:	f84a                	sd	s2,48(sp)
    80002236:	f44e                	sd	s3,40(sp)
    80002238:	f052                	sd	s4,32(sp)
    8000223a:	ec56                	sd	s5,24(sp)
    8000223c:	e85a                	sd	s6,16(sp)
    8000223e:	e45e                	sd	s7,8(sp)
    80002240:	0880                	addi	s0,sp,80
    80002242:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80002244:	eeaff0ef          	jal	8000192e <myproc>
    80002248:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000224a:	0000d517          	auipc	a0,0xd
    8000224e:	75650513          	addi	a0,a0,1878 # 8000f9a0 <wait_lock>
    80002252:	9d7fe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    80002256:	4a15                	li	s4,5
        havekids = 1;
    80002258:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000225a:	00013997          	auipc	s3,0x13
    8000225e:	75e98993          	addi	s3,s3,1886 # 800159b8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002262:	0000db17          	auipc	s6,0xd
    80002266:	73eb0b13          	addi	s6,s6,1854 # 8000f9a0 <wait_lock>
    8000226a:	a869                	j	80002304 <kwait+0xd8>
          pid = pp->pid;
    8000226c:	0384a983          	lw	s3,56(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002270:	000b8c63          	beqz	s7,80002288 <kwait+0x5c>
    80002274:	4691                	li	a3,4
    80002276:	03448613          	addi	a2,s1,52
    8000227a:	85de                	mv	a1,s7
    8000227c:	05893503          	ld	a0,88(s2)
    80002280:	bd4ff0ef          	jal	80001654 <copyout>
    80002284:	02054a63          	bltz	a0,800022b8 <kwait+0x8c>
          freeproc(pp);
    80002288:	8526                	mv	a0,s1
    8000228a:	879ff0ef          	jal	80001b02 <freeproc>
          release(&pp->lock);
    8000228e:	8526                	mv	a0,s1
    80002290:	a2dfe0ef          	jal	80000cbc <release>
          release(&wait_lock);
    80002294:	0000d517          	auipc	a0,0xd
    80002298:	70c50513          	addi	a0,a0,1804 # 8000f9a0 <wait_lock>
    8000229c:	a21fe0ef          	jal	80000cbc <release>
}
    800022a0:	854e                	mv	a0,s3
    800022a2:	60a6                	ld	ra,72(sp)
    800022a4:	6406                	ld	s0,64(sp)
    800022a6:	74e2                	ld	s1,56(sp)
    800022a8:	7942                	ld	s2,48(sp)
    800022aa:	79a2                	ld	s3,40(sp)
    800022ac:	7a02                	ld	s4,32(sp)
    800022ae:	6ae2                	ld	s5,24(sp)
    800022b0:	6b42                	ld	s6,16(sp)
    800022b2:	6ba2                	ld	s7,8(sp)
    800022b4:	6161                	addi	sp,sp,80
    800022b6:	8082                	ret
            release(&pp->lock);
    800022b8:	8526                	mv	a0,s1
    800022ba:	a03fe0ef          	jal	80000cbc <release>
            release(&wait_lock);
    800022be:	0000d517          	auipc	a0,0xd
    800022c2:	6e250513          	addi	a0,a0,1762 # 8000f9a0 <wait_lock>
    800022c6:	9f7fe0ef          	jal	80000cbc <release>
            return -1;
    800022ca:	59fd                	li	s3,-1
    800022cc:	bfd1                	j	800022a0 <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022ce:	17048493          	addi	s1,s1,368
    800022d2:	03348063          	beq	s1,s3,800022f2 <kwait+0xc6>
      if(pp->parent == p){
    800022d6:	60bc                	ld	a5,64(s1)
    800022d8:	ff279be3          	bne	a5,s2,800022ce <kwait+0xa2>
        acquire(&pp->lock);
    800022dc:	8526                	mv	a0,s1
    800022de:	94bfe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    800022e2:	50dc                	lw	a5,36(s1)
    800022e4:	f94784e3          	beq	a5,s4,8000226c <kwait+0x40>
        release(&pp->lock);
    800022e8:	8526                	mv	a0,s1
    800022ea:	9d3fe0ef          	jal	80000cbc <release>
        havekids = 1;
    800022ee:	8756                	mv	a4,s5
    800022f0:	bff9                	j	800022ce <kwait+0xa2>
    if(!havekids || killed(p)){
    800022f2:	cf19                	beqz	a4,80002310 <kwait+0xe4>
    800022f4:	854a                	mv	a0,s2
    800022f6:	f0dff0ef          	jal	80002202 <killed>
    800022fa:	e919                	bnez	a0,80002310 <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800022fc:	85da                	mv	a1,s6
    800022fe:	854a                	mv	a0,s2
    80002300:	cc7ff0ef          	jal	80001fc6 <sleep>
    havekids = 0;
    80002304:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002306:	0000e497          	auipc	s1,0xe
    8000230a:	ab248493          	addi	s1,s1,-1358 # 8000fdb8 <proc>
    8000230e:	b7e1                	j	800022d6 <kwait+0xaa>
      release(&wait_lock);
    80002310:	0000d517          	auipc	a0,0xd
    80002314:	69050513          	addi	a0,a0,1680 # 8000f9a0 <wait_lock>
    80002318:	9a5fe0ef          	jal	80000cbc <release>
      return -1;
    8000231c:	59fd                	li	s3,-1
    8000231e:	b749                	j	800022a0 <kwait+0x74>

0000000080002320 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002320:	7179                	addi	sp,sp,-48
    80002322:	f406                	sd	ra,40(sp)
    80002324:	f022                	sd	s0,32(sp)
    80002326:	ec26                	sd	s1,24(sp)
    80002328:	e84a                	sd	s2,16(sp)
    8000232a:	e44e                	sd	s3,8(sp)
    8000232c:	e052                	sd	s4,0(sp)
    8000232e:	1800                	addi	s0,sp,48
    80002330:	84aa                	mv	s1,a0
    80002332:	8a2e                	mv	s4,a1
    80002334:	89b2                	mv	s3,a2
    80002336:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002338:	df6ff0ef          	jal	8000192e <myproc>
  if(user_dst){
    8000233c:	cc99                	beqz	s1,8000235a <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    8000233e:	86ca                	mv	a3,s2
    80002340:	864e                	mv	a2,s3
    80002342:	85d2                	mv	a1,s4
    80002344:	6d28                	ld	a0,88(a0)
    80002346:	b0eff0ef          	jal	80001654 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000234a:	70a2                	ld	ra,40(sp)
    8000234c:	7402                	ld	s0,32(sp)
    8000234e:	64e2                	ld	s1,24(sp)
    80002350:	6942                	ld	s2,16(sp)
    80002352:	69a2                	ld	s3,8(sp)
    80002354:	6a02                	ld	s4,0(sp)
    80002356:	6145                	addi	sp,sp,48
    80002358:	8082                	ret
    memmove((char *)dst, src, len);
    8000235a:	0009061b          	sext.w	a2,s2
    8000235e:	85ce                	mv	a1,s3
    80002360:	8552                	mv	a0,s4
    80002362:	9f7fe0ef          	jal	80000d58 <memmove>
    return 0;
    80002366:	8526                	mv	a0,s1
    80002368:	b7cd                	j	8000234a <either_copyout+0x2a>

000000008000236a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000236a:	7179                	addi	sp,sp,-48
    8000236c:	f406                	sd	ra,40(sp)
    8000236e:	f022                	sd	s0,32(sp)
    80002370:	ec26                	sd	s1,24(sp)
    80002372:	e84a                	sd	s2,16(sp)
    80002374:	e44e                	sd	s3,8(sp)
    80002376:	e052                	sd	s4,0(sp)
    80002378:	1800                	addi	s0,sp,48
    8000237a:	8a2a                	mv	s4,a0
    8000237c:	84ae                	mv	s1,a1
    8000237e:	89b2                	mv	s3,a2
    80002380:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002382:	dacff0ef          	jal	8000192e <myproc>
  if(user_src){
    80002386:	cc99                	beqz	s1,800023a4 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002388:	86ca                	mv	a3,s2
    8000238a:	864e                	mv	a2,s3
    8000238c:	85d2                	mv	a1,s4
    8000238e:	6d28                	ld	a0,88(a0)
    80002390:	b82ff0ef          	jal	80001712 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002394:	70a2                	ld	ra,40(sp)
    80002396:	7402                	ld	s0,32(sp)
    80002398:	64e2                	ld	s1,24(sp)
    8000239a:	6942                	ld	s2,16(sp)
    8000239c:	69a2                	ld	s3,8(sp)
    8000239e:	6a02                	ld	s4,0(sp)
    800023a0:	6145                	addi	sp,sp,48
    800023a2:	8082                	ret
    memmove(dst, (char*)src, len);
    800023a4:	0009061b          	sext.w	a2,s2
    800023a8:	85ce                	mv	a1,s3
    800023aa:	8552                	mv	a0,s4
    800023ac:	9adfe0ef          	jal	80000d58 <memmove>
    return 0;
    800023b0:	8526                	mv	a0,s1
    800023b2:	b7cd                	j	80002394 <either_copyin+0x2a>

00000000800023b4 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800023b4:	715d                	addi	sp,sp,-80
    800023b6:	e486                	sd	ra,72(sp)
    800023b8:	e0a2                	sd	s0,64(sp)
    800023ba:	fc26                	sd	s1,56(sp)
    800023bc:	f84a                	sd	s2,48(sp)
    800023be:	f44e                	sd	s3,40(sp)
    800023c0:	f052                	sd	s4,32(sp)
    800023c2:	ec56                	sd	s5,24(sp)
    800023c4:	e85a                	sd	s6,16(sp)
    800023c6:	e45e                	sd	s7,8(sp)
    800023c8:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800023ca:	00005517          	auipc	a0,0x5
    800023ce:	cae50513          	addi	a0,a0,-850 # 80007078 <etext+0x78>
    800023d2:	928fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800023d6:	0000e497          	auipc	s1,0xe
    800023da:	b4248493          	addi	s1,s1,-1214 # 8000ff18 <proc+0x160>
    800023de:	00013917          	auipc	s2,0x13
    800023e2:	73a90913          	addi	s2,s2,1850 # 80015b18 <bcache+0x148>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023e6:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800023e8:	00005997          	auipc	s3,0x5
    800023ec:	e1898993          	addi	s3,s3,-488 # 80007200 <etext+0x200>
    printf("%d %s %s", p->pid, state, p->name);
    800023f0:	00005a97          	auipc	s5,0x5
    800023f4:	e18a8a93          	addi	s5,s5,-488 # 80007208 <etext+0x208>
    printf("\n");
    800023f8:	00005a17          	auipc	s4,0x5
    800023fc:	c80a0a13          	addi	s4,s4,-896 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002400:	00005b97          	auipc	s7,0x5
    80002404:	328b8b93          	addi	s7,s7,808 # 80007728 <states.0>
    80002408:	a829                	j	80002422 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000240a:	ed86a583          	lw	a1,-296(a3)
    8000240e:	8556                	mv	a0,s5
    80002410:	8eafe0ef          	jal	800004fa <printf>
    printf("\n");
    80002414:	8552                	mv	a0,s4
    80002416:	8e4fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000241a:	17048493          	addi	s1,s1,368
    8000241e:	03248263          	beq	s1,s2,80002442 <procdump+0x8e>
    if(p->state == UNUSED)
    80002422:	86a6                	mv	a3,s1
    80002424:	ec44a783          	lw	a5,-316(s1)
    80002428:	dbed                	beqz	a5,8000241a <procdump+0x66>
      state = "???";
    8000242a:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000242c:	fcfb6fe3          	bltu	s6,a5,8000240a <procdump+0x56>
    80002430:	02079713          	slli	a4,a5,0x20
    80002434:	01d75793          	srli	a5,a4,0x1d
    80002438:	97de                	add	a5,a5,s7
    8000243a:	6390                	ld	a2,0(a5)
    8000243c:	f679                	bnez	a2,8000240a <procdump+0x56>
      state = "???";
    8000243e:	864e                	mv	a2,s3
    80002440:	b7e9                	j	8000240a <procdump+0x56>
  }
}
    80002442:	60a6                	ld	ra,72(sp)
    80002444:	6406                	ld	s0,64(sp)
    80002446:	74e2                	ld	s1,56(sp)
    80002448:	7942                	ld	s2,48(sp)
    8000244a:	79a2                	ld	s3,40(sp)
    8000244c:	7a02                	ld	s4,32(sp)
    8000244e:	6ae2                	ld	s5,24(sp)
    80002450:	6b42                	ld	s6,16(sp)
    80002452:	6ba2                	ld	s7,8(sp)
    80002454:	6161                	addi	sp,sp,80
    80002456:	8082                	ret

0000000080002458 <getfilenum>:

int getfilenum(int pid){
    80002458:	7179                	addi	sp,sp,-48
    8000245a:	f406                	sd	ra,40(sp)
    8000245c:	f022                	sd	s0,32(sp)
    8000245e:	ec26                	sd	s1,24(sp)
    80002460:	e84a                	sd	s2,16(sp)
    80002462:	e44e                	sd	s3,8(sp)
    80002464:	1800                	addi	s0,sp,48
    80002466:	892a                	mv	s2,a0
  struct proc *p;
  int count = 0;
  for (p=proc; p <&proc[NPROC];p++){
    80002468:	0000e497          	auipc	s1,0xe
    8000246c:	95048493          	addi	s1,s1,-1712 # 8000fdb8 <proc>
    80002470:	00013997          	auipc	s3,0x13
    80002474:	54898993          	addi	s3,s3,1352 # 800159b8 <tickslock>
    acquire(&p->lock);
    80002478:	8526                	mv	a0,s1
    8000247a:	faefe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    8000247e:	5c9c                	lw	a5,56(s1)
    80002480:	01278b63          	beq	a5,s2,80002496 <getfilenum+0x3e>
        }
      }
      release(&p->lock);
      return count;
    }
    release(&p->lock);
    80002484:	8526                	mv	a0,s1
    80002486:	837fe0ef          	jal	80000cbc <release>
  for (p=proc; p <&proc[NPROC];p++){
    8000248a:	17048493          	addi	s1,s1,368
    8000248e:	ff3495e3          	bne	s1,s3,80002478 <getfilenum+0x20>
  }
  return count;
    80002492:	4901                	li	s2,0
    80002494:	a00d                	j	800024b6 <getfilenum+0x5e>
    80002496:	0d848793          	addi	a5,s1,216
    8000249a:	15848693          	addi	a3,s1,344
  int count = 0;
    8000249e:	4901                	li	s2,0
    800024a0:	a021                	j	800024a8 <getfilenum+0x50>
      for(int i = 0; i<NOFILE; i++){
    800024a2:	07a1                	addi	a5,a5,8
    800024a4:	00d78663          	beq	a5,a3,800024b0 <getfilenum+0x58>
        if(p->ofile[i] != 0){
    800024a8:	6398                	ld	a4,0(a5)
    800024aa:	df65                	beqz	a4,800024a2 <getfilenum+0x4a>
          count++;
    800024ac:	2905                	addiw	s2,s2,1
    800024ae:	bfd5                	j	800024a2 <getfilenum+0x4a>
      release(&p->lock);
    800024b0:	8526                	mv	a0,s1
    800024b2:	80bfe0ef          	jal	80000cbc <release>
}
    800024b6:	854a                	mv	a0,s2
    800024b8:	70a2                	ld	ra,40(sp)
    800024ba:	7402                	ld	s0,32(sp)
    800024bc:	64e2                	ld	s1,24(sp)
    800024be:	6942                	ld	s2,16(sp)
    800024c0:	69a2                	ld	s3,8(sp)
    800024c2:	6145                	addi	sp,sp,48
    800024c4:	8082                	ret

00000000800024c6 <getpinfo>:

#include "pstat.h"   // make sure this is included near top of proc.c

int
getpinfo(struct pstat *up)
{
    800024c6:	bb010113          	addi	sp,sp,-1104
    800024ca:	44113423          	sd	ra,1096(sp)
    800024ce:	44813023          	sd	s0,1088(sp)
    800024d2:	42913c23          	sd	s1,1080(sp)
    800024d6:	43213823          	sd	s2,1072(sp)
    800024da:	43313423          	sd	s3,1064(sp)
    800024de:	43413023          	sd	s4,1056(sp)
    800024e2:	41513c23          	sd	s5,1048(sp)
    800024e6:	41613823          	sd	s6,1040(sp)
    800024ea:	45010413          	addi	s0,sp,1104
    800024ee:	8b2a                	mv	s6,a0
  struct pstat pinfo;

  // Initialize all slots to 0
  for (int i = 0; i < NPROC; i++) {
    800024f0:	bb840913          	addi	s2,s0,-1096
    800024f4:	cb840713          	addi	a4,s0,-840
{
    800024f8:	87ca                	mv	a5,s2
    pinfo.inuse[i]  = 0;
    800024fa:	0007a023          	sw	zero,0(a5)
    pinfo.pid[i]    = 0;
    800024fe:	1007a023          	sw	zero,256(a5)
    pinfo.runtime[i]= 0;
    80002502:	2007a023          	sw	zero,512(a5)
    pinfo.pass[i]   = 0;
    80002506:	3007a023          	sw	zero,768(a5)
  for (int i = 0; i < NPROC; i++) {
    8000250a:	0791                	addi	a5,a5,4
    8000250c:	fee797e3          	bne	a5,a4,800024fa <getpinfo+0x34>
  }
  pinfo.passTotal = passTotal;
    80002510:	00005797          	auipc	a5,0x5
    80002514:	3607a783          	lw	a5,864(a5) # 80007870 <passTotal>
    80002518:	faf42c23          	sw	a5,-72(s0)
  for (int i = 0; i < NPROC; i++) {
    8000251c:	0000e497          	auipc	s1,0xe
    80002520:	89c48493          	addi	s1,s1,-1892 # 8000fdb8 <proc>
    80002524:	00013a17          	auipc	s4,0x13
    80002528:	494a0a13          	addi	s4,s4,1172 # 800159b8 <tickslock>
    struct proc *p = &proc[i];
    acquire(&p->lock);
    if (p->state!=UNUSED) {
      pinfo.inuse[i]=1;
    8000252c:	4a85                	li	s5,1
    8000252e:	a809                	j	80002540 <getpinfo+0x7a>
      pinfo.pid[i]=p->pid;
      pinfo.runtime[i]=p->runtime;
      pinfo.pass[i]=p->pass;
    }
    release(&p->lock);
    80002530:	854e                	mv	a0,s3
    80002532:	f8afe0ef          	jal	80000cbc <release>
  for (int i = 0; i < NPROC; i++) {
    80002536:	17048493          	addi	s1,s1,368
    8000253a:	0911                	addi	s2,s2,4
    8000253c:	03448463          	beq	s1,s4,80002564 <getpinfo+0x9e>
    acquire(&p->lock);
    80002540:	89a6                	mv	s3,s1
    80002542:	8526                	mv	a0,s1
    80002544:	ee4fe0ef          	jal	80000c28 <acquire>
    if (p->state!=UNUSED) {
    80002548:	50dc                	lw	a5,36(s1)
    8000254a:	d3fd                	beqz	a5,80002530 <getpinfo+0x6a>
      pinfo.inuse[i]=1;
    8000254c:	01592023          	sw	s5,0(s2)
      pinfo.pid[i]=p->pid;
    80002550:	5c9c                	lw	a5,56(s1)
    80002552:	10f92023          	sw	a5,256(s2)
      pinfo.runtime[i]=p->runtime;
    80002556:	4c9c                	lw	a5,24(s1)
    80002558:	20f92023          	sw	a5,512(s2)
      pinfo.pass[i]=p->pass;
    8000255c:	509c                	lw	a5,32(s1)
    8000255e:	30f92023          	sw	a5,768(s2)
    80002562:	b7f9                	j	80002530 <getpinfo+0x6a>
  }
  if (either_copyout(1, (uint64)up, &pinfo, sizeof(pinfo)) < 0) {
    80002564:	40400693          	li	a3,1028
    80002568:	bb840613          	addi	a2,s0,-1096
    8000256c:	85da                	mv	a1,s6
    8000256e:	4505                	li	a0,1
    80002570:	db1ff0ef          	jal	80002320 <either_copyout>
    return -1;
  }
  return 0;
}
    80002574:	41f5551b          	sraiw	a0,a0,0x1f
    80002578:	44813083          	ld	ra,1096(sp)
    8000257c:	44013403          	ld	s0,1088(sp)
    80002580:	43813483          	ld	s1,1080(sp)
    80002584:	43013903          	ld	s2,1072(sp)
    80002588:	42813983          	ld	s3,1064(sp)
    8000258c:	42013a03          	ld	s4,1056(sp)
    80002590:	41813a83          	ld	s5,1048(sp)
    80002594:	41013b03          	ld	s6,1040(sp)
    80002598:	45010113          	addi	sp,sp,1104
    8000259c:	8082                	ret

000000008000259e <setStride>:


int setStride(int strideLength)
{
    8000259e:	1101                	addi	sp,sp,-32
    800025a0:	ec06                	sd	ra,24(sp)
    800025a2:	e822                	sd	s0,16(sp)
    800025a4:	e04a                	sd	s2,0(sp)
    800025a6:	1000                	addi	s0,sp,32
    800025a8:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800025aa:	b84ff0ef          	jal	8000192e <myproc>
  if (strideLength < 1) {
    800025ae:	03205263          	blez	s2,800025d2 <setStride+0x34>
    800025b2:	e426                	sd	s1,8(sp)
    800025b4:	84aa                	mv	s1,a0
    return -1;
  }
  acquire(&p->lock);
    800025b6:	e72fe0ef          	jal	80000c28 <acquire>
  p->stride = strideLength;
    800025ba:	0124ae23          	sw	s2,28(s1)
  release(&p->lock);
    800025be:	8526                	mv	a0,s1
    800025c0:	efcfe0ef          	jal	80000cbc <release>
  return 0;
    800025c4:	4501                	li	a0,0
    800025c6:	64a2                	ld	s1,8(sp)
}
    800025c8:	60e2                	ld	ra,24(sp)
    800025ca:	6442                	ld	s0,16(sp)
    800025cc:	6902                	ld	s2,0(sp)
    800025ce:	6105                	addi	sp,sp,32
    800025d0:	8082                	ret
    return -1;
    800025d2:	557d                	li	a0,-1
    800025d4:	bfd5                	j	800025c8 <setStride+0x2a>

00000000800025d6 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800025d6:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800025da:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800025de:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800025e0:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800025e2:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800025e6:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800025ea:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800025ee:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800025f2:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800025f6:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800025fa:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800025fe:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002602:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002606:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000260a:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    8000260e:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002612:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002614:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002616:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000261a:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    8000261e:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002622:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002626:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000262a:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    8000262e:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002632:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002636:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000263a:	0685bd83          	ld	s11,104(a1)
        
        ret
    8000263e:	8082                	ret

0000000080002640 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002640:	1141                	addi	sp,sp,-16
    80002642:	e406                	sd	ra,8(sp)
    80002644:	e022                	sd	s0,0(sp)
    80002646:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002648:	00005597          	auipc	a1,0x5
    8000264c:	c0058593          	addi	a1,a1,-1024 # 80007248 <etext+0x248>
    80002650:	00013517          	auipc	a0,0x13
    80002654:	36850513          	addi	a0,a0,872 # 800159b8 <tickslock>
    80002658:	d46fe0ef          	jal	80000b9e <initlock>
}
    8000265c:	60a2                	ld	ra,8(sp)
    8000265e:	6402                	ld	s0,0(sp)
    80002660:	0141                	addi	sp,sp,16
    80002662:	8082                	ret

0000000080002664 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002664:	1141                	addi	sp,sp,-16
    80002666:	e406                	sd	ra,8(sp)
    80002668:	e022                	sd	s0,0(sp)
    8000266a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000266c:	00003797          	auipc	a5,0x3
    80002670:	ff478793          	addi	a5,a5,-12 # 80005660 <kernelvec>
    80002674:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002678:	60a2                	ld	ra,8(sp)
    8000267a:	6402                	ld	s0,0(sp)
    8000267c:	0141                	addi	sp,sp,16
    8000267e:	8082                	ret

0000000080002680 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002680:	1141                	addi	sp,sp,-16
    80002682:	e406                	sd	ra,8(sp)
    80002684:	e022                	sd	s0,0(sp)
    80002686:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002688:	aa6ff0ef          	jal	8000192e <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000268c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002690:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002692:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002696:	04000737          	lui	a4,0x4000
    8000269a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000269c:	0732                	slli	a4,a4,0xc
    8000269e:	00004797          	auipc	a5,0x4
    800026a2:	96278793          	addi	a5,a5,-1694 # 80006000 <_trampoline>
    800026a6:	00004697          	auipc	a3,0x4
    800026aa:	95a68693          	addi	a3,a3,-1702 # 80006000 <_trampoline>
    800026ae:	8f95                	sub	a5,a5,a3
    800026b0:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800026b2:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800026b6:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800026b8:	18002773          	csrr	a4,satp
    800026bc:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800026be:	7138                	ld	a4,96(a0)
    800026c0:	653c                	ld	a5,72(a0)
    800026c2:	6685                	lui	a3,0x1
    800026c4:	97b6                	add	a5,a5,a3
    800026c6:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800026c8:	713c                	ld	a5,96(a0)
    800026ca:	00000717          	auipc	a4,0x0
    800026ce:	0fc70713          	addi	a4,a4,252 # 800027c6 <usertrap>
    800026d2:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800026d4:	713c                	ld	a5,96(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800026d6:	8712                	mv	a4,tp
    800026d8:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026da:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800026de:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800026e2:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800026e6:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800026ea:	713c                	ld	a5,96(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800026ec:	6f9c                	ld	a5,24(a5)
    800026ee:	14179073          	csrw	sepc,a5
}
    800026f2:	60a2                	ld	ra,8(sp)
    800026f4:	6402                	ld	s0,0(sp)
    800026f6:	0141                	addi	sp,sp,16
    800026f8:	8082                	ret

00000000800026fa <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800026fa:	1141                	addi	sp,sp,-16
    800026fc:	e406                	sd	ra,8(sp)
    800026fe:	e022                	sd	s0,0(sp)
    80002700:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80002702:	9f8ff0ef          	jal	800018fa <cpuid>
    80002706:	cd11                	beqz	a0,80002722 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80002708:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000270c:	000f4737          	lui	a4,0xf4
    80002710:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002714:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002716:	14d79073          	csrw	stimecmp,a5
}
    8000271a:	60a2                	ld	ra,8(sp)
    8000271c:	6402                	ld	s0,0(sp)
    8000271e:	0141                	addi	sp,sp,16
    80002720:	8082                	ret
    acquire(&tickslock);
    80002722:	00013517          	auipc	a0,0x13
    80002726:	29650513          	addi	a0,a0,662 # 800159b8 <tickslock>
    8000272a:	cfefe0ef          	jal	80000c28 <acquire>
    ticks++;
    8000272e:	00005717          	auipc	a4,0x5
    80002732:	15270713          	addi	a4,a4,338 # 80007880 <ticks>
    80002736:	431c                	lw	a5,0(a4)
    80002738:	2785                	addiw	a5,a5,1
    8000273a:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000273c:	853a                	mv	a0,a4
    8000273e:	8d5ff0ef          	jal	80002012 <wakeup>
    release(&tickslock);
    80002742:	00013517          	auipc	a0,0x13
    80002746:	27650513          	addi	a0,a0,630 # 800159b8 <tickslock>
    8000274a:	d72fe0ef          	jal	80000cbc <release>
    8000274e:	bf6d                	j	80002708 <clockintr+0xe>

0000000080002750 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002750:	1101                	addi	sp,sp,-32
    80002752:	ec06                	sd	ra,24(sp)
    80002754:	e822                	sd	s0,16(sp)
    80002756:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002758:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000275c:	57fd                	li	a5,-1
    8000275e:	17fe                	slli	a5,a5,0x3f
    80002760:	07a5                	addi	a5,a5,9
    80002762:	00f70c63          	beq	a4,a5,8000277a <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002766:	57fd                	li	a5,-1
    80002768:	17fe                	slli	a5,a5,0x3f
    8000276a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000276c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000276e:	04f70863          	beq	a4,a5,800027be <devintr+0x6e>
  }
}
    80002772:	60e2                	ld	ra,24(sp)
    80002774:	6442                	ld	s0,16(sp)
    80002776:	6105                	addi	sp,sp,32
    80002778:	8082                	ret
    8000277a:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000277c:	791020ef          	jal	8000570c <plic_claim>
    80002780:	872a                	mv	a4,a0
    80002782:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002784:	47a9                	li	a5,10
    80002786:	00f50963          	beq	a0,a5,80002798 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    8000278a:	4785                	li	a5,1
    8000278c:	00f50963          	beq	a0,a5,8000279e <devintr+0x4e>
    return 1;
    80002790:	4505                	li	a0,1
    } else if(irq){
    80002792:	eb09                	bnez	a4,800027a4 <devintr+0x54>
    80002794:	64a2                	ld	s1,8(sp)
    80002796:	bff1                	j	80002772 <devintr+0x22>
      uartintr();
    80002798:	a5cfe0ef          	jal	800009f4 <uartintr>
    if(irq)
    8000279c:	a819                	j	800027b2 <devintr+0x62>
      virtio_disk_intr();
    8000279e:	404030ef          	jal	80005ba2 <virtio_disk_intr>
    if(irq)
    800027a2:	a801                	j	800027b2 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800027a4:	85ba                	mv	a1,a4
    800027a6:	00005517          	auipc	a0,0x5
    800027aa:	aaa50513          	addi	a0,a0,-1366 # 80007250 <etext+0x250>
    800027ae:	d4dfd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    800027b2:	8526                	mv	a0,s1
    800027b4:	779020ef          	jal	8000572c <plic_complete>
    return 1;
    800027b8:	4505                	li	a0,1
    800027ba:	64a2                	ld	s1,8(sp)
    800027bc:	bf5d                	j	80002772 <devintr+0x22>
    clockintr();
    800027be:	f3dff0ef          	jal	800026fa <clockintr>
    return 2;
    800027c2:	4509                	li	a0,2
    800027c4:	b77d                	j	80002772 <devintr+0x22>

00000000800027c6 <usertrap>:
{
    800027c6:	1101                	addi	sp,sp,-32
    800027c8:	ec06                	sd	ra,24(sp)
    800027ca:	e822                	sd	s0,16(sp)
    800027cc:	e426                	sd	s1,8(sp)
    800027ce:	e04a                	sd	s2,0(sp)
    800027d0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027d2:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800027d6:	1007f793          	andi	a5,a5,256
    800027da:	eba5                	bnez	a5,8000284a <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800027dc:	00003797          	auipc	a5,0x3
    800027e0:	e8478793          	addi	a5,a5,-380 # 80005660 <kernelvec>
    800027e4:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800027e8:	946ff0ef          	jal	8000192e <myproc>
    800027ec:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800027ee:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027f0:	14102773          	csrr	a4,sepc
    800027f4:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027f6:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800027fa:	47a1                	li	a5,8
    800027fc:	04f70d63          	beq	a4,a5,80002856 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002800:	f51ff0ef          	jal	80002750 <devintr>
    80002804:	892a                	mv	s2,a0
    80002806:	e945                	bnez	a0,800028b6 <usertrap+0xf0>
    80002808:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    8000280c:	47bd                	li	a5,15
    8000280e:	08f70863          	beq	a4,a5,8000289e <usertrap+0xd8>
    80002812:	14202773          	csrr	a4,scause
    80002816:	47b5                	li	a5,13
    80002818:	08f70363          	beq	a4,a5,8000289e <usertrap+0xd8>
    8000281c:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002820:	5c90                	lw	a2,56(s1)
    80002822:	00005517          	auipc	a0,0x5
    80002826:	a6e50513          	addi	a0,a0,-1426 # 80007290 <etext+0x290>
    8000282a:	cd1fd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000282e:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002832:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002836:	00005517          	auipc	a0,0x5
    8000283a:	a8a50513          	addi	a0,a0,-1398 # 800072c0 <etext+0x2c0>
    8000283e:	cbdfd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002842:	8526                	mv	a0,s1
    80002844:	99bff0ef          	jal	800021de <setkilled>
    80002848:	a035                	j	80002874 <usertrap+0xae>
    panic("usertrap: not from user mode");
    8000284a:	00005517          	auipc	a0,0x5
    8000284e:	a2650513          	addi	a0,a0,-1498 # 80007270 <etext+0x270>
    80002852:	fd3fd0ef          	jal	80000824 <panic>
    if(killed(p))
    80002856:	9adff0ef          	jal	80002202 <killed>
    8000285a:	ed15                	bnez	a0,80002896 <usertrap+0xd0>
    p->trapframe->epc += 4;
    8000285c:	70b8                	ld	a4,96(s1)
    8000285e:	6f1c                	ld	a5,24(a4)
    80002860:	0791                	addi	a5,a5,4
    80002862:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002864:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002868:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000286c:	10079073          	csrw	sstatus,a5
    syscall();
    80002870:	240000ef          	jal	80002ab0 <syscall>
  if(killed(p))
    80002874:	8526                	mv	a0,s1
    80002876:	98dff0ef          	jal	80002202 <killed>
    8000287a:	e139                	bnez	a0,800028c0 <usertrap+0xfa>
  prepare_return();
    8000287c:	e05ff0ef          	jal	80002680 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002880:	6ca8                	ld	a0,88(s1)
    80002882:	8131                	srli	a0,a0,0xc
    80002884:	57fd                	li	a5,-1
    80002886:	17fe                	slli	a5,a5,0x3f
    80002888:	8d5d                	or	a0,a0,a5
}
    8000288a:	60e2                	ld	ra,24(sp)
    8000288c:	6442                	ld	s0,16(sp)
    8000288e:	64a2                	ld	s1,8(sp)
    80002890:	6902                	ld	s2,0(sp)
    80002892:	6105                	addi	sp,sp,32
    80002894:	8082                	ret
      kexit(-1);
    80002896:	557d                	li	a0,-1
    80002898:	83bff0ef          	jal	800020d2 <kexit>
    8000289c:	b7c1                	j	8000285c <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000289e:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028a2:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800028a6:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    800028a8:	00163613          	seqz	a2,a2
    800028ac:	6ca8                	ld	a0,88(s1)
    800028ae:	d23fe0ef          	jal	800015d0 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800028b2:	f169                	bnez	a0,80002874 <usertrap+0xae>
    800028b4:	b7a5                	j	8000281c <usertrap+0x56>
  if(killed(p))
    800028b6:	8526                	mv	a0,s1
    800028b8:	94bff0ef          	jal	80002202 <killed>
    800028bc:	c511                	beqz	a0,800028c8 <usertrap+0x102>
    800028be:	a011                	j	800028c2 <usertrap+0xfc>
    800028c0:	4901                	li	s2,0
    kexit(-1);
    800028c2:	557d                	li	a0,-1
    800028c4:	80fff0ef          	jal	800020d2 <kexit>
  if(which_dev == 2)
    800028c8:	4789                	li	a5,2
    800028ca:	faf919e3          	bne	s2,a5,8000287c <usertrap+0xb6>
    yield();
    800028ce:	eccff0ef          	jal	80001f9a <yield>
    800028d2:	b76d                	j	8000287c <usertrap+0xb6>

00000000800028d4 <kerneltrap>:
{
    800028d4:	7179                	addi	sp,sp,-48
    800028d6:	f406                	sd	ra,40(sp)
    800028d8:	f022                	sd	s0,32(sp)
    800028da:	ec26                	sd	s1,24(sp)
    800028dc:	e84a                	sd	s2,16(sp)
    800028de:	e44e                	sd	s3,8(sp)
    800028e0:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028e2:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028e6:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028ea:	142027f3          	csrr	a5,scause
    800028ee:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    800028f0:	1004f793          	andi	a5,s1,256
    800028f4:	c795                	beqz	a5,80002920 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028f6:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800028fa:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800028fc:	eb85                	bnez	a5,8000292c <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    800028fe:	e53ff0ef          	jal	80002750 <devintr>
    80002902:	c91d                	beqz	a0,80002938 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002904:	4789                	li	a5,2
    80002906:	04f50a63          	beq	a0,a5,8000295a <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000290a:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000290e:	10049073          	csrw	sstatus,s1
}
    80002912:	70a2                	ld	ra,40(sp)
    80002914:	7402                	ld	s0,32(sp)
    80002916:	64e2                	ld	s1,24(sp)
    80002918:	6942                	ld	s2,16(sp)
    8000291a:	69a2                	ld	s3,8(sp)
    8000291c:	6145                	addi	sp,sp,48
    8000291e:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002920:	00005517          	auipc	a0,0x5
    80002924:	9c850513          	addi	a0,a0,-1592 # 800072e8 <etext+0x2e8>
    80002928:	efdfd0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    8000292c:	00005517          	auipc	a0,0x5
    80002930:	9e450513          	addi	a0,a0,-1564 # 80007310 <etext+0x310>
    80002934:	ef1fd0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002938:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000293c:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002940:	85ce                	mv	a1,s3
    80002942:	00005517          	auipc	a0,0x5
    80002946:	9ee50513          	addi	a0,a0,-1554 # 80007330 <etext+0x330>
    8000294a:	bb1fd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    8000294e:	00005517          	auipc	a0,0x5
    80002952:	a0a50513          	addi	a0,a0,-1526 # 80007358 <etext+0x358>
    80002956:	ecffd0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    8000295a:	fd5fe0ef          	jal	8000192e <myproc>
    8000295e:	d555                	beqz	a0,8000290a <kerneltrap+0x36>
    yield();
    80002960:	e3aff0ef          	jal	80001f9a <yield>
    80002964:	b75d                	j	8000290a <kerneltrap+0x36>

0000000080002966 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002966:	1101                	addi	sp,sp,-32
    80002968:	ec06                	sd	ra,24(sp)
    8000296a:	e822                	sd	s0,16(sp)
    8000296c:	e426                	sd	s1,8(sp)
    8000296e:	1000                	addi	s0,sp,32
    80002970:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002972:	fbdfe0ef          	jal	8000192e <myproc>
  switch (n) {
    80002976:	4795                	li	a5,5
    80002978:	0497e163          	bltu	a5,s1,800029ba <argraw+0x54>
    8000297c:	048a                	slli	s1,s1,0x2
    8000297e:	00005717          	auipc	a4,0x5
    80002982:	dda70713          	addi	a4,a4,-550 # 80007758 <states.0+0x30>
    80002986:	94ba                	add	s1,s1,a4
    80002988:	409c                	lw	a5,0(s1)
    8000298a:	97ba                	add	a5,a5,a4
    8000298c:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000298e:	713c                	ld	a5,96(a0)
    80002990:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002992:	60e2                	ld	ra,24(sp)
    80002994:	6442                	ld	s0,16(sp)
    80002996:	64a2                	ld	s1,8(sp)
    80002998:	6105                	addi	sp,sp,32
    8000299a:	8082                	ret
    return p->trapframe->a1;
    8000299c:	713c                	ld	a5,96(a0)
    8000299e:	7fa8                	ld	a0,120(a5)
    800029a0:	bfcd                	j	80002992 <argraw+0x2c>
    return p->trapframe->a2;
    800029a2:	713c                	ld	a5,96(a0)
    800029a4:	63c8                	ld	a0,128(a5)
    800029a6:	b7f5                	j	80002992 <argraw+0x2c>
    return p->trapframe->a3;
    800029a8:	713c                	ld	a5,96(a0)
    800029aa:	67c8                	ld	a0,136(a5)
    800029ac:	b7dd                	j	80002992 <argraw+0x2c>
    return p->trapframe->a4;
    800029ae:	713c                	ld	a5,96(a0)
    800029b0:	6bc8                	ld	a0,144(a5)
    800029b2:	b7c5                	j	80002992 <argraw+0x2c>
    return p->trapframe->a5;
    800029b4:	713c                	ld	a5,96(a0)
    800029b6:	6fc8                	ld	a0,152(a5)
    800029b8:	bfe9                	j	80002992 <argraw+0x2c>
  panic("argraw");
    800029ba:	00005517          	auipc	a0,0x5
    800029be:	9ae50513          	addi	a0,a0,-1618 # 80007368 <etext+0x368>
    800029c2:	e63fd0ef          	jal	80000824 <panic>

00000000800029c6 <fetchaddr>:
{
    800029c6:	1101                	addi	sp,sp,-32
    800029c8:	ec06                	sd	ra,24(sp)
    800029ca:	e822                	sd	s0,16(sp)
    800029cc:	e426                	sd	s1,8(sp)
    800029ce:	e04a                	sd	s2,0(sp)
    800029d0:	1000                	addi	s0,sp,32
    800029d2:	84aa                	mv	s1,a0
    800029d4:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800029d6:	f59fe0ef          	jal	8000192e <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800029da:	693c                	ld	a5,80(a0)
    800029dc:	02f4f663          	bgeu	s1,a5,80002a08 <fetchaddr+0x42>
    800029e0:	00848713          	addi	a4,s1,8
    800029e4:	02e7e463          	bltu	a5,a4,80002a0c <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    800029e8:	46a1                	li	a3,8
    800029ea:	8626                	mv	a2,s1
    800029ec:	85ca                	mv	a1,s2
    800029ee:	6d28                	ld	a0,88(a0)
    800029f0:	d23fe0ef          	jal	80001712 <copyin>
    800029f4:	00a03533          	snez	a0,a0
    800029f8:	40a0053b          	negw	a0,a0
}
    800029fc:	60e2                	ld	ra,24(sp)
    800029fe:	6442                	ld	s0,16(sp)
    80002a00:	64a2                	ld	s1,8(sp)
    80002a02:	6902                	ld	s2,0(sp)
    80002a04:	6105                	addi	sp,sp,32
    80002a06:	8082                	ret
    return -1;
    80002a08:	557d                	li	a0,-1
    80002a0a:	bfcd                	j	800029fc <fetchaddr+0x36>
    80002a0c:	557d                	li	a0,-1
    80002a0e:	b7fd                	j	800029fc <fetchaddr+0x36>

0000000080002a10 <fetchstr>:
{
    80002a10:	7179                	addi	sp,sp,-48
    80002a12:	f406                	sd	ra,40(sp)
    80002a14:	f022                	sd	s0,32(sp)
    80002a16:	ec26                	sd	s1,24(sp)
    80002a18:	e84a                	sd	s2,16(sp)
    80002a1a:	e44e                	sd	s3,8(sp)
    80002a1c:	1800                	addi	s0,sp,48
    80002a1e:	89aa                	mv	s3,a0
    80002a20:	84ae                	mv	s1,a1
    80002a22:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002a24:	f0bfe0ef          	jal	8000192e <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002a28:	86ca                	mv	a3,s2
    80002a2a:	864e                	mv	a2,s3
    80002a2c:	85a6                	mv	a1,s1
    80002a2e:	6d28                	ld	a0,88(a0)
    80002a30:	ac9fe0ef          	jal	800014f8 <copyinstr>
    80002a34:	00054c63          	bltz	a0,80002a4c <fetchstr+0x3c>
  return strlen(buf);
    80002a38:	8526                	mv	a0,s1
    80002a3a:	c48fe0ef          	jal	80000e82 <strlen>
}
    80002a3e:	70a2                	ld	ra,40(sp)
    80002a40:	7402                	ld	s0,32(sp)
    80002a42:	64e2                	ld	s1,24(sp)
    80002a44:	6942                	ld	s2,16(sp)
    80002a46:	69a2                	ld	s3,8(sp)
    80002a48:	6145                	addi	sp,sp,48
    80002a4a:	8082                	ret
    return -1;
    80002a4c:	557d                	li	a0,-1
    80002a4e:	bfc5                	j	80002a3e <fetchstr+0x2e>

0000000080002a50 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002a50:	1101                	addi	sp,sp,-32
    80002a52:	ec06                	sd	ra,24(sp)
    80002a54:	e822                	sd	s0,16(sp)
    80002a56:	e426                	sd	s1,8(sp)
    80002a58:	1000                	addi	s0,sp,32
    80002a5a:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a5c:	f0bff0ef          	jal	80002966 <argraw>
    80002a60:	c088                	sw	a0,0(s1)
}
    80002a62:	60e2                	ld	ra,24(sp)
    80002a64:	6442                	ld	s0,16(sp)
    80002a66:	64a2                	ld	s1,8(sp)
    80002a68:	6105                	addi	sp,sp,32
    80002a6a:	8082                	ret

0000000080002a6c <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002a6c:	1101                	addi	sp,sp,-32
    80002a6e:	ec06                	sd	ra,24(sp)
    80002a70:	e822                	sd	s0,16(sp)
    80002a72:	e426                	sd	s1,8(sp)
    80002a74:	1000                	addi	s0,sp,32
    80002a76:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a78:	eefff0ef          	jal	80002966 <argraw>
    80002a7c:	e088                	sd	a0,0(s1)
}
    80002a7e:	60e2                	ld	ra,24(sp)
    80002a80:	6442                	ld	s0,16(sp)
    80002a82:	64a2                	ld	s1,8(sp)
    80002a84:	6105                	addi	sp,sp,32
    80002a86:	8082                	ret

0000000080002a88 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002a88:	1101                	addi	sp,sp,-32
    80002a8a:	ec06                	sd	ra,24(sp)
    80002a8c:	e822                	sd	s0,16(sp)
    80002a8e:	e426                	sd	s1,8(sp)
    80002a90:	e04a                	sd	s2,0(sp)
    80002a92:	1000                	addi	s0,sp,32
    80002a94:	892e                	mv	s2,a1
    80002a96:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002a98:	ecfff0ef          	jal	80002966 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002a9c:	8626                	mv	a2,s1
    80002a9e:	85ca                	mv	a1,s2
    80002aa0:	f71ff0ef          	jal	80002a10 <fetchstr>
}
    80002aa4:	60e2                	ld	ra,24(sp)
    80002aa6:	6442                	ld	s0,16(sp)
    80002aa8:	64a2                	ld	s1,8(sp)
    80002aaa:	6902                	ld	s2,0(sp)
    80002aac:	6105                	addi	sp,sp,32
    80002aae:	8082                	ret

0000000080002ab0 <syscall>:
[SYS_setStride] sys_setStride,
};

void
syscall(void)
{
    80002ab0:	1101                	addi	sp,sp,-32
    80002ab2:	ec06                	sd	ra,24(sp)
    80002ab4:	e822                	sd	s0,16(sp)
    80002ab6:	e426                	sd	s1,8(sp)
    80002ab8:	e04a                	sd	s2,0(sp)
    80002aba:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002abc:	e73fe0ef          	jal	8000192e <myproc>
    80002ac0:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002ac2:	06053903          	ld	s2,96(a0)
    80002ac6:	0a893783          	ld	a5,168(s2)
    80002aca:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002ace:	37fd                	addiw	a5,a5,-1
    80002ad0:	475d                	li	a4,23
    80002ad2:	00f76f63          	bltu	a4,a5,80002af0 <syscall+0x40>
    80002ad6:	00369713          	slli	a4,a3,0x3
    80002ada:	00005797          	auipc	a5,0x5
    80002ade:	c9678793          	addi	a5,a5,-874 # 80007770 <syscalls>
    80002ae2:	97ba                	add	a5,a5,a4
    80002ae4:	639c                	ld	a5,0(a5)
    80002ae6:	c789                	beqz	a5,80002af0 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002ae8:	9782                	jalr	a5
    80002aea:	06a93823          	sd	a0,112(s2)
    80002aee:	a829                	j	80002b08 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002af0:	16048613          	addi	a2,s1,352
    80002af4:	5c8c                	lw	a1,56(s1)
    80002af6:	00005517          	auipc	a0,0x5
    80002afa:	87a50513          	addi	a0,a0,-1926 # 80007370 <etext+0x370>
    80002afe:	9fdfd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002b02:	70bc                	ld	a5,96(s1)
    80002b04:	577d                	li	a4,-1
    80002b06:	fbb8                	sd	a4,112(a5)
  }
}
    80002b08:	60e2                	ld	ra,24(sp)
    80002b0a:	6442                	ld	s0,16(sp)
    80002b0c:	64a2                	ld	s1,8(sp)
    80002b0e:	6902                	ld	s2,0(sp)
    80002b10:	6105                	addi	sp,sp,32
    80002b12:	8082                	ret

0000000080002b14 <sys_exit>:
#include "vm.h"
#include "pstat.h"

uint64
sys_exit(void)
{
    80002b14:	1101                	addi	sp,sp,-32
    80002b16:	ec06                	sd	ra,24(sp)
    80002b18:	e822                	sd	s0,16(sp)
    80002b1a:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002b1c:	fec40593          	addi	a1,s0,-20
    80002b20:	4501                	li	a0,0
    80002b22:	f2fff0ef          	jal	80002a50 <argint>
  kexit(n);
    80002b26:	fec42503          	lw	a0,-20(s0)
    80002b2a:	da8ff0ef          	jal	800020d2 <kexit>
  return 0;  // not reached
}
    80002b2e:	4501                	li	a0,0
    80002b30:	60e2                	ld	ra,24(sp)
    80002b32:	6442                	ld	s0,16(sp)
    80002b34:	6105                	addi	sp,sp,32
    80002b36:	8082                	ret

0000000080002b38 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002b38:	1141                	addi	sp,sp,-16
    80002b3a:	e406                	sd	ra,8(sp)
    80002b3c:	e022                	sd	s0,0(sp)
    80002b3e:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002b40:	deffe0ef          	jal	8000192e <myproc>
}
    80002b44:	5d08                	lw	a0,56(a0)
    80002b46:	60a2                	ld	ra,8(sp)
    80002b48:	6402                	ld	s0,0(sp)
    80002b4a:	0141                	addi	sp,sp,16
    80002b4c:	8082                	ret

0000000080002b4e <sys_fork>:

uint64
sys_fork(void)
{
    80002b4e:	1141                	addi	sp,sp,-16
    80002b50:	e406                	sd	ra,8(sp)
    80002b52:	e022                	sd	s0,0(sp)
    80002b54:	0800                	addi	s0,sp,16
  return kfork();
    80002b56:	93cff0ef          	jal	80001c92 <kfork>
}
    80002b5a:	60a2                	ld	ra,8(sp)
    80002b5c:	6402                	ld	s0,0(sp)
    80002b5e:	0141                	addi	sp,sp,16
    80002b60:	8082                	ret

0000000080002b62 <sys_wait>:

uint64
sys_wait(void)
{
    80002b62:	1101                	addi	sp,sp,-32
    80002b64:	ec06                	sd	ra,24(sp)
    80002b66:	e822                	sd	s0,16(sp)
    80002b68:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002b6a:	fe840593          	addi	a1,s0,-24
    80002b6e:	4501                	li	a0,0
    80002b70:	efdff0ef          	jal	80002a6c <argaddr>
  return kwait(p);
    80002b74:	fe843503          	ld	a0,-24(s0)
    80002b78:	eb4ff0ef          	jal	8000222c <kwait>
}
    80002b7c:	60e2                	ld	ra,24(sp)
    80002b7e:	6442                	ld	s0,16(sp)
    80002b80:	6105                	addi	sp,sp,32
    80002b82:	8082                	ret

0000000080002b84 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002b84:	7179                	addi	sp,sp,-48
    80002b86:	f406                	sd	ra,40(sp)
    80002b88:	f022                	sd	s0,32(sp)
    80002b8a:	ec26                	sd	s1,24(sp)
    80002b8c:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002b8e:	fd840593          	addi	a1,s0,-40
    80002b92:	4501                	li	a0,0
    80002b94:	ebdff0ef          	jal	80002a50 <argint>
  argint(1, &t);
    80002b98:	fdc40593          	addi	a1,s0,-36
    80002b9c:	4505                	li	a0,1
    80002b9e:	eb3ff0ef          	jal	80002a50 <argint>
  addr = myproc()->sz;
    80002ba2:	d8dfe0ef          	jal	8000192e <myproc>
    80002ba6:	6924                	ld	s1,80(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002ba8:	fdc42703          	lw	a4,-36(s0)
    80002bac:	4785                	li	a5,1
    80002bae:	02f70163          	beq	a4,a5,80002bd0 <sys_sbrk+0x4c>
    80002bb2:	fd842783          	lw	a5,-40(s0)
    80002bb6:	0007cd63          	bltz	a5,80002bd0 <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002bba:	97a6                	add	a5,a5,s1
    80002bbc:	0297e863          	bltu	a5,s1,80002bec <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002bc0:	d6ffe0ef          	jal	8000192e <myproc>
    80002bc4:	fd842703          	lw	a4,-40(s0)
    80002bc8:	693c                	ld	a5,80(a0)
    80002bca:	97ba                	add	a5,a5,a4
    80002bcc:	e93c                	sd	a5,80(a0)
    80002bce:	a039                	j	80002bdc <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002bd0:	fd842503          	lw	a0,-40(s0)
    80002bd4:	86eff0ef          	jal	80001c42 <growproc>
    80002bd8:	00054863          	bltz	a0,80002be8 <sys_sbrk+0x64>
  }
  return addr;
}
    80002bdc:	8526                	mv	a0,s1
    80002bde:	70a2                	ld	ra,40(sp)
    80002be0:	7402                	ld	s0,32(sp)
    80002be2:	64e2                	ld	s1,24(sp)
    80002be4:	6145                	addi	sp,sp,48
    80002be6:	8082                	ret
      return -1;
    80002be8:	54fd                	li	s1,-1
    80002bea:	bfcd                	j	80002bdc <sys_sbrk+0x58>
      return -1;
    80002bec:	54fd                	li	s1,-1
    80002bee:	b7fd                	j	80002bdc <sys_sbrk+0x58>

0000000080002bf0 <sys_pause>:

uint64
sys_pause(void)
{
    80002bf0:	7139                	addi	sp,sp,-64
    80002bf2:	fc06                	sd	ra,56(sp)
    80002bf4:	f822                	sd	s0,48(sp)
    80002bf6:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002bf8:	fcc40593          	addi	a1,s0,-52
    80002bfc:	4501                	li	a0,0
    80002bfe:	e53ff0ef          	jal	80002a50 <argint>
  if(n < 0)
    80002c02:	fcc42783          	lw	a5,-52(s0)
    80002c06:	0607c863          	bltz	a5,80002c76 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002c0a:	00013517          	auipc	a0,0x13
    80002c0e:	dae50513          	addi	a0,a0,-594 # 800159b8 <tickslock>
    80002c12:	816fe0ef          	jal	80000c28 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002c16:	fcc42783          	lw	a5,-52(s0)
    80002c1a:	c3b9                	beqz	a5,80002c60 <sys_pause+0x70>
    80002c1c:	f426                	sd	s1,40(sp)
    80002c1e:	f04a                	sd	s2,32(sp)
    80002c20:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002c22:	00005997          	auipc	s3,0x5
    80002c26:	c5e9a983          	lw	s3,-930(s3) # 80007880 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002c2a:	00013917          	auipc	s2,0x13
    80002c2e:	d8e90913          	addi	s2,s2,-626 # 800159b8 <tickslock>
    80002c32:	00005497          	auipc	s1,0x5
    80002c36:	c4e48493          	addi	s1,s1,-946 # 80007880 <ticks>
    if(killed(myproc())){
    80002c3a:	cf5fe0ef          	jal	8000192e <myproc>
    80002c3e:	dc4ff0ef          	jal	80002202 <killed>
    80002c42:	ed0d                	bnez	a0,80002c7c <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002c44:	85ca                	mv	a1,s2
    80002c46:	8526                	mv	a0,s1
    80002c48:	b7eff0ef          	jal	80001fc6 <sleep>
  while(ticks - ticks0 < n){
    80002c4c:	409c                	lw	a5,0(s1)
    80002c4e:	413787bb          	subw	a5,a5,s3
    80002c52:	fcc42703          	lw	a4,-52(s0)
    80002c56:	fee7e2e3          	bltu	a5,a4,80002c3a <sys_pause+0x4a>
    80002c5a:	74a2                	ld	s1,40(sp)
    80002c5c:	7902                	ld	s2,32(sp)
    80002c5e:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002c60:	00013517          	auipc	a0,0x13
    80002c64:	d5850513          	addi	a0,a0,-680 # 800159b8 <tickslock>
    80002c68:	854fe0ef          	jal	80000cbc <release>
  return 0;
    80002c6c:	4501                	li	a0,0
}
    80002c6e:	70e2                	ld	ra,56(sp)
    80002c70:	7442                	ld	s0,48(sp)
    80002c72:	6121                	addi	sp,sp,64
    80002c74:	8082                	ret
    n = 0;
    80002c76:	fc042623          	sw	zero,-52(s0)
    80002c7a:	bf41                	j	80002c0a <sys_pause+0x1a>
      release(&tickslock);
    80002c7c:	00013517          	auipc	a0,0x13
    80002c80:	d3c50513          	addi	a0,a0,-708 # 800159b8 <tickslock>
    80002c84:	838fe0ef          	jal	80000cbc <release>
      return -1;
    80002c88:	557d                	li	a0,-1
    80002c8a:	74a2                	ld	s1,40(sp)
    80002c8c:	7902                	ld	s2,32(sp)
    80002c8e:	69e2                	ld	s3,24(sp)
    80002c90:	bff9                	j	80002c6e <sys_pause+0x7e>

0000000080002c92 <sys_kill>:

uint64
sys_kill(void)
{
    80002c92:	1101                	addi	sp,sp,-32
    80002c94:	ec06                	sd	ra,24(sp)
    80002c96:	e822                	sd	s0,16(sp)
    80002c98:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002c9a:	fec40593          	addi	a1,s0,-20
    80002c9e:	4501                	li	a0,0
    80002ca0:	db1ff0ef          	jal	80002a50 <argint>
  return kkill(pid);
    80002ca4:	fec42503          	lw	a0,-20(s0)
    80002ca8:	cd0ff0ef          	jal	80002178 <kkill>
}
    80002cac:	60e2                	ld	ra,24(sp)
    80002cae:	6442                	ld	s0,16(sp)
    80002cb0:	6105                	addi	sp,sp,32
    80002cb2:	8082                	ret

0000000080002cb4 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002cb4:	1101                	addi	sp,sp,-32
    80002cb6:	ec06                	sd	ra,24(sp)
    80002cb8:	e822                	sd	s0,16(sp)
    80002cba:	e426                	sd	s1,8(sp)
    80002cbc:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002cbe:	00013517          	auipc	a0,0x13
    80002cc2:	cfa50513          	addi	a0,a0,-774 # 800159b8 <tickslock>
    80002cc6:	f63fd0ef          	jal	80000c28 <acquire>
  xticks = ticks;
    80002cca:	00005797          	auipc	a5,0x5
    80002cce:	bb67a783          	lw	a5,-1098(a5) # 80007880 <ticks>
    80002cd2:	84be                	mv	s1,a5
  release(&tickslock);
    80002cd4:	00013517          	auipc	a0,0x13
    80002cd8:	ce450513          	addi	a0,a0,-796 # 800159b8 <tickslock>
    80002cdc:	fe1fd0ef          	jal	80000cbc <release>
  return xticks;
}
    80002ce0:	02049513          	slli	a0,s1,0x20
    80002ce4:	9101                	srli	a0,a0,0x20
    80002ce6:	60e2                	ld	ra,24(sp)
    80002ce8:	6442                	ld	s0,16(sp)
    80002cea:	64a2                	ld	s1,8(sp)
    80002cec:	6105                	addi	sp,sp,32
    80002cee:	8082                	ret

0000000080002cf0 <sys_getfilenum>:

uint64 
sys_getfilenum(void){
    80002cf0:	1101                	addi	sp,sp,-32
    80002cf2:	ec06                	sd	ra,24(sp)
    80002cf4:	e822                	sd	s0,16(sp)
    80002cf6:	1000                	addi	s0,sp,32
  int pid;
  argint(0,&pid);
    80002cf8:	fec40593          	addi	a1,s0,-20
    80002cfc:	4501                	li	a0,0
    80002cfe:	d53ff0ef          	jal	80002a50 <argint>
  return 0;
}
    80002d02:	4501                	li	a0,0
    80002d04:	60e2                	ld	ra,24(sp)
    80002d06:	6442                	ld	s0,16(sp)
    80002d08:	6105                	addi	sp,sp,32
    80002d0a:	8082                	ret

0000000080002d0c <sys_getpinfo>:

uint64
sys_getpinfo(void)
{
    80002d0c:	1101                	addi	sp,sp,-32
    80002d0e:	ec06                	sd	ra,24(sp)
    80002d10:	e822                	sd	s0,16(sp)
    80002d12:	1000                	addi	s0,sp,32
    uint64 uaddr;
    argaddr(0, &uaddr);   
    80002d14:	fe840593          	addi	a1,s0,-24
    80002d18:	4501                	li	a0,0
    80002d1a:	d53ff0ef          	jal	80002a6c <argaddr>
    return getpinfo((struct pstat *)uaddr);
    80002d1e:	fe843503          	ld	a0,-24(s0)
    80002d22:	fa4ff0ef          	jal	800024c6 <getpinfo>
}
    80002d26:	60e2                	ld	ra,24(sp)
    80002d28:	6442                	ld	s0,16(sp)
    80002d2a:	6105                	addi	sp,sp,32
    80002d2c:	8082                	ret

0000000080002d2e <sys_setStride>:

uint64
sys_setStride(void)
{
    80002d2e:	1101                	addi	sp,sp,-32
    80002d30:	ec06                	sd	ra,24(sp)
    80002d32:	e822                	sd	s0,16(sp)
    80002d34:	1000                	addi	s0,sp,32
    int strideLength;
    argint(0, &strideLength);  
    80002d36:	fec40593          	addi	a1,s0,-20
    80002d3a:	4501                	li	a0,0
    80002d3c:	d15ff0ef          	jal	80002a50 <argint>
    return setStride(strideLength);
    80002d40:	fec42503          	lw	a0,-20(s0)
    80002d44:	85bff0ef          	jal	8000259e <setStride>
}
    80002d48:	60e2                	ld	ra,24(sp)
    80002d4a:	6442                	ld	s0,16(sp)
    80002d4c:	6105                	addi	sp,sp,32
    80002d4e:	8082                	ret

0000000080002d50 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002d50:	7179                	addi	sp,sp,-48
    80002d52:	f406                	sd	ra,40(sp)
    80002d54:	f022                	sd	s0,32(sp)
    80002d56:	ec26                	sd	s1,24(sp)
    80002d58:	e84a                	sd	s2,16(sp)
    80002d5a:	e44e                	sd	s3,8(sp)
    80002d5c:	e052                	sd	s4,0(sp)
    80002d5e:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002d60:	00004597          	auipc	a1,0x4
    80002d64:	63058593          	addi	a1,a1,1584 # 80007390 <etext+0x390>
    80002d68:	00013517          	auipc	a0,0x13
    80002d6c:	c6850513          	addi	a0,a0,-920 # 800159d0 <bcache>
    80002d70:	e2ffd0ef          	jal	80000b9e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002d74:	0001b797          	auipc	a5,0x1b
    80002d78:	c5c78793          	addi	a5,a5,-932 # 8001d9d0 <bcache+0x8000>
    80002d7c:	0001b717          	auipc	a4,0x1b
    80002d80:	ebc70713          	addi	a4,a4,-324 # 8001dc38 <bcache+0x8268>
    80002d84:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002d88:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002d8c:	00013497          	auipc	s1,0x13
    80002d90:	c5c48493          	addi	s1,s1,-932 # 800159e8 <bcache+0x18>
    b->next = bcache.head.next;
    80002d94:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002d96:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002d98:	00004a17          	auipc	s4,0x4
    80002d9c:	600a0a13          	addi	s4,s4,1536 # 80007398 <etext+0x398>
    b->next = bcache.head.next;
    80002da0:	2b893783          	ld	a5,696(s2)
    80002da4:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002da6:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002daa:	85d2                	mv	a1,s4
    80002dac:	01048513          	addi	a0,s1,16
    80002db0:	328010ef          	jal	800040d8 <initsleeplock>
    bcache.head.next->prev = b;
    80002db4:	2b893783          	ld	a5,696(s2)
    80002db8:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002dba:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002dbe:	45848493          	addi	s1,s1,1112
    80002dc2:	fd349fe3          	bne	s1,s3,80002da0 <binit+0x50>
  }
}
    80002dc6:	70a2                	ld	ra,40(sp)
    80002dc8:	7402                	ld	s0,32(sp)
    80002dca:	64e2                	ld	s1,24(sp)
    80002dcc:	6942                	ld	s2,16(sp)
    80002dce:	69a2                	ld	s3,8(sp)
    80002dd0:	6a02                	ld	s4,0(sp)
    80002dd2:	6145                	addi	sp,sp,48
    80002dd4:	8082                	ret

0000000080002dd6 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002dd6:	7179                	addi	sp,sp,-48
    80002dd8:	f406                	sd	ra,40(sp)
    80002dda:	f022                	sd	s0,32(sp)
    80002ddc:	ec26                	sd	s1,24(sp)
    80002dde:	e84a                	sd	s2,16(sp)
    80002de0:	e44e                	sd	s3,8(sp)
    80002de2:	1800                	addi	s0,sp,48
    80002de4:	892a                	mv	s2,a0
    80002de6:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002de8:	00013517          	auipc	a0,0x13
    80002dec:	be850513          	addi	a0,a0,-1048 # 800159d0 <bcache>
    80002df0:	e39fd0ef          	jal	80000c28 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002df4:	0001b497          	auipc	s1,0x1b
    80002df8:	e944b483          	ld	s1,-364(s1) # 8001dc88 <bcache+0x82b8>
    80002dfc:	0001b797          	auipc	a5,0x1b
    80002e00:	e3c78793          	addi	a5,a5,-452 # 8001dc38 <bcache+0x8268>
    80002e04:	02f48b63          	beq	s1,a5,80002e3a <bread+0x64>
    80002e08:	873e                	mv	a4,a5
    80002e0a:	a021                	j	80002e12 <bread+0x3c>
    80002e0c:	68a4                	ld	s1,80(s1)
    80002e0e:	02e48663          	beq	s1,a4,80002e3a <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002e12:	449c                	lw	a5,8(s1)
    80002e14:	ff279ce3          	bne	a5,s2,80002e0c <bread+0x36>
    80002e18:	44dc                	lw	a5,12(s1)
    80002e1a:	ff3799e3          	bne	a5,s3,80002e0c <bread+0x36>
      b->refcnt++;
    80002e1e:	40bc                	lw	a5,64(s1)
    80002e20:	2785                	addiw	a5,a5,1
    80002e22:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e24:	00013517          	auipc	a0,0x13
    80002e28:	bac50513          	addi	a0,a0,-1108 # 800159d0 <bcache>
    80002e2c:	e91fd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002e30:	01048513          	addi	a0,s1,16
    80002e34:	2da010ef          	jal	8000410e <acquiresleep>
      return b;
    80002e38:	a889                	j	80002e8a <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002e3a:	0001b497          	auipc	s1,0x1b
    80002e3e:	e464b483          	ld	s1,-442(s1) # 8001dc80 <bcache+0x82b0>
    80002e42:	0001b797          	auipc	a5,0x1b
    80002e46:	df678793          	addi	a5,a5,-522 # 8001dc38 <bcache+0x8268>
    80002e4a:	00f48863          	beq	s1,a5,80002e5a <bread+0x84>
    80002e4e:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002e50:	40bc                	lw	a5,64(s1)
    80002e52:	cb91                	beqz	a5,80002e66 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002e54:	64a4                	ld	s1,72(s1)
    80002e56:	fee49de3          	bne	s1,a4,80002e50 <bread+0x7a>
  panic("bget: no buffers");
    80002e5a:	00004517          	auipc	a0,0x4
    80002e5e:	54650513          	addi	a0,a0,1350 # 800073a0 <etext+0x3a0>
    80002e62:	9c3fd0ef          	jal	80000824 <panic>
      b->dev = dev;
    80002e66:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002e6a:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002e6e:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002e72:	4785                	li	a5,1
    80002e74:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e76:	00013517          	auipc	a0,0x13
    80002e7a:	b5a50513          	addi	a0,a0,-1190 # 800159d0 <bcache>
    80002e7e:	e3ffd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002e82:	01048513          	addi	a0,s1,16
    80002e86:	288010ef          	jal	8000410e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002e8a:	409c                	lw	a5,0(s1)
    80002e8c:	cb89                	beqz	a5,80002e9e <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002e8e:	8526                	mv	a0,s1
    80002e90:	70a2                	ld	ra,40(sp)
    80002e92:	7402                	ld	s0,32(sp)
    80002e94:	64e2                	ld	s1,24(sp)
    80002e96:	6942                	ld	s2,16(sp)
    80002e98:	69a2                	ld	s3,8(sp)
    80002e9a:	6145                	addi	sp,sp,48
    80002e9c:	8082                	ret
    virtio_disk_rw(b, 0);
    80002e9e:	4581                	li	a1,0
    80002ea0:	8526                	mv	a0,s1
    80002ea2:	2ef020ef          	jal	80005990 <virtio_disk_rw>
    b->valid = 1;
    80002ea6:	4785                	li	a5,1
    80002ea8:	c09c                	sw	a5,0(s1)
  return b;
    80002eaa:	b7d5                	j	80002e8e <bread+0xb8>

0000000080002eac <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002eac:	1101                	addi	sp,sp,-32
    80002eae:	ec06                	sd	ra,24(sp)
    80002eb0:	e822                	sd	s0,16(sp)
    80002eb2:	e426                	sd	s1,8(sp)
    80002eb4:	1000                	addi	s0,sp,32
    80002eb6:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002eb8:	0541                	addi	a0,a0,16
    80002eba:	2d2010ef          	jal	8000418c <holdingsleep>
    80002ebe:	c911                	beqz	a0,80002ed2 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002ec0:	4585                	li	a1,1
    80002ec2:	8526                	mv	a0,s1
    80002ec4:	2cd020ef          	jal	80005990 <virtio_disk_rw>
}
    80002ec8:	60e2                	ld	ra,24(sp)
    80002eca:	6442                	ld	s0,16(sp)
    80002ecc:	64a2                	ld	s1,8(sp)
    80002ece:	6105                	addi	sp,sp,32
    80002ed0:	8082                	ret
    panic("bwrite");
    80002ed2:	00004517          	auipc	a0,0x4
    80002ed6:	4e650513          	addi	a0,a0,1254 # 800073b8 <etext+0x3b8>
    80002eda:	94bfd0ef          	jal	80000824 <panic>

0000000080002ede <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002ede:	1101                	addi	sp,sp,-32
    80002ee0:	ec06                	sd	ra,24(sp)
    80002ee2:	e822                	sd	s0,16(sp)
    80002ee4:	e426                	sd	s1,8(sp)
    80002ee6:	e04a                	sd	s2,0(sp)
    80002ee8:	1000                	addi	s0,sp,32
    80002eea:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002eec:	01050913          	addi	s2,a0,16
    80002ef0:	854a                	mv	a0,s2
    80002ef2:	29a010ef          	jal	8000418c <holdingsleep>
    80002ef6:	c125                	beqz	a0,80002f56 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002ef8:	854a                	mv	a0,s2
    80002efa:	25a010ef          	jal	80004154 <releasesleep>

  acquire(&bcache.lock);
    80002efe:	00013517          	auipc	a0,0x13
    80002f02:	ad250513          	addi	a0,a0,-1326 # 800159d0 <bcache>
    80002f06:	d23fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002f0a:	40bc                	lw	a5,64(s1)
    80002f0c:	37fd                	addiw	a5,a5,-1
    80002f0e:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002f10:	e79d                	bnez	a5,80002f3e <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002f12:	68b8                	ld	a4,80(s1)
    80002f14:	64bc                	ld	a5,72(s1)
    80002f16:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002f18:	68b8                	ld	a4,80(s1)
    80002f1a:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002f1c:	0001b797          	auipc	a5,0x1b
    80002f20:	ab478793          	addi	a5,a5,-1356 # 8001d9d0 <bcache+0x8000>
    80002f24:	2b87b703          	ld	a4,696(a5)
    80002f28:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002f2a:	0001b717          	auipc	a4,0x1b
    80002f2e:	d0e70713          	addi	a4,a4,-754 # 8001dc38 <bcache+0x8268>
    80002f32:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002f34:	2b87b703          	ld	a4,696(a5)
    80002f38:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002f3a:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002f3e:	00013517          	auipc	a0,0x13
    80002f42:	a9250513          	addi	a0,a0,-1390 # 800159d0 <bcache>
    80002f46:	d77fd0ef          	jal	80000cbc <release>
}
    80002f4a:	60e2                	ld	ra,24(sp)
    80002f4c:	6442                	ld	s0,16(sp)
    80002f4e:	64a2                	ld	s1,8(sp)
    80002f50:	6902                	ld	s2,0(sp)
    80002f52:	6105                	addi	sp,sp,32
    80002f54:	8082                	ret
    panic("brelse");
    80002f56:	00004517          	auipc	a0,0x4
    80002f5a:	46a50513          	addi	a0,a0,1130 # 800073c0 <etext+0x3c0>
    80002f5e:	8c7fd0ef          	jal	80000824 <panic>

0000000080002f62 <bpin>:

void
bpin(struct buf *b) {
    80002f62:	1101                	addi	sp,sp,-32
    80002f64:	ec06                	sd	ra,24(sp)
    80002f66:	e822                	sd	s0,16(sp)
    80002f68:	e426                	sd	s1,8(sp)
    80002f6a:	1000                	addi	s0,sp,32
    80002f6c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f6e:	00013517          	auipc	a0,0x13
    80002f72:	a6250513          	addi	a0,a0,-1438 # 800159d0 <bcache>
    80002f76:	cb3fd0ef          	jal	80000c28 <acquire>
  b->refcnt++;
    80002f7a:	40bc                	lw	a5,64(s1)
    80002f7c:	2785                	addiw	a5,a5,1
    80002f7e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f80:	00013517          	auipc	a0,0x13
    80002f84:	a5050513          	addi	a0,a0,-1456 # 800159d0 <bcache>
    80002f88:	d35fd0ef          	jal	80000cbc <release>
}
    80002f8c:	60e2                	ld	ra,24(sp)
    80002f8e:	6442                	ld	s0,16(sp)
    80002f90:	64a2                	ld	s1,8(sp)
    80002f92:	6105                	addi	sp,sp,32
    80002f94:	8082                	ret

0000000080002f96 <bunpin>:

void
bunpin(struct buf *b) {
    80002f96:	1101                	addi	sp,sp,-32
    80002f98:	ec06                	sd	ra,24(sp)
    80002f9a:	e822                	sd	s0,16(sp)
    80002f9c:	e426                	sd	s1,8(sp)
    80002f9e:	1000                	addi	s0,sp,32
    80002fa0:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002fa2:	00013517          	auipc	a0,0x13
    80002fa6:	a2e50513          	addi	a0,a0,-1490 # 800159d0 <bcache>
    80002faa:	c7ffd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002fae:	40bc                	lw	a5,64(s1)
    80002fb0:	37fd                	addiw	a5,a5,-1
    80002fb2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002fb4:	00013517          	auipc	a0,0x13
    80002fb8:	a1c50513          	addi	a0,a0,-1508 # 800159d0 <bcache>
    80002fbc:	d01fd0ef          	jal	80000cbc <release>
}
    80002fc0:	60e2                	ld	ra,24(sp)
    80002fc2:	6442                	ld	s0,16(sp)
    80002fc4:	64a2                	ld	s1,8(sp)
    80002fc6:	6105                	addi	sp,sp,32
    80002fc8:	8082                	ret

0000000080002fca <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002fca:	1101                	addi	sp,sp,-32
    80002fcc:	ec06                	sd	ra,24(sp)
    80002fce:	e822                	sd	s0,16(sp)
    80002fd0:	e426                	sd	s1,8(sp)
    80002fd2:	e04a                	sd	s2,0(sp)
    80002fd4:	1000                	addi	s0,sp,32
    80002fd6:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002fd8:	00d5d79b          	srliw	a5,a1,0xd
    80002fdc:	0001b597          	auipc	a1,0x1b
    80002fe0:	0d05a583          	lw	a1,208(a1) # 8001e0ac <sb+0x1c>
    80002fe4:	9dbd                	addw	a1,a1,a5
    80002fe6:	df1ff0ef          	jal	80002dd6 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002fea:	0074f713          	andi	a4,s1,7
    80002fee:	4785                	li	a5,1
    80002ff0:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002ff4:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002ff6:	90d9                	srli	s1,s1,0x36
    80002ff8:	00950733          	add	a4,a0,s1
    80002ffc:	05874703          	lbu	a4,88(a4)
    80003000:	00e7f6b3          	and	a3,a5,a4
    80003004:	c29d                	beqz	a3,8000302a <bfree+0x60>
    80003006:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003008:	94aa                	add	s1,s1,a0
    8000300a:	fff7c793          	not	a5,a5
    8000300e:	8f7d                	and	a4,a4,a5
    80003010:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80003014:	000010ef          	jal	80004014 <log_write>
  brelse(bp);
    80003018:	854a                	mv	a0,s2
    8000301a:	ec5ff0ef          	jal	80002ede <brelse>
}
    8000301e:	60e2                	ld	ra,24(sp)
    80003020:	6442                	ld	s0,16(sp)
    80003022:	64a2                	ld	s1,8(sp)
    80003024:	6902                	ld	s2,0(sp)
    80003026:	6105                	addi	sp,sp,32
    80003028:	8082                	ret
    panic("freeing free block");
    8000302a:	00004517          	auipc	a0,0x4
    8000302e:	39e50513          	addi	a0,a0,926 # 800073c8 <etext+0x3c8>
    80003032:	ff2fd0ef          	jal	80000824 <panic>

0000000080003036 <balloc>:
{
    80003036:	715d                	addi	sp,sp,-80
    80003038:	e486                	sd	ra,72(sp)
    8000303a:	e0a2                	sd	s0,64(sp)
    8000303c:	fc26                	sd	s1,56(sp)
    8000303e:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80003040:	0001b797          	auipc	a5,0x1b
    80003044:	0547a783          	lw	a5,84(a5) # 8001e094 <sb+0x4>
    80003048:	0e078263          	beqz	a5,8000312c <balloc+0xf6>
    8000304c:	f84a                	sd	s2,48(sp)
    8000304e:	f44e                	sd	s3,40(sp)
    80003050:	f052                	sd	s4,32(sp)
    80003052:	ec56                	sd	s5,24(sp)
    80003054:	e85a                	sd	s6,16(sp)
    80003056:	e45e                	sd	s7,8(sp)
    80003058:	e062                	sd	s8,0(sp)
    8000305a:	8baa                	mv	s7,a0
    8000305c:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    8000305e:	0001bb17          	auipc	s6,0x1b
    80003062:	032b0b13          	addi	s6,s6,50 # 8001e090 <sb>
      m = 1 << (bi % 8);
    80003066:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003068:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    8000306a:	6c09                	lui	s8,0x2
    8000306c:	a09d                	j	800030d2 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    8000306e:	97ca                	add	a5,a5,s2
    80003070:	8e55                	or	a2,a2,a3
    80003072:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003076:	854a                	mv	a0,s2
    80003078:	79d000ef          	jal	80004014 <log_write>
        brelse(bp);
    8000307c:	854a                	mv	a0,s2
    8000307e:	e61ff0ef          	jal	80002ede <brelse>
  bp = bread(dev, bno);
    80003082:	85a6                	mv	a1,s1
    80003084:	855e                	mv	a0,s7
    80003086:	d51ff0ef          	jal	80002dd6 <bread>
    8000308a:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000308c:	40000613          	li	a2,1024
    80003090:	4581                	li	a1,0
    80003092:	05850513          	addi	a0,a0,88
    80003096:	c63fd0ef          	jal	80000cf8 <memset>
  log_write(bp);
    8000309a:	854a                	mv	a0,s2
    8000309c:	779000ef          	jal	80004014 <log_write>
  brelse(bp);
    800030a0:	854a                	mv	a0,s2
    800030a2:	e3dff0ef          	jal	80002ede <brelse>
}
    800030a6:	7942                	ld	s2,48(sp)
    800030a8:	79a2                	ld	s3,40(sp)
    800030aa:	7a02                	ld	s4,32(sp)
    800030ac:	6ae2                	ld	s5,24(sp)
    800030ae:	6b42                	ld	s6,16(sp)
    800030b0:	6ba2                	ld	s7,8(sp)
    800030b2:	6c02                	ld	s8,0(sp)
}
    800030b4:	8526                	mv	a0,s1
    800030b6:	60a6                	ld	ra,72(sp)
    800030b8:	6406                	ld	s0,64(sp)
    800030ba:	74e2                	ld	s1,56(sp)
    800030bc:	6161                	addi	sp,sp,80
    800030be:	8082                	ret
    brelse(bp);
    800030c0:	854a                	mv	a0,s2
    800030c2:	e1dff0ef          	jal	80002ede <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800030c6:	015c0abb          	addw	s5,s8,s5
    800030ca:	004b2783          	lw	a5,4(s6)
    800030ce:	04faf863          	bgeu	s5,a5,8000311e <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    800030d2:	40dad59b          	sraiw	a1,s5,0xd
    800030d6:	01cb2783          	lw	a5,28(s6)
    800030da:	9dbd                	addw	a1,a1,a5
    800030dc:	855e                	mv	a0,s7
    800030de:	cf9ff0ef          	jal	80002dd6 <bread>
    800030e2:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030e4:	004b2503          	lw	a0,4(s6)
    800030e8:	84d6                	mv	s1,s5
    800030ea:	4701                	li	a4,0
    800030ec:	fca4fae3          	bgeu	s1,a0,800030c0 <balloc+0x8a>
      m = 1 << (bi % 8);
    800030f0:	00777693          	andi	a3,a4,7
    800030f4:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800030f8:	41f7579b          	sraiw	a5,a4,0x1f
    800030fc:	01d7d79b          	srliw	a5,a5,0x1d
    80003100:	9fb9                	addw	a5,a5,a4
    80003102:	4037d79b          	sraiw	a5,a5,0x3
    80003106:	00f90633          	add	a2,s2,a5
    8000310a:	05864603          	lbu	a2,88(a2)
    8000310e:	00c6f5b3          	and	a1,a3,a2
    80003112:	ddb1                	beqz	a1,8000306e <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003114:	2705                	addiw	a4,a4,1
    80003116:	2485                	addiw	s1,s1,1
    80003118:	fd471ae3          	bne	a4,s4,800030ec <balloc+0xb6>
    8000311c:	b755                	j	800030c0 <balloc+0x8a>
    8000311e:	7942                	ld	s2,48(sp)
    80003120:	79a2                	ld	s3,40(sp)
    80003122:	7a02                	ld	s4,32(sp)
    80003124:	6ae2                	ld	s5,24(sp)
    80003126:	6b42                	ld	s6,16(sp)
    80003128:	6ba2                	ld	s7,8(sp)
    8000312a:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    8000312c:	00004517          	auipc	a0,0x4
    80003130:	2b450513          	addi	a0,a0,692 # 800073e0 <etext+0x3e0>
    80003134:	bc6fd0ef          	jal	800004fa <printf>
  return 0;
    80003138:	4481                	li	s1,0
    8000313a:	bfad                	j	800030b4 <balloc+0x7e>

000000008000313c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000313c:	7179                	addi	sp,sp,-48
    8000313e:	f406                	sd	ra,40(sp)
    80003140:	f022                	sd	s0,32(sp)
    80003142:	ec26                	sd	s1,24(sp)
    80003144:	e84a                	sd	s2,16(sp)
    80003146:	e44e                	sd	s3,8(sp)
    80003148:	1800                	addi	s0,sp,48
    8000314a:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    8000314c:	47ad                	li	a5,11
    8000314e:	02b7e363          	bltu	a5,a1,80003174 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80003152:	02059793          	slli	a5,a1,0x20
    80003156:	01e7d593          	srli	a1,a5,0x1e
    8000315a:	00b509b3          	add	s3,a0,a1
    8000315e:	0509a483          	lw	s1,80(s3)
    80003162:	e0b5                	bnez	s1,800031c6 <bmap+0x8a>
      addr = balloc(ip->dev);
    80003164:	4108                	lw	a0,0(a0)
    80003166:	ed1ff0ef          	jal	80003036 <balloc>
    8000316a:	84aa                	mv	s1,a0
      if(addr == 0)
    8000316c:	cd29                	beqz	a0,800031c6 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    8000316e:	04a9a823          	sw	a0,80(s3)
    80003172:	a891                	j	800031c6 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003174:	ff45879b          	addiw	a5,a1,-12
    80003178:	873e                	mv	a4,a5
    8000317a:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    8000317c:	0ff00793          	li	a5,255
    80003180:	06e7e763          	bltu	a5,a4,800031ee <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003184:	08052483          	lw	s1,128(a0)
    80003188:	e891                	bnez	s1,8000319c <bmap+0x60>
      addr = balloc(ip->dev);
    8000318a:	4108                	lw	a0,0(a0)
    8000318c:	eabff0ef          	jal	80003036 <balloc>
    80003190:	84aa                	mv	s1,a0
      if(addr == 0)
    80003192:	c915                	beqz	a0,800031c6 <bmap+0x8a>
    80003194:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003196:	08a92023          	sw	a0,128(s2)
    8000319a:	a011                	j	8000319e <bmap+0x62>
    8000319c:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000319e:	85a6                	mv	a1,s1
    800031a0:	00092503          	lw	a0,0(s2)
    800031a4:	c33ff0ef          	jal	80002dd6 <bread>
    800031a8:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    800031aa:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    800031ae:	02099713          	slli	a4,s3,0x20
    800031b2:	01e75593          	srli	a1,a4,0x1e
    800031b6:	97ae                	add	a5,a5,a1
    800031b8:	89be                	mv	s3,a5
    800031ba:	4384                	lw	s1,0(a5)
    800031bc:	cc89                	beqz	s1,800031d6 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800031be:	8552                	mv	a0,s4
    800031c0:	d1fff0ef          	jal	80002ede <brelse>
    return addr;
    800031c4:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    800031c6:	8526                	mv	a0,s1
    800031c8:	70a2                	ld	ra,40(sp)
    800031ca:	7402                	ld	s0,32(sp)
    800031cc:	64e2                	ld	s1,24(sp)
    800031ce:	6942                	ld	s2,16(sp)
    800031d0:	69a2                	ld	s3,8(sp)
    800031d2:	6145                	addi	sp,sp,48
    800031d4:	8082                	ret
      addr = balloc(ip->dev);
    800031d6:	00092503          	lw	a0,0(s2)
    800031da:	e5dff0ef          	jal	80003036 <balloc>
    800031de:	84aa                	mv	s1,a0
      if(addr){
    800031e0:	dd79                	beqz	a0,800031be <bmap+0x82>
        a[bn] = addr;
    800031e2:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    800031e6:	8552                	mv	a0,s4
    800031e8:	62d000ef          	jal	80004014 <log_write>
    800031ec:	bfc9                	j	800031be <bmap+0x82>
    800031ee:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800031f0:	00004517          	auipc	a0,0x4
    800031f4:	20850513          	addi	a0,a0,520 # 800073f8 <etext+0x3f8>
    800031f8:	e2cfd0ef          	jal	80000824 <panic>

00000000800031fc <iget>:
{
    800031fc:	7179                	addi	sp,sp,-48
    800031fe:	f406                	sd	ra,40(sp)
    80003200:	f022                	sd	s0,32(sp)
    80003202:	ec26                	sd	s1,24(sp)
    80003204:	e84a                	sd	s2,16(sp)
    80003206:	e44e                	sd	s3,8(sp)
    80003208:	e052                	sd	s4,0(sp)
    8000320a:	1800                	addi	s0,sp,48
    8000320c:	892a                	mv	s2,a0
    8000320e:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003210:	0001b517          	auipc	a0,0x1b
    80003214:	ea050513          	addi	a0,a0,-352 # 8001e0b0 <itable>
    80003218:	a11fd0ef          	jal	80000c28 <acquire>
  empty = 0;
    8000321c:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000321e:	0001b497          	auipc	s1,0x1b
    80003222:	eaa48493          	addi	s1,s1,-342 # 8001e0c8 <itable+0x18>
    80003226:	0001d697          	auipc	a3,0x1d
    8000322a:	93268693          	addi	a3,a3,-1742 # 8001fb58 <log>
    8000322e:	a809                	j	80003240 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003230:	e781                	bnez	a5,80003238 <iget+0x3c>
    80003232:	00099363          	bnez	s3,80003238 <iget+0x3c>
      empty = ip;
    80003236:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003238:	08848493          	addi	s1,s1,136
    8000323c:	02d48563          	beq	s1,a3,80003266 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003240:	449c                	lw	a5,8(s1)
    80003242:	fef057e3          	blez	a5,80003230 <iget+0x34>
    80003246:	4098                	lw	a4,0(s1)
    80003248:	ff2718e3          	bne	a4,s2,80003238 <iget+0x3c>
    8000324c:	40d8                	lw	a4,4(s1)
    8000324e:	ff4715e3          	bne	a4,s4,80003238 <iget+0x3c>
      ip->ref++;
    80003252:	2785                	addiw	a5,a5,1
    80003254:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003256:	0001b517          	auipc	a0,0x1b
    8000325a:	e5a50513          	addi	a0,a0,-422 # 8001e0b0 <itable>
    8000325e:	a5ffd0ef          	jal	80000cbc <release>
      return ip;
    80003262:	89a6                	mv	s3,s1
    80003264:	a015                	j	80003288 <iget+0x8c>
  if(empty == 0)
    80003266:	02098a63          	beqz	s3,8000329a <iget+0x9e>
  ip->dev = dev;
    8000326a:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    8000326e:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80003272:	4785                	li	a5,1
    80003274:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80003278:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000327c:	0001b517          	auipc	a0,0x1b
    80003280:	e3450513          	addi	a0,a0,-460 # 8001e0b0 <itable>
    80003284:	a39fd0ef          	jal	80000cbc <release>
}
    80003288:	854e                	mv	a0,s3
    8000328a:	70a2                	ld	ra,40(sp)
    8000328c:	7402                	ld	s0,32(sp)
    8000328e:	64e2                	ld	s1,24(sp)
    80003290:	6942                	ld	s2,16(sp)
    80003292:	69a2                	ld	s3,8(sp)
    80003294:	6a02                	ld	s4,0(sp)
    80003296:	6145                	addi	sp,sp,48
    80003298:	8082                	ret
    panic("iget: no inodes");
    8000329a:	00004517          	auipc	a0,0x4
    8000329e:	17650513          	addi	a0,a0,374 # 80007410 <etext+0x410>
    800032a2:	d82fd0ef          	jal	80000824 <panic>

00000000800032a6 <iinit>:
{
    800032a6:	7179                	addi	sp,sp,-48
    800032a8:	f406                	sd	ra,40(sp)
    800032aa:	f022                	sd	s0,32(sp)
    800032ac:	ec26                	sd	s1,24(sp)
    800032ae:	e84a                	sd	s2,16(sp)
    800032b0:	e44e                	sd	s3,8(sp)
    800032b2:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800032b4:	00004597          	auipc	a1,0x4
    800032b8:	16c58593          	addi	a1,a1,364 # 80007420 <etext+0x420>
    800032bc:	0001b517          	auipc	a0,0x1b
    800032c0:	df450513          	addi	a0,a0,-524 # 8001e0b0 <itable>
    800032c4:	8dbfd0ef          	jal	80000b9e <initlock>
  for(i = 0; i < NINODE; i++) {
    800032c8:	0001b497          	auipc	s1,0x1b
    800032cc:	e1048493          	addi	s1,s1,-496 # 8001e0d8 <itable+0x28>
    800032d0:	0001d997          	auipc	s3,0x1d
    800032d4:	89898993          	addi	s3,s3,-1896 # 8001fb68 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800032d8:	00004917          	auipc	s2,0x4
    800032dc:	15090913          	addi	s2,s2,336 # 80007428 <etext+0x428>
    800032e0:	85ca                	mv	a1,s2
    800032e2:	8526                	mv	a0,s1
    800032e4:	5f5000ef          	jal	800040d8 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800032e8:	08848493          	addi	s1,s1,136
    800032ec:	ff349ae3          	bne	s1,s3,800032e0 <iinit+0x3a>
}
    800032f0:	70a2                	ld	ra,40(sp)
    800032f2:	7402                	ld	s0,32(sp)
    800032f4:	64e2                	ld	s1,24(sp)
    800032f6:	6942                	ld	s2,16(sp)
    800032f8:	69a2                	ld	s3,8(sp)
    800032fa:	6145                	addi	sp,sp,48
    800032fc:	8082                	ret

00000000800032fe <ialloc>:
{
    800032fe:	7139                	addi	sp,sp,-64
    80003300:	fc06                	sd	ra,56(sp)
    80003302:	f822                	sd	s0,48(sp)
    80003304:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003306:	0001b717          	auipc	a4,0x1b
    8000330a:	d9672703          	lw	a4,-618(a4) # 8001e09c <sb+0xc>
    8000330e:	4785                	li	a5,1
    80003310:	06e7f063          	bgeu	a5,a4,80003370 <ialloc+0x72>
    80003314:	f426                	sd	s1,40(sp)
    80003316:	f04a                	sd	s2,32(sp)
    80003318:	ec4e                	sd	s3,24(sp)
    8000331a:	e852                	sd	s4,16(sp)
    8000331c:	e456                	sd	s5,8(sp)
    8000331e:	e05a                	sd	s6,0(sp)
    80003320:	8aaa                	mv	s5,a0
    80003322:	8b2e                	mv	s6,a1
    80003324:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003326:	0001ba17          	auipc	s4,0x1b
    8000332a:	d6aa0a13          	addi	s4,s4,-662 # 8001e090 <sb>
    8000332e:	00495593          	srli	a1,s2,0x4
    80003332:	018a2783          	lw	a5,24(s4)
    80003336:	9dbd                	addw	a1,a1,a5
    80003338:	8556                	mv	a0,s5
    8000333a:	a9dff0ef          	jal	80002dd6 <bread>
    8000333e:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003340:	05850993          	addi	s3,a0,88
    80003344:	00f97793          	andi	a5,s2,15
    80003348:	079a                	slli	a5,a5,0x6
    8000334a:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000334c:	00099783          	lh	a5,0(s3)
    80003350:	cb9d                	beqz	a5,80003386 <ialloc+0x88>
    brelse(bp);
    80003352:	b8dff0ef          	jal	80002ede <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003356:	0905                	addi	s2,s2,1
    80003358:	00ca2703          	lw	a4,12(s4)
    8000335c:	0009079b          	sext.w	a5,s2
    80003360:	fce7e7e3          	bltu	a5,a4,8000332e <ialloc+0x30>
    80003364:	74a2                	ld	s1,40(sp)
    80003366:	7902                	ld	s2,32(sp)
    80003368:	69e2                	ld	s3,24(sp)
    8000336a:	6a42                	ld	s4,16(sp)
    8000336c:	6aa2                	ld	s5,8(sp)
    8000336e:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80003370:	00004517          	auipc	a0,0x4
    80003374:	0c050513          	addi	a0,a0,192 # 80007430 <etext+0x430>
    80003378:	982fd0ef          	jal	800004fa <printf>
  return 0;
    8000337c:	4501                	li	a0,0
}
    8000337e:	70e2                	ld	ra,56(sp)
    80003380:	7442                	ld	s0,48(sp)
    80003382:	6121                	addi	sp,sp,64
    80003384:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003386:	04000613          	li	a2,64
    8000338a:	4581                	li	a1,0
    8000338c:	854e                	mv	a0,s3
    8000338e:	96bfd0ef          	jal	80000cf8 <memset>
      dip->type = type;
    80003392:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003396:	8526                	mv	a0,s1
    80003398:	47d000ef          	jal	80004014 <log_write>
      brelse(bp);
    8000339c:	8526                	mv	a0,s1
    8000339e:	b41ff0ef          	jal	80002ede <brelse>
      return iget(dev, inum);
    800033a2:	0009059b          	sext.w	a1,s2
    800033a6:	8556                	mv	a0,s5
    800033a8:	e55ff0ef          	jal	800031fc <iget>
    800033ac:	74a2                	ld	s1,40(sp)
    800033ae:	7902                	ld	s2,32(sp)
    800033b0:	69e2                	ld	s3,24(sp)
    800033b2:	6a42                	ld	s4,16(sp)
    800033b4:	6aa2                	ld	s5,8(sp)
    800033b6:	6b02                	ld	s6,0(sp)
    800033b8:	b7d9                	j	8000337e <ialloc+0x80>

00000000800033ba <iupdate>:
{
    800033ba:	1101                	addi	sp,sp,-32
    800033bc:	ec06                	sd	ra,24(sp)
    800033be:	e822                	sd	s0,16(sp)
    800033c0:	e426                	sd	s1,8(sp)
    800033c2:	e04a                	sd	s2,0(sp)
    800033c4:	1000                	addi	s0,sp,32
    800033c6:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800033c8:	415c                	lw	a5,4(a0)
    800033ca:	0047d79b          	srliw	a5,a5,0x4
    800033ce:	0001b597          	auipc	a1,0x1b
    800033d2:	cda5a583          	lw	a1,-806(a1) # 8001e0a8 <sb+0x18>
    800033d6:	9dbd                	addw	a1,a1,a5
    800033d8:	4108                	lw	a0,0(a0)
    800033da:	9fdff0ef          	jal	80002dd6 <bread>
    800033de:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800033e0:	05850793          	addi	a5,a0,88
    800033e4:	40d8                	lw	a4,4(s1)
    800033e6:	8b3d                	andi	a4,a4,15
    800033e8:	071a                	slli	a4,a4,0x6
    800033ea:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800033ec:	04449703          	lh	a4,68(s1)
    800033f0:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800033f4:	04649703          	lh	a4,70(s1)
    800033f8:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800033fc:	04849703          	lh	a4,72(s1)
    80003400:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003404:	04a49703          	lh	a4,74(s1)
    80003408:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000340c:	44f8                	lw	a4,76(s1)
    8000340e:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003410:	03400613          	li	a2,52
    80003414:	05048593          	addi	a1,s1,80
    80003418:	00c78513          	addi	a0,a5,12
    8000341c:	93dfd0ef          	jal	80000d58 <memmove>
  log_write(bp);
    80003420:	854a                	mv	a0,s2
    80003422:	3f3000ef          	jal	80004014 <log_write>
  brelse(bp);
    80003426:	854a                	mv	a0,s2
    80003428:	ab7ff0ef          	jal	80002ede <brelse>
}
    8000342c:	60e2                	ld	ra,24(sp)
    8000342e:	6442                	ld	s0,16(sp)
    80003430:	64a2                	ld	s1,8(sp)
    80003432:	6902                	ld	s2,0(sp)
    80003434:	6105                	addi	sp,sp,32
    80003436:	8082                	ret

0000000080003438 <idup>:
{
    80003438:	1101                	addi	sp,sp,-32
    8000343a:	ec06                	sd	ra,24(sp)
    8000343c:	e822                	sd	s0,16(sp)
    8000343e:	e426                	sd	s1,8(sp)
    80003440:	1000                	addi	s0,sp,32
    80003442:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003444:	0001b517          	auipc	a0,0x1b
    80003448:	c6c50513          	addi	a0,a0,-916 # 8001e0b0 <itable>
    8000344c:	fdcfd0ef          	jal	80000c28 <acquire>
  ip->ref++;
    80003450:	449c                	lw	a5,8(s1)
    80003452:	2785                	addiw	a5,a5,1
    80003454:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003456:	0001b517          	auipc	a0,0x1b
    8000345a:	c5a50513          	addi	a0,a0,-934 # 8001e0b0 <itable>
    8000345e:	85ffd0ef          	jal	80000cbc <release>
}
    80003462:	8526                	mv	a0,s1
    80003464:	60e2                	ld	ra,24(sp)
    80003466:	6442                	ld	s0,16(sp)
    80003468:	64a2                	ld	s1,8(sp)
    8000346a:	6105                	addi	sp,sp,32
    8000346c:	8082                	ret

000000008000346e <ilock>:
{
    8000346e:	1101                	addi	sp,sp,-32
    80003470:	ec06                	sd	ra,24(sp)
    80003472:	e822                	sd	s0,16(sp)
    80003474:	e426                	sd	s1,8(sp)
    80003476:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003478:	cd19                	beqz	a0,80003496 <ilock+0x28>
    8000347a:	84aa                	mv	s1,a0
    8000347c:	451c                	lw	a5,8(a0)
    8000347e:	00f05c63          	blez	a5,80003496 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003482:	0541                	addi	a0,a0,16
    80003484:	48b000ef          	jal	8000410e <acquiresleep>
  if(ip->valid == 0){
    80003488:	40bc                	lw	a5,64(s1)
    8000348a:	cf89                	beqz	a5,800034a4 <ilock+0x36>
}
    8000348c:	60e2                	ld	ra,24(sp)
    8000348e:	6442                	ld	s0,16(sp)
    80003490:	64a2                	ld	s1,8(sp)
    80003492:	6105                	addi	sp,sp,32
    80003494:	8082                	ret
    80003496:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003498:	00004517          	auipc	a0,0x4
    8000349c:	fb050513          	addi	a0,a0,-80 # 80007448 <etext+0x448>
    800034a0:	b84fd0ef          	jal	80000824 <panic>
    800034a4:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800034a6:	40dc                	lw	a5,4(s1)
    800034a8:	0047d79b          	srliw	a5,a5,0x4
    800034ac:	0001b597          	auipc	a1,0x1b
    800034b0:	bfc5a583          	lw	a1,-1028(a1) # 8001e0a8 <sb+0x18>
    800034b4:	9dbd                	addw	a1,a1,a5
    800034b6:	4088                	lw	a0,0(s1)
    800034b8:	91fff0ef          	jal	80002dd6 <bread>
    800034bc:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800034be:	05850593          	addi	a1,a0,88
    800034c2:	40dc                	lw	a5,4(s1)
    800034c4:	8bbd                	andi	a5,a5,15
    800034c6:	079a                	slli	a5,a5,0x6
    800034c8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800034ca:	00059783          	lh	a5,0(a1)
    800034ce:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800034d2:	00259783          	lh	a5,2(a1)
    800034d6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800034da:	00459783          	lh	a5,4(a1)
    800034de:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800034e2:	00659783          	lh	a5,6(a1)
    800034e6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800034ea:	459c                	lw	a5,8(a1)
    800034ec:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800034ee:	03400613          	li	a2,52
    800034f2:	05b1                	addi	a1,a1,12
    800034f4:	05048513          	addi	a0,s1,80
    800034f8:	861fd0ef          	jal	80000d58 <memmove>
    brelse(bp);
    800034fc:	854a                	mv	a0,s2
    800034fe:	9e1ff0ef          	jal	80002ede <brelse>
    ip->valid = 1;
    80003502:	4785                	li	a5,1
    80003504:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003506:	04449783          	lh	a5,68(s1)
    8000350a:	c399                	beqz	a5,80003510 <ilock+0xa2>
    8000350c:	6902                	ld	s2,0(sp)
    8000350e:	bfbd                	j	8000348c <ilock+0x1e>
      panic("ilock: no type");
    80003510:	00004517          	auipc	a0,0x4
    80003514:	f4050513          	addi	a0,a0,-192 # 80007450 <etext+0x450>
    80003518:	b0cfd0ef          	jal	80000824 <panic>

000000008000351c <iunlock>:
{
    8000351c:	1101                	addi	sp,sp,-32
    8000351e:	ec06                	sd	ra,24(sp)
    80003520:	e822                	sd	s0,16(sp)
    80003522:	e426                	sd	s1,8(sp)
    80003524:	e04a                	sd	s2,0(sp)
    80003526:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003528:	c505                	beqz	a0,80003550 <iunlock+0x34>
    8000352a:	84aa                	mv	s1,a0
    8000352c:	01050913          	addi	s2,a0,16
    80003530:	854a                	mv	a0,s2
    80003532:	45b000ef          	jal	8000418c <holdingsleep>
    80003536:	cd09                	beqz	a0,80003550 <iunlock+0x34>
    80003538:	449c                	lw	a5,8(s1)
    8000353a:	00f05b63          	blez	a5,80003550 <iunlock+0x34>
  releasesleep(&ip->lock);
    8000353e:	854a                	mv	a0,s2
    80003540:	415000ef          	jal	80004154 <releasesleep>
}
    80003544:	60e2                	ld	ra,24(sp)
    80003546:	6442                	ld	s0,16(sp)
    80003548:	64a2                	ld	s1,8(sp)
    8000354a:	6902                	ld	s2,0(sp)
    8000354c:	6105                	addi	sp,sp,32
    8000354e:	8082                	ret
    panic("iunlock");
    80003550:	00004517          	auipc	a0,0x4
    80003554:	f1050513          	addi	a0,a0,-240 # 80007460 <etext+0x460>
    80003558:	accfd0ef          	jal	80000824 <panic>

000000008000355c <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000355c:	7179                	addi	sp,sp,-48
    8000355e:	f406                	sd	ra,40(sp)
    80003560:	f022                	sd	s0,32(sp)
    80003562:	ec26                	sd	s1,24(sp)
    80003564:	e84a                	sd	s2,16(sp)
    80003566:	e44e                	sd	s3,8(sp)
    80003568:	1800                	addi	s0,sp,48
    8000356a:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000356c:	05050493          	addi	s1,a0,80
    80003570:	08050913          	addi	s2,a0,128
    80003574:	a021                	j	8000357c <itrunc+0x20>
    80003576:	0491                	addi	s1,s1,4
    80003578:	01248b63          	beq	s1,s2,8000358e <itrunc+0x32>
    if(ip->addrs[i]){
    8000357c:	408c                	lw	a1,0(s1)
    8000357e:	dde5                	beqz	a1,80003576 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003580:	0009a503          	lw	a0,0(s3)
    80003584:	a47ff0ef          	jal	80002fca <bfree>
      ip->addrs[i] = 0;
    80003588:	0004a023          	sw	zero,0(s1)
    8000358c:	b7ed                	j	80003576 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000358e:	0809a583          	lw	a1,128(s3)
    80003592:	ed89                	bnez	a1,800035ac <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003594:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003598:	854e                	mv	a0,s3
    8000359a:	e21ff0ef          	jal	800033ba <iupdate>
}
    8000359e:	70a2                	ld	ra,40(sp)
    800035a0:	7402                	ld	s0,32(sp)
    800035a2:	64e2                	ld	s1,24(sp)
    800035a4:	6942                	ld	s2,16(sp)
    800035a6:	69a2                	ld	s3,8(sp)
    800035a8:	6145                	addi	sp,sp,48
    800035aa:	8082                	ret
    800035ac:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800035ae:	0009a503          	lw	a0,0(s3)
    800035b2:	825ff0ef          	jal	80002dd6 <bread>
    800035b6:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800035b8:	05850493          	addi	s1,a0,88
    800035bc:	45850913          	addi	s2,a0,1112
    800035c0:	a021                	j	800035c8 <itrunc+0x6c>
    800035c2:	0491                	addi	s1,s1,4
    800035c4:	01248963          	beq	s1,s2,800035d6 <itrunc+0x7a>
      if(a[j])
    800035c8:	408c                	lw	a1,0(s1)
    800035ca:	dde5                	beqz	a1,800035c2 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800035cc:	0009a503          	lw	a0,0(s3)
    800035d0:	9fbff0ef          	jal	80002fca <bfree>
    800035d4:	b7fd                	j	800035c2 <itrunc+0x66>
    brelse(bp);
    800035d6:	8552                	mv	a0,s4
    800035d8:	907ff0ef          	jal	80002ede <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800035dc:	0809a583          	lw	a1,128(s3)
    800035e0:	0009a503          	lw	a0,0(s3)
    800035e4:	9e7ff0ef          	jal	80002fca <bfree>
    ip->addrs[NDIRECT] = 0;
    800035e8:	0809a023          	sw	zero,128(s3)
    800035ec:	6a02                	ld	s4,0(sp)
    800035ee:	b75d                	j	80003594 <itrunc+0x38>

00000000800035f0 <iput>:
{
    800035f0:	1101                	addi	sp,sp,-32
    800035f2:	ec06                	sd	ra,24(sp)
    800035f4:	e822                	sd	s0,16(sp)
    800035f6:	e426                	sd	s1,8(sp)
    800035f8:	1000                	addi	s0,sp,32
    800035fa:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800035fc:	0001b517          	auipc	a0,0x1b
    80003600:	ab450513          	addi	a0,a0,-1356 # 8001e0b0 <itable>
    80003604:	e24fd0ef          	jal	80000c28 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003608:	4498                	lw	a4,8(s1)
    8000360a:	4785                	li	a5,1
    8000360c:	02f70063          	beq	a4,a5,8000362c <iput+0x3c>
  ip->ref--;
    80003610:	449c                	lw	a5,8(s1)
    80003612:	37fd                	addiw	a5,a5,-1
    80003614:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003616:	0001b517          	auipc	a0,0x1b
    8000361a:	a9a50513          	addi	a0,a0,-1382 # 8001e0b0 <itable>
    8000361e:	e9efd0ef          	jal	80000cbc <release>
}
    80003622:	60e2                	ld	ra,24(sp)
    80003624:	6442                	ld	s0,16(sp)
    80003626:	64a2                	ld	s1,8(sp)
    80003628:	6105                	addi	sp,sp,32
    8000362a:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000362c:	40bc                	lw	a5,64(s1)
    8000362e:	d3ed                	beqz	a5,80003610 <iput+0x20>
    80003630:	04a49783          	lh	a5,74(s1)
    80003634:	fff1                	bnez	a5,80003610 <iput+0x20>
    80003636:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003638:	01048793          	addi	a5,s1,16
    8000363c:	893e                	mv	s2,a5
    8000363e:	853e                	mv	a0,a5
    80003640:	2cf000ef          	jal	8000410e <acquiresleep>
    release(&itable.lock);
    80003644:	0001b517          	auipc	a0,0x1b
    80003648:	a6c50513          	addi	a0,a0,-1428 # 8001e0b0 <itable>
    8000364c:	e70fd0ef          	jal	80000cbc <release>
    itrunc(ip);
    80003650:	8526                	mv	a0,s1
    80003652:	f0bff0ef          	jal	8000355c <itrunc>
    ip->type = 0;
    80003656:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000365a:	8526                	mv	a0,s1
    8000365c:	d5fff0ef          	jal	800033ba <iupdate>
    ip->valid = 0;
    80003660:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003664:	854a                	mv	a0,s2
    80003666:	2ef000ef          	jal	80004154 <releasesleep>
    acquire(&itable.lock);
    8000366a:	0001b517          	auipc	a0,0x1b
    8000366e:	a4650513          	addi	a0,a0,-1466 # 8001e0b0 <itable>
    80003672:	db6fd0ef          	jal	80000c28 <acquire>
    80003676:	6902                	ld	s2,0(sp)
    80003678:	bf61                	j	80003610 <iput+0x20>

000000008000367a <iunlockput>:
{
    8000367a:	1101                	addi	sp,sp,-32
    8000367c:	ec06                	sd	ra,24(sp)
    8000367e:	e822                	sd	s0,16(sp)
    80003680:	e426                	sd	s1,8(sp)
    80003682:	1000                	addi	s0,sp,32
    80003684:	84aa                	mv	s1,a0
  iunlock(ip);
    80003686:	e97ff0ef          	jal	8000351c <iunlock>
  iput(ip);
    8000368a:	8526                	mv	a0,s1
    8000368c:	f65ff0ef          	jal	800035f0 <iput>
}
    80003690:	60e2                	ld	ra,24(sp)
    80003692:	6442                	ld	s0,16(sp)
    80003694:	64a2                	ld	s1,8(sp)
    80003696:	6105                	addi	sp,sp,32
    80003698:	8082                	ret

000000008000369a <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000369a:	0001b717          	auipc	a4,0x1b
    8000369e:	a0272703          	lw	a4,-1534(a4) # 8001e09c <sb+0xc>
    800036a2:	4785                	li	a5,1
    800036a4:	0ae7fe63          	bgeu	a5,a4,80003760 <ireclaim+0xc6>
{
    800036a8:	7139                	addi	sp,sp,-64
    800036aa:	fc06                	sd	ra,56(sp)
    800036ac:	f822                	sd	s0,48(sp)
    800036ae:	f426                	sd	s1,40(sp)
    800036b0:	f04a                	sd	s2,32(sp)
    800036b2:	ec4e                	sd	s3,24(sp)
    800036b4:	e852                	sd	s4,16(sp)
    800036b6:	e456                	sd	s5,8(sp)
    800036b8:	e05a                	sd	s6,0(sp)
    800036ba:	0080                	addi	s0,sp,64
    800036bc:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800036be:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800036c0:	0001ba17          	auipc	s4,0x1b
    800036c4:	9d0a0a13          	addi	s4,s4,-1584 # 8001e090 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    800036c8:	00004b17          	auipc	s6,0x4
    800036cc:	da0b0b13          	addi	s6,s6,-608 # 80007468 <etext+0x468>
    800036d0:	a099                	j	80003716 <ireclaim+0x7c>
    800036d2:	85ce                	mv	a1,s3
    800036d4:	855a                	mv	a0,s6
    800036d6:	e25fc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    800036da:	85ce                	mv	a1,s3
    800036dc:	8556                	mv	a0,s5
    800036de:	b1fff0ef          	jal	800031fc <iget>
    800036e2:	89aa                	mv	s3,a0
    brelse(bp);
    800036e4:	854a                	mv	a0,s2
    800036e6:	ff8ff0ef          	jal	80002ede <brelse>
    if (ip) {
    800036ea:	00098f63          	beqz	s3,80003708 <ireclaim+0x6e>
      begin_op();
    800036ee:	78c000ef          	jal	80003e7a <begin_op>
      ilock(ip);
    800036f2:	854e                	mv	a0,s3
    800036f4:	d7bff0ef          	jal	8000346e <ilock>
      iunlock(ip);
    800036f8:	854e                	mv	a0,s3
    800036fa:	e23ff0ef          	jal	8000351c <iunlock>
      iput(ip);
    800036fe:	854e                	mv	a0,s3
    80003700:	ef1ff0ef          	jal	800035f0 <iput>
      end_op();
    80003704:	7e6000ef          	jal	80003eea <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003708:	0485                	addi	s1,s1,1
    8000370a:	00ca2703          	lw	a4,12(s4)
    8000370e:	0004879b          	sext.w	a5,s1
    80003712:	02e7fd63          	bgeu	a5,a4,8000374c <ireclaim+0xb2>
    80003716:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000371a:	0044d593          	srli	a1,s1,0x4
    8000371e:	018a2783          	lw	a5,24(s4)
    80003722:	9dbd                	addw	a1,a1,a5
    80003724:	8556                	mv	a0,s5
    80003726:	eb0ff0ef          	jal	80002dd6 <bread>
    8000372a:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000372c:	05850793          	addi	a5,a0,88
    80003730:	00f9f713          	andi	a4,s3,15
    80003734:	071a                	slli	a4,a4,0x6
    80003736:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    80003738:	00079703          	lh	a4,0(a5)
    8000373c:	c701                	beqz	a4,80003744 <ireclaim+0xaa>
    8000373e:	00679783          	lh	a5,6(a5)
    80003742:	dbc1                	beqz	a5,800036d2 <ireclaim+0x38>
    brelse(bp);
    80003744:	854a                	mv	a0,s2
    80003746:	f98ff0ef          	jal	80002ede <brelse>
    if (ip) {
    8000374a:	bf7d                	j	80003708 <ireclaim+0x6e>
}
    8000374c:	70e2                	ld	ra,56(sp)
    8000374e:	7442                	ld	s0,48(sp)
    80003750:	74a2                	ld	s1,40(sp)
    80003752:	7902                	ld	s2,32(sp)
    80003754:	69e2                	ld	s3,24(sp)
    80003756:	6a42                	ld	s4,16(sp)
    80003758:	6aa2                	ld	s5,8(sp)
    8000375a:	6b02                	ld	s6,0(sp)
    8000375c:	6121                	addi	sp,sp,64
    8000375e:	8082                	ret
    80003760:	8082                	ret

0000000080003762 <fsinit>:
fsinit(int dev) {
    80003762:	1101                	addi	sp,sp,-32
    80003764:	ec06                	sd	ra,24(sp)
    80003766:	e822                	sd	s0,16(sp)
    80003768:	e426                	sd	s1,8(sp)
    8000376a:	e04a                	sd	s2,0(sp)
    8000376c:	1000                	addi	s0,sp,32
    8000376e:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003770:	4585                	li	a1,1
    80003772:	e64ff0ef          	jal	80002dd6 <bread>
    80003776:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003778:	02000613          	li	a2,32
    8000377c:	05850593          	addi	a1,a0,88
    80003780:	0001b517          	auipc	a0,0x1b
    80003784:	91050513          	addi	a0,a0,-1776 # 8001e090 <sb>
    80003788:	dd0fd0ef          	jal	80000d58 <memmove>
  brelse(bp);
    8000378c:	8526                	mv	a0,s1
    8000378e:	f50ff0ef          	jal	80002ede <brelse>
  if(sb.magic != FSMAGIC)
    80003792:	0001b717          	auipc	a4,0x1b
    80003796:	8fe72703          	lw	a4,-1794(a4) # 8001e090 <sb>
    8000379a:	102037b7          	lui	a5,0x10203
    8000379e:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800037a2:	02f71263          	bne	a4,a5,800037c6 <fsinit+0x64>
  initlog(dev, &sb);
    800037a6:	0001b597          	auipc	a1,0x1b
    800037aa:	8ea58593          	addi	a1,a1,-1814 # 8001e090 <sb>
    800037ae:	854a                	mv	a0,s2
    800037b0:	648000ef          	jal	80003df8 <initlog>
  ireclaim(dev);
    800037b4:	854a                	mv	a0,s2
    800037b6:	ee5ff0ef          	jal	8000369a <ireclaim>
}
    800037ba:	60e2                	ld	ra,24(sp)
    800037bc:	6442                	ld	s0,16(sp)
    800037be:	64a2                	ld	s1,8(sp)
    800037c0:	6902                	ld	s2,0(sp)
    800037c2:	6105                	addi	sp,sp,32
    800037c4:	8082                	ret
    panic("invalid file system");
    800037c6:	00004517          	auipc	a0,0x4
    800037ca:	cc250513          	addi	a0,a0,-830 # 80007488 <etext+0x488>
    800037ce:	856fd0ef          	jal	80000824 <panic>

00000000800037d2 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800037d2:	1141                	addi	sp,sp,-16
    800037d4:	e406                	sd	ra,8(sp)
    800037d6:	e022                	sd	s0,0(sp)
    800037d8:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800037da:	411c                	lw	a5,0(a0)
    800037dc:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800037de:	415c                	lw	a5,4(a0)
    800037e0:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800037e2:	04451783          	lh	a5,68(a0)
    800037e6:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800037ea:	04a51783          	lh	a5,74(a0)
    800037ee:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800037f2:	04c56783          	lwu	a5,76(a0)
    800037f6:	e99c                	sd	a5,16(a1)
}
    800037f8:	60a2                	ld	ra,8(sp)
    800037fa:	6402                	ld	s0,0(sp)
    800037fc:	0141                	addi	sp,sp,16
    800037fe:	8082                	ret

0000000080003800 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003800:	457c                	lw	a5,76(a0)
    80003802:	0ed7e663          	bltu	a5,a3,800038ee <readi+0xee>
{
    80003806:	7159                	addi	sp,sp,-112
    80003808:	f486                	sd	ra,104(sp)
    8000380a:	f0a2                	sd	s0,96(sp)
    8000380c:	eca6                	sd	s1,88(sp)
    8000380e:	e0d2                	sd	s4,64(sp)
    80003810:	fc56                	sd	s5,56(sp)
    80003812:	f85a                	sd	s6,48(sp)
    80003814:	f45e                	sd	s7,40(sp)
    80003816:	1880                	addi	s0,sp,112
    80003818:	8b2a                	mv	s6,a0
    8000381a:	8bae                	mv	s7,a1
    8000381c:	8a32                	mv	s4,a2
    8000381e:	84b6                	mv	s1,a3
    80003820:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003822:	9f35                	addw	a4,a4,a3
    return 0;
    80003824:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003826:	0ad76b63          	bltu	a4,a3,800038dc <readi+0xdc>
    8000382a:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    8000382c:	00e7f463          	bgeu	a5,a4,80003834 <readi+0x34>
    n = ip->size - off;
    80003830:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003834:	080a8b63          	beqz	s5,800038ca <readi+0xca>
    80003838:	e8ca                	sd	s2,80(sp)
    8000383a:	f062                	sd	s8,32(sp)
    8000383c:	ec66                	sd	s9,24(sp)
    8000383e:	e86a                	sd	s10,16(sp)
    80003840:	e46e                	sd	s11,8(sp)
    80003842:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003844:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003848:	5c7d                	li	s8,-1
    8000384a:	a80d                	j	8000387c <readi+0x7c>
    8000384c:	020d1d93          	slli	s11,s10,0x20
    80003850:	020ddd93          	srli	s11,s11,0x20
    80003854:	05890613          	addi	a2,s2,88
    80003858:	86ee                	mv	a3,s11
    8000385a:	963e                	add	a2,a2,a5
    8000385c:	85d2                	mv	a1,s4
    8000385e:	855e                	mv	a0,s7
    80003860:	ac1fe0ef          	jal	80002320 <either_copyout>
    80003864:	05850363          	beq	a0,s8,800038aa <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003868:	854a                	mv	a0,s2
    8000386a:	e74ff0ef          	jal	80002ede <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000386e:	013d09bb          	addw	s3,s10,s3
    80003872:	009d04bb          	addw	s1,s10,s1
    80003876:	9a6e                	add	s4,s4,s11
    80003878:	0559f363          	bgeu	s3,s5,800038be <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000387c:	00a4d59b          	srliw	a1,s1,0xa
    80003880:	855a                	mv	a0,s6
    80003882:	8bbff0ef          	jal	8000313c <bmap>
    80003886:	85aa                	mv	a1,a0
    if(addr == 0)
    80003888:	c139                	beqz	a0,800038ce <readi+0xce>
    bp = bread(ip->dev, addr);
    8000388a:	000b2503          	lw	a0,0(s6)
    8000388e:	d48ff0ef          	jal	80002dd6 <bread>
    80003892:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003894:	3ff4f793          	andi	a5,s1,1023
    80003898:	40fc873b          	subw	a4,s9,a5
    8000389c:	413a86bb          	subw	a3,s5,s3
    800038a0:	8d3a                	mv	s10,a4
    800038a2:	fae6f5e3          	bgeu	a3,a4,8000384c <readi+0x4c>
    800038a6:	8d36                	mv	s10,a3
    800038a8:	b755                	j	8000384c <readi+0x4c>
      brelse(bp);
    800038aa:	854a                	mv	a0,s2
    800038ac:	e32ff0ef          	jal	80002ede <brelse>
      tot = -1;
    800038b0:	59fd                	li	s3,-1
      break;
    800038b2:	6946                	ld	s2,80(sp)
    800038b4:	7c02                	ld	s8,32(sp)
    800038b6:	6ce2                	ld	s9,24(sp)
    800038b8:	6d42                	ld	s10,16(sp)
    800038ba:	6da2                	ld	s11,8(sp)
    800038bc:	a831                	j	800038d8 <readi+0xd8>
    800038be:	6946                	ld	s2,80(sp)
    800038c0:	7c02                	ld	s8,32(sp)
    800038c2:	6ce2                	ld	s9,24(sp)
    800038c4:	6d42                	ld	s10,16(sp)
    800038c6:	6da2                	ld	s11,8(sp)
    800038c8:	a801                	j	800038d8 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800038ca:	89d6                	mv	s3,s5
    800038cc:	a031                	j	800038d8 <readi+0xd8>
    800038ce:	6946                	ld	s2,80(sp)
    800038d0:	7c02                	ld	s8,32(sp)
    800038d2:	6ce2                	ld	s9,24(sp)
    800038d4:	6d42                	ld	s10,16(sp)
    800038d6:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800038d8:	854e                	mv	a0,s3
    800038da:	69a6                	ld	s3,72(sp)
}
    800038dc:	70a6                	ld	ra,104(sp)
    800038de:	7406                	ld	s0,96(sp)
    800038e0:	64e6                	ld	s1,88(sp)
    800038e2:	6a06                	ld	s4,64(sp)
    800038e4:	7ae2                	ld	s5,56(sp)
    800038e6:	7b42                	ld	s6,48(sp)
    800038e8:	7ba2                	ld	s7,40(sp)
    800038ea:	6165                	addi	sp,sp,112
    800038ec:	8082                	ret
    return 0;
    800038ee:	4501                	li	a0,0
}
    800038f0:	8082                	ret

00000000800038f2 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800038f2:	457c                	lw	a5,76(a0)
    800038f4:	0ed7eb63          	bltu	a5,a3,800039ea <writei+0xf8>
{
    800038f8:	7159                	addi	sp,sp,-112
    800038fa:	f486                	sd	ra,104(sp)
    800038fc:	f0a2                	sd	s0,96(sp)
    800038fe:	e8ca                	sd	s2,80(sp)
    80003900:	e0d2                	sd	s4,64(sp)
    80003902:	fc56                	sd	s5,56(sp)
    80003904:	f85a                	sd	s6,48(sp)
    80003906:	f45e                	sd	s7,40(sp)
    80003908:	1880                	addi	s0,sp,112
    8000390a:	8aaa                	mv	s5,a0
    8000390c:	8bae                	mv	s7,a1
    8000390e:	8a32                	mv	s4,a2
    80003910:	8936                	mv	s2,a3
    80003912:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003914:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003918:	00043737          	lui	a4,0x43
    8000391c:	0cf76963          	bltu	a4,a5,800039ee <writei+0xfc>
    80003920:	0cd7e763          	bltu	a5,a3,800039ee <writei+0xfc>
    80003924:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003926:	0a0b0a63          	beqz	s6,800039da <writei+0xe8>
    8000392a:	eca6                	sd	s1,88(sp)
    8000392c:	f062                	sd	s8,32(sp)
    8000392e:	ec66                	sd	s9,24(sp)
    80003930:	e86a                	sd	s10,16(sp)
    80003932:	e46e                	sd	s11,8(sp)
    80003934:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003936:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000393a:	5c7d                	li	s8,-1
    8000393c:	a825                	j	80003974 <writei+0x82>
    8000393e:	020d1d93          	slli	s11,s10,0x20
    80003942:	020ddd93          	srli	s11,s11,0x20
    80003946:	05848513          	addi	a0,s1,88
    8000394a:	86ee                	mv	a3,s11
    8000394c:	8652                	mv	a2,s4
    8000394e:	85de                	mv	a1,s7
    80003950:	953e                	add	a0,a0,a5
    80003952:	a19fe0ef          	jal	8000236a <either_copyin>
    80003956:	05850663          	beq	a0,s8,800039a2 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    8000395a:	8526                	mv	a0,s1
    8000395c:	6b8000ef          	jal	80004014 <log_write>
    brelse(bp);
    80003960:	8526                	mv	a0,s1
    80003962:	d7cff0ef          	jal	80002ede <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003966:	013d09bb          	addw	s3,s10,s3
    8000396a:	012d093b          	addw	s2,s10,s2
    8000396e:	9a6e                	add	s4,s4,s11
    80003970:	0369fc63          	bgeu	s3,s6,800039a8 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003974:	00a9559b          	srliw	a1,s2,0xa
    80003978:	8556                	mv	a0,s5
    8000397a:	fc2ff0ef          	jal	8000313c <bmap>
    8000397e:	85aa                	mv	a1,a0
    if(addr == 0)
    80003980:	c505                	beqz	a0,800039a8 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80003982:	000aa503          	lw	a0,0(s5)
    80003986:	c50ff0ef          	jal	80002dd6 <bread>
    8000398a:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000398c:	3ff97793          	andi	a5,s2,1023
    80003990:	40fc873b          	subw	a4,s9,a5
    80003994:	413b06bb          	subw	a3,s6,s3
    80003998:	8d3a                	mv	s10,a4
    8000399a:	fae6f2e3          	bgeu	a3,a4,8000393e <writei+0x4c>
    8000399e:	8d36                	mv	s10,a3
    800039a0:	bf79                	j	8000393e <writei+0x4c>
      brelse(bp);
    800039a2:	8526                	mv	a0,s1
    800039a4:	d3aff0ef          	jal	80002ede <brelse>
  }

  if(off > ip->size)
    800039a8:	04caa783          	lw	a5,76(s5)
    800039ac:	0327f963          	bgeu	a5,s2,800039de <writei+0xec>
    ip->size = off;
    800039b0:	052aa623          	sw	s2,76(s5)
    800039b4:	64e6                	ld	s1,88(sp)
    800039b6:	7c02                	ld	s8,32(sp)
    800039b8:	6ce2                	ld	s9,24(sp)
    800039ba:	6d42                	ld	s10,16(sp)
    800039bc:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800039be:	8556                	mv	a0,s5
    800039c0:	9fbff0ef          	jal	800033ba <iupdate>

  return tot;
    800039c4:	854e                	mv	a0,s3
    800039c6:	69a6                	ld	s3,72(sp)
}
    800039c8:	70a6                	ld	ra,104(sp)
    800039ca:	7406                	ld	s0,96(sp)
    800039cc:	6946                	ld	s2,80(sp)
    800039ce:	6a06                	ld	s4,64(sp)
    800039d0:	7ae2                	ld	s5,56(sp)
    800039d2:	7b42                	ld	s6,48(sp)
    800039d4:	7ba2                	ld	s7,40(sp)
    800039d6:	6165                	addi	sp,sp,112
    800039d8:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800039da:	89da                	mv	s3,s6
    800039dc:	b7cd                	j	800039be <writei+0xcc>
    800039de:	64e6                	ld	s1,88(sp)
    800039e0:	7c02                	ld	s8,32(sp)
    800039e2:	6ce2                	ld	s9,24(sp)
    800039e4:	6d42                	ld	s10,16(sp)
    800039e6:	6da2                	ld	s11,8(sp)
    800039e8:	bfd9                	j	800039be <writei+0xcc>
    return -1;
    800039ea:	557d                	li	a0,-1
}
    800039ec:	8082                	ret
    return -1;
    800039ee:	557d                	li	a0,-1
    800039f0:	bfe1                	j	800039c8 <writei+0xd6>

00000000800039f2 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800039f2:	1141                	addi	sp,sp,-16
    800039f4:	e406                	sd	ra,8(sp)
    800039f6:	e022                	sd	s0,0(sp)
    800039f8:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800039fa:	4639                	li	a2,14
    800039fc:	bd0fd0ef          	jal	80000dcc <strncmp>
}
    80003a00:	60a2                	ld	ra,8(sp)
    80003a02:	6402                	ld	s0,0(sp)
    80003a04:	0141                	addi	sp,sp,16
    80003a06:	8082                	ret

0000000080003a08 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003a08:	711d                	addi	sp,sp,-96
    80003a0a:	ec86                	sd	ra,88(sp)
    80003a0c:	e8a2                	sd	s0,80(sp)
    80003a0e:	e4a6                	sd	s1,72(sp)
    80003a10:	e0ca                	sd	s2,64(sp)
    80003a12:	fc4e                	sd	s3,56(sp)
    80003a14:	f852                	sd	s4,48(sp)
    80003a16:	f456                	sd	s5,40(sp)
    80003a18:	f05a                	sd	s6,32(sp)
    80003a1a:	ec5e                	sd	s7,24(sp)
    80003a1c:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003a1e:	04451703          	lh	a4,68(a0)
    80003a22:	4785                	li	a5,1
    80003a24:	00f71f63          	bne	a4,a5,80003a42 <dirlookup+0x3a>
    80003a28:	892a                	mv	s2,a0
    80003a2a:	8aae                	mv	s5,a1
    80003a2c:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a2e:	457c                	lw	a5,76(a0)
    80003a30:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a32:	fa040a13          	addi	s4,s0,-96
    80003a36:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80003a38:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003a3c:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a3e:	e39d                	bnez	a5,80003a64 <dirlookup+0x5c>
    80003a40:	a8b9                	j	80003a9e <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003a42:	00004517          	auipc	a0,0x4
    80003a46:	a5e50513          	addi	a0,a0,-1442 # 800074a0 <etext+0x4a0>
    80003a4a:	ddbfc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    80003a4e:	00004517          	auipc	a0,0x4
    80003a52:	a6a50513          	addi	a0,a0,-1430 # 800074b8 <etext+0x4b8>
    80003a56:	dcffc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a5a:	24c1                	addiw	s1,s1,16
    80003a5c:	04c92783          	lw	a5,76(s2)
    80003a60:	02f4fe63          	bgeu	s1,a5,80003a9c <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a64:	874e                	mv	a4,s3
    80003a66:	86a6                	mv	a3,s1
    80003a68:	8652                	mv	a2,s4
    80003a6a:	4581                	li	a1,0
    80003a6c:	854a                	mv	a0,s2
    80003a6e:	d93ff0ef          	jal	80003800 <readi>
    80003a72:	fd351ee3          	bne	a0,s3,80003a4e <dirlookup+0x46>
    if(de.inum == 0)
    80003a76:	fa045783          	lhu	a5,-96(s0)
    80003a7a:	d3e5                	beqz	a5,80003a5a <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80003a7c:	85da                	mv	a1,s6
    80003a7e:	8556                	mv	a0,s5
    80003a80:	f73ff0ef          	jal	800039f2 <namecmp>
    80003a84:	f979                	bnez	a0,80003a5a <dirlookup+0x52>
      if(poff)
    80003a86:	000b8463          	beqz	s7,80003a8e <dirlookup+0x86>
        *poff = off;
    80003a8a:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003a8e:	fa045583          	lhu	a1,-96(s0)
    80003a92:	00092503          	lw	a0,0(s2)
    80003a96:	f66ff0ef          	jal	800031fc <iget>
    80003a9a:	a011                	j	80003a9e <dirlookup+0x96>
  return 0;
    80003a9c:	4501                	li	a0,0
}
    80003a9e:	60e6                	ld	ra,88(sp)
    80003aa0:	6446                	ld	s0,80(sp)
    80003aa2:	64a6                	ld	s1,72(sp)
    80003aa4:	6906                	ld	s2,64(sp)
    80003aa6:	79e2                	ld	s3,56(sp)
    80003aa8:	7a42                	ld	s4,48(sp)
    80003aaa:	7aa2                	ld	s5,40(sp)
    80003aac:	7b02                	ld	s6,32(sp)
    80003aae:	6be2                	ld	s7,24(sp)
    80003ab0:	6125                	addi	sp,sp,96
    80003ab2:	8082                	ret

0000000080003ab4 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003ab4:	711d                	addi	sp,sp,-96
    80003ab6:	ec86                	sd	ra,88(sp)
    80003ab8:	e8a2                	sd	s0,80(sp)
    80003aba:	e4a6                	sd	s1,72(sp)
    80003abc:	e0ca                	sd	s2,64(sp)
    80003abe:	fc4e                	sd	s3,56(sp)
    80003ac0:	f852                	sd	s4,48(sp)
    80003ac2:	f456                	sd	s5,40(sp)
    80003ac4:	f05a                	sd	s6,32(sp)
    80003ac6:	ec5e                	sd	s7,24(sp)
    80003ac8:	e862                	sd	s8,16(sp)
    80003aca:	e466                	sd	s9,8(sp)
    80003acc:	e06a                	sd	s10,0(sp)
    80003ace:	1080                	addi	s0,sp,96
    80003ad0:	84aa                	mv	s1,a0
    80003ad2:	8b2e                	mv	s6,a1
    80003ad4:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003ad6:	00054703          	lbu	a4,0(a0)
    80003ada:	02f00793          	li	a5,47
    80003ade:	00f70f63          	beq	a4,a5,80003afc <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003ae2:	e4dfd0ef          	jal	8000192e <myproc>
    80003ae6:	15853503          	ld	a0,344(a0)
    80003aea:	94fff0ef          	jal	80003438 <idup>
    80003aee:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003af0:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003af4:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003af6:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003af8:	4b85                	li	s7,1
    80003afa:	a879                	j	80003b98 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003afc:	4585                	li	a1,1
    80003afe:	852e                	mv	a0,a1
    80003b00:	efcff0ef          	jal	800031fc <iget>
    80003b04:	8a2a                	mv	s4,a0
    80003b06:	b7ed                	j	80003af0 <namex+0x3c>
      iunlockput(ip);
    80003b08:	8552                	mv	a0,s4
    80003b0a:	b71ff0ef          	jal	8000367a <iunlockput>
      return 0;
    80003b0e:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003b10:	8552                	mv	a0,s4
    80003b12:	60e6                	ld	ra,88(sp)
    80003b14:	6446                	ld	s0,80(sp)
    80003b16:	64a6                	ld	s1,72(sp)
    80003b18:	6906                	ld	s2,64(sp)
    80003b1a:	79e2                	ld	s3,56(sp)
    80003b1c:	7a42                	ld	s4,48(sp)
    80003b1e:	7aa2                	ld	s5,40(sp)
    80003b20:	7b02                	ld	s6,32(sp)
    80003b22:	6be2                	ld	s7,24(sp)
    80003b24:	6c42                	ld	s8,16(sp)
    80003b26:	6ca2                	ld	s9,8(sp)
    80003b28:	6d02                	ld	s10,0(sp)
    80003b2a:	6125                	addi	sp,sp,96
    80003b2c:	8082                	ret
      iunlock(ip);
    80003b2e:	8552                	mv	a0,s4
    80003b30:	9edff0ef          	jal	8000351c <iunlock>
      return ip;
    80003b34:	bff1                	j	80003b10 <namex+0x5c>
      iunlockput(ip);
    80003b36:	8552                	mv	a0,s4
    80003b38:	b43ff0ef          	jal	8000367a <iunlockput>
      return 0;
    80003b3c:	8a4a                	mv	s4,s2
    80003b3e:	bfc9                	j	80003b10 <namex+0x5c>
  len = path - s;
    80003b40:	40990633          	sub	a2,s2,s1
    80003b44:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003b48:	09ac5463          	bge	s8,s10,80003bd0 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80003b4c:	8666                	mv	a2,s9
    80003b4e:	85a6                	mv	a1,s1
    80003b50:	8556                	mv	a0,s5
    80003b52:	a06fd0ef          	jal	80000d58 <memmove>
    80003b56:	84ca                	mv	s1,s2
  while(*path == '/')
    80003b58:	0004c783          	lbu	a5,0(s1)
    80003b5c:	01379763          	bne	a5,s3,80003b6a <namex+0xb6>
    path++;
    80003b60:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003b62:	0004c783          	lbu	a5,0(s1)
    80003b66:	ff378de3          	beq	a5,s3,80003b60 <namex+0xac>
    ilock(ip);
    80003b6a:	8552                	mv	a0,s4
    80003b6c:	903ff0ef          	jal	8000346e <ilock>
    if(ip->type != T_DIR){
    80003b70:	044a1783          	lh	a5,68(s4)
    80003b74:	f9779ae3          	bne	a5,s7,80003b08 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80003b78:	000b0563          	beqz	s6,80003b82 <namex+0xce>
    80003b7c:	0004c783          	lbu	a5,0(s1)
    80003b80:	d7dd                	beqz	a5,80003b2e <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003b82:	4601                	li	a2,0
    80003b84:	85d6                	mv	a1,s5
    80003b86:	8552                	mv	a0,s4
    80003b88:	e81ff0ef          	jal	80003a08 <dirlookup>
    80003b8c:	892a                	mv	s2,a0
    80003b8e:	d545                	beqz	a0,80003b36 <namex+0x82>
    iunlockput(ip);
    80003b90:	8552                	mv	a0,s4
    80003b92:	ae9ff0ef          	jal	8000367a <iunlockput>
    ip = next;
    80003b96:	8a4a                	mv	s4,s2
  while(*path == '/')
    80003b98:	0004c783          	lbu	a5,0(s1)
    80003b9c:	01379763          	bne	a5,s3,80003baa <namex+0xf6>
    path++;
    80003ba0:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003ba2:	0004c783          	lbu	a5,0(s1)
    80003ba6:	ff378de3          	beq	a5,s3,80003ba0 <namex+0xec>
  if(*path == 0)
    80003baa:	cf8d                	beqz	a5,80003be4 <namex+0x130>
  while(*path != '/' && *path != 0)
    80003bac:	0004c783          	lbu	a5,0(s1)
    80003bb0:	fd178713          	addi	a4,a5,-47
    80003bb4:	cb19                	beqz	a4,80003bca <namex+0x116>
    80003bb6:	cb91                	beqz	a5,80003bca <namex+0x116>
    80003bb8:	8926                	mv	s2,s1
    path++;
    80003bba:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80003bbc:	00094783          	lbu	a5,0(s2)
    80003bc0:	fd178713          	addi	a4,a5,-47
    80003bc4:	df35                	beqz	a4,80003b40 <namex+0x8c>
    80003bc6:	fbf5                	bnez	a5,80003bba <namex+0x106>
    80003bc8:	bfa5                	j	80003b40 <namex+0x8c>
    80003bca:	8926                	mv	s2,s1
  len = path - s;
    80003bcc:	4d01                	li	s10,0
    80003bce:	4601                	li	a2,0
    memmove(name, s, len);
    80003bd0:	2601                	sext.w	a2,a2
    80003bd2:	85a6                	mv	a1,s1
    80003bd4:	8556                	mv	a0,s5
    80003bd6:	982fd0ef          	jal	80000d58 <memmove>
    name[len] = 0;
    80003bda:	9d56                	add	s10,s10,s5
    80003bdc:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde268>
    80003be0:	84ca                	mv	s1,s2
    80003be2:	bf9d                	j	80003b58 <namex+0xa4>
  if(nameiparent){
    80003be4:	f20b06e3          	beqz	s6,80003b10 <namex+0x5c>
    iput(ip);
    80003be8:	8552                	mv	a0,s4
    80003bea:	a07ff0ef          	jal	800035f0 <iput>
    return 0;
    80003bee:	4a01                	li	s4,0
    80003bf0:	b705                	j	80003b10 <namex+0x5c>

0000000080003bf2 <dirlink>:
{
    80003bf2:	715d                	addi	sp,sp,-80
    80003bf4:	e486                	sd	ra,72(sp)
    80003bf6:	e0a2                	sd	s0,64(sp)
    80003bf8:	f84a                	sd	s2,48(sp)
    80003bfa:	ec56                	sd	s5,24(sp)
    80003bfc:	e85a                	sd	s6,16(sp)
    80003bfe:	0880                	addi	s0,sp,80
    80003c00:	892a                	mv	s2,a0
    80003c02:	8aae                	mv	s5,a1
    80003c04:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003c06:	4601                	li	a2,0
    80003c08:	e01ff0ef          	jal	80003a08 <dirlookup>
    80003c0c:	ed1d                	bnez	a0,80003c4a <dirlink+0x58>
    80003c0e:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c10:	04c92483          	lw	s1,76(s2)
    80003c14:	c4b9                	beqz	s1,80003c62 <dirlink+0x70>
    80003c16:	f44e                	sd	s3,40(sp)
    80003c18:	f052                	sd	s4,32(sp)
    80003c1a:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c1c:	fb040a13          	addi	s4,s0,-80
    80003c20:	49c1                	li	s3,16
    80003c22:	874e                	mv	a4,s3
    80003c24:	86a6                	mv	a3,s1
    80003c26:	8652                	mv	a2,s4
    80003c28:	4581                	li	a1,0
    80003c2a:	854a                	mv	a0,s2
    80003c2c:	bd5ff0ef          	jal	80003800 <readi>
    80003c30:	03351163          	bne	a0,s3,80003c52 <dirlink+0x60>
    if(de.inum == 0)
    80003c34:	fb045783          	lhu	a5,-80(s0)
    80003c38:	c39d                	beqz	a5,80003c5e <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c3a:	24c1                	addiw	s1,s1,16
    80003c3c:	04c92783          	lw	a5,76(s2)
    80003c40:	fef4e1e3          	bltu	s1,a5,80003c22 <dirlink+0x30>
    80003c44:	79a2                	ld	s3,40(sp)
    80003c46:	7a02                	ld	s4,32(sp)
    80003c48:	a829                	j	80003c62 <dirlink+0x70>
    iput(ip);
    80003c4a:	9a7ff0ef          	jal	800035f0 <iput>
    return -1;
    80003c4e:	557d                	li	a0,-1
    80003c50:	a83d                	j	80003c8e <dirlink+0x9c>
      panic("dirlink read");
    80003c52:	00004517          	auipc	a0,0x4
    80003c56:	87650513          	addi	a0,a0,-1930 # 800074c8 <etext+0x4c8>
    80003c5a:	bcbfc0ef          	jal	80000824 <panic>
    80003c5e:	79a2                	ld	s3,40(sp)
    80003c60:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003c62:	4639                	li	a2,14
    80003c64:	85d6                	mv	a1,s5
    80003c66:	fb240513          	addi	a0,s0,-78
    80003c6a:	99cfd0ef          	jal	80000e06 <strncpy>
  de.inum = inum;
    80003c6e:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c72:	4741                	li	a4,16
    80003c74:	86a6                	mv	a3,s1
    80003c76:	fb040613          	addi	a2,s0,-80
    80003c7a:	4581                	li	a1,0
    80003c7c:	854a                	mv	a0,s2
    80003c7e:	c75ff0ef          	jal	800038f2 <writei>
    80003c82:	1541                	addi	a0,a0,-16
    80003c84:	00a03533          	snez	a0,a0
    80003c88:	40a0053b          	negw	a0,a0
    80003c8c:	74e2                	ld	s1,56(sp)
}
    80003c8e:	60a6                	ld	ra,72(sp)
    80003c90:	6406                	ld	s0,64(sp)
    80003c92:	7942                	ld	s2,48(sp)
    80003c94:	6ae2                	ld	s5,24(sp)
    80003c96:	6b42                	ld	s6,16(sp)
    80003c98:	6161                	addi	sp,sp,80
    80003c9a:	8082                	ret

0000000080003c9c <namei>:

struct inode*
namei(char *path)
{
    80003c9c:	1101                	addi	sp,sp,-32
    80003c9e:	ec06                	sd	ra,24(sp)
    80003ca0:	e822                	sd	s0,16(sp)
    80003ca2:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003ca4:	fe040613          	addi	a2,s0,-32
    80003ca8:	4581                	li	a1,0
    80003caa:	e0bff0ef          	jal	80003ab4 <namex>
}
    80003cae:	60e2                	ld	ra,24(sp)
    80003cb0:	6442                	ld	s0,16(sp)
    80003cb2:	6105                	addi	sp,sp,32
    80003cb4:	8082                	ret

0000000080003cb6 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003cb6:	1141                	addi	sp,sp,-16
    80003cb8:	e406                	sd	ra,8(sp)
    80003cba:	e022                	sd	s0,0(sp)
    80003cbc:	0800                	addi	s0,sp,16
    80003cbe:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003cc0:	4585                	li	a1,1
    80003cc2:	df3ff0ef          	jal	80003ab4 <namex>
}
    80003cc6:	60a2                	ld	ra,8(sp)
    80003cc8:	6402                	ld	s0,0(sp)
    80003cca:	0141                	addi	sp,sp,16
    80003ccc:	8082                	ret

0000000080003cce <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003cce:	1101                	addi	sp,sp,-32
    80003cd0:	ec06                	sd	ra,24(sp)
    80003cd2:	e822                	sd	s0,16(sp)
    80003cd4:	e426                	sd	s1,8(sp)
    80003cd6:	e04a                	sd	s2,0(sp)
    80003cd8:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003cda:	0001c917          	auipc	s2,0x1c
    80003cde:	e7e90913          	addi	s2,s2,-386 # 8001fb58 <log>
    80003ce2:	01892583          	lw	a1,24(s2)
    80003ce6:	02492503          	lw	a0,36(s2)
    80003cea:	8ecff0ef          	jal	80002dd6 <bread>
    80003cee:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003cf0:	02892603          	lw	a2,40(s2)
    80003cf4:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003cf6:	00c05f63          	blez	a2,80003d14 <write_head+0x46>
    80003cfa:	0001c717          	auipc	a4,0x1c
    80003cfe:	e8a70713          	addi	a4,a4,-374 # 8001fb84 <log+0x2c>
    80003d02:	87aa                	mv	a5,a0
    80003d04:	060a                	slli	a2,a2,0x2
    80003d06:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003d08:	4314                	lw	a3,0(a4)
    80003d0a:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003d0c:	0711                	addi	a4,a4,4
    80003d0e:	0791                	addi	a5,a5,4
    80003d10:	fec79ce3          	bne	a5,a2,80003d08 <write_head+0x3a>
  }
  bwrite(buf);
    80003d14:	8526                	mv	a0,s1
    80003d16:	996ff0ef          	jal	80002eac <bwrite>
  brelse(buf);
    80003d1a:	8526                	mv	a0,s1
    80003d1c:	9c2ff0ef          	jal	80002ede <brelse>
}
    80003d20:	60e2                	ld	ra,24(sp)
    80003d22:	6442                	ld	s0,16(sp)
    80003d24:	64a2                	ld	s1,8(sp)
    80003d26:	6902                	ld	s2,0(sp)
    80003d28:	6105                	addi	sp,sp,32
    80003d2a:	8082                	ret

0000000080003d2c <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d2c:	0001c797          	auipc	a5,0x1c
    80003d30:	e547a783          	lw	a5,-428(a5) # 8001fb80 <log+0x28>
    80003d34:	0cf05163          	blez	a5,80003df6 <install_trans+0xca>
{
    80003d38:	715d                	addi	sp,sp,-80
    80003d3a:	e486                	sd	ra,72(sp)
    80003d3c:	e0a2                	sd	s0,64(sp)
    80003d3e:	fc26                	sd	s1,56(sp)
    80003d40:	f84a                	sd	s2,48(sp)
    80003d42:	f44e                	sd	s3,40(sp)
    80003d44:	f052                	sd	s4,32(sp)
    80003d46:	ec56                	sd	s5,24(sp)
    80003d48:	e85a                	sd	s6,16(sp)
    80003d4a:	e45e                	sd	s7,8(sp)
    80003d4c:	e062                	sd	s8,0(sp)
    80003d4e:	0880                	addi	s0,sp,80
    80003d50:	8b2a                	mv	s6,a0
    80003d52:	0001ca97          	auipc	s5,0x1c
    80003d56:	e32a8a93          	addi	s5,s5,-462 # 8001fb84 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d5a:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003d5c:	00003c17          	auipc	s8,0x3
    80003d60:	77cc0c13          	addi	s8,s8,1916 # 800074d8 <etext+0x4d8>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003d64:	0001ca17          	auipc	s4,0x1c
    80003d68:	df4a0a13          	addi	s4,s4,-524 # 8001fb58 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003d6c:	40000b93          	li	s7,1024
    80003d70:	a025                	j	80003d98 <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003d72:	000aa603          	lw	a2,0(s5)
    80003d76:	85ce                	mv	a1,s3
    80003d78:	8562                	mv	a0,s8
    80003d7a:	f80fc0ef          	jal	800004fa <printf>
    80003d7e:	a839                	j	80003d9c <install_trans+0x70>
    brelse(lbuf);
    80003d80:	854a                	mv	a0,s2
    80003d82:	95cff0ef          	jal	80002ede <brelse>
    brelse(dbuf);
    80003d86:	8526                	mv	a0,s1
    80003d88:	956ff0ef          	jal	80002ede <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d8c:	2985                	addiw	s3,s3,1
    80003d8e:	0a91                	addi	s5,s5,4
    80003d90:	028a2783          	lw	a5,40(s4)
    80003d94:	04f9d563          	bge	s3,a5,80003dde <install_trans+0xb2>
    if(recovering) {
    80003d98:	fc0b1de3          	bnez	s6,80003d72 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003d9c:	018a2583          	lw	a1,24(s4)
    80003da0:	013585bb          	addw	a1,a1,s3
    80003da4:	2585                	addiw	a1,a1,1
    80003da6:	024a2503          	lw	a0,36(s4)
    80003daa:	82cff0ef          	jal	80002dd6 <bread>
    80003dae:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003db0:	000aa583          	lw	a1,0(s5)
    80003db4:	024a2503          	lw	a0,36(s4)
    80003db8:	81eff0ef          	jal	80002dd6 <bread>
    80003dbc:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003dbe:	865e                	mv	a2,s7
    80003dc0:	05890593          	addi	a1,s2,88
    80003dc4:	05850513          	addi	a0,a0,88
    80003dc8:	f91fc0ef          	jal	80000d58 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003dcc:	8526                	mv	a0,s1
    80003dce:	8deff0ef          	jal	80002eac <bwrite>
    if(recovering == 0)
    80003dd2:	fa0b17e3          	bnez	s6,80003d80 <install_trans+0x54>
      bunpin(dbuf);
    80003dd6:	8526                	mv	a0,s1
    80003dd8:	9beff0ef          	jal	80002f96 <bunpin>
    80003ddc:	b755                	j	80003d80 <install_trans+0x54>
}
    80003dde:	60a6                	ld	ra,72(sp)
    80003de0:	6406                	ld	s0,64(sp)
    80003de2:	74e2                	ld	s1,56(sp)
    80003de4:	7942                	ld	s2,48(sp)
    80003de6:	79a2                	ld	s3,40(sp)
    80003de8:	7a02                	ld	s4,32(sp)
    80003dea:	6ae2                	ld	s5,24(sp)
    80003dec:	6b42                	ld	s6,16(sp)
    80003dee:	6ba2                	ld	s7,8(sp)
    80003df0:	6c02                	ld	s8,0(sp)
    80003df2:	6161                	addi	sp,sp,80
    80003df4:	8082                	ret
    80003df6:	8082                	ret

0000000080003df8 <initlog>:
{
    80003df8:	7179                	addi	sp,sp,-48
    80003dfa:	f406                	sd	ra,40(sp)
    80003dfc:	f022                	sd	s0,32(sp)
    80003dfe:	ec26                	sd	s1,24(sp)
    80003e00:	e84a                	sd	s2,16(sp)
    80003e02:	e44e                	sd	s3,8(sp)
    80003e04:	1800                	addi	s0,sp,48
    80003e06:	84aa                	mv	s1,a0
    80003e08:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003e0a:	0001c917          	auipc	s2,0x1c
    80003e0e:	d4e90913          	addi	s2,s2,-690 # 8001fb58 <log>
    80003e12:	00003597          	auipc	a1,0x3
    80003e16:	6e658593          	addi	a1,a1,1766 # 800074f8 <etext+0x4f8>
    80003e1a:	854a                	mv	a0,s2
    80003e1c:	d83fc0ef          	jal	80000b9e <initlock>
  log.start = sb->logstart;
    80003e20:	0149a583          	lw	a1,20(s3)
    80003e24:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003e28:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003e2c:	8526                	mv	a0,s1
    80003e2e:	fa9fe0ef          	jal	80002dd6 <bread>
  log.lh.n = lh->n;
    80003e32:	4d30                	lw	a2,88(a0)
    80003e34:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003e38:	00c05f63          	blez	a2,80003e56 <initlog+0x5e>
    80003e3c:	87aa                	mv	a5,a0
    80003e3e:	0001c717          	auipc	a4,0x1c
    80003e42:	d4670713          	addi	a4,a4,-698 # 8001fb84 <log+0x2c>
    80003e46:	060a                	slli	a2,a2,0x2
    80003e48:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003e4a:	4ff4                	lw	a3,92(a5)
    80003e4c:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003e4e:	0791                	addi	a5,a5,4
    80003e50:	0711                	addi	a4,a4,4
    80003e52:	fec79ce3          	bne	a5,a2,80003e4a <initlog+0x52>
  brelse(buf);
    80003e56:	888ff0ef          	jal	80002ede <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003e5a:	4505                	li	a0,1
    80003e5c:	ed1ff0ef          	jal	80003d2c <install_trans>
  log.lh.n = 0;
    80003e60:	0001c797          	auipc	a5,0x1c
    80003e64:	d207a023          	sw	zero,-736(a5) # 8001fb80 <log+0x28>
  write_head(); // clear the log
    80003e68:	e67ff0ef          	jal	80003cce <write_head>
}
    80003e6c:	70a2                	ld	ra,40(sp)
    80003e6e:	7402                	ld	s0,32(sp)
    80003e70:	64e2                	ld	s1,24(sp)
    80003e72:	6942                	ld	s2,16(sp)
    80003e74:	69a2                	ld	s3,8(sp)
    80003e76:	6145                	addi	sp,sp,48
    80003e78:	8082                	ret

0000000080003e7a <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003e7a:	1101                	addi	sp,sp,-32
    80003e7c:	ec06                	sd	ra,24(sp)
    80003e7e:	e822                	sd	s0,16(sp)
    80003e80:	e426                	sd	s1,8(sp)
    80003e82:	e04a                	sd	s2,0(sp)
    80003e84:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003e86:	0001c517          	auipc	a0,0x1c
    80003e8a:	cd250513          	addi	a0,a0,-814 # 8001fb58 <log>
    80003e8e:	d9bfc0ef          	jal	80000c28 <acquire>
  while(1){
    if(log.committing){
    80003e92:	0001c497          	auipc	s1,0x1c
    80003e96:	cc648493          	addi	s1,s1,-826 # 8001fb58 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003e9a:	4979                	li	s2,30
    80003e9c:	a029                	j	80003ea6 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003e9e:	85a6                	mv	a1,s1
    80003ea0:	8526                	mv	a0,s1
    80003ea2:	924fe0ef          	jal	80001fc6 <sleep>
    if(log.committing){
    80003ea6:	509c                	lw	a5,32(s1)
    80003ea8:	fbfd                	bnez	a5,80003e9e <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003eaa:	4cd8                	lw	a4,28(s1)
    80003eac:	2705                	addiw	a4,a4,1
    80003eae:	0027179b          	slliw	a5,a4,0x2
    80003eb2:	9fb9                	addw	a5,a5,a4
    80003eb4:	0017979b          	slliw	a5,a5,0x1
    80003eb8:	5494                	lw	a3,40(s1)
    80003eba:	9fb5                	addw	a5,a5,a3
    80003ebc:	00f95763          	bge	s2,a5,80003eca <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003ec0:	85a6                	mv	a1,s1
    80003ec2:	8526                	mv	a0,s1
    80003ec4:	902fe0ef          	jal	80001fc6 <sleep>
    80003ec8:	bff9                	j	80003ea6 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003eca:	0001c797          	auipc	a5,0x1c
    80003ece:	cae7a523          	sw	a4,-854(a5) # 8001fb74 <log+0x1c>
      release(&log.lock);
    80003ed2:	0001c517          	auipc	a0,0x1c
    80003ed6:	c8650513          	addi	a0,a0,-890 # 8001fb58 <log>
    80003eda:	de3fc0ef          	jal	80000cbc <release>
      break;
    }
  }
}
    80003ede:	60e2                	ld	ra,24(sp)
    80003ee0:	6442                	ld	s0,16(sp)
    80003ee2:	64a2                	ld	s1,8(sp)
    80003ee4:	6902                	ld	s2,0(sp)
    80003ee6:	6105                	addi	sp,sp,32
    80003ee8:	8082                	ret

0000000080003eea <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003eea:	7139                	addi	sp,sp,-64
    80003eec:	fc06                	sd	ra,56(sp)
    80003eee:	f822                	sd	s0,48(sp)
    80003ef0:	f426                	sd	s1,40(sp)
    80003ef2:	f04a                	sd	s2,32(sp)
    80003ef4:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003ef6:	0001c497          	auipc	s1,0x1c
    80003efa:	c6248493          	addi	s1,s1,-926 # 8001fb58 <log>
    80003efe:	8526                	mv	a0,s1
    80003f00:	d29fc0ef          	jal	80000c28 <acquire>
  log.outstanding -= 1;
    80003f04:	4cdc                	lw	a5,28(s1)
    80003f06:	37fd                	addiw	a5,a5,-1
    80003f08:	893e                	mv	s2,a5
    80003f0a:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003f0c:	509c                	lw	a5,32(s1)
    80003f0e:	e7b1                	bnez	a5,80003f5a <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003f10:	04091e63          	bnez	s2,80003f6c <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80003f14:	0001c497          	auipc	s1,0x1c
    80003f18:	c4448493          	addi	s1,s1,-956 # 8001fb58 <log>
    80003f1c:	4785                	li	a5,1
    80003f1e:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003f20:	8526                	mv	a0,s1
    80003f22:	d9bfc0ef          	jal	80000cbc <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003f26:	549c                	lw	a5,40(s1)
    80003f28:	06f04463          	bgtz	a5,80003f90 <end_op+0xa6>
    acquire(&log.lock);
    80003f2c:	0001c517          	auipc	a0,0x1c
    80003f30:	c2c50513          	addi	a0,a0,-980 # 8001fb58 <log>
    80003f34:	cf5fc0ef          	jal	80000c28 <acquire>
    log.committing = 0;
    80003f38:	0001c797          	auipc	a5,0x1c
    80003f3c:	c407a023          	sw	zero,-960(a5) # 8001fb78 <log+0x20>
    wakeup(&log);
    80003f40:	0001c517          	auipc	a0,0x1c
    80003f44:	c1850513          	addi	a0,a0,-1000 # 8001fb58 <log>
    80003f48:	8cafe0ef          	jal	80002012 <wakeup>
    release(&log.lock);
    80003f4c:	0001c517          	auipc	a0,0x1c
    80003f50:	c0c50513          	addi	a0,a0,-1012 # 8001fb58 <log>
    80003f54:	d69fc0ef          	jal	80000cbc <release>
}
    80003f58:	a035                	j	80003f84 <end_op+0x9a>
    80003f5a:	ec4e                	sd	s3,24(sp)
    80003f5c:	e852                	sd	s4,16(sp)
    80003f5e:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003f60:	00003517          	auipc	a0,0x3
    80003f64:	5a050513          	addi	a0,a0,1440 # 80007500 <etext+0x500>
    80003f68:	8bdfc0ef          	jal	80000824 <panic>
    wakeup(&log);
    80003f6c:	0001c517          	auipc	a0,0x1c
    80003f70:	bec50513          	addi	a0,a0,-1044 # 8001fb58 <log>
    80003f74:	89efe0ef          	jal	80002012 <wakeup>
  release(&log.lock);
    80003f78:	0001c517          	auipc	a0,0x1c
    80003f7c:	be050513          	addi	a0,a0,-1056 # 8001fb58 <log>
    80003f80:	d3dfc0ef          	jal	80000cbc <release>
}
    80003f84:	70e2                	ld	ra,56(sp)
    80003f86:	7442                	ld	s0,48(sp)
    80003f88:	74a2                	ld	s1,40(sp)
    80003f8a:	7902                	ld	s2,32(sp)
    80003f8c:	6121                	addi	sp,sp,64
    80003f8e:	8082                	ret
    80003f90:	ec4e                	sd	s3,24(sp)
    80003f92:	e852                	sd	s4,16(sp)
    80003f94:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f96:	0001ca97          	auipc	s5,0x1c
    80003f9a:	beea8a93          	addi	s5,s5,-1042 # 8001fb84 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003f9e:	0001ca17          	auipc	s4,0x1c
    80003fa2:	bbaa0a13          	addi	s4,s4,-1094 # 8001fb58 <log>
    80003fa6:	018a2583          	lw	a1,24(s4)
    80003faa:	012585bb          	addw	a1,a1,s2
    80003fae:	2585                	addiw	a1,a1,1
    80003fb0:	024a2503          	lw	a0,36(s4)
    80003fb4:	e23fe0ef          	jal	80002dd6 <bread>
    80003fb8:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003fba:	000aa583          	lw	a1,0(s5)
    80003fbe:	024a2503          	lw	a0,36(s4)
    80003fc2:	e15fe0ef          	jal	80002dd6 <bread>
    80003fc6:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003fc8:	40000613          	li	a2,1024
    80003fcc:	05850593          	addi	a1,a0,88
    80003fd0:	05848513          	addi	a0,s1,88
    80003fd4:	d85fc0ef          	jal	80000d58 <memmove>
    bwrite(to);  // write the log
    80003fd8:	8526                	mv	a0,s1
    80003fda:	ed3fe0ef          	jal	80002eac <bwrite>
    brelse(from);
    80003fde:	854e                	mv	a0,s3
    80003fe0:	efffe0ef          	jal	80002ede <brelse>
    brelse(to);
    80003fe4:	8526                	mv	a0,s1
    80003fe6:	ef9fe0ef          	jal	80002ede <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fea:	2905                	addiw	s2,s2,1
    80003fec:	0a91                	addi	s5,s5,4
    80003fee:	028a2783          	lw	a5,40(s4)
    80003ff2:	faf94ae3          	blt	s2,a5,80003fa6 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003ff6:	cd9ff0ef          	jal	80003cce <write_head>
    install_trans(0); // Now install writes to home locations
    80003ffa:	4501                	li	a0,0
    80003ffc:	d31ff0ef          	jal	80003d2c <install_trans>
    log.lh.n = 0;
    80004000:	0001c797          	auipc	a5,0x1c
    80004004:	b807a023          	sw	zero,-1152(a5) # 8001fb80 <log+0x28>
    write_head();    // Erase the transaction from the log
    80004008:	cc7ff0ef          	jal	80003cce <write_head>
    8000400c:	69e2                	ld	s3,24(sp)
    8000400e:	6a42                	ld	s4,16(sp)
    80004010:	6aa2                	ld	s5,8(sp)
    80004012:	bf29                	j	80003f2c <end_op+0x42>

0000000080004014 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004014:	1101                	addi	sp,sp,-32
    80004016:	ec06                	sd	ra,24(sp)
    80004018:	e822                	sd	s0,16(sp)
    8000401a:	e426                	sd	s1,8(sp)
    8000401c:	1000                	addi	s0,sp,32
    8000401e:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004020:	0001c517          	auipc	a0,0x1c
    80004024:	b3850513          	addi	a0,a0,-1224 # 8001fb58 <log>
    80004028:	c01fc0ef          	jal	80000c28 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    8000402c:	0001c617          	auipc	a2,0x1c
    80004030:	b5462603          	lw	a2,-1196(a2) # 8001fb80 <log+0x28>
    80004034:	47f5                	li	a5,29
    80004036:	04c7cd63          	blt	a5,a2,80004090 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000403a:	0001c797          	auipc	a5,0x1c
    8000403e:	b3a7a783          	lw	a5,-1222(a5) # 8001fb74 <log+0x1c>
    80004042:	04f05d63          	blez	a5,8000409c <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004046:	4781                	li	a5,0
    80004048:	06c05063          	blez	a2,800040a8 <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000404c:	44cc                	lw	a1,12(s1)
    8000404e:	0001c717          	auipc	a4,0x1c
    80004052:	b3670713          	addi	a4,a4,-1226 # 8001fb84 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80004056:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004058:	4314                	lw	a3,0(a4)
    8000405a:	04b68763          	beq	a3,a1,800040a8 <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    8000405e:	2785                	addiw	a5,a5,1
    80004060:	0711                	addi	a4,a4,4
    80004062:	fef61be3          	bne	a2,a5,80004058 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004066:	060a                	slli	a2,a2,0x2
    80004068:	02060613          	addi	a2,a2,32
    8000406c:	0001c797          	auipc	a5,0x1c
    80004070:	aec78793          	addi	a5,a5,-1300 # 8001fb58 <log>
    80004074:	97b2                	add	a5,a5,a2
    80004076:	44d8                	lw	a4,12(s1)
    80004078:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000407a:	8526                	mv	a0,s1
    8000407c:	ee7fe0ef          	jal	80002f62 <bpin>
    log.lh.n++;
    80004080:	0001c717          	auipc	a4,0x1c
    80004084:	ad870713          	addi	a4,a4,-1320 # 8001fb58 <log>
    80004088:	571c                	lw	a5,40(a4)
    8000408a:	2785                	addiw	a5,a5,1
    8000408c:	d71c                	sw	a5,40(a4)
    8000408e:	a815                	j	800040c2 <log_write+0xae>
    panic("too big a transaction");
    80004090:	00003517          	auipc	a0,0x3
    80004094:	48050513          	addi	a0,a0,1152 # 80007510 <etext+0x510>
    80004098:	f8cfc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    8000409c:	00003517          	auipc	a0,0x3
    800040a0:	48c50513          	addi	a0,a0,1164 # 80007528 <etext+0x528>
    800040a4:	f80fc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    800040a8:	00279693          	slli	a3,a5,0x2
    800040ac:	02068693          	addi	a3,a3,32
    800040b0:	0001c717          	auipc	a4,0x1c
    800040b4:	aa870713          	addi	a4,a4,-1368 # 8001fb58 <log>
    800040b8:	9736                	add	a4,a4,a3
    800040ba:	44d4                	lw	a3,12(s1)
    800040bc:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800040be:	faf60ee3          	beq	a2,a5,8000407a <log_write+0x66>
  }
  release(&log.lock);
    800040c2:	0001c517          	auipc	a0,0x1c
    800040c6:	a9650513          	addi	a0,a0,-1386 # 8001fb58 <log>
    800040ca:	bf3fc0ef          	jal	80000cbc <release>
}
    800040ce:	60e2                	ld	ra,24(sp)
    800040d0:	6442                	ld	s0,16(sp)
    800040d2:	64a2                	ld	s1,8(sp)
    800040d4:	6105                	addi	sp,sp,32
    800040d6:	8082                	ret

00000000800040d8 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800040d8:	1101                	addi	sp,sp,-32
    800040da:	ec06                	sd	ra,24(sp)
    800040dc:	e822                	sd	s0,16(sp)
    800040de:	e426                	sd	s1,8(sp)
    800040e0:	e04a                	sd	s2,0(sp)
    800040e2:	1000                	addi	s0,sp,32
    800040e4:	84aa                	mv	s1,a0
    800040e6:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800040e8:	00003597          	auipc	a1,0x3
    800040ec:	46058593          	addi	a1,a1,1120 # 80007548 <etext+0x548>
    800040f0:	0521                	addi	a0,a0,8
    800040f2:	aadfc0ef          	jal	80000b9e <initlock>
  lk->name = name;
    800040f6:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800040fa:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800040fe:	0204a423          	sw	zero,40(s1)
}
    80004102:	60e2                	ld	ra,24(sp)
    80004104:	6442                	ld	s0,16(sp)
    80004106:	64a2                	ld	s1,8(sp)
    80004108:	6902                	ld	s2,0(sp)
    8000410a:	6105                	addi	sp,sp,32
    8000410c:	8082                	ret

000000008000410e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000410e:	1101                	addi	sp,sp,-32
    80004110:	ec06                	sd	ra,24(sp)
    80004112:	e822                	sd	s0,16(sp)
    80004114:	e426                	sd	s1,8(sp)
    80004116:	e04a                	sd	s2,0(sp)
    80004118:	1000                	addi	s0,sp,32
    8000411a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000411c:	00850913          	addi	s2,a0,8
    80004120:	854a                	mv	a0,s2
    80004122:	b07fc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    80004126:	409c                	lw	a5,0(s1)
    80004128:	c799                	beqz	a5,80004136 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000412a:	85ca                	mv	a1,s2
    8000412c:	8526                	mv	a0,s1
    8000412e:	e99fd0ef          	jal	80001fc6 <sleep>
  while (lk->locked) {
    80004132:	409c                	lw	a5,0(s1)
    80004134:	fbfd                	bnez	a5,8000412a <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004136:	4785                	li	a5,1
    80004138:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000413a:	ff4fd0ef          	jal	8000192e <myproc>
    8000413e:	5d1c                	lw	a5,56(a0)
    80004140:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004142:	854a                	mv	a0,s2
    80004144:	b79fc0ef          	jal	80000cbc <release>
}
    80004148:	60e2                	ld	ra,24(sp)
    8000414a:	6442                	ld	s0,16(sp)
    8000414c:	64a2                	ld	s1,8(sp)
    8000414e:	6902                	ld	s2,0(sp)
    80004150:	6105                	addi	sp,sp,32
    80004152:	8082                	ret

0000000080004154 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004154:	1101                	addi	sp,sp,-32
    80004156:	ec06                	sd	ra,24(sp)
    80004158:	e822                	sd	s0,16(sp)
    8000415a:	e426                	sd	s1,8(sp)
    8000415c:	e04a                	sd	s2,0(sp)
    8000415e:	1000                	addi	s0,sp,32
    80004160:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004162:	00850913          	addi	s2,a0,8
    80004166:	854a                	mv	a0,s2
    80004168:	ac1fc0ef          	jal	80000c28 <acquire>
  lk->locked = 0;
    8000416c:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004170:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004174:	8526                	mv	a0,s1
    80004176:	e9dfd0ef          	jal	80002012 <wakeup>
  release(&lk->lk);
    8000417a:	854a                	mv	a0,s2
    8000417c:	b41fc0ef          	jal	80000cbc <release>
}
    80004180:	60e2                	ld	ra,24(sp)
    80004182:	6442                	ld	s0,16(sp)
    80004184:	64a2                	ld	s1,8(sp)
    80004186:	6902                	ld	s2,0(sp)
    80004188:	6105                	addi	sp,sp,32
    8000418a:	8082                	ret

000000008000418c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000418c:	7179                	addi	sp,sp,-48
    8000418e:	f406                	sd	ra,40(sp)
    80004190:	f022                	sd	s0,32(sp)
    80004192:	ec26                	sd	s1,24(sp)
    80004194:	e84a                	sd	s2,16(sp)
    80004196:	1800                	addi	s0,sp,48
    80004198:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000419a:	00850913          	addi	s2,a0,8
    8000419e:	854a                	mv	a0,s2
    800041a0:	a89fc0ef          	jal	80000c28 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800041a4:	409c                	lw	a5,0(s1)
    800041a6:	ef81                	bnez	a5,800041be <holdingsleep+0x32>
    800041a8:	4481                	li	s1,0
  release(&lk->lk);
    800041aa:	854a                	mv	a0,s2
    800041ac:	b11fc0ef          	jal	80000cbc <release>
  return r;
}
    800041b0:	8526                	mv	a0,s1
    800041b2:	70a2                	ld	ra,40(sp)
    800041b4:	7402                	ld	s0,32(sp)
    800041b6:	64e2                	ld	s1,24(sp)
    800041b8:	6942                	ld	s2,16(sp)
    800041ba:	6145                	addi	sp,sp,48
    800041bc:	8082                	ret
    800041be:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800041c0:	0284a983          	lw	s3,40(s1)
    800041c4:	f6afd0ef          	jal	8000192e <myproc>
    800041c8:	5d04                	lw	s1,56(a0)
    800041ca:	413484b3          	sub	s1,s1,s3
    800041ce:	0014b493          	seqz	s1,s1
    800041d2:	69a2                	ld	s3,8(sp)
    800041d4:	bfd9                	j	800041aa <holdingsleep+0x1e>

00000000800041d6 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800041d6:	1141                	addi	sp,sp,-16
    800041d8:	e406                	sd	ra,8(sp)
    800041da:	e022                	sd	s0,0(sp)
    800041dc:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800041de:	00003597          	auipc	a1,0x3
    800041e2:	37a58593          	addi	a1,a1,890 # 80007558 <etext+0x558>
    800041e6:	0001c517          	auipc	a0,0x1c
    800041ea:	aba50513          	addi	a0,a0,-1350 # 8001fca0 <ftable>
    800041ee:	9b1fc0ef          	jal	80000b9e <initlock>
}
    800041f2:	60a2                	ld	ra,8(sp)
    800041f4:	6402                	ld	s0,0(sp)
    800041f6:	0141                	addi	sp,sp,16
    800041f8:	8082                	ret

00000000800041fa <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800041fa:	1101                	addi	sp,sp,-32
    800041fc:	ec06                	sd	ra,24(sp)
    800041fe:	e822                	sd	s0,16(sp)
    80004200:	e426                	sd	s1,8(sp)
    80004202:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004204:	0001c517          	auipc	a0,0x1c
    80004208:	a9c50513          	addi	a0,a0,-1380 # 8001fca0 <ftable>
    8000420c:	a1dfc0ef          	jal	80000c28 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004210:	0001c497          	auipc	s1,0x1c
    80004214:	aa848493          	addi	s1,s1,-1368 # 8001fcb8 <ftable+0x18>
    80004218:	0001d717          	auipc	a4,0x1d
    8000421c:	a4070713          	addi	a4,a4,-1472 # 80020c58 <disk>
    if(f->ref == 0){
    80004220:	40dc                	lw	a5,4(s1)
    80004222:	cf89                	beqz	a5,8000423c <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004224:	02848493          	addi	s1,s1,40
    80004228:	fee49ce3          	bne	s1,a4,80004220 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000422c:	0001c517          	auipc	a0,0x1c
    80004230:	a7450513          	addi	a0,a0,-1420 # 8001fca0 <ftable>
    80004234:	a89fc0ef          	jal	80000cbc <release>
  return 0;
    80004238:	4481                	li	s1,0
    8000423a:	a809                	j	8000424c <filealloc+0x52>
      f->ref = 1;
    8000423c:	4785                	li	a5,1
    8000423e:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004240:	0001c517          	auipc	a0,0x1c
    80004244:	a6050513          	addi	a0,a0,-1440 # 8001fca0 <ftable>
    80004248:	a75fc0ef          	jal	80000cbc <release>
}
    8000424c:	8526                	mv	a0,s1
    8000424e:	60e2                	ld	ra,24(sp)
    80004250:	6442                	ld	s0,16(sp)
    80004252:	64a2                	ld	s1,8(sp)
    80004254:	6105                	addi	sp,sp,32
    80004256:	8082                	ret

0000000080004258 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004258:	1101                	addi	sp,sp,-32
    8000425a:	ec06                	sd	ra,24(sp)
    8000425c:	e822                	sd	s0,16(sp)
    8000425e:	e426                	sd	s1,8(sp)
    80004260:	1000                	addi	s0,sp,32
    80004262:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004264:	0001c517          	auipc	a0,0x1c
    80004268:	a3c50513          	addi	a0,a0,-1476 # 8001fca0 <ftable>
    8000426c:	9bdfc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    80004270:	40dc                	lw	a5,4(s1)
    80004272:	02f05063          	blez	a5,80004292 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004276:	2785                	addiw	a5,a5,1
    80004278:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000427a:	0001c517          	auipc	a0,0x1c
    8000427e:	a2650513          	addi	a0,a0,-1498 # 8001fca0 <ftable>
    80004282:	a3bfc0ef          	jal	80000cbc <release>
  return f;
}
    80004286:	8526                	mv	a0,s1
    80004288:	60e2                	ld	ra,24(sp)
    8000428a:	6442                	ld	s0,16(sp)
    8000428c:	64a2                	ld	s1,8(sp)
    8000428e:	6105                	addi	sp,sp,32
    80004290:	8082                	ret
    panic("filedup");
    80004292:	00003517          	auipc	a0,0x3
    80004296:	2ce50513          	addi	a0,a0,718 # 80007560 <etext+0x560>
    8000429a:	d8afc0ef          	jal	80000824 <panic>

000000008000429e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000429e:	7139                	addi	sp,sp,-64
    800042a0:	fc06                	sd	ra,56(sp)
    800042a2:	f822                	sd	s0,48(sp)
    800042a4:	f426                	sd	s1,40(sp)
    800042a6:	0080                	addi	s0,sp,64
    800042a8:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800042aa:	0001c517          	auipc	a0,0x1c
    800042ae:	9f650513          	addi	a0,a0,-1546 # 8001fca0 <ftable>
    800042b2:	977fc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    800042b6:	40dc                	lw	a5,4(s1)
    800042b8:	04f05a63          	blez	a5,8000430c <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800042bc:	37fd                	addiw	a5,a5,-1
    800042be:	c0dc                	sw	a5,4(s1)
    800042c0:	06f04063          	bgtz	a5,80004320 <fileclose+0x82>
    800042c4:	f04a                	sd	s2,32(sp)
    800042c6:	ec4e                	sd	s3,24(sp)
    800042c8:	e852                	sd	s4,16(sp)
    800042ca:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800042cc:	0004a903          	lw	s2,0(s1)
    800042d0:	0094c783          	lbu	a5,9(s1)
    800042d4:	89be                	mv	s3,a5
    800042d6:	689c                	ld	a5,16(s1)
    800042d8:	8a3e                	mv	s4,a5
    800042da:	6c9c                	ld	a5,24(s1)
    800042dc:	8abe                	mv	s5,a5
  f->ref = 0;
    800042de:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800042e2:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800042e6:	0001c517          	auipc	a0,0x1c
    800042ea:	9ba50513          	addi	a0,a0,-1606 # 8001fca0 <ftable>
    800042ee:	9cffc0ef          	jal	80000cbc <release>

  if(ff.type == FD_PIPE){
    800042f2:	4785                	li	a5,1
    800042f4:	04f90163          	beq	s2,a5,80004336 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800042f8:	ffe9079b          	addiw	a5,s2,-2
    800042fc:	4705                	li	a4,1
    800042fe:	04f77563          	bgeu	a4,a5,80004348 <fileclose+0xaa>
    80004302:	7902                	ld	s2,32(sp)
    80004304:	69e2                	ld	s3,24(sp)
    80004306:	6a42                	ld	s4,16(sp)
    80004308:	6aa2                	ld	s5,8(sp)
    8000430a:	a00d                	j	8000432c <fileclose+0x8e>
    8000430c:	f04a                	sd	s2,32(sp)
    8000430e:	ec4e                	sd	s3,24(sp)
    80004310:	e852                	sd	s4,16(sp)
    80004312:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004314:	00003517          	auipc	a0,0x3
    80004318:	25450513          	addi	a0,a0,596 # 80007568 <etext+0x568>
    8000431c:	d08fc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    80004320:	0001c517          	auipc	a0,0x1c
    80004324:	98050513          	addi	a0,a0,-1664 # 8001fca0 <ftable>
    80004328:	995fc0ef          	jal	80000cbc <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000432c:	70e2                	ld	ra,56(sp)
    8000432e:	7442                	ld	s0,48(sp)
    80004330:	74a2                	ld	s1,40(sp)
    80004332:	6121                	addi	sp,sp,64
    80004334:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004336:	85ce                	mv	a1,s3
    80004338:	8552                	mv	a0,s4
    8000433a:	348000ef          	jal	80004682 <pipeclose>
    8000433e:	7902                	ld	s2,32(sp)
    80004340:	69e2                	ld	s3,24(sp)
    80004342:	6a42                	ld	s4,16(sp)
    80004344:	6aa2                	ld	s5,8(sp)
    80004346:	b7dd                	j	8000432c <fileclose+0x8e>
    begin_op();
    80004348:	b33ff0ef          	jal	80003e7a <begin_op>
    iput(ff.ip);
    8000434c:	8556                	mv	a0,s5
    8000434e:	aa2ff0ef          	jal	800035f0 <iput>
    end_op();
    80004352:	b99ff0ef          	jal	80003eea <end_op>
    80004356:	7902                	ld	s2,32(sp)
    80004358:	69e2                	ld	s3,24(sp)
    8000435a:	6a42                	ld	s4,16(sp)
    8000435c:	6aa2                	ld	s5,8(sp)
    8000435e:	b7f9                	j	8000432c <fileclose+0x8e>

0000000080004360 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004360:	715d                	addi	sp,sp,-80
    80004362:	e486                	sd	ra,72(sp)
    80004364:	e0a2                	sd	s0,64(sp)
    80004366:	fc26                	sd	s1,56(sp)
    80004368:	f052                	sd	s4,32(sp)
    8000436a:	0880                	addi	s0,sp,80
    8000436c:	84aa                	mv	s1,a0
    8000436e:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004370:	dbefd0ef          	jal	8000192e <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004374:	409c                	lw	a5,0(s1)
    80004376:	37f9                	addiw	a5,a5,-2
    80004378:	4705                	li	a4,1
    8000437a:	04f76263          	bltu	a4,a5,800043be <filestat+0x5e>
    8000437e:	f84a                	sd	s2,48(sp)
    80004380:	f44e                	sd	s3,40(sp)
    80004382:	89aa                	mv	s3,a0
    ilock(f->ip);
    80004384:	6c88                	ld	a0,24(s1)
    80004386:	8e8ff0ef          	jal	8000346e <ilock>
    stati(f->ip, &st);
    8000438a:	fb840913          	addi	s2,s0,-72
    8000438e:	85ca                	mv	a1,s2
    80004390:	6c88                	ld	a0,24(s1)
    80004392:	c40ff0ef          	jal	800037d2 <stati>
    iunlock(f->ip);
    80004396:	6c88                	ld	a0,24(s1)
    80004398:	984ff0ef          	jal	8000351c <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000439c:	46e1                	li	a3,24
    8000439e:	864a                	mv	a2,s2
    800043a0:	85d2                	mv	a1,s4
    800043a2:	0589b503          	ld	a0,88(s3)
    800043a6:	aaefd0ef          	jal	80001654 <copyout>
    800043aa:	41f5551b          	sraiw	a0,a0,0x1f
    800043ae:	7942                	ld	s2,48(sp)
    800043b0:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800043b2:	60a6                	ld	ra,72(sp)
    800043b4:	6406                	ld	s0,64(sp)
    800043b6:	74e2                	ld	s1,56(sp)
    800043b8:	7a02                	ld	s4,32(sp)
    800043ba:	6161                	addi	sp,sp,80
    800043bc:	8082                	ret
  return -1;
    800043be:	557d                	li	a0,-1
    800043c0:	bfcd                	j	800043b2 <filestat+0x52>

00000000800043c2 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800043c2:	7179                	addi	sp,sp,-48
    800043c4:	f406                	sd	ra,40(sp)
    800043c6:	f022                	sd	s0,32(sp)
    800043c8:	e84a                	sd	s2,16(sp)
    800043ca:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800043cc:	00854783          	lbu	a5,8(a0)
    800043d0:	cfd1                	beqz	a5,8000446c <fileread+0xaa>
    800043d2:	ec26                	sd	s1,24(sp)
    800043d4:	e44e                	sd	s3,8(sp)
    800043d6:	84aa                	mv	s1,a0
    800043d8:	892e                	mv	s2,a1
    800043da:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800043dc:	411c                	lw	a5,0(a0)
    800043de:	4705                	li	a4,1
    800043e0:	04e78363          	beq	a5,a4,80004426 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800043e4:	470d                	li	a4,3
    800043e6:	04e78763          	beq	a5,a4,80004434 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800043ea:	4709                	li	a4,2
    800043ec:	06e79a63          	bne	a5,a4,80004460 <fileread+0x9e>
    ilock(f->ip);
    800043f0:	6d08                	ld	a0,24(a0)
    800043f2:	87cff0ef          	jal	8000346e <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800043f6:	874e                	mv	a4,s3
    800043f8:	5094                	lw	a3,32(s1)
    800043fa:	864a                	mv	a2,s2
    800043fc:	4585                	li	a1,1
    800043fe:	6c88                	ld	a0,24(s1)
    80004400:	c00ff0ef          	jal	80003800 <readi>
    80004404:	892a                	mv	s2,a0
    80004406:	00a05563          	blez	a0,80004410 <fileread+0x4e>
      f->off += r;
    8000440a:	509c                	lw	a5,32(s1)
    8000440c:	9fa9                	addw	a5,a5,a0
    8000440e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004410:	6c88                	ld	a0,24(s1)
    80004412:	90aff0ef          	jal	8000351c <iunlock>
    80004416:	64e2                	ld	s1,24(sp)
    80004418:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000441a:	854a                	mv	a0,s2
    8000441c:	70a2                	ld	ra,40(sp)
    8000441e:	7402                	ld	s0,32(sp)
    80004420:	6942                	ld	s2,16(sp)
    80004422:	6145                	addi	sp,sp,48
    80004424:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004426:	6908                	ld	a0,16(a0)
    80004428:	3b0000ef          	jal	800047d8 <piperead>
    8000442c:	892a                	mv	s2,a0
    8000442e:	64e2                	ld	s1,24(sp)
    80004430:	69a2                	ld	s3,8(sp)
    80004432:	b7e5                	j	8000441a <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004434:	02451783          	lh	a5,36(a0)
    80004438:	03079693          	slli	a3,a5,0x30
    8000443c:	92c1                	srli	a3,a3,0x30
    8000443e:	4725                	li	a4,9
    80004440:	02d76963          	bltu	a4,a3,80004472 <fileread+0xb0>
    80004444:	0792                	slli	a5,a5,0x4
    80004446:	0001b717          	auipc	a4,0x1b
    8000444a:	7ba70713          	addi	a4,a4,1978 # 8001fc00 <devsw>
    8000444e:	97ba                	add	a5,a5,a4
    80004450:	639c                	ld	a5,0(a5)
    80004452:	c78d                	beqz	a5,8000447c <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80004454:	4505                	li	a0,1
    80004456:	9782                	jalr	a5
    80004458:	892a                	mv	s2,a0
    8000445a:	64e2                	ld	s1,24(sp)
    8000445c:	69a2                	ld	s3,8(sp)
    8000445e:	bf75                	j	8000441a <fileread+0x58>
    panic("fileread");
    80004460:	00003517          	auipc	a0,0x3
    80004464:	11850513          	addi	a0,a0,280 # 80007578 <etext+0x578>
    80004468:	bbcfc0ef          	jal	80000824 <panic>
    return -1;
    8000446c:	57fd                	li	a5,-1
    8000446e:	893e                	mv	s2,a5
    80004470:	b76d                	j	8000441a <fileread+0x58>
      return -1;
    80004472:	57fd                	li	a5,-1
    80004474:	893e                	mv	s2,a5
    80004476:	64e2                	ld	s1,24(sp)
    80004478:	69a2                	ld	s3,8(sp)
    8000447a:	b745                	j	8000441a <fileread+0x58>
    8000447c:	57fd                	li	a5,-1
    8000447e:	893e                	mv	s2,a5
    80004480:	64e2                	ld	s1,24(sp)
    80004482:	69a2                	ld	s3,8(sp)
    80004484:	bf59                	j	8000441a <fileread+0x58>

0000000080004486 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004486:	00954783          	lbu	a5,9(a0)
    8000448a:	10078f63          	beqz	a5,800045a8 <filewrite+0x122>
{
    8000448e:	711d                	addi	sp,sp,-96
    80004490:	ec86                	sd	ra,88(sp)
    80004492:	e8a2                	sd	s0,80(sp)
    80004494:	e0ca                	sd	s2,64(sp)
    80004496:	f456                	sd	s5,40(sp)
    80004498:	f05a                	sd	s6,32(sp)
    8000449a:	1080                	addi	s0,sp,96
    8000449c:	892a                	mv	s2,a0
    8000449e:	8b2e                	mv	s6,a1
    800044a0:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800044a2:	411c                	lw	a5,0(a0)
    800044a4:	4705                	li	a4,1
    800044a6:	02e78a63          	beq	a5,a4,800044da <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800044aa:	470d                	li	a4,3
    800044ac:	02e78b63          	beq	a5,a4,800044e2 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800044b0:	4709                	li	a4,2
    800044b2:	0ce79f63          	bne	a5,a4,80004590 <filewrite+0x10a>
    800044b6:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800044b8:	0ac05a63          	blez	a2,8000456c <filewrite+0xe6>
    800044bc:	e4a6                	sd	s1,72(sp)
    800044be:	fc4e                	sd	s3,56(sp)
    800044c0:	ec5e                	sd	s7,24(sp)
    800044c2:	e862                	sd	s8,16(sp)
    800044c4:	e466                	sd	s9,8(sp)
    int i = 0;
    800044c6:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800044c8:	6b85                	lui	s7,0x1
    800044ca:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800044ce:	6785                	lui	a5,0x1
    800044d0:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800044d4:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800044d6:	4c05                	li	s8,1
    800044d8:	a8ad                	j	80004552 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800044da:	6908                	ld	a0,16(a0)
    800044dc:	204000ef          	jal	800046e0 <pipewrite>
    800044e0:	a04d                	j	80004582 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800044e2:	02451783          	lh	a5,36(a0)
    800044e6:	03079693          	slli	a3,a5,0x30
    800044ea:	92c1                	srli	a3,a3,0x30
    800044ec:	4725                	li	a4,9
    800044ee:	0ad76f63          	bltu	a4,a3,800045ac <filewrite+0x126>
    800044f2:	0792                	slli	a5,a5,0x4
    800044f4:	0001b717          	auipc	a4,0x1b
    800044f8:	70c70713          	addi	a4,a4,1804 # 8001fc00 <devsw>
    800044fc:	97ba                	add	a5,a5,a4
    800044fe:	679c                	ld	a5,8(a5)
    80004500:	cbc5                	beqz	a5,800045b0 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80004502:	4505                	li	a0,1
    80004504:	9782                	jalr	a5
    80004506:	a8b5                	j	80004582 <filewrite+0xfc>
      if(n1 > max)
    80004508:	2981                	sext.w	s3,s3
      begin_op();
    8000450a:	971ff0ef          	jal	80003e7a <begin_op>
      ilock(f->ip);
    8000450e:	01893503          	ld	a0,24(s2)
    80004512:	f5dfe0ef          	jal	8000346e <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004516:	874e                	mv	a4,s3
    80004518:	02092683          	lw	a3,32(s2)
    8000451c:	016a0633          	add	a2,s4,s6
    80004520:	85e2                	mv	a1,s8
    80004522:	01893503          	ld	a0,24(s2)
    80004526:	bccff0ef          	jal	800038f2 <writei>
    8000452a:	84aa                	mv	s1,a0
    8000452c:	00a05763          	blez	a0,8000453a <filewrite+0xb4>
        f->off += r;
    80004530:	02092783          	lw	a5,32(s2)
    80004534:	9fa9                	addw	a5,a5,a0
    80004536:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000453a:	01893503          	ld	a0,24(s2)
    8000453e:	fdffe0ef          	jal	8000351c <iunlock>
      end_op();
    80004542:	9a9ff0ef          	jal	80003eea <end_op>

      if(r != n1){
    80004546:	02999563          	bne	s3,s1,80004570 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000454a:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    8000454e:	015a5963          	bge	s4,s5,80004560 <filewrite+0xda>
      int n1 = n - i;
    80004552:	414a87bb          	subw	a5,s5,s4
    80004556:	89be                	mv	s3,a5
      if(n1 > max)
    80004558:	fafbd8e3          	bge	s7,a5,80004508 <filewrite+0x82>
    8000455c:	89e6                	mv	s3,s9
    8000455e:	b76d                	j	80004508 <filewrite+0x82>
    80004560:	64a6                	ld	s1,72(sp)
    80004562:	79e2                	ld	s3,56(sp)
    80004564:	6be2                	ld	s7,24(sp)
    80004566:	6c42                	ld	s8,16(sp)
    80004568:	6ca2                	ld	s9,8(sp)
    8000456a:	a801                	j	8000457a <filewrite+0xf4>
    int i = 0;
    8000456c:	4a01                	li	s4,0
    8000456e:	a031                	j	8000457a <filewrite+0xf4>
    80004570:	64a6                	ld	s1,72(sp)
    80004572:	79e2                	ld	s3,56(sp)
    80004574:	6be2                	ld	s7,24(sp)
    80004576:	6c42                	ld	s8,16(sp)
    80004578:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000457a:	034a9d63          	bne	s5,s4,800045b4 <filewrite+0x12e>
    8000457e:	8556                	mv	a0,s5
    80004580:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004582:	60e6                	ld	ra,88(sp)
    80004584:	6446                	ld	s0,80(sp)
    80004586:	6906                	ld	s2,64(sp)
    80004588:	7aa2                	ld	s5,40(sp)
    8000458a:	7b02                	ld	s6,32(sp)
    8000458c:	6125                	addi	sp,sp,96
    8000458e:	8082                	ret
    80004590:	e4a6                	sd	s1,72(sp)
    80004592:	fc4e                	sd	s3,56(sp)
    80004594:	f852                	sd	s4,48(sp)
    80004596:	ec5e                	sd	s7,24(sp)
    80004598:	e862                	sd	s8,16(sp)
    8000459a:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000459c:	00003517          	auipc	a0,0x3
    800045a0:	fec50513          	addi	a0,a0,-20 # 80007588 <etext+0x588>
    800045a4:	a80fc0ef          	jal	80000824 <panic>
    return -1;
    800045a8:	557d                	li	a0,-1
}
    800045aa:	8082                	ret
      return -1;
    800045ac:	557d                	li	a0,-1
    800045ae:	bfd1                	j	80004582 <filewrite+0xfc>
    800045b0:	557d                	li	a0,-1
    800045b2:	bfc1                	j	80004582 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800045b4:	557d                	li	a0,-1
    800045b6:	7a42                	ld	s4,48(sp)
    800045b8:	b7e9                	j	80004582 <filewrite+0xfc>

00000000800045ba <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800045ba:	7179                	addi	sp,sp,-48
    800045bc:	f406                	sd	ra,40(sp)
    800045be:	f022                	sd	s0,32(sp)
    800045c0:	ec26                	sd	s1,24(sp)
    800045c2:	e052                	sd	s4,0(sp)
    800045c4:	1800                	addi	s0,sp,48
    800045c6:	84aa                	mv	s1,a0
    800045c8:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800045ca:	0005b023          	sd	zero,0(a1)
    800045ce:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800045d2:	c29ff0ef          	jal	800041fa <filealloc>
    800045d6:	e088                	sd	a0,0(s1)
    800045d8:	c549                	beqz	a0,80004662 <pipealloc+0xa8>
    800045da:	c21ff0ef          	jal	800041fa <filealloc>
    800045de:	00aa3023          	sd	a0,0(s4)
    800045e2:	cd25                	beqz	a0,8000465a <pipealloc+0xa0>
    800045e4:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800045e6:	d5efc0ef          	jal	80000b44 <kalloc>
    800045ea:	892a                	mv	s2,a0
    800045ec:	c12d                	beqz	a0,8000464e <pipealloc+0x94>
    800045ee:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800045f0:	4985                	li	s3,1
    800045f2:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800045f6:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800045fa:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800045fe:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004602:	00003597          	auipc	a1,0x3
    80004606:	f9658593          	addi	a1,a1,-106 # 80007598 <etext+0x598>
    8000460a:	d94fc0ef          	jal	80000b9e <initlock>
  (*f0)->type = FD_PIPE;
    8000460e:	609c                	ld	a5,0(s1)
    80004610:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004614:	609c                	ld	a5,0(s1)
    80004616:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000461a:	609c                	ld	a5,0(s1)
    8000461c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004620:	609c                	ld	a5,0(s1)
    80004622:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004626:	000a3783          	ld	a5,0(s4)
    8000462a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000462e:	000a3783          	ld	a5,0(s4)
    80004632:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004636:	000a3783          	ld	a5,0(s4)
    8000463a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000463e:	000a3783          	ld	a5,0(s4)
    80004642:	0127b823          	sd	s2,16(a5)
  return 0;
    80004646:	4501                	li	a0,0
    80004648:	6942                	ld	s2,16(sp)
    8000464a:	69a2                	ld	s3,8(sp)
    8000464c:	a01d                	j	80004672 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000464e:	6088                	ld	a0,0(s1)
    80004650:	c119                	beqz	a0,80004656 <pipealloc+0x9c>
    80004652:	6942                	ld	s2,16(sp)
    80004654:	a029                	j	8000465e <pipealloc+0xa4>
    80004656:	6942                	ld	s2,16(sp)
    80004658:	a029                	j	80004662 <pipealloc+0xa8>
    8000465a:	6088                	ld	a0,0(s1)
    8000465c:	c10d                	beqz	a0,8000467e <pipealloc+0xc4>
    fileclose(*f0);
    8000465e:	c41ff0ef          	jal	8000429e <fileclose>
  if(*f1)
    80004662:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004666:	557d                	li	a0,-1
  if(*f1)
    80004668:	c789                	beqz	a5,80004672 <pipealloc+0xb8>
    fileclose(*f1);
    8000466a:	853e                	mv	a0,a5
    8000466c:	c33ff0ef          	jal	8000429e <fileclose>
  return -1;
    80004670:	557d                	li	a0,-1
}
    80004672:	70a2                	ld	ra,40(sp)
    80004674:	7402                	ld	s0,32(sp)
    80004676:	64e2                	ld	s1,24(sp)
    80004678:	6a02                	ld	s4,0(sp)
    8000467a:	6145                	addi	sp,sp,48
    8000467c:	8082                	ret
  return -1;
    8000467e:	557d                	li	a0,-1
    80004680:	bfcd                	j	80004672 <pipealloc+0xb8>

0000000080004682 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004682:	1101                	addi	sp,sp,-32
    80004684:	ec06                	sd	ra,24(sp)
    80004686:	e822                	sd	s0,16(sp)
    80004688:	e426                	sd	s1,8(sp)
    8000468a:	e04a                	sd	s2,0(sp)
    8000468c:	1000                	addi	s0,sp,32
    8000468e:	84aa                	mv	s1,a0
    80004690:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004692:	d96fc0ef          	jal	80000c28 <acquire>
  if(writable){
    80004696:	02090763          	beqz	s2,800046c4 <pipeclose+0x42>
    pi->writeopen = 0;
    8000469a:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000469e:	21848513          	addi	a0,s1,536
    800046a2:	971fd0ef          	jal	80002012 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800046a6:	2204a783          	lw	a5,544(s1)
    800046aa:	e781                	bnez	a5,800046b2 <pipeclose+0x30>
    800046ac:	2244a783          	lw	a5,548(s1)
    800046b0:	c38d                	beqz	a5,800046d2 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800046b2:	8526                	mv	a0,s1
    800046b4:	e08fc0ef          	jal	80000cbc <release>
}
    800046b8:	60e2                	ld	ra,24(sp)
    800046ba:	6442                	ld	s0,16(sp)
    800046bc:	64a2                	ld	s1,8(sp)
    800046be:	6902                	ld	s2,0(sp)
    800046c0:	6105                	addi	sp,sp,32
    800046c2:	8082                	ret
    pi->readopen = 0;
    800046c4:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800046c8:	21c48513          	addi	a0,s1,540
    800046cc:	947fd0ef          	jal	80002012 <wakeup>
    800046d0:	bfd9                	j	800046a6 <pipeclose+0x24>
    release(&pi->lock);
    800046d2:	8526                	mv	a0,s1
    800046d4:	de8fc0ef          	jal	80000cbc <release>
    kfree((char*)pi);
    800046d8:	8526                	mv	a0,s1
    800046da:	b82fc0ef          	jal	80000a5c <kfree>
    800046de:	bfe9                	j	800046b8 <pipeclose+0x36>

00000000800046e0 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800046e0:	7159                	addi	sp,sp,-112
    800046e2:	f486                	sd	ra,104(sp)
    800046e4:	f0a2                	sd	s0,96(sp)
    800046e6:	eca6                	sd	s1,88(sp)
    800046e8:	e8ca                	sd	s2,80(sp)
    800046ea:	e4ce                	sd	s3,72(sp)
    800046ec:	e0d2                	sd	s4,64(sp)
    800046ee:	fc56                	sd	s5,56(sp)
    800046f0:	1880                	addi	s0,sp,112
    800046f2:	84aa                	mv	s1,a0
    800046f4:	8aae                	mv	s5,a1
    800046f6:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800046f8:	a36fd0ef          	jal	8000192e <myproc>
    800046fc:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800046fe:	8526                	mv	a0,s1
    80004700:	d28fc0ef          	jal	80000c28 <acquire>
  while(i < n){
    80004704:	0d405263          	blez	s4,800047c8 <pipewrite+0xe8>
    80004708:	f85a                	sd	s6,48(sp)
    8000470a:	f45e                	sd	s7,40(sp)
    8000470c:	f062                	sd	s8,32(sp)
    8000470e:	ec66                	sd	s9,24(sp)
    80004710:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004712:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004714:	f9f40c13          	addi	s8,s0,-97
    80004718:	4b85                	li	s7,1
    8000471a:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000471c:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004720:	21c48c93          	addi	s9,s1,540
    80004724:	a82d                	j	8000475e <pipewrite+0x7e>
      release(&pi->lock);
    80004726:	8526                	mv	a0,s1
    80004728:	d94fc0ef          	jal	80000cbc <release>
      return -1;
    8000472c:	597d                	li	s2,-1
    8000472e:	7b42                	ld	s6,48(sp)
    80004730:	7ba2                	ld	s7,40(sp)
    80004732:	7c02                	ld	s8,32(sp)
    80004734:	6ce2                	ld	s9,24(sp)
    80004736:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004738:	854a                	mv	a0,s2
    8000473a:	70a6                	ld	ra,104(sp)
    8000473c:	7406                	ld	s0,96(sp)
    8000473e:	64e6                	ld	s1,88(sp)
    80004740:	6946                	ld	s2,80(sp)
    80004742:	69a6                	ld	s3,72(sp)
    80004744:	6a06                	ld	s4,64(sp)
    80004746:	7ae2                	ld	s5,56(sp)
    80004748:	6165                	addi	sp,sp,112
    8000474a:	8082                	ret
      wakeup(&pi->nread);
    8000474c:	856a                	mv	a0,s10
    8000474e:	8c5fd0ef          	jal	80002012 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004752:	85a6                	mv	a1,s1
    80004754:	8566                	mv	a0,s9
    80004756:	871fd0ef          	jal	80001fc6 <sleep>
  while(i < n){
    8000475a:	05495a63          	bge	s2,s4,800047ae <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    8000475e:	2204a783          	lw	a5,544(s1)
    80004762:	d3f1                	beqz	a5,80004726 <pipewrite+0x46>
    80004764:	854e                	mv	a0,s3
    80004766:	a9dfd0ef          	jal	80002202 <killed>
    8000476a:	fd55                	bnez	a0,80004726 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000476c:	2184a783          	lw	a5,536(s1)
    80004770:	21c4a703          	lw	a4,540(s1)
    80004774:	2007879b          	addiw	a5,a5,512
    80004778:	fcf70ae3          	beq	a4,a5,8000474c <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000477c:	86de                	mv	a3,s7
    8000477e:	01590633          	add	a2,s2,s5
    80004782:	85e2                	mv	a1,s8
    80004784:	0589b503          	ld	a0,88(s3)
    80004788:	f8bfc0ef          	jal	80001712 <copyin>
    8000478c:	05650063          	beq	a0,s6,800047cc <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004790:	21c4a783          	lw	a5,540(s1)
    80004794:	0017871b          	addiw	a4,a5,1
    80004798:	20e4ae23          	sw	a4,540(s1)
    8000479c:	1ff7f793          	andi	a5,a5,511
    800047a0:	97a6                	add	a5,a5,s1
    800047a2:	f9f44703          	lbu	a4,-97(s0)
    800047a6:	00e78c23          	sb	a4,24(a5)
      i++;
    800047aa:	2905                	addiw	s2,s2,1
    800047ac:	b77d                	j	8000475a <pipewrite+0x7a>
    800047ae:	7b42                	ld	s6,48(sp)
    800047b0:	7ba2                	ld	s7,40(sp)
    800047b2:	7c02                	ld	s8,32(sp)
    800047b4:	6ce2                	ld	s9,24(sp)
    800047b6:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800047b8:	21848513          	addi	a0,s1,536
    800047bc:	857fd0ef          	jal	80002012 <wakeup>
  release(&pi->lock);
    800047c0:	8526                	mv	a0,s1
    800047c2:	cfafc0ef          	jal	80000cbc <release>
  return i;
    800047c6:	bf8d                	j	80004738 <pipewrite+0x58>
  int i = 0;
    800047c8:	4901                	li	s2,0
    800047ca:	b7fd                	j	800047b8 <pipewrite+0xd8>
    800047cc:	7b42                	ld	s6,48(sp)
    800047ce:	7ba2                	ld	s7,40(sp)
    800047d0:	7c02                	ld	s8,32(sp)
    800047d2:	6ce2                	ld	s9,24(sp)
    800047d4:	6d42                	ld	s10,16(sp)
    800047d6:	b7cd                	j	800047b8 <pipewrite+0xd8>

00000000800047d8 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800047d8:	711d                	addi	sp,sp,-96
    800047da:	ec86                	sd	ra,88(sp)
    800047dc:	e8a2                	sd	s0,80(sp)
    800047de:	e4a6                	sd	s1,72(sp)
    800047e0:	e0ca                	sd	s2,64(sp)
    800047e2:	fc4e                	sd	s3,56(sp)
    800047e4:	f852                	sd	s4,48(sp)
    800047e6:	f456                	sd	s5,40(sp)
    800047e8:	1080                	addi	s0,sp,96
    800047ea:	84aa                	mv	s1,a0
    800047ec:	892e                	mv	s2,a1
    800047ee:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800047f0:	93efd0ef          	jal	8000192e <myproc>
    800047f4:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800047f6:	8526                	mv	a0,s1
    800047f8:	c30fc0ef          	jal	80000c28 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800047fc:	2184a703          	lw	a4,536(s1)
    80004800:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004804:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004808:	02f71763          	bne	a4,a5,80004836 <piperead+0x5e>
    8000480c:	2244a783          	lw	a5,548(s1)
    80004810:	cf85                	beqz	a5,80004848 <piperead+0x70>
    if(killed(pr)){
    80004812:	8552                	mv	a0,s4
    80004814:	9effd0ef          	jal	80002202 <killed>
    80004818:	e11d                	bnez	a0,8000483e <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000481a:	85a6                	mv	a1,s1
    8000481c:	854e                	mv	a0,s3
    8000481e:	fa8fd0ef          	jal	80001fc6 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004822:	2184a703          	lw	a4,536(s1)
    80004826:	21c4a783          	lw	a5,540(s1)
    8000482a:	fef701e3          	beq	a4,a5,8000480c <piperead+0x34>
    8000482e:	f05a                	sd	s6,32(sp)
    80004830:	ec5e                	sd	s7,24(sp)
    80004832:	e862                	sd	s8,16(sp)
    80004834:	a829                	j	8000484e <piperead+0x76>
    80004836:	f05a                	sd	s6,32(sp)
    80004838:	ec5e                	sd	s7,24(sp)
    8000483a:	e862                	sd	s8,16(sp)
    8000483c:	a809                	j	8000484e <piperead+0x76>
      release(&pi->lock);
    8000483e:	8526                	mv	a0,s1
    80004840:	c7cfc0ef          	jal	80000cbc <release>
      return -1;
    80004844:	59fd                	li	s3,-1
    80004846:	a09d                	j	800048ac <piperead+0xd4>
    80004848:	f05a                	sd	s6,32(sp)
    8000484a:	ec5e                	sd	s7,24(sp)
    8000484c:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000484e:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004850:	faf40c13          	addi	s8,s0,-81
    80004854:	4b85                	li	s7,1
    80004856:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004858:	05505063          	blez	s5,80004898 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    8000485c:	2184a783          	lw	a5,536(s1)
    80004860:	21c4a703          	lw	a4,540(s1)
    80004864:	02f70a63          	beq	a4,a5,80004898 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004868:	0017871b          	addiw	a4,a5,1
    8000486c:	20e4ac23          	sw	a4,536(s1)
    80004870:	1ff7f793          	andi	a5,a5,511
    80004874:	97a6                	add	a5,a5,s1
    80004876:	0187c783          	lbu	a5,24(a5)
    8000487a:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000487e:	86de                	mv	a3,s7
    80004880:	8662                	mv	a2,s8
    80004882:	85ca                	mv	a1,s2
    80004884:	058a3503          	ld	a0,88(s4)
    80004888:	dcdfc0ef          	jal	80001654 <copyout>
    8000488c:	01650663          	beq	a0,s6,80004898 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004890:	2985                	addiw	s3,s3,1
    80004892:	0905                	addi	s2,s2,1
    80004894:	fd3a94e3          	bne	s5,s3,8000485c <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004898:	21c48513          	addi	a0,s1,540
    8000489c:	f76fd0ef          	jal	80002012 <wakeup>
  release(&pi->lock);
    800048a0:	8526                	mv	a0,s1
    800048a2:	c1afc0ef          	jal	80000cbc <release>
    800048a6:	7b02                	ld	s6,32(sp)
    800048a8:	6be2                	ld	s7,24(sp)
    800048aa:	6c42                	ld	s8,16(sp)
  return i;
}
    800048ac:	854e                	mv	a0,s3
    800048ae:	60e6                	ld	ra,88(sp)
    800048b0:	6446                	ld	s0,80(sp)
    800048b2:	64a6                	ld	s1,72(sp)
    800048b4:	6906                	ld	s2,64(sp)
    800048b6:	79e2                	ld	s3,56(sp)
    800048b8:	7a42                	ld	s4,48(sp)
    800048ba:	7aa2                	ld	s5,40(sp)
    800048bc:	6125                	addi	sp,sp,96
    800048be:	8082                	ret

00000000800048c0 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800048c0:	1141                	addi	sp,sp,-16
    800048c2:	e406                	sd	ra,8(sp)
    800048c4:	e022                	sd	s0,0(sp)
    800048c6:	0800                	addi	s0,sp,16
    800048c8:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800048ca:	0035151b          	slliw	a0,a0,0x3
    800048ce:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    800048d0:	8b89                	andi	a5,a5,2
    800048d2:	c399                	beqz	a5,800048d8 <flags2perm+0x18>
      perm |= PTE_W;
    800048d4:	00456513          	ori	a0,a0,4
    return perm;
}
    800048d8:	60a2                	ld	ra,8(sp)
    800048da:	6402                	ld	s0,0(sp)
    800048dc:	0141                	addi	sp,sp,16
    800048de:	8082                	ret

00000000800048e0 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800048e0:	de010113          	addi	sp,sp,-544
    800048e4:	20113c23          	sd	ra,536(sp)
    800048e8:	20813823          	sd	s0,528(sp)
    800048ec:	20913423          	sd	s1,520(sp)
    800048f0:	21213023          	sd	s2,512(sp)
    800048f4:	1400                	addi	s0,sp,544
    800048f6:	892a                	mv	s2,a0
    800048f8:	dea43823          	sd	a0,-528(s0)
    800048fc:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004900:	82efd0ef          	jal	8000192e <myproc>
    80004904:	84aa                	mv	s1,a0

  begin_op();
    80004906:	d74ff0ef          	jal	80003e7a <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    8000490a:	854a                	mv	a0,s2
    8000490c:	b90ff0ef          	jal	80003c9c <namei>
    80004910:	cd21                	beqz	a0,80004968 <kexec+0x88>
    80004912:	fbd2                	sd	s4,496(sp)
    80004914:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004916:	b59fe0ef          	jal	8000346e <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000491a:	04000713          	li	a4,64
    8000491e:	4681                	li	a3,0
    80004920:	e5040613          	addi	a2,s0,-432
    80004924:	4581                	li	a1,0
    80004926:	8552                	mv	a0,s4
    80004928:	ed9fe0ef          	jal	80003800 <readi>
    8000492c:	04000793          	li	a5,64
    80004930:	00f51a63          	bne	a0,a5,80004944 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004934:	e5042703          	lw	a4,-432(s0)
    80004938:	464c47b7          	lui	a5,0x464c4
    8000493c:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004940:	02f70863          	beq	a4,a5,80004970 <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004944:	8552                	mv	a0,s4
    80004946:	d35fe0ef          	jal	8000367a <iunlockput>
    end_op();
    8000494a:	da0ff0ef          	jal	80003eea <end_op>
  }
  return -1;
    8000494e:	557d                	li	a0,-1
    80004950:	7a5e                	ld	s4,496(sp)
}
    80004952:	21813083          	ld	ra,536(sp)
    80004956:	21013403          	ld	s0,528(sp)
    8000495a:	20813483          	ld	s1,520(sp)
    8000495e:	20013903          	ld	s2,512(sp)
    80004962:	22010113          	addi	sp,sp,544
    80004966:	8082                	ret
    end_op();
    80004968:	d82ff0ef          	jal	80003eea <end_op>
    return -1;
    8000496c:	557d                	li	a0,-1
    8000496e:	b7d5                	j	80004952 <kexec+0x72>
    80004970:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004972:	8526                	mv	a0,s1
    80004974:	8c4fd0ef          	jal	80001a38 <proc_pagetable>
    80004978:	8b2a                	mv	s6,a0
    8000497a:	26050f63          	beqz	a0,80004bf8 <kexec+0x318>
    8000497e:	ffce                	sd	s3,504(sp)
    80004980:	f7d6                	sd	s5,488(sp)
    80004982:	efde                	sd	s7,472(sp)
    80004984:	ebe2                	sd	s8,464(sp)
    80004986:	e7e6                	sd	s9,456(sp)
    80004988:	e3ea                	sd	s10,448(sp)
    8000498a:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000498c:	e8845783          	lhu	a5,-376(s0)
    80004990:	0e078963          	beqz	a5,80004a82 <kexec+0x1a2>
    80004994:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004998:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000499a:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000499c:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    800049a0:	6c85                	lui	s9,0x1
    800049a2:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800049a6:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800049aa:	6a85                	lui	s5,0x1
    800049ac:	a085                	j	80004a0c <kexec+0x12c>
      panic("loadseg: address should exist");
    800049ae:	00003517          	auipc	a0,0x3
    800049b2:	bf250513          	addi	a0,a0,-1038 # 800075a0 <etext+0x5a0>
    800049b6:	e6ffb0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    800049ba:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800049bc:	874a                	mv	a4,s2
    800049be:	009b86bb          	addw	a3,s7,s1
    800049c2:	4581                	li	a1,0
    800049c4:	8552                	mv	a0,s4
    800049c6:	e3bfe0ef          	jal	80003800 <readi>
    800049ca:	22a91b63          	bne	s2,a0,80004c00 <kexec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    800049ce:	009a84bb          	addw	s1,s5,s1
    800049d2:	0334f263          	bgeu	s1,s3,800049f6 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    800049d6:	02049593          	slli	a1,s1,0x20
    800049da:	9181                	srli	a1,a1,0x20
    800049dc:	95e2                	add	a1,a1,s8
    800049de:	855a                	mv	a0,s6
    800049e0:	e46fc0ef          	jal	80001026 <walkaddr>
    800049e4:	862a                	mv	a2,a0
    if(pa == 0)
    800049e6:	d561                	beqz	a0,800049ae <kexec+0xce>
    if(sz - i < PGSIZE)
    800049e8:	409987bb          	subw	a5,s3,s1
    800049ec:	893e                	mv	s2,a5
    800049ee:	fcfcf6e3          	bgeu	s9,a5,800049ba <kexec+0xda>
    800049f2:	8956                	mv	s2,s5
    800049f4:	b7d9                	j	800049ba <kexec+0xda>
    sz = sz1;
    800049f6:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800049fa:	2d05                	addiw	s10,s10,1
    800049fc:	e0843783          	ld	a5,-504(s0)
    80004a00:	0387869b          	addiw	a3,a5,56
    80004a04:	e8845783          	lhu	a5,-376(s0)
    80004a08:	06fd5e63          	bge	s10,a5,80004a84 <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a0c:	e0d43423          	sd	a3,-504(s0)
    80004a10:	876e                	mv	a4,s11
    80004a12:	e1840613          	addi	a2,s0,-488
    80004a16:	4581                	li	a1,0
    80004a18:	8552                	mv	a0,s4
    80004a1a:	de7fe0ef          	jal	80003800 <readi>
    80004a1e:	1db51f63          	bne	a0,s11,80004bfc <kexec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80004a22:	e1842783          	lw	a5,-488(s0)
    80004a26:	4705                	li	a4,1
    80004a28:	fce799e3          	bne	a5,a4,800049fa <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    80004a2c:	e4043483          	ld	s1,-448(s0)
    80004a30:	e3843783          	ld	a5,-456(s0)
    80004a34:	1ef4e463          	bltu	s1,a5,80004c1c <kexec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004a38:	e2843783          	ld	a5,-472(s0)
    80004a3c:	94be                	add	s1,s1,a5
    80004a3e:	1ef4e263          	bltu	s1,a5,80004c22 <kexec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80004a42:	de843703          	ld	a4,-536(s0)
    80004a46:	8ff9                	and	a5,a5,a4
    80004a48:	1e079063          	bnez	a5,80004c28 <kexec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004a4c:	e1c42503          	lw	a0,-484(s0)
    80004a50:	e71ff0ef          	jal	800048c0 <flags2perm>
    80004a54:	86aa                	mv	a3,a0
    80004a56:	8626                	mv	a2,s1
    80004a58:	85ca                	mv	a1,s2
    80004a5a:	855a                	mv	a0,s6
    80004a5c:	8a1fc0ef          	jal	800012fc <uvmalloc>
    80004a60:	dea43c23          	sd	a0,-520(s0)
    80004a64:	1c050563          	beqz	a0,80004c2e <kexec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a68:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004a6c:	00098863          	beqz	s3,80004a7c <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a70:	e2843c03          	ld	s8,-472(s0)
    80004a74:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004a78:	4481                	li	s1,0
    80004a7a:	bfb1                	j	800049d6 <kexec+0xf6>
    sz = sz1;
    80004a7c:	df843903          	ld	s2,-520(s0)
    80004a80:	bfad                	j	800049fa <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a82:	4901                	li	s2,0
  iunlockput(ip);
    80004a84:	8552                	mv	a0,s4
    80004a86:	bf5fe0ef          	jal	8000367a <iunlockput>
  end_op();
    80004a8a:	c60ff0ef          	jal	80003eea <end_op>
  p = myproc();
    80004a8e:	ea1fc0ef          	jal	8000192e <myproc>
    80004a92:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004a94:	05053d03          	ld	s10,80(a0)
  sz = PGROUNDUP(sz);
    80004a98:	6985                	lui	s3,0x1
    80004a9a:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004a9c:	99ca                	add	s3,s3,s2
    80004a9e:	77fd                	lui	a5,0xfffff
    80004aa0:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004aa4:	4691                	li	a3,4
    80004aa6:	6609                	lui	a2,0x2
    80004aa8:	964e                	add	a2,a2,s3
    80004aaa:	85ce                	mv	a1,s3
    80004aac:	855a                	mv	a0,s6
    80004aae:	84ffc0ef          	jal	800012fc <uvmalloc>
    80004ab2:	8a2a                	mv	s4,a0
    80004ab4:	e105                	bnez	a0,80004ad4 <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80004ab6:	85ce                	mv	a1,s3
    80004ab8:	855a                	mv	a0,s6
    80004aba:	802fd0ef          	jal	80001abc <proc_freepagetable>
  return -1;
    80004abe:	557d                	li	a0,-1
    80004ac0:	79fe                	ld	s3,504(sp)
    80004ac2:	7a5e                	ld	s4,496(sp)
    80004ac4:	7abe                	ld	s5,488(sp)
    80004ac6:	7b1e                	ld	s6,480(sp)
    80004ac8:	6bfe                	ld	s7,472(sp)
    80004aca:	6c5e                	ld	s8,464(sp)
    80004acc:	6cbe                	ld	s9,456(sp)
    80004ace:	6d1e                	ld	s10,448(sp)
    80004ad0:	7dfa                	ld	s11,440(sp)
    80004ad2:	b541                	j	80004952 <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004ad4:	75f9                	lui	a1,0xffffe
    80004ad6:	95aa                	add	a1,a1,a0
    80004ad8:	855a                	mv	a0,s6
    80004ada:	9f5fc0ef          	jal	800014ce <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004ade:	800a0b93          	addi	s7,s4,-2048
    80004ae2:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80004ae6:	e0043783          	ld	a5,-512(s0)
    80004aea:	6388                	ld	a0,0(a5)
  sp = sz;
    80004aec:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80004aee:	4481                	li	s1,0
    ustack[argc] = sp;
    80004af0:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004af4:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80004af8:	cd21                	beqz	a0,80004b50 <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80004afa:	b88fc0ef          	jal	80000e82 <strlen>
    80004afe:	0015079b          	addiw	a5,a0,1
    80004b02:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004b06:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004b0a:	13796563          	bltu	s2,s7,80004c34 <kexec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004b0e:	e0043d83          	ld	s11,-512(s0)
    80004b12:	000db983          	ld	s3,0(s11)
    80004b16:	854e                	mv	a0,s3
    80004b18:	b6afc0ef          	jal	80000e82 <strlen>
    80004b1c:	0015069b          	addiw	a3,a0,1
    80004b20:	864e                	mv	a2,s3
    80004b22:	85ca                	mv	a1,s2
    80004b24:	855a                	mv	a0,s6
    80004b26:	b2ffc0ef          	jal	80001654 <copyout>
    80004b2a:	10054763          	bltz	a0,80004c38 <kexec+0x358>
    ustack[argc] = sp;
    80004b2e:	00349793          	slli	a5,s1,0x3
    80004b32:	97e6                	add	a5,a5,s9
    80004b34:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde268>
  for(argc = 0; argv[argc]; argc++) {
    80004b38:	0485                	addi	s1,s1,1
    80004b3a:	008d8793          	addi	a5,s11,8
    80004b3e:	e0f43023          	sd	a5,-512(s0)
    80004b42:	008db503          	ld	a0,8(s11)
    80004b46:	c509                	beqz	a0,80004b50 <kexec+0x270>
    if(argc >= MAXARG)
    80004b48:	fb8499e3          	bne	s1,s8,80004afa <kexec+0x21a>
  sz = sz1;
    80004b4c:	89d2                	mv	s3,s4
    80004b4e:	b7a5                	j	80004ab6 <kexec+0x1d6>
  ustack[argc] = 0;
    80004b50:	00349793          	slli	a5,s1,0x3
    80004b54:	f9078793          	addi	a5,a5,-112
    80004b58:	97a2                	add	a5,a5,s0
    80004b5a:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004b5e:	00349693          	slli	a3,s1,0x3
    80004b62:	06a1                	addi	a3,a3,8
    80004b64:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004b68:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004b6c:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80004b6e:	f57964e3          	bltu	s2,s7,80004ab6 <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004b72:	e9040613          	addi	a2,s0,-368
    80004b76:	85ca                	mv	a1,s2
    80004b78:	855a                	mv	a0,s6
    80004b7a:	adbfc0ef          	jal	80001654 <copyout>
    80004b7e:	f2054ce3          	bltz	a0,80004ab6 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004b82:	060ab783          	ld	a5,96(s5) # 1060 <_entry-0x7fffefa0>
    80004b86:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004b8a:	df043783          	ld	a5,-528(s0)
    80004b8e:	0007c703          	lbu	a4,0(a5)
    80004b92:	cf11                	beqz	a4,80004bae <kexec+0x2ce>
    80004b94:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004b96:	02f00693          	li	a3,47
    80004b9a:	a029                	j	80004ba4 <kexec+0x2c4>
  for(last=s=path; *s; s++)
    80004b9c:	0785                	addi	a5,a5,1
    80004b9e:	fff7c703          	lbu	a4,-1(a5)
    80004ba2:	c711                	beqz	a4,80004bae <kexec+0x2ce>
    if(*s == '/')
    80004ba4:	fed71ce3          	bne	a4,a3,80004b9c <kexec+0x2bc>
      last = s+1;
    80004ba8:	def43823          	sd	a5,-528(s0)
    80004bac:	bfc5                	j	80004b9c <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004bae:	4641                	li	a2,16
    80004bb0:	df043583          	ld	a1,-528(s0)
    80004bb4:	160a8513          	addi	a0,s5,352
    80004bb8:	a94fc0ef          	jal	80000e4c <safestrcpy>
  oldpagetable = p->pagetable;
    80004bbc:	058ab503          	ld	a0,88(s5)
  p->pagetable = pagetable;
    80004bc0:	056abc23          	sd	s6,88(s5)
  p->sz = sz;
    80004bc4:	054ab823          	sd	s4,80(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004bc8:	060ab783          	ld	a5,96(s5)
    80004bcc:	e6843703          	ld	a4,-408(s0)
    80004bd0:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004bd2:	060ab783          	ld	a5,96(s5)
    80004bd6:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004bda:	85ea                	mv	a1,s10
    80004bdc:	ee1fc0ef          	jal	80001abc <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004be0:	0004851b          	sext.w	a0,s1
    80004be4:	79fe                	ld	s3,504(sp)
    80004be6:	7a5e                	ld	s4,496(sp)
    80004be8:	7abe                	ld	s5,488(sp)
    80004bea:	7b1e                	ld	s6,480(sp)
    80004bec:	6bfe                	ld	s7,472(sp)
    80004bee:	6c5e                	ld	s8,464(sp)
    80004bf0:	6cbe                	ld	s9,456(sp)
    80004bf2:	6d1e                	ld	s10,448(sp)
    80004bf4:	7dfa                	ld	s11,440(sp)
    80004bf6:	bbb1                	j	80004952 <kexec+0x72>
    80004bf8:	7b1e                	ld	s6,480(sp)
    80004bfa:	b3a9                	j	80004944 <kexec+0x64>
    80004bfc:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004c00:	df843583          	ld	a1,-520(s0)
    80004c04:	855a                	mv	a0,s6
    80004c06:	eb7fc0ef          	jal	80001abc <proc_freepagetable>
  if(ip){
    80004c0a:	79fe                	ld	s3,504(sp)
    80004c0c:	7abe                	ld	s5,488(sp)
    80004c0e:	7b1e                	ld	s6,480(sp)
    80004c10:	6bfe                	ld	s7,472(sp)
    80004c12:	6c5e                	ld	s8,464(sp)
    80004c14:	6cbe                	ld	s9,456(sp)
    80004c16:	6d1e                	ld	s10,448(sp)
    80004c18:	7dfa                	ld	s11,440(sp)
    80004c1a:	b32d                	j	80004944 <kexec+0x64>
    80004c1c:	df243c23          	sd	s2,-520(s0)
    80004c20:	b7c5                	j	80004c00 <kexec+0x320>
    80004c22:	df243c23          	sd	s2,-520(s0)
    80004c26:	bfe9                	j	80004c00 <kexec+0x320>
    80004c28:	df243c23          	sd	s2,-520(s0)
    80004c2c:	bfd1                	j	80004c00 <kexec+0x320>
    80004c2e:	df243c23          	sd	s2,-520(s0)
    80004c32:	b7f9                	j	80004c00 <kexec+0x320>
  sz = sz1;
    80004c34:	89d2                	mv	s3,s4
    80004c36:	b541                	j	80004ab6 <kexec+0x1d6>
    80004c38:	89d2                	mv	s3,s4
    80004c3a:	bdb5                	j	80004ab6 <kexec+0x1d6>

0000000080004c3c <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004c3c:	7179                	addi	sp,sp,-48
    80004c3e:	f406                	sd	ra,40(sp)
    80004c40:	f022                	sd	s0,32(sp)
    80004c42:	ec26                	sd	s1,24(sp)
    80004c44:	e84a                	sd	s2,16(sp)
    80004c46:	1800                	addi	s0,sp,48
    80004c48:	892e                	mv	s2,a1
    80004c4a:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004c4c:	fdc40593          	addi	a1,s0,-36
    80004c50:	e01fd0ef          	jal	80002a50 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004c54:	fdc42703          	lw	a4,-36(s0)
    80004c58:	47bd                	li	a5,15
    80004c5a:	02e7ea63          	bltu	a5,a4,80004c8e <argfd+0x52>
    80004c5e:	cd1fc0ef          	jal	8000192e <myproc>
    80004c62:	fdc42703          	lw	a4,-36(s0)
    80004c66:	00371793          	slli	a5,a4,0x3
    80004c6a:	0d078793          	addi	a5,a5,208
    80004c6e:	953e                	add	a0,a0,a5
    80004c70:	651c                	ld	a5,8(a0)
    80004c72:	c385                	beqz	a5,80004c92 <argfd+0x56>
    return -1;
  if(pfd)
    80004c74:	00090463          	beqz	s2,80004c7c <argfd+0x40>
    *pfd = fd;
    80004c78:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004c7c:	4501                	li	a0,0
  if(pf)
    80004c7e:	c091                	beqz	s1,80004c82 <argfd+0x46>
    *pf = f;
    80004c80:	e09c                	sd	a5,0(s1)
}
    80004c82:	70a2                	ld	ra,40(sp)
    80004c84:	7402                	ld	s0,32(sp)
    80004c86:	64e2                	ld	s1,24(sp)
    80004c88:	6942                	ld	s2,16(sp)
    80004c8a:	6145                	addi	sp,sp,48
    80004c8c:	8082                	ret
    return -1;
    80004c8e:	557d                	li	a0,-1
    80004c90:	bfcd                	j	80004c82 <argfd+0x46>
    80004c92:	557d                	li	a0,-1
    80004c94:	b7fd                	j	80004c82 <argfd+0x46>

0000000080004c96 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004c96:	1101                	addi	sp,sp,-32
    80004c98:	ec06                	sd	ra,24(sp)
    80004c9a:	e822                	sd	s0,16(sp)
    80004c9c:	e426                	sd	s1,8(sp)
    80004c9e:	1000                	addi	s0,sp,32
    80004ca0:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004ca2:	c8dfc0ef          	jal	8000192e <myproc>
    80004ca6:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004ca8:	0d850793          	addi	a5,a0,216
    80004cac:	4501                	li	a0,0
    80004cae:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004cb0:	6398                	ld	a4,0(a5)
    80004cb2:	cb19                	beqz	a4,80004cc8 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004cb4:	2505                	addiw	a0,a0,1
    80004cb6:	07a1                	addi	a5,a5,8
    80004cb8:	fed51ce3          	bne	a0,a3,80004cb0 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004cbc:	557d                	li	a0,-1
}
    80004cbe:	60e2                	ld	ra,24(sp)
    80004cc0:	6442                	ld	s0,16(sp)
    80004cc2:	64a2                	ld	s1,8(sp)
    80004cc4:	6105                	addi	sp,sp,32
    80004cc6:	8082                	ret
      p->ofile[fd] = f;
    80004cc8:	00351793          	slli	a5,a0,0x3
    80004ccc:	0d078793          	addi	a5,a5,208
    80004cd0:	963e                	add	a2,a2,a5
    80004cd2:	e604                	sd	s1,8(a2)
      return fd;
    80004cd4:	b7ed                	j	80004cbe <fdalloc+0x28>

0000000080004cd6 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004cd6:	715d                	addi	sp,sp,-80
    80004cd8:	e486                	sd	ra,72(sp)
    80004cda:	e0a2                	sd	s0,64(sp)
    80004cdc:	fc26                	sd	s1,56(sp)
    80004cde:	f84a                	sd	s2,48(sp)
    80004ce0:	f44e                	sd	s3,40(sp)
    80004ce2:	f052                	sd	s4,32(sp)
    80004ce4:	ec56                	sd	s5,24(sp)
    80004ce6:	e85a                	sd	s6,16(sp)
    80004ce8:	0880                	addi	s0,sp,80
    80004cea:	892e                	mv	s2,a1
    80004cec:	8a2e                	mv	s4,a1
    80004cee:	8ab2                	mv	s5,a2
    80004cf0:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004cf2:	fb040593          	addi	a1,s0,-80
    80004cf6:	fc1fe0ef          	jal	80003cb6 <nameiparent>
    80004cfa:	84aa                	mv	s1,a0
    80004cfc:	10050763          	beqz	a0,80004e0a <create+0x134>
    return 0;

  ilock(dp);
    80004d00:	f6efe0ef          	jal	8000346e <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004d04:	4601                	li	a2,0
    80004d06:	fb040593          	addi	a1,s0,-80
    80004d0a:	8526                	mv	a0,s1
    80004d0c:	cfdfe0ef          	jal	80003a08 <dirlookup>
    80004d10:	89aa                	mv	s3,a0
    80004d12:	c131                	beqz	a0,80004d56 <create+0x80>
    iunlockput(dp);
    80004d14:	8526                	mv	a0,s1
    80004d16:	965fe0ef          	jal	8000367a <iunlockput>
    ilock(ip);
    80004d1a:	854e                	mv	a0,s3
    80004d1c:	f52fe0ef          	jal	8000346e <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004d20:	4789                	li	a5,2
    80004d22:	02f91563          	bne	s2,a5,80004d4c <create+0x76>
    80004d26:	0449d783          	lhu	a5,68(s3)
    80004d2a:	37f9                	addiw	a5,a5,-2
    80004d2c:	17c2                	slli	a5,a5,0x30
    80004d2e:	93c1                	srli	a5,a5,0x30
    80004d30:	4705                	li	a4,1
    80004d32:	00f76d63          	bltu	a4,a5,80004d4c <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d36:	854e                	mv	a0,s3
    80004d38:	60a6                	ld	ra,72(sp)
    80004d3a:	6406                	ld	s0,64(sp)
    80004d3c:	74e2                	ld	s1,56(sp)
    80004d3e:	7942                	ld	s2,48(sp)
    80004d40:	79a2                	ld	s3,40(sp)
    80004d42:	7a02                	ld	s4,32(sp)
    80004d44:	6ae2                	ld	s5,24(sp)
    80004d46:	6b42                	ld	s6,16(sp)
    80004d48:	6161                	addi	sp,sp,80
    80004d4a:	8082                	ret
    iunlockput(ip);
    80004d4c:	854e                	mv	a0,s3
    80004d4e:	92dfe0ef          	jal	8000367a <iunlockput>
    return 0;
    80004d52:	4981                	li	s3,0
    80004d54:	b7cd                	j	80004d36 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004d56:	85ca                	mv	a1,s2
    80004d58:	4088                	lw	a0,0(s1)
    80004d5a:	da4fe0ef          	jal	800032fe <ialloc>
    80004d5e:	892a                	mv	s2,a0
    80004d60:	cd15                	beqz	a0,80004d9c <create+0xc6>
  ilock(ip);
    80004d62:	f0cfe0ef          	jal	8000346e <ilock>
  ip->major = major;
    80004d66:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004d6a:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004d6e:	4785                	li	a5,1
    80004d70:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004d74:	854a                	mv	a0,s2
    80004d76:	e44fe0ef          	jal	800033ba <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004d7a:	4705                	li	a4,1
    80004d7c:	02ea0463          	beq	s4,a4,80004da4 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004d80:	00492603          	lw	a2,4(s2)
    80004d84:	fb040593          	addi	a1,s0,-80
    80004d88:	8526                	mv	a0,s1
    80004d8a:	e69fe0ef          	jal	80003bf2 <dirlink>
    80004d8e:	06054263          	bltz	a0,80004df2 <create+0x11c>
  iunlockput(dp);
    80004d92:	8526                	mv	a0,s1
    80004d94:	8e7fe0ef          	jal	8000367a <iunlockput>
  return ip;
    80004d98:	89ca                	mv	s3,s2
    80004d9a:	bf71                	j	80004d36 <create+0x60>
    iunlockput(dp);
    80004d9c:	8526                	mv	a0,s1
    80004d9e:	8ddfe0ef          	jal	8000367a <iunlockput>
    return 0;
    80004da2:	bf51                	j	80004d36 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004da4:	00492603          	lw	a2,4(s2)
    80004da8:	00003597          	auipc	a1,0x3
    80004dac:	81858593          	addi	a1,a1,-2024 # 800075c0 <etext+0x5c0>
    80004db0:	854a                	mv	a0,s2
    80004db2:	e41fe0ef          	jal	80003bf2 <dirlink>
    80004db6:	02054e63          	bltz	a0,80004df2 <create+0x11c>
    80004dba:	40d0                	lw	a2,4(s1)
    80004dbc:	00003597          	auipc	a1,0x3
    80004dc0:	80c58593          	addi	a1,a1,-2036 # 800075c8 <etext+0x5c8>
    80004dc4:	854a                	mv	a0,s2
    80004dc6:	e2dfe0ef          	jal	80003bf2 <dirlink>
    80004dca:	02054463          	bltz	a0,80004df2 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004dce:	00492603          	lw	a2,4(s2)
    80004dd2:	fb040593          	addi	a1,s0,-80
    80004dd6:	8526                	mv	a0,s1
    80004dd8:	e1bfe0ef          	jal	80003bf2 <dirlink>
    80004ddc:	00054b63          	bltz	a0,80004df2 <create+0x11c>
    dp->nlink++;  // for ".."
    80004de0:	04a4d783          	lhu	a5,74(s1)
    80004de4:	2785                	addiw	a5,a5,1
    80004de6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004dea:	8526                	mv	a0,s1
    80004dec:	dcefe0ef          	jal	800033ba <iupdate>
    80004df0:	b74d                	j	80004d92 <create+0xbc>
  ip->nlink = 0;
    80004df2:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004df6:	854a                	mv	a0,s2
    80004df8:	dc2fe0ef          	jal	800033ba <iupdate>
  iunlockput(ip);
    80004dfc:	854a                	mv	a0,s2
    80004dfe:	87dfe0ef          	jal	8000367a <iunlockput>
  iunlockput(dp);
    80004e02:	8526                	mv	a0,s1
    80004e04:	877fe0ef          	jal	8000367a <iunlockput>
  return 0;
    80004e08:	b73d                	j	80004d36 <create+0x60>
    return 0;
    80004e0a:	89aa                	mv	s3,a0
    80004e0c:	b72d                	j	80004d36 <create+0x60>

0000000080004e0e <sys_dup>:
{
    80004e0e:	7179                	addi	sp,sp,-48
    80004e10:	f406                	sd	ra,40(sp)
    80004e12:	f022                	sd	s0,32(sp)
    80004e14:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004e16:	fd840613          	addi	a2,s0,-40
    80004e1a:	4581                	li	a1,0
    80004e1c:	4501                	li	a0,0
    80004e1e:	e1fff0ef          	jal	80004c3c <argfd>
    return -1;
    80004e22:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004e24:	02054363          	bltz	a0,80004e4a <sys_dup+0x3c>
    80004e28:	ec26                	sd	s1,24(sp)
    80004e2a:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004e2c:	fd843483          	ld	s1,-40(s0)
    80004e30:	8526                	mv	a0,s1
    80004e32:	e65ff0ef          	jal	80004c96 <fdalloc>
    80004e36:	892a                	mv	s2,a0
    return -1;
    80004e38:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004e3a:	00054d63          	bltz	a0,80004e54 <sys_dup+0x46>
  filedup(f);
    80004e3e:	8526                	mv	a0,s1
    80004e40:	c18ff0ef          	jal	80004258 <filedup>
  return fd;
    80004e44:	87ca                	mv	a5,s2
    80004e46:	64e2                	ld	s1,24(sp)
    80004e48:	6942                	ld	s2,16(sp)
}
    80004e4a:	853e                	mv	a0,a5
    80004e4c:	70a2                	ld	ra,40(sp)
    80004e4e:	7402                	ld	s0,32(sp)
    80004e50:	6145                	addi	sp,sp,48
    80004e52:	8082                	ret
    80004e54:	64e2                	ld	s1,24(sp)
    80004e56:	6942                	ld	s2,16(sp)
    80004e58:	bfcd                	j	80004e4a <sys_dup+0x3c>

0000000080004e5a <sys_read>:
{
    80004e5a:	7179                	addi	sp,sp,-48
    80004e5c:	f406                	sd	ra,40(sp)
    80004e5e:	f022                	sd	s0,32(sp)
    80004e60:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e62:	fd840593          	addi	a1,s0,-40
    80004e66:	4505                	li	a0,1
    80004e68:	c05fd0ef          	jal	80002a6c <argaddr>
  argint(2, &n);
    80004e6c:	fe440593          	addi	a1,s0,-28
    80004e70:	4509                	li	a0,2
    80004e72:	bdffd0ef          	jal	80002a50 <argint>
  if(argfd(0, 0, &f) < 0)
    80004e76:	fe840613          	addi	a2,s0,-24
    80004e7a:	4581                	li	a1,0
    80004e7c:	4501                	li	a0,0
    80004e7e:	dbfff0ef          	jal	80004c3c <argfd>
    80004e82:	87aa                	mv	a5,a0
    return -1;
    80004e84:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004e86:	0007ca63          	bltz	a5,80004e9a <sys_read+0x40>
  return fileread(f, p, n);
    80004e8a:	fe442603          	lw	a2,-28(s0)
    80004e8e:	fd843583          	ld	a1,-40(s0)
    80004e92:	fe843503          	ld	a0,-24(s0)
    80004e96:	d2cff0ef          	jal	800043c2 <fileread>
}
    80004e9a:	70a2                	ld	ra,40(sp)
    80004e9c:	7402                	ld	s0,32(sp)
    80004e9e:	6145                	addi	sp,sp,48
    80004ea0:	8082                	ret

0000000080004ea2 <sys_write>:
{
    80004ea2:	7179                	addi	sp,sp,-48
    80004ea4:	f406                	sd	ra,40(sp)
    80004ea6:	f022                	sd	s0,32(sp)
    80004ea8:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004eaa:	fd840593          	addi	a1,s0,-40
    80004eae:	4505                	li	a0,1
    80004eb0:	bbdfd0ef          	jal	80002a6c <argaddr>
  argint(2, &n);
    80004eb4:	fe440593          	addi	a1,s0,-28
    80004eb8:	4509                	li	a0,2
    80004eba:	b97fd0ef          	jal	80002a50 <argint>
  if(argfd(0, 0, &f) < 0)
    80004ebe:	fe840613          	addi	a2,s0,-24
    80004ec2:	4581                	li	a1,0
    80004ec4:	4501                	li	a0,0
    80004ec6:	d77ff0ef          	jal	80004c3c <argfd>
    80004eca:	87aa                	mv	a5,a0
    return -1;
    80004ecc:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004ece:	0007ca63          	bltz	a5,80004ee2 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ed2:	fe442603          	lw	a2,-28(s0)
    80004ed6:	fd843583          	ld	a1,-40(s0)
    80004eda:	fe843503          	ld	a0,-24(s0)
    80004ede:	da8ff0ef          	jal	80004486 <filewrite>
}
    80004ee2:	70a2                	ld	ra,40(sp)
    80004ee4:	7402                	ld	s0,32(sp)
    80004ee6:	6145                	addi	sp,sp,48
    80004ee8:	8082                	ret

0000000080004eea <sys_close>:
{
    80004eea:	1101                	addi	sp,sp,-32
    80004eec:	ec06                	sd	ra,24(sp)
    80004eee:	e822                	sd	s0,16(sp)
    80004ef0:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004ef2:	fe040613          	addi	a2,s0,-32
    80004ef6:	fec40593          	addi	a1,s0,-20
    80004efa:	4501                	li	a0,0
    80004efc:	d41ff0ef          	jal	80004c3c <argfd>
    return -1;
    80004f00:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004f02:	02054163          	bltz	a0,80004f24 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004f06:	a29fc0ef          	jal	8000192e <myproc>
    80004f0a:	fec42783          	lw	a5,-20(s0)
    80004f0e:	078e                	slli	a5,a5,0x3
    80004f10:	0d078793          	addi	a5,a5,208
    80004f14:	953e                	add	a0,a0,a5
    80004f16:	00053423          	sd	zero,8(a0)
  fileclose(f);
    80004f1a:	fe043503          	ld	a0,-32(s0)
    80004f1e:	b80ff0ef          	jal	8000429e <fileclose>
  return 0;
    80004f22:	4781                	li	a5,0
}
    80004f24:	853e                	mv	a0,a5
    80004f26:	60e2                	ld	ra,24(sp)
    80004f28:	6442                	ld	s0,16(sp)
    80004f2a:	6105                	addi	sp,sp,32
    80004f2c:	8082                	ret

0000000080004f2e <sys_fstat>:
{
    80004f2e:	1101                	addi	sp,sp,-32
    80004f30:	ec06                	sd	ra,24(sp)
    80004f32:	e822                	sd	s0,16(sp)
    80004f34:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f36:	fe040593          	addi	a1,s0,-32
    80004f3a:	4505                	li	a0,1
    80004f3c:	b31fd0ef          	jal	80002a6c <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004f40:	fe840613          	addi	a2,s0,-24
    80004f44:	4581                	li	a1,0
    80004f46:	4501                	li	a0,0
    80004f48:	cf5ff0ef          	jal	80004c3c <argfd>
    80004f4c:	87aa                	mv	a5,a0
    return -1;
    80004f4e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004f50:	0007c863          	bltz	a5,80004f60 <sys_fstat+0x32>
  return filestat(f, st);
    80004f54:	fe043583          	ld	a1,-32(s0)
    80004f58:	fe843503          	ld	a0,-24(s0)
    80004f5c:	c04ff0ef          	jal	80004360 <filestat>
}
    80004f60:	60e2                	ld	ra,24(sp)
    80004f62:	6442                	ld	s0,16(sp)
    80004f64:	6105                	addi	sp,sp,32
    80004f66:	8082                	ret

0000000080004f68 <sys_link>:
{
    80004f68:	7169                	addi	sp,sp,-304
    80004f6a:	f606                	sd	ra,296(sp)
    80004f6c:	f222                	sd	s0,288(sp)
    80004f6e:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f70:	08000613          	li	a2,128
    80004f74:	ed040593          	addi	a1,s0,-304
    80004f78:	4501                	li	a0,0
    80004f7a:	b0ffd0ef          	jal	80002a88 <argstr>
    return -1;
    80004f7e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f80:	0c054e63          	bltz	a0,8000505c <sys_link+0xf4>
    80004f84:	08000613          	li	a2,128
    80004f88:	f5040593          	addi	a1,s0,-176
    80004f8c:	4505                	li	a0,1
    80004f8e:	afbfd0ef          	jal	80002a88 <argstr>
    return -1;
    80004f92:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f94:	0c054463          	bltz	a0,8000505c <sys_link+0xf4>
    80004f98:	ee26                	sd	s1,280(sp)
  begin_op();
    80004f9a:	ee1fe0ef          	jal	80003e7a <begin_op>
  if((ip = namei(old)) == 0){
    80004f9e:	ed040513          	addi	a0,s0,-304
    80004fa2:	cfbfe0ef          	jal	80003c9c <namei>
    80004fa6:	84aa                	mv	s1,a0
    80004fa8:	c53d                	beqz	a0,80005016 <sys_link+0xae>
  ilock(ip);
    80004faa:	cc4fe0ef          	jal	8000346e <ilock>
  if(ip->type == T_DIR){
    80004fae:	04449703          	lh	a4,68(s1)
    80004fb2:	4785                	li	a5,1
    80004fb4:	06f70663          	beq	a4,a5,80005020 <sys_link+0xb8>
    80004fb8:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fba:	04a4d783          	lhu	a5,74(s1)
    80004fbe:	2785                	addiw	a5,a5,1
    80004fc0:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fc4:	8526                	mv	a0,s1
    80004fc6:	bf4fe0ef          	jal	800033ba <iupdate>
  iunlock(ip);
    80004fca:	8526                	mv	a0,s1
    80004fcc:	d50fe0ef          	jal	8000351c <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004fd0:	fd040593          	addi	a1,s0,-48
    80004fd4:	f5040513          	addi	a0,s0,-176
    80004fd8:	cdffe0ef          	jal	80003cb6 <nameiparent>
    80004fdc:	892a                	mv	s2,a0
    80004fde:	cd21                	beqz	a0,80005036 <sys_link+0xce>
  ilock(dp);
    80004fe0:	c8efe0ef          	jal	8000346e <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004fe4:	854a                	mv	a0,s2
    80004fe6:	00092703          	lw	a4,0(s2)
    80004fea:	409c                	lw	a5,0(s1)
    80004fec:	04f71263          	bne	a4,a5,80005030 <sys_link+0xc8>
    80004ff0:	40d0                	lw	a2,4(s1)
    80004ff2:	fd040593          	addi	a1,s0,-48
    80004ff6:	bfdfe0ef          	jal	80003bf2 <dirlink>
    80004ffa:	02054b63          	bltz	a0,80005030 <sys_link+0xc8>
  iunlockput(dp);
    80004ffe:	854a                	mv	a0,s2
    80005000:	e7afe0ef          	jal	8000367a <iunlockput>
  iput(ip);
    80005004:	8526                	mv	a0,s1
    80005006:	deafe0ef          	jal	800035f0 <iput>
  end_op();
    8000500a:	ee1fe0ef          	jal	80003eea <end_op>
  return 0;
    8000500e:	4781                	li	a5,0
    80005010:	64f2                	ld	s1,280(sp)
    80005012:	6952                	ld	s2,272(sp)
    80005014:	a0a1                	j	8000505c <sys_link+0xf4>
    end_op();
    80005016:	ed5fe0ef          	jal	80003eea <end_op>
    return -1;
    8000501a:	57fd                	li	a5,-1
    8000501c:	64f2                	ld	s1,280(sp)
    8000501e:	a83d                	j	8000505c <sys_link+0xf4>
    iunlockput(ip);
    80005020:	8526                	mv	a0,s1
    80005022:	e58fe0ef          	jal	8000367a <iunlockput>
    end_op();
    80005026:	ec5fe0ef          	jal	80003eea <end_op>
    return -1;
    8000502a:	57fd                	li	a5,-1
    8000502c:	64f2                	ld	s1,280(sp)
    8000502e:	a03d                	j	8000505c <sys_link+0xf4>
    iunlockput(dp);
    80005030:	854a                	mv	a0,s2
    80005032:	e48fe0ef          	jal	8000367a <iunlockput>
  ilock(ip);
    80005036:	8526                	mv	a0,s1
    80005038:	c36fe0ef          	jal	8000346e <ilock>
  ip->nlink--;
    8000503c:	04a4d783          	lhu	a5,74(s1)
    80005040:	37fd                	addiw	a5,a5,-1
    80005042:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005046:	8526                	mv	a0,s1
    80005048:	b72fe0ef          	jal	800033ba <iupdate>
  iunlockput(ip);
    8000504c:	8526                	mv	a0,s1
    8000504e:	e2cfe0ef          	jal	8000367a <iunlockput>
  end_op();
    80005052:	e99fe0ef          	jal	80003eea <end_op>
  return -1;
    80005056:	57fd                	li	a5,-1
    80005058:	64f2                	ld	s1,280(sp)
    8000505a:	6952                	ld	s2,272(sp)
}
    8000505c:	853e                	mv	a0,a5
    8000505e:	70b2                	ld	ra,296(sp)
    80005060:	7412                	ld	s0,288(sp)
    80005062:	6155                	addi	sp,sp,304
    80005064:	8082                	ret

0000000080005066 <sys_unlink>:
{
    80005066:	7151                	addi	sp,sp,-240
    80005068:	f586                	sd	ra,232(sp)
    8000506a:	f1a2                	sd	s0,224(sp)
    8000506c:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000506e:	08000613          	li	a2,128
    80005072:	f3040593          	addi	a1,s0,-208
    80005076:	4501                	li	a0,0
    80005078:	a11fd0ef          	jal	80002a88 <argstr>
    8000507c:	14054d63          	bltz	a0,800051d6 <sys_unlink+0x170>
    80005080:	eda6                	sd	s1,216(sp)
  begin_op();
    80005082:	df9fe0ef          	jal	80003e7a <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005086:	fb040593          	addi	a1,s0,-80
    8000508a:	f3040513          	addi	a0,s0,-208
    8000508e:	c29fe0ef          	jal	80003cb6 <nameiparent>
    80005092:	84aa                	mv	s1,a0
    80005094:	c955                	beqz	a0,80005148 <sys_unlink+0xe2>
  ilock(dp);
    80005096:	bd8fe0ef          	jal	8000346e <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000509a:	00002597          	auipc	a1,0x2
    8000509e:	52658593          	addi	a1,a1,1318 # 800075c0 <etext+0x5c0>
    800050a2:	fb040513          	addi	a0,s0,-80
    800050a6:	94dfe0ef          	jal	800039f2 <namecmp>
    800050aa:	10050b63          	beqz	a0,800051c0 <sys_unlink+0x15a>
    800050ae:	00002597          	auipc	a1,0x2
    800050b2:	51a58593          	addi	a1,a1,1306 # 800075c8 <etext+0x5c8>
    800050b6:	fb040513          	addi	a0,s0,-80
    800050ba:	939fe0ef          	jal	800039f2 <namecmp>
    800050be:	10050163          	beqz	a0,800051c0 <sys_unlink+0x15a>
    800050c2:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800050c4:	f2c40613          	addi	a2,s0,-212
    800050c8:	fb040593          	addi	a1,s0,-80
    800050cc:	8526                	mv	a0,s1
    800050ce:	93bfe0ef          	jal	80003a08 <dirlookup>
    800050d2:	892a                	mv	s2,a0
    800050d4:	0e050563          	beqz	a0,800051be <sys_unlink+0x158>
    800050d8:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800050da:	b94fe0ef          	jal	8000346e <ilock>
  if(ip->nlink < 1)
    800050de:	04a91783          	lh	a5,74(s2)
    800050e2:	06f05863          	blez	a5,80005152 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800050e6:	04491703          	lh	a4,68(s2)
    800050ea:	4785                	li	a5,1
    800050ec:	06f70963          	beq	a4,a5,8000515e <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800050f0:	fc040993          	addi	s3,s0,-64
    800050f4:	4641                	li	a2,16
    800050f6:	4581                	li	a1,0
    800050f8:	854e                	mv	a0,s3
    800050fa:	bfffb0ef          	jal	80000cf8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800050fe:	4741                	li	a4,16
    80005100:	f2c42683          	lw	a3,-212(s0)
    80005104:	864e                	mv	a2,s3
    80005106:	4581                	li	a1,0
    80005108:	8526                	mv	a0,s1
    8000510a:	fe8fe0ef          	jal	800038f2 <writei>
    8000510e:	47c1                	li	a5,16
    80005110:	08f51863          	bne	a0,a5,800051a0 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80005114:	04491703          	lh	a4,68(s2)
    80005118:	4785                	li	a5,1
    8000511a:	08f70963          	beq	a4,a5,800051ac <sys_unlink+0x146>
  iunlockput(dp);
    8000511e:	8526                	mv	a0,s1
    80005120:	d5afe0ef          	jal	8000367a <iunlockput>
  ip->nlink--;
    80005124:	04a95783          	lhu	a5,74(s2)
    80005128:	37fd                	addiw	a5,a5,-1
    8000512a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000512e:	854a                	mv	a0,s2
    80005130:	a8afe0ef          	jal	800033ba <iupdate>
  iunlockput(ip);
    80005134:	854a                	mv	a0,s2
    80005136:	d44fe0ef          	jal	8000367a <iunlockput>
  end_op();
    8000513a:	db1fe0ef          	jal	80003eea <end_op>
  return 0;
    8000513e:	4501                	li	a0,0
    80005140:	64ee                	ld	s1,216(sp)
    80005142:	694e                	ld	s2,208(sp)
    80005144:	69ae                	ld	s3,200(sp)
    80005146:	a061                	j	800051ce <sys_unlink+0x168>
    end_op();
    80005148:	da3fe0ef          	jal	80003eea <end_op>
    return -1;
    8000514c:	557d                	li	a0,-1
    8000514e:	64ee                	ld	s1,216(sp)
    80005150:	a8bd                	j	800051ce <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80005152:	00002517          	auipc	a0,0x2
    80005156:	47e50513          	addi	a0,a0,1150 # 800075d0 <etext+0x5d0>
    8000515a:	ecafb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000515e:	04c92703          	lw	a4,76(s2)
    80005162:	02000793          	li	a5,32
    80005166:	f8e7f5e3          	bgeu	a5,a4,800050f0 <sys_unlink+0x8a>
    8000516a:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000516c:	4741                	li	a4,16
    8000516e:	86ce                	mv	a3,s3
    80005170:	f1840613          	addi	a2,s0,-232
    80005174:	4581                	li	a1,0
    80005176:	854a                	mv	a0,s2
    80005178:	e88fe0ef          	jal	80003800 <readi>
    8000517c:	47c1                	li	a5,16
    8000517e:	00f51b63          	bne	a0,a5,80005194 <sys_unlink+0x12e>
    if(de.inum != 0)
    80005182:	f1845783          	lhu	a5,-232(s0)
    80005186:	ebb1                	bnez	a5,800051da <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005188:	29c1                	addiw	s3,s3,16
    8000518a:	04c92783          	lw	a5,76(s2)
    8000518e:	fcf9efe3          	bltu	s3,a5,8000516c <sys_unlink+0x106>
    80005192:	bfb9                	j	800050f0 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80005194:	00002517          	auipc	a0,0x2
    80005198:	45450513          	addi	a0,a0,1108 # 800075e8 <etext+0x5e8>
    8000519c:	e88fb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    800051a0:	00002517          	auipc	a0,0x2
    800051a4:	46050513          	addi	a0,a0,1120 # 80007600 <etext+0x600>
    800051a8:	e7cfb0ef          	jal	80000824 <panic>
    dp->nlink--;
    800051ac:	04a4d783          	lhu	a5,74(s1)
    800051b0:	37fd                	addiw	a5,a5,-1
    800051b2:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051b6:	8526                	mv	a0,s1
    800051b8:	a02fe0ef          	jal	800033ba <iupdate>
    800051bc:	b78d                	j	8000511e <sys_unlink+0xb8>
    800051be:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051c0:	8526                	mv	a0,s1
    800051c2:	cb8fe0ef          	jal	8000367a <iunlockput>
  end_op();
    800051c6:	d25fe0ef          	jal	80003eea <end_op>
  return -1;
    800051ca:	557d                	li	a0,-1
    800051cc:	64ee                	ld	s1,216(sp)
}
    800051ce:	70ae                	ld	ra,232(sp)
    800051d0:	740e                	ld	s0,224(sp)
    800051d2:	616d                	addi	sp,sp,240
    800051d4:	8082                	ret
    return -1;
    800051d6:	557d                	li	a0,-1
    800051d8:	bfdd                	j	800051ce <sys_unlink+0x168>
    iunlockput(ip);
    800051da:	854a                	mv	a0,s2
    800051dc:	c9efe0ef          	jal	8000367a <iunlockput>
    goto bad;
    800051e0:	694e                	ld	s2,208(sp)
    800051e2:	69ae                	ld	s3,200(sp)
    800051e4:	bff1                	j	800051c0 <sys_unlink+0x15a>

00000000800051e6 <sys_open>:

uint64
sys_open(void)
{
    800051e6:	7131                	addi	sp,sp,-192
    800051e8:	fd06                	sd	ra,184(sp)
    800051ea:	f922                	sd	s0,176(sp)
    800051ec:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800051ee:	f4c40593          	addi	a1,s0,-180
    800051f2:	4505                	li	a0,1
    800051f4:	85dfd0ef          	jal	80002a50 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800051f8:	08000613          	li	a2,128
    800051fc:	f5040593          	addi	a1,s0,-176
    80005200:	4501                	li	a0,0
    80005202:	887fd0ef          	jal	80002a88 <argstr>
    80005206:	87aa                	mv	a5,a0
    return -1;
    80005208:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000520a:	0a07c363          	bltz	a5,800052b0 <sys_open+0xca>
    8000520e:	f526                	sd	s1,168(sp)

  begin_op();
    80005210:	c6bfe0ef          	jal	80003e7a <begin_op>

  if(omode & O_CREATE){
    80005214:	f4c42783          	lw	a5,-180(s0)
    80005218:	2007f793          	andi	a5,a5,512
    8000521c:	c3dd                	beqz	a5,800052c2 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    8000521e:	4681                	li	a3,0
    80005220:	4601                	li	a2,0
    80005222:	4589                	li	a1,2
    80005224:	f5040513          	addi	a0,s0,-176
    80005228:	aafff0ef          	jal	80004cd6 <create>
    8000522c:	84aa                	mv	s1,a0
    if(ip == 0){
    8000522e:	c549                	beqz	a0,800052b8 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80005230:	04449703          	lh	a4,68(s1)
    80005234:	478d                	li	a5,3
    80005236:	00f71763          	bne	a4,a5,80005244 <sys_open+0x5e>
    8000523a:	0464d703          	lhu	a4,70(s1)
    8000523e:	47a5                	li	a5,9
    80005240:	0ae7ee63          	bltu	a5,a4,800052fc <sys_open+0x116>
    80005244:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005246:	fb5fe0ef          	jal	800041fa <filealloc>
    8000524a:	892a                	mv	s2,a0
    8000524c:	c561                	beqz	a0,80005314 <sys_open+0x12e>
    8000524e:	ed4e                	sd	s3,152(sp)
    80005250:	a47ff0ef          	jal	80004c96 <fdalloc>
    80005254:	89aa                	mv	s3,a0
    80005256:	0a054b63          	bltz	a0,8000530c <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000525a:	04449703          	lh	a4,68(s1)
    8000525e:	478d                	li	a5,3
    80005260:	0cf70363          	beq	a4,a5,80005326 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005264:	4789                	li	a5,2
    80005266:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000526a:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000526e:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005272:	f4c42783          	lw	a5,-180(s0)
    80005276:	0017f713          	andi	a4,a5,1
    8000527a:	00174713          	xori	a4,a4,1
    8000527e:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005282:	0037f713          	andi	a4,a5,3
    80005286:	00e03733          	snez	a4,a4
    8000528a:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000528e:	4007f793          	andi	a5,a5,1024
    80005292:	c791                	beqz	a5,8000529e <sys_open+0xb8>
    80005294:	04449703          	lh	a4,68(s1)
    80005298:	4789                	li	a5,2
    8000529a:	08f70d63          	beq	a4,a5,80005334 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000529e:	8526                	mv	a0,s1
    800052a0:	a7cfe0ef          	jal	8000351c <iunlock>
  end_op();
    800052a4:	c47fe0ef          	jal	80003eea <end_op>

  return fd;
    800052a8:	854e                	mv	a0,s3
    800052aa:	74aa                	ld	s1,168(sp)
    800052ac:	790a                	ld	s2,160(sp)
    800052ae:	69ea                	ld	s3,152(sp)
}
    800052b0:	70ea                	ld	ra,184(sp)
    800052b2:	744a                	ld	s0,176(sp)
    800052b4:	6129                	addi	sp,sp,192
    800052b6:	8082                	ret
      end_op();
    800052b8:	c33fe0ef          	jal	80003eea <end_op>
      return -1;
    800052bc:	557d                	li	a0,-1
    800052be:	74aa                	ld	s1,168(sp)
    800052c0:	bfc5                	j	800052b0 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800052c2:	f5040513          	addi	a0,s0,-176
    800052c6:	9d7fe0ef          	jal	80003c9c <namei>
    800052ca:	84aa                	mv	s1,a0
    800052cc:	c11d                	beqz	a0,800052f2 <sys_open+0x10c>
    ilock(ip);
    800052ce:	9a0fe0ef          	jal	8000346e <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800052d2:	04449703          	lh	a4,68(s1)
    800052d6:	4785                	li	a5,1
    800052d8:	f4f71ce3          	bne	a4,a5,80005230 <sys_open+0x4a>
    800052dc:	f4c42783          	lw	a5,-180(s0)
    800052e0:	d3b5                	beqz	a5,80005244 <sys_open+0x5e>
      iunlockput(ip);
    800052e2:	8526                	mv	a0,s1
    800052e4:	b96fe0ef          	jal	8000367a <iunlockput>
      end_op();
    800052e8:	c03fe0ef          	jal	80003eea <end_op>
      return -1;
    800052ec:	557d                	li	a0,-1
    800052ee:	74aa                	ld	s1,168(sp)
    800052f0:	b7c1                	j	800052b0 <sys_open+0xca>
      end_op();
    800052f2:	bf9fe0ef          	jal	80003eea <end_op>
      return -1;
    800052f6:	557d                	li	a0,-1
    800052f8:	74aa                	ld	s1,168(sp)
    800052fa:	bf5d                	j	800052b0 <sys_open+0xca>
    iunlockput(ip);
    800052fc:	8526                	mv	a0,s1
    800052fe:	b7cfe0ef          	jal	8000367a <iunlockput>
    end_op();
    80005302:	be9fe0ef          	jal	80003eea <end_op>
    return -1;
    80005306:	557d                	li	a0,-1
    80005308:	74aa                	ld	s1,168(sp)
    8000530a:	b75d                	j	800052b0 <sys_open+0xca>
      fileclose(f);
    8000530c:	854a                	mv	a0,s2
    8000530e:	f91fe0ef          	jal	8000429e <fileclose>
    80005312:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005314:	8526                	mv	a0,s1
    80005316:	b64fe0ef          	jal	8000367a <iunlockput>
    end_op();
    8000531a:	bd1fe0ef          	jal	80003eea <end_op>
    return -1;
    8000531e:	557d                	li	a0,-1
    80005320:	74aa                	ld	s1,168(sp)
    80005322:	790a                	ld	s2,160(sp)
    80005324:	b771                	j	800052b0 <sys_open+0xca>
    f->type = FD_DEVICE;
    80005326:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    8000532a:	04649783          	lh	a5,70(s1)
    8000532e:	02f91223          	sh	a5,36(s2)
    80005332:	bf35                	j	8000526e <sys_open+0x88>
    itrunc(ip);
    80005334:	8526                	mv	a0,s1
    80005336:	a26fe0ef          	jal	8000355c <itrunc>
    8000533a:	b795                	j	8000529e <sys_open+0xb8>

000000008000533c <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000533c:	7175                	addi	sp,sp,-144
    8000533e:	e506                	sd	ra,136(sp)
    80005340:	e122                	sd	s0,128(sp)
    80005342:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005344:	b37fe0ef          	jal	80003e7a <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005348:	08000613          	li	a2,128
    8000534c:	f7040593          	addi	a1,s0,-144
    80005350:	4501                	li	a0,0
    80005352:	f36fd0ef          	jal	80002a88 <argstr>
    80005356:	02054363          	bltz	a0,8000537c <sys_mkdir+0x40>
    8000535a:	4681                	li	a3,0
    8000535c:	4601                	li	a2,0
    8000535e:	4585                	li	a1,1
    80005360:	f7040513          	addi	a0,s0,-144
    80005364:	973ff0ef          	jal	80004cd6 <create>
    80005368:	c911                	beqz	a0,8000537c <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000536a:	b10fe0ef          	jal	8000367a <iunlockput>
  end_op();
    8000536e:	b7dfe0ef          	jal	80003eea <end_op>
  return 0;
    80005372:	4501                	li	a0,0
}
    80005374:	60aa                	ld	ra,136(sp)
    80005376:	640a                	ld	s0,128(sp)
    80005378:	6149                	addi	sp,sp,144
    8000537a:	8082                	ret
    end_op();
    8000537c:	b6ffe0ef          	jal	80003eea <end_op>
    return -1;
    80005380:	557d                	li	a0,-1
    80005382:	bfcd                	j	80005374 <sys_mkdir+0x38>

0000000080005384 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005384:	7135                	addi	sp,sp,-160
    80005386:	ed06                	sd	ra,152(sp)
    80005388:	e922                	sd	s0,144(sp)
    8000538a:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000538c:	aeffe0ef          	jal	80003e7a <begin_op>
  argint(1, &major);
    80005390:	f6c40593          	addi	a1,s0,-148
    80005394:	4505                	li	a0,1
    80005396:	ebafd0ef          	jal	80002a50 <argint>
  argint(2, &minor);
    8000539a:	f6840593          	addi	a1,s0,-152
    8000539e:	4509                	li	a0,2
    800053a0:	eb0fd0ef          	jal	80002a50 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053a4:	08000613          	li	a2,128
    800053a8:	f7040593          	addi	a1,s0,-144
    800053ac:	4501                	li	a0,0
    800053ae:	edafd0ef          	jal	80002a88 <argstr>
    800053b2:	02054563          	bltz	a0,800053dc <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800053b6:	f6841683          	lh	a3,-152(s0)
    800053ba:	f6c41603          	lh	a2,-148(s0)
    800053be:	458d                	li	a1,3
    800053c0:	f7040513          	addi	a0,s0,-144
    800053c4:	913ff0ef          	jal	80004cd6 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053c8:	c911                	beqz	a0,800053dc <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053ca:	ab0fe0ef          	jal	8000367a <iunlockput>
  end_op();
    800053ce:	b1dfe0ef          	jal	80003eea <end_op>
  return 0;
    800053d2:	4501                	li	a0,0
}
    800053d4:	60ea                	ld	ra,152(sp)
    800053d6:	644a                	ld	s0,144(sp)
    800053d8:	610d                	addi	sp,sp,160
    800053da:	8082                	ret
    end_op();
    800053dc:	b0ffe0ef          	jal	80003eea <end_op>
    return -1;
    800053e0:	557d                	li	a0,-1
    800053e2:	bfcd                	j	800053d4 <sys_mknod+0x50>

00000000800053e4 <sys_chdir>:

uint64
sys_chdir(void)
{
    800053e4:	7135                	addi	sp,sp,-160
    800053e6:	ed06                	sd	ra,152(sp)
    800053e8:	e922                	sd	s0,144(sp)
    800053ea:	e14a                	sd	s2,128(sp)
    800053ec:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800053ee:	d40fc0ef          	jal	8000192e <myproc>
    800053f2:	892a                	mv	s2,a0
  
  begin_op();
    800053f4:	a87fe0ef          	jal	80003e7a <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800053f8:	08000613          	li	a2,128
    800053fc:	f6040593          	addi	a1,s0,-160
    80005400:	4501                	li	a0,0
    80005402:	e86fd0ef          	jal	80002a88 <argstr>
    80005406:	04054363          	bltz	a0,8000544c <sys_chdir+0x68>
    8000540a:	e526                	sd	s1,136(sp)
    8000540c:	f6040513          	addi	a0,s0,-160
    80005410:	88dfe0ef          	jal	80003c9c <namei>
    80005414:	84aa                	mv	s1,a0
    80005416:	c915                	beqz	a0,8000544a <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005418:	856fe0ef          	jal	8000346e <ilock>
  if(ip->type != T_DIR){
    8000541c:	04449703          	lh	a4,68(s1)
    80005420:	4785                	li	a5,1
    80005422:	02f71963          	bne	a4,a5,80005454 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005426:	8526                	mv	a0,s1
    80005428:	8f4fe0ef          	jal	8000351c <iunlock>
  iput(p->cwd);
    8000542c:	15893503          	ld	a0,344(s2)
    80005430:	9c0fe0ef          	jal	800035f0 <iput>
  end_op();
    80005434:	ab7fe0ef          	jal	80003eea <end_op>
  p->cwd = ip;
    80005438:	14993c23          	sd	s1,344(s2)
  return 0;
    8000543c:	4501                	li	a0,0
    8000543e:	64aa                	ld	s1,136(sp)
}
    80005440:	60ea                	ld	ra,152(sp)
    80005442:	644a                	ld	s0,144(sp)
    80005444:	690a                	ld	s2,128(sp)
    80005446:	610d                	addi	sp,sp,160
    80005448:	8082                	ret
    8000544a:	64aa                	ld	s1,136(sp)
    end_op();
    8000544c:	a9ffe0ef          	jal	80003eea <end_op>
    return -1;
    80005450:	557d                	li	a0,-1
    80005452:	b7fd                	j	80005440 <sys_chdir+0x5c>
    iunlockput(ip);
    80005454:	8526                	mv	a0,s1
    80005456:	a24fe0ef          	jal	8000367a <iunlockput>
    end_op();
    8000545a:	a91fe0ef          	jal	80003eea <end_op>
    return -1;
    8000545e:	557d                	li	a0,-1
    80005460:	64aa                	ld	s1,136(sp)
    80005462:	bff9                	j	80005440 <sys_chdir+0x5c>

0000000080005464 <sys_exec>:

uint64
sys_exec(void)
{
    80005464:	7105                	addi	sp,sp,-480
    80005466:	ef86                	sd	ra,472(sp)
    80005468:	eba2                	sd	s0,464(sp)
    8000546a:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000546c:	e2840593          	addi	a1,s0,-472
    80005470:	4505                	li	a0,1
    80005472:	dfafd0ef          	jal	80002a6c <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005476:	08000613          	li	a2,128
    8000547a:	f3040593          	addi	a1,s0,-208
    8000547e:	4501                	li	a0,0
    80005480:	e08fd0ef          	jal	80002a88 <argstr>
    80005484:	87aa                	mv	a5,a0
    return -1;
    80005486:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005488:	0e07c063          	bltz	a5,80005568 <sys_exec+0x104>
    8000548c:	e7a6                	sd	s1,456(sp)
    8000548e:	e3ca                	sd	s2,448(sp)
    80005490:	ff4e                	sd	s3,440(sp)
    80005492:	fb52                	sd	s4,432(sp)
    80005494:	f756                	sd	s5,424(sp)
    80005496:	f35a                	sd	s6,416(sp)
    80005498:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000549a:	e3040a13          	addi	s4,s0,-464
    8000549e:	10000613          	li	a2,256
    800054a2:	4581                	li	a1,0
    800054a4:	8552                	mv	a0,s4
    800054a6:	853fb0ef          	jal	80000cf8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800054aa:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800054ac:	89d2                	mv	s3,s4
    800054ae:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800054b0:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054b4:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800054b6:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800054ba:	00391513          	slli	a0,s2,0x3
    800054be:	85d6                	mv	a1,s5
    800054c0:	e2843783          	ld	a5,-472(s0)
    800054c4:	953e                	add	a0,a0,a5
    800054c6:	d00fd0ef          	jal	800029c6 <fetchaddr>
    800054ca:	02054663          	bltz	a0,800054f6 <sys_exec+0x92>
    if(uarg == 0){
    800054ce:	e2043783          	ld	a5,-480(s0)
    800054d2:	c7a1                	beqz	a5,8000551a <sys_exec+0xb6>
    argv[i] = kalloc();
    800054d4:	e70fb0ef          	jal	80000b44 <kalloc>
    800054d8:	85aa                	mv	a1,a0
    800054da:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800054de:	cd01                	beqz	a0,800054f6 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054e0:	865a                	mv	a2,s6
    800054e2:	e2043503          	ld	a0,-480(s0)
    800054e6:	d2afd0ef          	jal	80002a10 <fetchstr>
    800054ea:	00054663          	bltz	a0,800054f6 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800054ee:	0905                	addi	s2,s2,1
    800054f0:	09a1                	addi	s3,s3,8
    800054f2:	fd7914e3          	bne	s2,s7,800054ba <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800054f6:	100a0a13          	addi	s4,s4,256
    800054fa:	6088                	ld	a0,0(s1)
    800054fc:	cd31                	beqz	a0,80005558 <sys_exec+0xf4>
    kfree(argv[i]);
    800054fe:	d5efb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005502:	04a1                	addi	s1,s1,8
    80005504:	ff449be3          	bne	s1,s4,800054fa <sys_exec+0x96>
  return -1;
    80005508:	557d                	li	a0,-1
    8000550a:	64be                	ld	s1,456(sp)
    8000550c:	691e                	ld	s2,448(sp)
    8000550e:	79fa                	ld	s3,440(sp)
    80005510:	7a5a                	ld	s4,432(sp)
    80005512:	7aba                	ld	s5,424(sp)
    80005514:	7b1a                	ld	s6,416(sp)
    80005516:	6bfa                	ld	s7,408(sp)
    80005518:	a881                	j	80005568 <sys_exec+0x104>
      argv[i] = 0;
    8000551a:	0009079b          	sext.w	a5,s2
    8000551e:	e3040593          	addi	a1,s0,-464
    80005522:	078e                	slli	a5,a5,0x3
    80005524:	97ae                	add	a5,a5,a1
    80005526:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    8000552a:	f3040513          	addi	a0,s0,-208
    8000552e:	bb2ff0ef          	jal	800048e0 <kexec>
    80005532:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005534:	100a0a13          	addi	s4,s4,256
    80005538:	6088                	ld	a0,0(s1)
    8000553a:	c511                	beqz	a0,80005546 <sys_exec+0xe2>
    kfree(argv[i]);
    8000553c:	d20fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005540:	04a1                	addi	s1,s1,8
    80005542:	ff449be3          	bne	s1,s4,80005538 <sys_exec+0xd4>
  return ret;
    80005546:	854a                	mv	a0,s2
    80005548:	64be                	ld	s1,456(sp)
    8000554a:	691e                	ld	s2,448(sp)
    8000554c:	79fa                	ld	s3,440(sp)
    8000554e:	7a5a                	ld	s4,432(sp)
    80005550:	7aba                	ld	s5,424(sp)
    80005552:	7b1a                	ld	s6,416(sp)
    80005554:	6bfa                	ld	s7,408(sp)
    80005556:	a809                	j	80005568 <sys_exec+0x104>
  return -1;
    80005558:	557d                	li	a0,-1
    8000555a:	64be                	ld	s1,456(sp)
    8000555c:	691e                	ld	s2,448(sp)
    8000555e:	79fa                	ld	s3,440(sp)
    80005560:	7a5a                	ld	s4,432(sp)
    80005562:	7aba                	ld	s5,424(sp)
    80005564:	7b1a                	ld	s6,416(sp)
    80005566:	6bfa                	ld	s7,408(sp)
}
    80005568:	60fe                	ld	ra,472(sp)
    8000556a:	645e                	ld	s0,464(sp)
    8000556c:	613d                	addi	sp,sp,480
    8000556e:	8082                	ret

0000000080005570 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005570:	7139                	addi	sp,sp,-64
    80005572:	fc06                	sd	ra,56(sp)
    80005574:	f822                	sd	s0,48(sp)
    80005576:	f426                	sd	s1,40(sp)
    80005578:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000557a:	bb4fc0ef          	jal	8000192e <myproc>
    8000557e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005580:	fd840593          	addi	a1,s0,-40
    80005584:	4501                	li	a0,0
    80005586:	ce6fd0ef          	jal	80002a6c <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000558a:	fc840593          	addi	a1,s0,-56
    8000558e:	fd040513          	addi	a0,s0,-48
    80005592:	828ff0ef          	jal	800045ba <pipealloc>
    return -1;
    80005596:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005598:	0a054763          	bltz	a0,80005646 <sys_pipe+0xd6>
  fd0 = -1;
    8000559c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800055a0:	fd043503          	ld	a0,-48(s0)
    800055a4:	ef2ff0ef          	jal	80004c96 <fdalloc>
    800055a8:	fca42223          	sw	a0,-60(s0)
    800055ac:	08054463          	bltz	a0,80005634 <sys_pipe+0xc4>
    800055b0:	fc843503          	ld	a0,-56(s0)
    800055b4:	ee2ff0ef          	jal	80004c96 <fdalloc>
    800055b8:	fca42023          	sw	a0,-64(s0)
    800055bc:	06054263          	bltz	a0,80005620 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800055c0:	4691                	li	a3,4
    800055c2:	fc440613          	addi	a2,s0,-60
    800055c6:	fd843583          	ld	a1,-40(s0)
    800055ca:	6ca8                	ld	a0,88(s1)
    800055cc:	888fc0ef          	jal	80001654 <copyout>
    800055d0:	00054e63          	bltz	a0,800055ec <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800055d4:	4691                	li	a3,4
    800055d6:	fc040613          	addi	a2,s0,-64
    800055da:	fd843583          	ld	a1,-40(s0)
    800055de:	95b6                	add	a1,a1,a3
    800055e0:	6ca8                	ld	a0,88(s1)
    800055e2:	872fc0ef          	jal	80001654 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800055e6:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800055e8:	04055f63          	bgez	a0,80005646 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800055ec:	fc442783          	lw	a5,-60(s0)
    800055f0:	078e                	slli	a5,a5,0x3
    800055f2:	0d078793          	addi	a5,a5,208
    800055f6:	97a6                	add	a5,a5,s1
    800055f8:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    800055fc:	fc042783          	lw	a5,-64(s0)
    80005600:	078e                	slli	a5,a5,0x3
    80005602:	0d078793          	addi	a5,a5,208
    80005606:	97a6                	add	a5,a5,s1
    80005608:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    8000560c:	fd043503          	ld	a0,-48(s0)
    80005610:	c8ffe0ef          	jal	8000429e <fileclose>
    fileclose(wf);
    80005614:	fc843503          	ld	a0,-56(s0)
    80005618:	c87fe0ef          	jal	8000429e <fileclose>
    return -1;
    8000561c:	57fd                	li	a5,-1
    8000561e:	a025                	j	80005646 <sys_pipe+0xd6>
    if(fd0 >= 0)
    80005620:	fc442783          	lw	a5,-60(s0)
    80005624:	0007c863          	bltz	a5,80005634 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    80005628:	078e                	slli	a5,a5,0x3
    8000562a:	0d078793          	addi	a5,a5,208
    8000562e:	97a6                	add	a5,a5,s1
    80005630:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    80005634:	fd043503          	ld	a0,-48(s0)
    80005638:	c67fe0ef          	jal	8000429e <fileclose>
    fileclose(wf);
    8000563c:	fc843503          	ld	a0,-56(s0)
    80005640:	c5ffe0ef          	jal	8000429e <fileclose>
    return -1;
    80005644:	57fd                	li	a5,-1
}
    80005646:	853e                	mv	a0,a5
    80005648:	70e2                	ld	ra,56(sp)
    8000564a:	7442                	ld	s0,48(sp)
    8000564c:	74a2                	ld	s1,40(sp)
    8000564e:	6121                	addi	sp,sp,64
    80005650:	8082                	ret
	...

0000000080005660 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005660:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005662:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005664:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005666:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005668:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000566a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000566c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000566e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005670:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005672:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005674:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005676:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005678:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000567a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000567c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000567e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005680:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005682:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005684:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005686:	a4efd0ef          	jal	800028d4 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000568a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000568c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000568e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005690:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005692:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005694:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005696:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005698:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000569a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000569c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000569e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800056a0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800056a2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800056a4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800056a6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800056a8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800056aa:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800056ac:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800056ae:	10200073          	sret
    800056b2:	00000013          	nop
    800056b6:	00000013          	nop
    800056ba:	00000013          	nop

00000000800056be <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056be:	1141                	addi	sp,sp,-16
    800056c0:	e406                	sd	ra,8(sp)
    800056c2:	e022                	sd	s0,0(sp)
    800056c4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800056c6:	0c000737          	lui	a4,0xc000
    800056ca:	4785                	li	a5,1
    800056cc:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800056ce:	c35c                	sw	a5,4(a4)
}
    800056d0:	60a2                	ld	ra,8(sp)
    800056d2:	6402                	ld	s0,0(sp)
    800056d4:	0141                	addi	sp,sp,16
    800056d6:	8082                	ret

00000000800056d8 <plicinithart>:

void
plicinithart(void)
{
    800056d8:	1141                	addi	sp,sp,-16
    800056da:	e406                	sd	ra,8(sp)
    800056dc:	e022                	sd	s0,0(sp)
    800056de:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056e0:	a1afc0ef          	jal	800018fa <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800056e4:	0085171b          	slliw	a4,a0,0x8
    800056e8:	0c0027b7          	lui	a5,0xc002
    800056ec:	97ba                	add	a5,a5,a4
    800056ee:	40200713          	li	a4,1026
    800056f2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800056f6:	00d5151b          	slliw	a0,a0,0xd
    800056fa:	0c2017b7          	lui	a5,0xc201
    800056fe:	97aa                	add	a5,a5,a0
    80005700:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005704:	60a2                	ld	ra,8(sp)
    80005706:	6402                	ld	s0,0(sp)
    80005708:	0141                	addi	sp,sp,16
    8000570a:	8082                	ret

000000008000570c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000570c:	1141                	addi	sp,sp,-16
    8000570e:	e406                	sd	ra,8(sp)
    80005710:	e022                	sd	s0,0(sp)
    80005712:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005714:	9e6fc0ef          	jal	800018fa <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005718:	00d5151b          	slliw	a0,a0,0xd
    8000571c:	0c2017b7          	lui	a5,0xc201
    80005720:	97aa                	add	a5,a5,a0
  return irq;
}
    80005722:	43c8                	lw	a0,4(a5)
    80005724:	60a2                	ld	ra,8(sp)
    80005726:	6402                	ld	s0,0(sp)
    80005728:	0141                	addi	sp,sp,16
    8000572a:	8082                	ret

000000008000572c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000572c:	1101                	addi	sp,sp,-32
    8000572e:	ec06                	sd	ra,24(sp)
    80005730:	e822                	sd	s0,16(sp)
    80005732:	e426                	sd	s1,8(sp)
    80005734:	1000                	addi	s0,sp,32
    80005736:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005738:	9c2fc0ef          	jal	800018fa <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000573c:	00d5179b          	slliw	a5,a0,0xd
    80005740:	0c201737          	lui	a4,0xc201
    80005744:	97ba                	add	a5,a5,a4
    80005746:	c3c4                	sw	s1,4(a5)
}
    80005748:	60e2                	ld	ra,24(sp)
    8000574a:	6442                	ld	s0,16(sp)
    8000574c:	64a2                	ld	s1,8(sp)
    8000574e:	6105                	addi	sp,sp,32
    80005750:	8082                	ret

0000000080005752 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005752:	1141                	addi	sp,sp,-16
    80005754:	e406                	sd	ra,8(sp)
    80005756:	e022                	sd	s0,0(sp)
    80005758:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000575a:	479d                	li	a5,7
    8000575c:	04a7ca63          	blt	a5,a0,800057b0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005760:	0001b797          	auipc	a5,0x1b
    80005764:	4f878793          	addi	a5,a5,1272 # 80020c58 <disk>
    80005768:	97aa                	add	a5,a5,a0
    8000576a:	0187c783          	lbu	a5,24(a5)
    8000576e:	e7b9                	bnez	a5,800057bc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005770:	00451693          	slli	a3,a0,0x4
    80005774:	0001b797          	auipc	a5,0x1b
    80005778:	4e478793          	addi	a5,a5,1252 # 80020c58 <disk>
    8000577c:	6398                	ld	a4,0(a5)
    8000577e:	9736                	add	a4,a4,a3
    80005780:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005784:	6398                	ld	a4,0(a5)
    80005786:	9736                	add	a4,a4,a3
    80005788:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000578c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005790:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005794:	97aa                	add	a5,a5,a0
    80005796:	4705                	li	a4,1
    80005798:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000579c:	0001b517          	auipc	a0,0x1b
    800057a0:	4d450513          	addi	a0,a0,1236 # 80020c70 <disk+0x18>
    800057a4:	86ffc0ef          	jal	80002012 <wakeup>
}
    800057a8:	60a2                	ld	ra,8(sp)
    800057aa:	6402                	ld	s0,0(sp)
    800057ac:	0141                	addi	sp,sp,16
    800057ae:	8082                	ret
    panic("free_desc 1");
    800057b0:	00002517          	auipc	a0,0x2
    800057b4:	e6050513          	addi	a0,a0,-416 # 80007610 <etext+0x610>
    800057b8:	86cfb0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    800057bc:	00002517          	auipc	a0,0x2
    800057c0:	e6450513          	addi	a0,a0,-412 # 80007620 <etext+0x620>
    800057c4:	860fb0ef          	jal	80000824 <panic>

00000000800057c8 <virtio_disk_init>:
{
    800057c8:	1101                	addi	sp,sp,-32
    800057ca:	ec06                	sd	ra,24(sp)
    800057cc:	e822                	sd	s0,16(sp)
    800057ce:	e426                	sd	s1,8(sp)
    800057d0:	e04a                	sd	s2,0(sp)
    800057d2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057d4:	00002597          	auipc	a1,0x2
    800057d8:	e5c58593          	addi	a1,a1,-420 # 80007630 <etext+0x630>
    800057dc:	0001b517          	auipc	a0,0x1b
    800057e0:	5a450513          	addi	a0,a0,1444 # 80020d80 <disk+0x128>
    800057e4:	bbafb0ef          	jal	80000b9e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057e8:	100017b7          	lui	a5,0x10001
    800057ec:	4398                	lw	a4,0(a5)
    800057ee:	2701                	sext.w	a4,a4
    800057f0:	747277b7          	lui	a5,0x74727
    800057f4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800057f8:	14f71863          	bne	a4,a5,80005948 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800057fc:	100017b7          	lui	a5,0x10001
    80005800:	43dc                	lw	a5,4(a5)
    80005802:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005804:	4709                	li	a4,2
    80005806:	14e79163          	bne	a5,a4,80005948 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000580a:	100017b7          	lui	a5,0x10001
    8000580e:	479c                	lw	a5,8(a5)
    80005810:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005812:	12e79b63          	bne	a5,a4,80005948 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005816:	100017b7          	lui	a5,0x10001
    8000581a:	47d8                	lw	a4,12(a5)
    8000581c:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000581e:	554d47b7          	lui	a5,0x554d4
    80005822:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005826:	12f71163          	bne	a4,a5,80005948 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000582a:	100017b7          	lui	a5,0x10001
    8000582e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005832:	4705                	li	a4,1
    80005834:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005836:	470d                	li	a4,3
    80005838:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000583a:	10001737          	lui	a4,0x10001
    8000583e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005840:	c7ffe6b7          	lui	a3,0xc7ffe
    80005844:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd9c7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005848:	8f75                	and	a4,a4,a3
    8000584a:	100016b7          	lui	a3,0x10001
    8000584e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005850:	472d                	li	a4,11
    80005852:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005854:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005858:	439c                	lw	a5,0(a5)
    8000585a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000585e:	8ba1                	andi	a5,a5,8
    80005860:	0e078a63          	beqz	a5,80005954 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005864:	100017b7          	lui	a5,0x10001
    80005868:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000586c:	43fc                	lw	a5,68(a5)
    8000586e:	2781                	sext.w	a5,a5
    80005870:	0e079863          	bnez	a5,80005960 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005874:	100017b7          	lui	a5,0x10001
    80005878:	5bdc                	lw	a5,52(a5)
    8000587a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000587c:	0e078863          	beqz	a5,8000596c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005880:	471d                	li	a4,7
    80005882:	0ef77b63          	bgeu	a4,a5,80005978 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005886:	abefb0ef          	jal	80000b44 <kalloc>
    8000588a:	0001b497          	auipc	s1,0x1b
    8000588e:	3ce48493          	addi	s1,s1,974 # 80020c58 <disk>
    80005892:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005894:	ab0fb0ef          	jal	80000b44 <kalloc>
    80005898:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000589a:	aaafb0ef          	jal	80000b44 <kalloc>
    8000589e:	87aa                	mv	a5,a0
    800058a0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800058a2:	6088                	ld	a0,0(s1)
    800058a4:	0e050063          	beqz	a0,80005984 <virtio_disk_init+0x1bc>
    800058a8:	0001b717          	auipc	a4,0x1b
    800058ac:	3b873703          	ld	a4,952(a4) # 80020c60 <disk+0x8>
    800058b0:	cb71                	beqz	a4,80005984 <virtio_disk_init+0x1bc>
    800058b2:	cbe9                	beqz	a5,80005984 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    800058b4:	6605                	lui	a2,0x1
    800058b6:	4581                	li	a1,0
    800058b8:	c40fb0ef          	jal	80000cf8 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058bc:	0001b497          	auipc	s1,0x1b
    800058c0:	39c48493          	addi	s1,s1,924 # 80020c58 <disk>
    800058c4:	6605                	lui	a2,0x1
    800058c6:	4581                	li	a1,0
    800058c8:	6488                	ld	a0,8(s1)
    800058ca:	c2efb0ef          	jal	80000cf8 <memset>
  memset(disk.used, 0, PGSIZE);
    800058ce:	6605                	lui	a2,0x1
    800058d0:	4581                	li	a1,0
    800058d2:	6888                	ld	a0,16(s1)
    800058d4:	c24fb0ef          	jal	80000cf8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058d8:	100017b7          	lui	a5,0x10001
    800058dc:	4721                	li	a4,8
    800058de:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800058e0:	4098                	lw	a4,0(s1)
    800058e2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800058e6:	40d8                	lw	a4,4(s1)
    800058e8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800058ec:	649c                	ld	a5,8(s1)
    800058ee:	0007869b          	sext.w	a3,a5
    800058f2:	10001737          	lui	a4,0x10001
    800058f6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800058fa:	9781                	srai	a5,a5,0x20
    800058fc:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005900:	689c                	ld	a5,16(s1)
    80005902:	0007869b          	sext.w	a3,a5
    80005906:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000590a:	9781                	srai	a5,a5,0x20
    8000590c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005910:	4785                	li	a5,1
    80005912:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005914:	00f48c23          	sb	a5,24(s1)
    80005918:	00f48ca3          	sb	a5,25(s1)
    8000591c:	00f48d23          	sb	a5,26(s1)
    80005920:	00f48da3          	sb	a5,27(s1)
    80005924:	00f48e23          	sb	a5,28(s1)
    80005928:	00f48ea3          	sb	a5,29(s1)
    8000592c:	00f48f23          	sb	a5,30(s1)
    80005930:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005934:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005938:	07272823          	sw	s2,112(a4)
}
    8000593c:	60e2                	ld	ra,24(sp)
    8000593e:	6442                	ld	s0,16(sp)
    80005940:	64a2                	ld	s1,8(sp)
    80005942:	6902                	ld	s2,0(sp)
    80005944:	6105                	addi	sp,sp,32
    80005946:	8082                	ret
    panic("could not find virtio disk");
    80005948:	00002517          	auipc	a0,0x2
    8000594c:	cf850513          	addi	a0,a0,-776 # 80007640 <etext+0x640>
    80005950:	ed5fa0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005954:	00002517          	auipc	a0,0x2
    80005958:	d0c50513          	addi	a0,a0,-756 # 80007660 <etext+0x660>
    8000595c:	ec9fa0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    80005960:	00002517          	auipc	a0,0x2
    80005964:	d2050513          	addi	a0,a0,-736 # 80007680 <etext+0x680>
    80005968:	ebdfa0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    8000596c:	00002517          	auipc	a0,0x2
    80005970:	d3450513          	addi	a0,a0,-716 # 800076a0 <etext+0x6a0>
    80005974:	eb1fa0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    80005978:	00002517          	auipc	a0,0x2
    8000597c:	d4850513          	addi	a0,a0,-696 # 800076c0 <etext+0x6c0>
    80005980:	ea5fa0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    80005984:	00002517          	auipc	a0,0x2
    80005988:	d5c50513          	addi	a0,a0,-676 # 800076e0 <etext+0x6e0>
    8000598c:	e99fa0ef          	jal	80000824 <panic>

0000000080005990 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005990:	711d                	addi	sp,sp,-96
    80005992:	ec86                	sd	ra,88(sp)
    80005994:	e8a2                	sd	s0,80(sp)
    80005996:	e4a6                	sd	s1,72(sp)
    80005998:	e0ca                	sd	s2,64(sp)
    8000599a:	fc4e                	sd	s3,56(sp)
    8000599c:	f852                	sd	s4,48(sp)
    8000599e:	f456                	sd	s5,40(sp)
    800059a0:	f05a                	sd	s6,32(sp)
    800059a2:	ec5e                	sd	s7,24(sp)
    800059a4:	e862                	sd	s8,16(sp)
    800059a6:	1080                	addi	s0,sp,96
    800059a8:	89aa                	mv	s3,a0
    800059aa:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800059ac:	00c52b83          	lw	s7,12(a0)
    800059b0:	001b9b9b          	slliw	s7,s7,0x1
    800059b4:	1b82                	slli	s7,s7,0x20
    800059b6:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    800059ba:	0001b517          	auipc	a0,0x1b
    800059be:	3c650513          	addi	a0,a0,966 # 80020d80 <disk+0x128>
    800059c2:	a66fb0ef          	jal	80000c28 <acquire>
  for(int i = 0; i < NUM; i++){
    800059c6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800059c8:	0001ba97          	auipc	s5,0x1b
    800059cc:	290a8a93          	addi	s5,s5,656 # 80020c58 <disk>
  for(int i = 0; i < 3; i++){
    800059d0:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800059d2:	5c7d                	li	s8,-1
    800059d4:	a095                	j	80005a38 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    800059d6:	00fa8733          	add	a4,s5,a5
    800059da:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800059de:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800059e0:	0207c563          	bltz	a5,80005a0a <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    800059e4:	2905                	addiw	s2,s2,1
    800059e6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800059e8:	05490c63          	beq	s2,s4,80005a40 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    800059ec:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800059ee:	0001b717          	auipc	a4,0x1b
    800059f2:	26a70713          	addi	a4,a4,618 # 80020c58 <disk>
    800059f6:	4781                	li	a5,0
    if(disk.free[i]){
    800059f8:	01874683          	lbu	a3,24(a4)
    800059fc:	fee9                	bnez	a3,800059d6 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    800059fe:	2785                	addiw	a5,a5,1
    80005a00:	0705                	addi	a4,a4,1
    80005a02:	fe979be3          	bne	a5,s1,800059f8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005a06:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80005a0a:	01205d63          	blez	s2,80005a24 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a0e:	fa042503          	lw	a0,-96(s0)
    80005a12:	d41ff0ef          	jal	80005752 <free_desc>
      for(int j = 0; j < i; j++)
    80005a16:	4785                	li	a5,1
    80005a18:	0127d663          	bge	a5,s2,80005a24 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a1c:	fa442503          	lw	a0,-92(s0)
    80005a20:	d33ff0ef          	jal	80005752 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a24:	0001b597          	auipc	a1,0x1b
    80005a28:	35c58593          	addi	a1,a1,860 # 80020d80 <disk+0x128>
    80005a2c:	0001b517          	auipc	a0,0x1b
    80005a30:	24450513          	addi	a0,a0,580 # 80020c70 <disk+0x18>
    80005a34:	d92fc0ef          	jal	80001fc6 <sleep>
  for(int i = 0; i < 3; i++){
    80005a38:	fa040613          	addi	a2,s0,-96
    80005a3c:	4901                	li	s2,0
    80005a3e:	b77d                	j	800059ec <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a40:	fa042503          	lw	a0,-96(s0)
    80005a44:	00451693          	slli	a3,a0,0x4

  if(write)
    80005a48:	0001b797          	auipc	a5,0x1b
    80005a4c:	21078793          	addi	a5,a5,528 # 80020c58 <disk>
    80005a50:	00451713          	slli	a4,a0,0x4
    80005a54:	0a070713          	addi	a4,a4,160
    80005a58:	973e                	add	a4,a4,a5
    80005a5a:	01603633          	snez	a2,s6
    80005a5e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005a60:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005a64:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005a68:	6398                	ld	a4,0(a5)
    80005a6a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a6c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005a70:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005a72:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005a74:	6390                	ld	a2,0(a5)
    80005a76:	00d60833          	add	a6,a2,a3
    80005a7a:	4741                	li	a4,16
    80005a7c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005a80:	4585                	li	a1,1
    80005a82:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005a86:	fa442703          	lw	a4,-92(s0)
    80005a8a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005a8e:	0712                	slli	a4,a4,0x4
    80005a90:	963a                	add	a2,a2,a4
    80005a92:	05898813          	addi	a6,s3,88
    80005a96:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005a9a:	0007b883          	ld	a7,0(a5)
    80005a9e:	9746                	add	a4,a4,a7
    80005aa0:	40000613          	li	a2,1024
    80005aa4:	c710                	sw	a2,8(a4)
  if(write)
    80005aa6:	001b3613          	seqz	a2,s6
    80005aaa:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005aae:	8e4d                	or	a2,a2,a1
    80005ab0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005ab4:	fa842603          	lw	a2,-88(s0)
    80005ab8:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005abc:	00451813          	slli	a6,a0,0x4
    80005ac0:	02080813          	addi	a6,a6,32
    80005ac4:	983e                	add	a6,a6,a5
    80005ac6:	577d                	li	a4,-1
    80005ac8:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005acc:	0612                	slli	a2,a2,0x4
    80005ace:	98b2                	add	a7,a7,a2
    80005ad0:	03068713          	addi	a4,a3,48
    80005ad4:	973e                	add	a4,a4,a5
    80005ad6:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005ada:	6398                	ld	a4,0(a5)
    80005adc:	9732                	add	a4,a4,a2
    80005ade:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005ae0:	4689                	li	a3,2
    80005ae2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005ae6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005aea:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80005aee:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005af2:	6794                	ld	a3,8(a5)
    80005af4:	0026d703          	lhu	a4,2(a3)
    80005af8:	8b1d                	andi	a4,a4,7
    80005afa:	0706                	slli	a4,a4,0x1
    80005afc:	96ba                	add	a3,a3,a4
    80005afe:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005b02:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b06:	6798                	ld	a4,8(a5)
    80005b08:	00275783          	lhu	a5,2(a4)
    80005b0c:	2785                	addiw	a5,a5,1
    80005b0e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005b12:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b16:	100017b7          	lui	a5,0x10001
    80005b1a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005b1e:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80005b22:	0001b917          	auipc	s2,0x1b
    80005b26:	25e90913          	addi	s2,s2,606 # 80020d80 <disk+0x128>
  while(b->disk == 1) {
    80005b2a:	84ae                	mv	s1,a1
    80005b2c:	00b79a63          	bne	a5,a1,80005b40 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005b30:	85ca                	mv	a1,s2
    80005b32:	854e                	mv	a0,s3
    80005b34:	c92fc0ef          	jal	80001fc6 <sleep>
  while(b->disk == 1) {
    80005b38:	0049a783          	lw	a5,4(s3)
    80005b3c:	fe978ae3          	beq	a5,s1,80005b30 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005b40:	fa042903          	lw	s2,-96(s0)
    80005b44:	00491713          	slli	a4,s2,0x4
    80005b48:	02070713          	addi	a4,a4,32
    80005b4c:	0001b797          	auipc	a5,0x1b
    80005b50:	10c78793          	addi	a5,a5,268 # 80020c58 <disk>
    80005b54:	97ba                	add	a5,a5,a4
    80005b56:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b5a:	0001b997          	auipc	s3,0x1b
    80005b5e:	0fe98993          	addi	s3,s3,254 # 80020c58 <disk>
    80005b62:	00491713          	slli	a4,s2,0x4
    80005b66:	0009b783          	ld	a5,0(s3)
    80005b6a:	97ba                	add	a5,a5,a4
    80005b6c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005b70:	854a                	mv	a0,s2
    80005b72:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005b76:	bddff0ef          	jal	80005752 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005b7a:	8885                	andi	s1,s1,1
    80005b7c:	f0fd                	bnez	s1,80005b62 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005b7e:	0001b517          	auipc	a0,0x1b
    80005b82:	20250513          	addi	a0,a0,514 # 80020d80 <disk+0x128>
    80005b86:	936fb0ef          	jal	80000cbc <release>
}
    80005b8a:	60e6                	ld	ra,88(sp)
    80005b8c:	6446                	ld	s0,80(sp)
    80005b8e:	64a6                	ld	s1,72(sp)
    80005b90:	6906                	ld	s2,64(sp)
    80005b92:	79e2                	ld	s3,56(sp)
    80005b94:	7a42                	ld	s4,48(sp)
    80005b96:	7aa2                	ld	s5,40(sp)
    80005b98:	7b02                	ld	s6,32(sp)
    80005b9a:	6be2                	ld	s7,24(sp)
    80005b9c:	6c42                	ld	s8,16(sp)
    80005b9e:	6125                	addi	sp,sp,96
    80005ba0:	8082                	ret

0000000080005ba2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005ba2:	1101                	addi	sp,sp,-32
    80005ba4:	ec06                	sd	ra,24(sp)
    80005ba6:	e822                	sd	s0,16(sp)
    80005ba8:	e426                	sd	s1,8(sp)
    80005baa:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005bac:	0001b497          	auipc	s1,0x1b
    80005bb0:	0ac48493          	addi	s1,s1,172 # 80020c58 <disk>
    80005bb4:	0001b517          	auipc	a0,0x1b
    80005bb8:	1cc50513          	addi	a0,a0,460 # 80020d80 <disk+0x128>
    80005bbc:	86cfb0ef          	jal	80000c28 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005bc0:	100017b7          	lui	a5,0x10001
    80005bc4:	53bc                	lw	a5,96(a5)
    80005bc6:	8b8d                	andi	a5,a5,3
    80005bc8:	10001737          	lui	a4,0x10001
    80005bcc:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005bce:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005bd2:	689c                	ld	a5,16(s1)
    80005bd4:	0204d703          	lhu	a4,32(s1)
    80005bd8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005bdc:	04f70863          	beq	a4,a5,80005c2c <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80005be0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005be4:	6898                	ld	a4,16(s1)
    80005be6:	0204d783          	lhu	a5,32(s1)
    80005bea:	8b9d                	andi	a5,a5,7
    80005bec:	078e                	slli	a5,a5,0x3
    80005bee:	97ba                	add	a5,a5,a4
    80005bf0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005bf2:	00479713          	slli	a4,a5,0x4
    80005bf6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005bfa:	9726                	add	a4,a4,s1
    80005bfc:	01074703          	lbu	a4,16(a4)
    80005c00:	e329                	bnez	a4,80005c42 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c02:	0792                	slli	a5,a5,0x4
    80005c04:	02078793          	addi	a5,a5,32
    80005c08:	97a6                	add	a5,a5,s1
    80005c0a:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005c0c:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c10:	c02fc0ef          	jal	80002012 <wakeup>

    disk.used_idx += 1;
    80005c14:	0204d783          	lhu	a5,32(s1)
    80005c18:	2785                	addiw	a5,a5,1
    80005c1a:	17c2                	slli	a5,a5,0x30
    80005c1c:	93c1                	srli	a5,a5,0x30
    80005c1e:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005c22:	6898                	ld	a4,16(s1)
    80005c24:	00275703          	lhu	a4,2(a4)
    80005c28:	faf71ce3          	bne	a4,a5,80005be0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c2c:	0001b517          	auipc	a0,0x1b
    80005c30:	15450513          	addi	a0,a0,340 # 80020d80 <disk+0x128>
    80005c34:	888fb0ef          	jal	80000cbc <release>
}
    80005c38:	60e2                	ld	ra,24(sp)
    80005c3a:	6442                	ld	s0,16(sp)
    80005c3c:	64a2                	ld	s1,8(sp)
    80005c3e:	6105                	addi	sp,sp,32
    80005c40:	8082                	ret
      panic("virtio_disk_intr status");
    80005c42:	00002517          	auipc	a0,0x2
    80005c46:	ab650513          	addi	a0,a0,-1354 # 800076f8 <etext+0x6f8>
    80005c4a:	bdbfa0ef          	jal	80000824 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
