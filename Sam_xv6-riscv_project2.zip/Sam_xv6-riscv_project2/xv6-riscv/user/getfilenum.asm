
user/_getfilenum:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <openFive>:
int fd2=0;
int fd3=0;
int fd4=0;
int fd5=0;
void openFive()
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
    fd1 = open("gfilenumtest1", O_CREATE|O_WRONLY);
   8:	20100593          	li	a1,513
   c:	00001517          	auipc	a0,0x1
  10:	a4450513          	addi	a0,a0,-1468 # a50 <malloc+0xfa>
  14:	47c000ef          	jal	490 <open>
  18:	00001797          	auipc	a5,0x1
  1c:	fea7ac23          	sw	a0,-8(a5) # 1010 <fd1>
    fd2 = open("gfilenumtest2", O_CREATE|O_WRONLY);
  20:	20100593          	li	a1,513
  24:	00001517          	auipc	a0,0x1
  28:	a3c50513          	addi	a0,a0,-1476 # a60 <malloc+0x10a>
  2c:	464000ef          	jal	490 <open>
  30:	00001797          	auipc	a5,0x1
  34:	fca7ae23          	sw	a0,-36(a5) # 100c <fd2>
    fd3 = open("gfilenumtest3", O_CREATE|O_WRONLY);
  38:	20100593          	li	a1,513
  3c:	00001517          	auipc	a0,0x1
  40:	a3450513          	addi	a0,a0,-1484 # a70 <malloc+0x11a>
  44:	44c000ef          	jal	490 <open>
  48:	00001797          	auipc	a5,0x1
  4c:	fca7a023          	sw	a0,-64(a5) # 1008 <fd3>
    fd4 = open("gfilenumtest4", O_CREATE|O_WRONLY);
  50:	20100593          	li	a1,513
  54:	00001517          	auipc	a0,0x1
  58:	a2c50513          	addi	a0,a0,-1492 # a80 <malloc+0x12a>
  5c:	434000ef          	jal	490 <open>
  60:	00001797          	auipc	a5,0x1
  64:	faa7a223          	sw	a0,-92(a5) # 1004 <fd4>
    fd5 = open("gfilenumtest5", O_CREATE|O_WRONLY);
  68:	20100593          	li	a1,513
  6c:	00001517          	auipc	a0,0x1
  70:	a2450513          	addi	a0,a0,-1500 # a90 <malloc+0x13a>
  74:	41c000ef          	jal	490 <open>
  78:	00001797          	auipc	a5,0x1
  7c:	f8a7a423          	sw	a0,-120(a5) # 1000 <fd5>
}
  80:	60a2                	ld	ra,8(sp)
  82:	6402                	ld	s0,0(sp)
  84:	0141                	addi	sp,sp,16
  86:	8082                	ret

0000000000000088 <main>:
int
main(int argc, char **argv)
{
  88:	1101                	addi	sp,sp,-32
  8a:	ec06                	sd	ra,24(sp)
  8c:	e822                	sd	s0,16(sp)
  8e:	e426                	sd	s1,8(sp)
  90:	e04a                	sd	s2,0(sp)
  92:	1000                	addi	s0,sp,32
  int pid = getpid();
  94:	43c000ef          	jal	4d0 <getpid>
  98:	84aa                	mv	s1,a0

  printf("files open for %d\n:",pid);
  9a:	85aa                	mv	a1,a0
  9c:	00001517          	auipc	a0,0x1
  a0:	a0450513          	addi	a0,a0,-1532 # aa0 <malloc+0x14a>
  a4:	7fa000ef          	jal	89e <printf>
  printf("before opening any additional: %d (should be 3)\n",getfilenum(pid));
  a8:	8526                	mv	a0,s1
  aa:	446000ef          	jal	4f0 <getfilenum>
  ae:	85aa                	mv	a1,a0
  b0:	00001517          	auipc	a0,0x1
  b4:	a0850513          	addi	a0,a0,-1528 # ab8 <malloc+0x162>
  b8:	7e6000ef          	jal	89e <printf>
  openFive();
  bc:	f45ff0ef          	jal	0 <openFive>
  printf("opened 5: %d (should be 8)\n",getfilenum(pid));
  c0:	8526                	mv	a0,s1
  c2:	42e000ef          	jal	4f0 <getfilenum>
  c6:	85aa                	mv	a1,a0
  c8:	00001517          	auipc	a0,0x1
  cc:	a2850513          	addi	a0,a0,-1496 # af0 <malloc+0x19a>
  d0:	7ce000ef          	jal	89e <printf>
  close(fd3);
  d4:	00001517          	auipc	a0,0x1
  d8:	f3452503          	lw	a0,-204(a0) # 1008 <fd3>
  dc:	39c000ef          	jal	478 <close>
  printf("closed 1: %d (should be 7)\n",getfilenum(pid));
  e0:	8526                	mv	a0,s1
  e2:	40e000ef          	jal	4f0 <getfilenum>
  e6:	85aa                	mv	a1,a0
  e8:	00001517          	auipc	a0,0x1
  ec:	a2850513          	addi	a0,a0,-1496 # b10 <malloc+0x1ba>
  f0:	7ae000ef          	jal	89e <printf>
  close(fd1);
  f4:	00001517          	auipc	a0,0x1
  f8:	f1c52503          	lw	a0,-228(a0) # 1010 <fd1>
  fc:	37c000ef          	jal	478 <close>
  printf("closed another: %d (should be 6)\n",getfilenum(pid));
 100:	8526                	mv	a0,s1
 102:	3ee000ef          	jal	4f0 <getfilenum>
 106:	85aa                	mv	a1,a0
 108:	00001517          	auipc	a0,0x1
 10c:	a2850513          	addi	a0,a0,-1496 # b30 <malloc+0x1da>
 110:	78e000ef          	jal	89e <printf>
  close(fd5);
 114:	00001917          	auipc	s2,0x1
 118:	eec90913          	addi	s2,s2,-276 # 1000 <fd5>
 11c:	00092503          	lw	a0,0(s2)
 120:	358000ef          	jal	478 <close>
  printf("closed another: %d (should be 5)\n",getfilenum(pid));
 124:	8526                	mv	a0,s1
 126:	3ca000ef          	jal	4f0 <getfilenum>
 12a:	85aa                	mv	a1,a0
 12c:	00001517          	auipc	a0,0x1
 130:	a2c50513          	addi	a0,a0,-1492 # b58 <malloc+0x202>
 134:	76a000ef          	jal	89e <printf>
  fd5 = open("gfilenmumtest6", O_CREATE|O_WRONLY);
 138:	20100593          	li	a1,513
 13c:	00001517          	auipc	a0,0x1
 140:	a4450513          	addi	a0,a0,-1468 # b80 <malloc+0x22a>
 144:	34c000ef          	jal	490 <open>
 148:	00a92023          	sw	a0,0(s2)
  printf("opened 1: %d (should be 6)\n",getfilenum(pid));
 14c:	8526                	mv	a0,s1
 14e:	3a2000ef          	jal	4f0 <getfilenum>
 152:	85aa                	mv	a1,a0
 154:	00001517          	auipc	a0,0x1
 158:	a3c50513          	addi	a0,a0,-1476 # b90 <malloc+0x23a>
 15c:	742000ef          	jal	89e <printf>
  close(fd5);
 160:	00092503          	lw	a0,0(s2)
 164:	314000ef          	jal	478 <close>
  close(fd2);
 168:	00001517          	auipc	a0,0x1
 16c:	ea452503          	lw	a0,-348(a0) # 100c <fd2>
 170:	308000ef          	jal	478 <close>
  close(fd4);
 174:	00001517          	auipc	a0,0x1
 178:	e9052503          	lw	a0,-368(a0) # 1004 <fd4>
 17c:	2fc000ef          	jal	478 <close>
  printf("closed all: %d (should be 3)\n",getfilenum(pid));
 180:	8526                	mv	a0,s1
 182:	36e000ef          	jal	4f0 <getfilenum>
 186:	85aa                	mv	a1,a0
 188:	00001517          	auipc	a0,0x1
 18c:	a2850513          	addi	a0,a0,-1496 # bb0 <malloc+0x25a>
 190:	70e000ef          	jal	89e <printf>
  exit(0);
 194:	4501                	li	a0,0
 196:	2ba000ef          	jal	450 <exit>

000000000000019a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 19a:	1141                	addi	sp,sp,-16
 19c:	e406                	sd	ra,8(sp)
 19e:	e022                	sd	s0,0(sp)
 1a0:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 1a2:	ee7ff0ef          	jal	88 <main>
  exit(r);
 1a6:	2aa000ef          	jal	450 <exit>

00000000000001aa <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1aa:	1141                	addi	sp,sp,-16
 1ac:	e406                	sd	ra,8(sp)
 1ae:	e022                	sd	s0,0(sp)
 1b0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1b2:	87aa                	mv	a5,a0
 1b4:	0585                	addi	a1,a1,1
 1b6:	0785                	addi	a5,a5,1
 1b8:	fff5c703          	lbu	a4,-1(a1)
 1bc:	fee78fa3          	sb	a4,-1(a5)
 1c0:	fb75                	bnez	a4,1b4 <strcpy+0xa>
    ;
  return os;
}
 1c2:	60a2                	ld	ra,8(sp)
 1c4:	6402                	ld	s0,0(sp)
 1c6:	0141                	addi	sp,sp,16
 1c8:	8082                	ret

00000000000001ca <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1ca:	1141                	addi	sp,sp,-16
 1cc:	e406                	sd	ra,8(sp)
 1ce:	e022                	sd	s0,0(sp)
 1d0:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1d2:	00054783          	lbu	a5,0(a0)
 1d6:	cb91                	beqz	a5,1ea <strcmp+0x20>
 1d8:	0005c703          	lbu	a4,0(a1)
 1dc:	00f71763          	bne	a4,a5,1ea <strcmp+0x20>
    p++, q++;
 1e0:	0505                	addi	a0,a0,1
 1e2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1e4:	00054783          	lbu	a5,0(a0)
 1e8:	fbe5                	bnez	a5,1d8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1ea:	0005c503          	lbu	a0,0(a1)
}
 1ee:	40a7853b          	subw	a0,a5,a0
 1f2:	60a2                	ld	ra,8(sp)
 1f4:	6402                	ld	s0,0(sp)
 1f6:	0141                	addi	sp,sp,16
 1f8:	8082                	ret

00000000000001fa <strlen>:

uint
strlen(const char *s)
{
 1fa:	1141                	addi	sp,sp,-16
 1fc:	e406                	sd	ra,8(sp)
 1fe:	e022                	sd	s0,0(sp)
 200:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 202:	00054783          	lbu	a5,0(a0)
 206:	cf91                	beqz	a5,222 <strlen+0x28>
 208:	00150793          	addi	a5,a0,1
 20c:	86be                	mv	a3,a5
 20e:	0785                	addi	a5,a5,1
 210:	fff7c703          	lbu	a4,-1(a5)
 214:	ff65                	bnez	a4,20c <strlen+0x12>
 216:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 21a:	60a2                	ld	ra,8(sp)
 21c:	6402                	ld	s0,0(sp)
 21e:	0141                	addi	sp,sp,16
 220:	8082                	ret
  for(n = 0; s[n]; n++)
 222:	4501                	li	a0,0
 224:	bfdd                	j	21a <strlen+0x20>

0000000000000226 <memset>:

void*
memset(void *dst, int c, uint n)
{
 226:	1141                	addi	sp,sp,-16
 228:	e406                	sd	ra,8(sp)
 22a:	e022                	sd	s0,0(sp)
 22c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 22e:	ca19                	beqz	a2,244 <memset+0x1e>
 230:	87aa                	mv	a5,a0
 232:	1602                	slli	a2,a2,0x20
 234:	9201                	srli	a2,a2,0x20
 236:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 23a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 23e:	0785                	addi	a5,a5,1
 240:	fee79de3          	bne	a5,a4,23a <memset+0x14>
  }
  return dst;
}
 244:	60a2                	ld	ra,8(sp)
 246:	6402                	ld	s0,0(sp)
 248:	0141                	addi	sp,sp,16
 24a:	8082                	ret

000000000000024c <strchr>:

char*
strchr(const char *s, char c)
{
 24c:	1141                	addi	sp,sp,-16
 24e:	e406                	sd	ra,8(sp)
 250:	e022                	sd	s0,0(sp)
 252:	0800                	addi	s0,sp,16
  for(; *s; s++)
 254:	00054783          	lbu	a5,0(a0)
 258:	cf81                	beqz	a5,270 <strchr+0x24>
    if(*s == c)
 25a:	00f58763          	beq	a1,a5,268 <strchr+0x1c>
  for(; *s; s++)
 25e:	0505                	addi	a0,a0,1
 260:	00054783          	lbu	a5,0(a0)
 264:	fbfd                	bnez	a5,25a <strchr+0xe>
      return (char*)s;
  return 0;
 266:	4501                	li	a0,0
}
 268:	60a2                	ld	ra,8(sp)
 26a:	6402                	ld	s0,0(sp)
 26c:	0141                	addi	sp,sp,16
 26e:	8082                	ret
  return 0;
 270:	4501                	li	a0,0
 272:	bfdd                	j	268 <strchr+0x1c>

0000000000000274 <gets>:

char*
gets(char *buf, int max)
{
 274:	711d                	addi	sp,sp,-96
 276:	ec86                	sd	ra,88(sp)
 278:	e8a2                	sd	s0,80(sp)
 27a:	e4a6                	sd	s1,72(sp)
 27c:	e0ca                	sd	s2,64(sp)
 27e:	fc4e                	sd	s3,56(sp)
 280:	f852                	sd	s4,48(sp)
 282:	f456                	sd	s5,40(sp)
 284:	f05a                	sd	s6,32(sp)
 286:	ec5e                	sd	s7,24(sp)
 288:	e862                	sd	s8,16(sp)
 28a:	1080                	addi	s0,sp,96
 28c:	8baa                	mv	s7,a0
 28e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 290:	892a                	mv	s2,a0
 292:	4481                	li	s1,0
    cc = read(0, &c, 1);
 294:	faf40b13          	addi	s6,s0,-81
 298:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 29a:	8c26                	mv	s8,s1
 29c:	0014899b          	addiw	s3,s1,1
 2a0:	84ce                	mv	s1,s3
 2a2:	0349d463          	bge	s3,s4,2ca <gets+0x56>
    cc = read(0, &c, 1);
 2a6:	8656                	mv	a2,s5
 2a8:	85da                	mv	a1,s6
 2aa:	4501                	li	a0,0
 2ac:	1bc000ef          	jal	468 <read>
    if(cc < 1)
 2b0:	00a05d63          	blez	a0,2ca <gets+0x56>
      break;
    buf[i++] = c;
 2b4:	faf44783          	lbu	a5,-81(s0)
 2b8:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 2bc:	0905                	addi	s2,s2,1
 2be:	ff678713          	addi	a4,a5,-10
 2c2:	c319                	beqz	a4,2c8 <gets+0x54>
 2c4:	17cd                	addi	a5,a5,-13
 2c6:	fbf1                	bnez	a5,29a <gets+0x26>
    buf[i++] = c;
 2c8:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 2ca:	9c5e                	add	s8,s8,s7
 2cc:	000c0023          	sb	zero,0(s8)
  return buf;
}
 2d0:	855e                	mv	a0,s7
 2d2:	60e6                	ld	ra,88(sp)
 2d4:	6446                	ld	s0,80(sp)
 2d6:	64a6                	ld	s1,72(sp)
 2d8:	6906                	ld	s2,64(sp)
 2da:	79e2                	ld	s3,56(sp)
 2dc:	7a42                	ld	s4,48(sp)
 2de:	7aa2                	ld	s5,40(sp)
 2e0:	7b02                	ld	s6,32(sp)
 2e2:	6be2                	ld	s7,24(sp)
 2e4:	6c42                	ld	s8,16(sp)
 2e6:	6125                	addi	sp,sp,96
 2e8:	8082                	ret

00000000000002ea <stat>:

int
stat(const char *n, struct stat *st)
{
 2ea:	1101                	addi	sp,sp,-32
 2ec:	ec06                	sd	ra,24(sp)
 2ee:	e822                	sd	s0,16(sp)
 2f0:	e04a                	sd	s2,0(sp)
 2f2:	1000                	addi	s0,sp,32
 2f4:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2f6:	4581                	li	a1,0
 2f8:	198000ef          	jal	490 <open>
  if(fd < 0)
 2fc:	02054263          	bltz	a0,320 <stat+0x36>
 300:	e426                	sd	s1,8(sp)
 302:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 304:	85ca                	mv	a1,s2
 306:	1a2000ef          	jal	4a8 <fstat>
 30a:	892a                	mv	s2,a0
  close(fd);
 30c:	8526                	mv	a0,s1
 30e:	16a000ef          	jal	478 <close>
  return r;
 312:	64a2                	ld	s1,8(sp)
}
 314:	854a                	mv	a0,s2
 316:	60e2                	ld	ra,24(sp)
 318:	6442                	ld	s0,16(sp)
 31a:	6902                	ld	s2,0(sp)
 31c:	6105                	addi	sp,sp,32
 31e:	8082                	ret
    return -1;
 320:	57fd                	li	a5,-1
 322:	893e                	mv	s2,a5
 324:	bfc5                	j	314 <stat+0x2a>

0000000000000326 <atoi>:

int
atoi(const char *s)
{
 326:	1141                	addi	sp,sp,-16
 328:	e406                	sd	ra,8(sp)
 32a:	e022                	sd	s0,0(sp)
 32c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 32e:	00054683          	lbu	a3,0(a0)
 332:	fd06879b          	addiw	a5,a3,-48
 336:	0ff7f793          	zext.b	a5,a5
 33a:	4625                	li	a2,9
 33c:	02f66963          	bltu	a2,a5,36e <atoi+0x48>
 340:	872a                	mv	a4,a0
  n = 0;
 342:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 344:	0705                	addi	a4,a4,1
 346:	0025179b          	slliw	a5,a0,0x2
 34a:	9fa9                	addw	a5,a5,a0
 34c:	0017979b          	slliw	a5,a5,0x1
 350:	9fb5                	addw	a5,a5,a3
 352:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 356:	00074683          	lbu	a3,0(a4)
 35a:	fd06879b          	addiw	a5,a3,-48
 35e:	0ff7f793          	zext.b	a5,a5
 362:	fef671e3          	bgeu	a2,a5,344 <atoi+0x1e>
  return n;
}
 366:	60a2                	ld	ra,8(sp)
 368:	6402                	ld	s0,0(sp)
 36a:	0141                	addi	sp,sp,16
 36c:	8082                	ret
  n = 0;
 36e:	4501                	li	a0,0
 370:	bfdd                	j	366 <atoi+0x40>

0000000000000372 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 372:	1141                	addi	sp,sp,-16
 374:	e406                	sd	ra,8(sp)
 376:	e022                	sd	s0,0(sp)
 378:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 37a:	02b57563          	bgeu	a0,a1,3a4 <memmove+0x32>
    while(n-- > 0)
 37e:	00c05f63          	blez	a2,39c <memmove+0x2a>
 382:	1602                	slli	a2,a2,0x20
 384:	9201                	srli	a2,a2,0x20
 386:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 38a:	872a                	mv	a4,a0
      *dst++ = *src++;
 38c:	0585                	addi	a1,a1,1
 38e:	0705                	addi	a4,a4,1
 390:	fff5c683          	lbu	a3,-1(a1)
 394:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 398:	fee79ae3          	bne	a5,a4,38c <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 39c:	60a2                	ld	ra,8(sp)
 39e:	6402                	ld	s0,0(sp)
 3a0:	0141                	addi	sp,sp,16
 3a2:	8082                	ret
    while(n-- > 0)
 3a4:	fec05ce3          	blez	a2,39c <memmove+0x2a>
    dst += n;
 3a8:	00c50733          	add	a4,a0,a2
    src += n;
 3ac:	95b2                	add	a1,a1,a2
 3ae:	fff6079b          	addiw	a5,a2,-1
 3b2:	1782                	slli	a5,a5,0x20
 3b4:	9381                	srli	a5,a5,0x20
 3b6:	fff7c793          	not	a5,a5
 3ba:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3bc:	15fd                	addi	a1,a1,-1
 3be:	177d                	addi	a4,a4,-1
 3c0:	0005c683          	lbu	a3,0(a1)
 3c4:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 3c8:	fef71ae3          	bne	a4,a5,3bc <memmove+0x4a>
 3cc:	bfc1                	j	39c <memmove+0x2a>

00000000000003ce <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3ce:	1141                	addi	sp,sp,-16
 3d0:	e406                	sd	ra,8(sp)
 3d2:	e022                	sd	s0,0(sp)
 3d4:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3d6:	c61d                	beqz	a2,404 <memcmp+0x36>
 3d8:	1602                	slli	a2,a2,0x20
 3da:	9201                	srli	a2,a2,0x20
 3dc:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3e0:	00054783          	lbu	a5,0(a0)
 3e4:	0005c703          	lbu	a4,0(a1)
 3e8:	00e79863          	bne	a5,a4,3f8 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 3ec:	0505                	addi	a0,a0,1
    p2++;
 3ee:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3f0:	fed518e3          	bne	a0,a3,3e0 <memcmp+0x12>
  }
  return 0;
 3f4:	4501                	li	a0,0
 3f6:	a019                	j	3fc <memcmp+0x2e>
      return *p1 - *p2;
 3f8:	40e7853b          	subw	a0,a5,a4
}
 3fc:	60a2                	ld	ra,8(sp)
 3fe:	6402                	ld	s0,0(sp)
 400:	0141                	addi	sp,sp,16
 402:	8082                	ret
  return 0;
 404:	4501                	li	a0,0
 406:	bfdd                	j	3fc <memcmp+0x2e>

0000000000000408 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 408:	1141                	addi	sp,sp,-16
 40a:	e406                	sd	ra,8(sp)
 40c:	e022                	sd	s0,0(sp)
 40e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 410:	f63ff0ef          	jal	372 <memmove>
}
 414:	60a2                	ld	ra,8(sp)
 416:	6402                	ld	s0,0(sp)
 418:	0141                	addi	sp,sp,16
 41a:	8082                	ret

000000000000041c <sbrk>:

char *
sbrk(int n) {
 41c:	1141                	addi	sp,sp,-16
 41e:	e406                	sd	ra,8(sp)
 420:	e022                	sd	s0,0(sp)
 422:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 424:	4585                	li	a1,1
 426:	0b2000ef          	jal	4d8 <sys_sbrk>
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret

0000000000000432 <sbrklazy>:

char *
sbrklazy(int n) {
 432:	1141                	addi	sp,sp,-16
 434:	e406                	sd	ra,8(sp)
 436:	e022                	sd	s0,0(sp)
 438:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 43a:	4589                	li	a1,2
 43c:	09c000ef          	jal	4d8 <sys_sbrk>
}
 440:	60a2                	ld	ra,8(sp)
 442:	6402                	ld	s0,0(sp)
 444:	0141                	addi	sp,sp,16
 446:	8082                	ret

0000000000000448 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 448:	4885                	li	a7,1
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <exit>:
.global exit
exit:
 li a7, SYS_exit
 450:	4889                	li	a7,2
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <wait>:
.global wait
wait:
 li a7, SYS_wait
 458:	488d                	li	a7,3
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 460:	4891                	li	a7,4
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <read>:
.global read
read:
 li a7, SYS_read
 468:	4895                	li	a7,5
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <write>:
.global write
write:
 li a7, SYS_write
 470:	48c1                	li	a7,16
 ecall
 472:	00000073          	ecall
 ret
 476:	8082                	ret

0000000000000478 <close>:
.global close
close:
 li a7, SYS_close
 478:	48d5                	li	a7,21
 ecall
 47a:	00000073          	ecall
 ret
 47e:	8082                	ret

0000000000000480 <kill>:
.global kill
kill:
 li a7, SYS_kill
 480:	4899                	li	a7,6
 ecall
 482:	00000073          	ecall
 ret
 486:	8082                	ret

0000000000000488 <exec>:
.global exec
exec:
 li a7, SYS_exec
 488:	489d                	li	a7,7
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <open>:
.global open
open:
 li a7, SYS_open
 490:	48bd                	li	a7,15
 ecall
 492:	00000073          	ecall
 ret
 496:	8082                	ret

0000000000000498 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 498:	48c5                	li	a7,17
 ecall
 49a:	00000073          	ecall
 ret
 49e:	8082                	ret

00000000000004a0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4a0:	48c9                	li	a7,18
 ecall
 4a2:	00000073          	ecall
 ret
 4a6:	8082                	ret

00000000000004a8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4a8:	48a1                	li	a7,8
 ecall
 4aa:	00000073          	ecall
 ret
 4ae:	8082                	ret

00000000000004b0 <link>:
.global link
link:
 li a7, SYS_link
 4b0:	48cd                	li	a7,19
 ecall
 4b2:	00000073          	ecall
 ret
 4b6:	8082                	ret

00000000000004b8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4b8:	48d1                	li	a7,20
 ecall
 4ba:	00000073          	ecall
 ret
 4be:	8082                	ret

00000000000004c0 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4c0:	48a5                	li	a7,9
 ecall
 4c2:	00000073          	ecall
 ret
 4c6:	8082                	ret

00000000000004c8 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4c8:	48a9                	li	a7,10
 ecall
 4ca:	00000073          	ecall
 ret
 4ce:	8082                	ret

00000000000004d0 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4d0:	48ad                	li	a7,11
 ecall
 4d2:	00000073          	ecall
 ret
 4d6:	8082                	ret

00000000000004d8 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 4d8:	48b1                	li	a7,12
 ecall
 4da:	00000073          	ecall
 ret
 4de:	8082                	ret

00000000000004e0 <pause>:
.global pause
pause:
 li a7, SYS_pause
 4e0:	48b5                	li	a7,13
 ecall
 4e2:	00000073          	ecall
 ret
 4e6:	8082                	ret

00000000000004e8 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4e8:	48b9                	li	a7,14
 ecall
 4ea:	00000073          	ecall
 ret
 4ee:	8082                	ret

00000000000004f0 <getfilenum>:
.global getfilenum
getfilenum:
 li a7, SYS_getfilenum
 4f0:	48d9                	li	a7,22
 ecall
 4f2:	00000073          	ecall
 ret
 4f6:	8082                	ret

00000000000004f8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4f8:	1101                	addi	sp,sp,-32
 4fa:	ec06                	sd	ra,24(sp)
 4fc:	e822                	sd	s0,16(sp)
 4fe:	1000                	addi	s0,sp,32
 500:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 504:	4605                	li	a2,1
 506:	fef40593          	addi	a1,s0,-17
 50a:	f67ff0ef          	jal	470 <write>
}
 50e:	60e2                	ld	ra,24(sp)
 510:	6442                	ld	s0,16(sp)
 512:	6105                	addi	sp,sp,32
 514:	8082                	ret

0000000000000516 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 516:	715d                	addi	sp,sp,-80
 518:	e486                	sd	ra,72(sp)
 51a:	e0a2                	sd	s0,64(sp)
 51c:	f84a                	sd	s2,48(sp)
 51e:	f44e                	sd	s3,40(sp)
 520:	0880                	addi	s0,sp,80
 522:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 524:	c6d1                	beqz	a3,5b0 <printint+0x9a>
 526:	0805d563          	bgez	a1,5b0 <printint+0x9a>
    neg = 1;
    x = -xx;
 52a:	40b005b3          	neg	a1,a1
    neg = 1;
 52e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 530:	fb840993          	addi	s3,s0,-72
  neg = 0;
 534:	86ce                	mv	a3,s3
  i = 0;
 536:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 538:	00000817          	auipc	a6,0x0
 53c:	6a080813          	addi	a6,a6,1696 # bd8 <digits>
 540:	88ba                	mv	a7,a4
 542:	0017051b          	addiw	a0,a4,1
 546:	872a                	mv	a4,a0
 548:	02c5f7b3          	remu	a5,a1,a2
 54c:	97c2                	add	a5,a5,a6
 54e:	0007c783          	lbu	a5,0(a5)
 552:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 556:	87ae                	mv	a5,a1
 558:	02c5d5b3          	divu	a1,a1,a2
 55c:	0685                	addi	a3,a3,1
 55e:	fec7f1e3          	bgeu	a5,a2,540 <printint+0x2a>
  if(neg)
 562:	00030c63          	beqz	t1,57a <printint+0x64>
    buf[i++] = '-';
 566:	fd050793          	addi	a5,a0,-48
 56a:	00878533          	add	a0,a5,s0
 56e:	02d00793          	li	a5,45
 572:	fef50423          	sb	a5,-24(a0)
 576:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 57a:	02e05563          	blez	a4,5a4 <printint+0x8e>
 57e:	fc26                	sd	s1,56(sp)
 580:	377d                	addiw	a4,a4,-1
 582:	00e984b3          	add	s1,s3,a4
 586:	19fd                	addi	s3,s3,-1
 588:	99ba                	add	s3,s3,a4
 58a:	1702                	slli	a4,a4,0x20
 58c:	9301                	srli	a4,a4,0x20
 58e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 592:	0004c583          	lbu	a1,0(s1)
 596:	854a                	mv	a0,s2
 598:	f61ff0ef          	jal	4f8 <putc>
  while(--i >= 0)
 59c:	14fd                	addi	s1,s1,-1
 59e:	ff349ae3          	bne	s1,s3,592 <printint+0x7c>
 5a2:	74e2                	ld	s1,56(sp)
}
 5a4:	60a6                	ld	ra,72(sp)
 5a6:	6406                	ld	s0,64(sp)
 5a8:	7942                	ld	s2,48(sp)
 5aa:	79a2                	ld	s3,40(sp)
 5ac:	6161                	addi	sp,sp,80
 5ae:	8082                	ret
  neg = 0;
 5b0:	4301                	li	t1,0
 5b2:	bfbd                	j	530 <printint+0x1a>

00000000000005b4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5b4:	711d                	addi	sp,sp,-96
 5b6:	ec86                	sd	ra,88(sp)
 5b8:	e8a2                	sd	s0,80(sp)
 5ba:	e4a6                	sd	s1,72(sp)
 5bc:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5be:	0005c483          	lbu	s1,0(a1)
 5c2:	22048363          	beqz	s1,7e8 <vprintf+0x234>
 5c6:	e0ca                	sd	s2,64(sp)
 5c8:	fc4e                	sd	s3,56(sp)
 5ca:	f852                	sd	s4,48(sp)
 5cc:	f456                	sd	s5,40(sp)
 5ce:	f05a                	sd	s6,32(sp)
 5d0:	ec5e                	sd	s7,24(sp)
 5d2:	e862                	sd	s8,16(sp)
 5d4:	8b2a                	mv	s6,a0
 5d6:	8a2e                	mv	s4,a1
 5d8:	8bb2                	mv	s7,a2
  state = 0;
 5da:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5dc:	4901                	li	s2,0
 5de:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5e0:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5e4:	06400c13          	li	s8,100
 5e8:	a00d                	j	60a <vprintf+0x56>
        putc(fd, c0);
 5ea:	85a6                	mv	a1,s1
 5ec:	855a                	mv	a0,s6
 5ee:	f0bff0ef          	jal	4f8 <putc>
 5f2:	a019                	j	5f8 <vprintf+0x44>
    } else if(state == '%'){
 5f4:	03598363          	beq	s3,s5,61a <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 5f8:	0019079b          	addiw	a5,s2,1
 5fc:	893e                	mv	s2,a5
 5fe:	873e                	mv	a4,a5
 600:	97d2                	add	a5,a5,s4
 602:	0007c483          	lbu	s1,0(a5)
 606:	1c048a63          	beqz	s1,7da <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 60a:	0004879b          	sext.w	a5,s1
    if(state == 0){
 60e:	fe0993e3          	bnez	s3,5f4 <vprintf+0x40>
      if(c0 == '%'){
 612:	fd579ce3          	bne	a5,s5,5ea <vprintf+0x36>
        state = '%';
 616:	89be                	mv	s3,a5
 618:	b7c5                	j	5f8 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 61a:	00ea06b3          	add	a3,s4,a4
 61e:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 622:	1c060863          	beqz	a2,7f2 <vprintf+0x23e>
      if(c0 == 'd'){
 626:	03878763          	beq	a5,s8,654 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 62a:	f9478693          	addi	a3,a5,-108
 62e:	0016b693          	seqz	a3,a3
 632:	f9c60593          	addi	a1,a2,-100
 636:	e99d                	bnez	a1,66c <vprintf+0xb8>
 638:	ca95                	beqz	a3,66c <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 63a:	008b8493          	addi	s1,s7,8
 63e:	4685                	li	a3,1
 640:	4629                	li	a2,10
 642:	000bb583          	ld	a1,0(s7)
 646:	855a                	mv	a0,s6
 648:	ecfff0ef          	jal	516 <printint>
        i += 1;
 64c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 64e:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 650:	4981                	li	s3,0
 652:	b75d                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 654:	008b8493          	addi	s1,s7,8
 658:	4685                	li	a3,1
 65a:	4629                	li	a2,10
 65c:	000ba583          	lw	a1,0(s7)
 660:	855a                	mv	a0,s6
 662:	eb5ff0ef          	jal	516 <printint>
 666:	8ba6                	mv	s7,s1
      state = 0;
 668:	4981                	li	s3,0
 66a:	b779                	j	5f8 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 66c:	9752                	add	a4,a4,s4
 66e:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 672:	f9460713          	addi	a4,a2,-108
 676:	00173713          	seqz	a4,a4
 67a:	8f75                	and	a4,a4,a3
 67c:	f9c58513          	addi	a0,a1,-100
 680:	18051363          	bnez	a0,806 <vprintf+0x252>
 684:	18070163          	beqz	a4,806 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 688:	008b8493          	addi	s1,s7,8
 68c:	4685                	li	a3,1
 68e:	4629                	li	a2,10
 690:	000bb583          	ld	a1,0(s7)
 694:	855a                	mv	a0,s6
 696:	e81ff0ef          	jal	516 <printint>
        i += 2;
 69a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 69c:	8ba6                	mv	s7,s1
      state = 0;
 69e:	4981                	li	s3,0
        i += 2;
 6a0:	bfa1                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 6a2:	008b8493          	addi	s1,s7,8
 6a6:	4681                	li	a3,0
 6a8:	4629                	li	a2,10
 6aa:	000be583          	lwu	a1,0(s7)
 6ae:	855a                	mv	a0,s6
 6b0:	e67ff0ef          	jal	516 <printint>
 6b4:	8ba6                	mv	s7,s1
      state = 0;
 6b6:	4981                	li	s3,0
 6b8:	b781                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ba:	008b8493          	addi	s1,s7,8
 6be:	4681                	li	a3,0
 6c0:	4629                	li	a2,10
 6c2:	000bb583          	ld	a1,0(s7)
 6c6:	855a                	mv	a0,s6
 6c8:	e4fff0ef          	jal	516 <printint>
        i += 1;
 6cc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ce:	8ba6                	mv	s7,s1
      state = 0;
 6d0:	4981                	li	s3,0
 6d2:	b71d                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6d4:	008b8493          	addi	s1,s7,8
 6d8:	4681                	li	a3,0
 6da:	4629                	li	a2,10
 6dc:	000bb583          	ld	a1,0(s7)
 6e0:	855a                	mv	a0,s6
 6e2:	e35ff0ef          	jal	516 <printint>
        i += 2;
 6e6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6e8:	8ba6                	mv	s7,s1
      state = 0;
 6ea:	4981                	li	s3,0
        i += 2;
 6ec:	b731                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6ee:	008b8493          	addi	s1,s7,8
 6f2:	4681                	li	a3,0
 6f4:	4641                	li	a2,16
 6f6:	000be583          	lwu	a1,0(s7)
 6fa:	855a                	mv	a0,s6
 6fc:	e1bff0ef          	jal	516 <printint>
 700:	8ba6                	mv	s7,s1
      state = 0;
 702:	4981                	li	s3,0
 704:	bdd5                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 706:	008b8493          	addi	s1,s7,8
 70a:	4681                	li	a3,0
 70c:	4641                	li	a2,16
 70e:	000bb583          	ld	a1,0(s7)
 712:	855a                	mv	a0,s6
 714:	e03ff0ef          	jal	516 <printint>
        i += 1;
 718:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 71a:	8ba6                	mv	s7,s1
      state = 0;
 71c:	4981                	li	s3,0
 71e:	bde9                	j	5f8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 720:	008b8493          	addi	s1,s7,8
 724:	4681                	li	a3,0
 726:	4641                	li	a2,16
 728:	000bb583          	ld	a1,0(s7)
 72c:	855a                	mv	a0,s6
 72e:	de9ff0ef          	jal	516 <printint>
        i += 2;
 732:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 734:	8ba6                	mv	s7,s1
      state = 0;
 736:	4981                	li	s3,0
        i += 2;
 738:	b5c1                	j	5f8 <vprintf+0x44>
 73a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 73c:	008b8793          	addi	a5,s7,8
 740:	8cbe                	mv	s9,a5
 742:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 746:	03000593          	li	a1,48
 74a:	855a                	mv	a0,s6
 74c:	dadff0ef          	jal	4f8 <putc>
  putc(fd, 'x');
 750:	07800593          	li	a1,120
 754:	855a                	mv	a0,s6
 756:	da3ff0ef          	jal	4f8 <putc>
 75a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 75c:	00000b97          	auipc	s7,0x0
 760:	47cb8b93          	addi	s7,s7,1148 # bd8 <digits>
 764:	03c9d793          	srli	a5,s3,0x3c
 768:	97de                	add	a5,a5,s7
 76a:	0007c583          	lbu	a1,0(a5)
 76e:	855a                	mv	a0,s6
 770:	d89ff0ef          	jal	4f8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 774:	0992                	slli	s3,s3,0x4
 776:	34fd                	addiw	s1,s1,-1
 778:	f4f5                	bnez	s1,764 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 77a:	8be6                	mv	s7,s9
      state = 0;
 77c:	4981                	li	s3,0
 77e:	6ca2                	ld	s9,8(sp)
 780:	bda5                	j	5f8 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 782:	008b8493          	addi	s1,s7,8
 786:	000bc583          	lbu	a1,0(s7)
 78a:	855a                	mv	a0,s6
 78c:	d6dff0ef          	jal	4f8 <putc>
 790:	8ba6                	mv	s7,s1
      state = 0;
 792:	4981                	li	s3,0
 794:	b595                	j	5f8 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 796:	008b8993          	addi	s3,s7,8
 79a:	000bb483          	ld	s1,0(s7)
 79e:	cc91                	beqz	s1,7ba <vprintf+0x206>
        for(; *s; s++)
 7a0:	0004c583          	lbu	a1,0(s1)
 7a4:	c985                	beqz	a1,7d4 <vprintf+0x220>
          putc(fd, *s);
 7a6:	855a                	mv	a0,s6
 7a8:	d51ff0ef          	jal	4f8 <putc>
        for(; *s; s++)
 7ac:	0485                	addi	s1,s1,1
 7ae:	0004c583          	lbu	a1,0(s1)
 7b2:	f9f5                	bnez	a1,7a6 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 7b4:	8bce                	mv	s7,s3
      state = 0;
 7b6:	4981                	li	s3,0
 7b8:	b581                	j	5f8 <vprintf+0x44>
          s = "(null)";
 7ba:	00000497          	auipc	s1,0x0
 7be:	41648493          	addi	s1,s1,1046 # bd0 <malloc+0x27a>
        for(; *s; s++)
 7c2:	02800593          	li	a1,40
 7c6:	b7c5                	j	7a6 <vprintf+0x1f2>
        putc(fd, '%');
 7c8:	85be                	mv	a1,a5
 7ca:	855a                	mv	a0,s6
 7cc:	d2dff0ef          	jal	4f8 <putc>
      state = 0;
 7d0:	4981                	li	s3,0
 7d2:	b51d                	j	5f8 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7d4:	8bce                	mv	s7,s3
      state = 0;
 7d6:	4981                	li	s3,0
 7d8:	b505                	j	5f8 <vprintf+0x44>
 7da:	6906                	ld	s2,64(sp)
 7dc:	79e2                	ld	s3,56(sp)
 7de:	7a42                	ld	s4,48(sp)
 7e0:	7aa2                	ld	s5,40(sp)
 7e2:	7b02                	ld	s6,32(sp)
 7e4:	6be2                	ld	s7,24(sp)
 7e6:	6c42                	ld	s8,16(sp)
    }
  }
}
 7e8:	60e6                	ld	ra,88(sp)
 7ea:	6446                	ld	s0,80(sp)
 7ec:	64a6                	ld	s1,72(sp)
 7ee:	6125                	addi	sp,sp,96
 7f0:	8082                	ret
      if(c0 == 'd'){
 7f2:	06400713          	li	a4,100
 7f6:	e4e78fe3          	beq	a5,a4,654 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 7fa:	f9478693          	addi	a3,a5,-108
 7fe:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 802:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 804:	4701                	li	a4,0
      } else if(c0 == 'u'){
 806:	07500513          	li	a0,117
 80a:	e8a78ce3          	beq	a5,a0,6a2 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 80e:	f8b60513          	addi	a0,a2,-117
 812:	e119                	bnez	a0,818 <vprintf+0x264>
 814:	ea0693e3          	bnez	a3,6ba <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 818:	f8b58513          	addi	a0,a1,-117
 81c:	e119                	bnez	a0,822 <vprintf+0x26e>
 81e:	ea071be3          	bnez	a4,6d4 <vprintf+0x120>
      } else if(c0 == 'x'){
 822:	07800513          	li	a0,120
 826:	eca784e3          	beq	a5,a0,6ee <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 82a:	f8860613          	addi	a2,a2,-120
 82e:	e219                	bnez	a2,834 <vprintf+0x280>
 830:	ec069be3          	bnez	a3,706 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 834:	f8858593          	addi	a1,a1,-120
 838:	e199                	bnez	a1,83e <vprintf+0x28a>
 83a:	ee0713e3          	bnez	a4,720 <vprintf+0x16c>
      } else if(c0 == 'p'){
 83e:	07000713          	li	a4,112
 842:	eee78ce3          	beq	a5,a4,73a <vprintf+0x186>
      } else if(c0 == 'c'){
 846:	06300713          	li	a4,99
 84a:	f2e78ce3          	beq	a5,a4,782 <vprintf+0x1ce>
      } else if(c0 == 's'){
 84e:	07300713          	li	a4,115
 852:	f4e782e3          	beq	a5,a4,796 <vprintf+0x1e2>
      } else if(c0 == '%'){
 856:	02500713          	li	a4,37
 85a:	f6e787e3          	beq	a5,a4,7c8 <vprintf+0x214>
        putc(fd, '%');
 85e:	02500593          	li	a1,37
 862:	855a                	mv	a0,s6
 864:	c95ff0ef          	jal	4f8 <putc>
        putc(fd, c0);
 868:	85a6                	mv	a1,s1
 86a:	855a                	mv	a0,s6
 86c:	c8dff0ef          	jal	4f8 <putc>
      state = 0;
 870:	4981                	li	s3,0
 872:	b359                	j	5f8 <vprintf+0x44>

0000000000000874 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 874:	715d                	addi	sp,sp,-80
 876:	ec06                	sd	ra,24(sp)
 878:	e822                	sd	s0,16(sp)
 87a:	1000                	addi	s0,sp,32
 87c:	e010                	sd	a2,0(s0)
 87e:	e414                	sd	a3,8(s0)
 880:	e818                	sd	a4,16(s0)
 882:	ec1c                	sd	a5,24(s0)
 884:	03043023          	sd	a6,32(s0)
 888:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 88c:	8622                	mv	a2,s0
 88e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 892:	d23ff0ef          	jal	5b4 <vprintf>
}
 896:	60e2                	ld	ra,24(sp)
 898:	6442                	ld	s0,16(sp)
 89a:	6161                	addi	sp,sp,80
 89c:	8082                	ret

000000000000089e <printf>:

void
printf(const char *fmt, ...)
{
 89e:	711d                	addi	sp,sp,-96
 8a0:	ec06                	sd	ra,24(sp)
 8a2:	e822                	sd	s0,16(sp)
 8a4:	1000                	addi	s0,sp,32
 8a6:	e40c                	sd	a1,8(s0)
 8a8:	e810                	sd	a2,16(s0)
 8aa:	ec14                	sd	a3,24(s0)
 8ac:	f018                	sd	a4,32(s0)
 8ae:	f41c                	sd	a5,40(s0)
 8b0:	03043823          	sd	a6,48(s0)
 8b4:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8b8:	00840613          	addi	a2,s0,8
 8bc:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8c0:	85aa                	mv	a1,a0
 8c2:	4505                	li	a0,1
 8c4:	cf1ff0ef          	jal	5b4 <vprintf>
}
 8c8:	60e2                	ld	ra,24(sp)
 8ca:	6442                	ld	s0,16(sp)
 8cc:	6125                	addi	sp,sp,96
 8ce:	8082                	ret

00000000000008d0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8d0:	1141                	addi	sp,sp,-16
 8d2:	e406                	sd	ra,8(sp)
 8d4:	e022                	sd	s0,0(sp)
 8d6:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8d8:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8dc:	00000797          	auipc	a5,0x0
 8e0:	73c7b783          	ld	a5,1852(a5) # 1018 <freep>
 8e4:	a039                	j	8f2 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8e6:	6398                	ld	a4,0(a5)
 8e8:	00e7e463          	bltu	a5,a4,8f0 <free+0x20>
 8ec:	00e6ea63          	bltu	a3,a4,900 <free+0x30>
{
 8f0:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8f2:	fed7fae3          	bgeu	a5,a3,8e6 <free+0x16>
 8f6:	6398                	ld	a4,0(a5)
 8f8:	00e6e463          	bltu	a3,a4,900 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8fc:	fee7eae3          	bltu	a5,a4,8f0 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 900:	ff852583          	lw	a1,-8(a0)
 904:	6390                	ld	a2,0(a5)
 906:	02059813          	slli	a6,a1,0x20
 90a:	01c85713          	srli	a4,a6,0x1c
 90e:	9736                	add	a4,a4,a3
 910:	02e60563          	beq	a2,a4,93a <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 914:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 918:	4790                	lw	a2,8(a5)
 91a:	02061593          	slli	a1,a2,0x20
 91e:	01c5d713          	srli	a4,a1,0x1c
 922:	973e                	add	a4,a4,a5
 924:	02e68263          	beq	a3,a4,948 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 928:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 92a:	00000717          	auipc	a4,0x0
 92e:	6ef73723          	sd	a5,1774(a4) # 1018 <freep>
}
 932:	60a2                	ld	ra,8(sp)
 934:	6402                	ld	s0,0(sp)
 936:	0141                	addi	sp,sp,16
 938:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 93a:	4618                	lw	a4,8(a2)
 93c:	9f2d                	addw	a4,a4,a1
 93e:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 942:	6398                	ld	a4,0(a5)
 944:	6310                	ld	a2,0(a4)
 946:	b7f9                	j	914 <free+0x44>
    p->s.size += bp->s.size;
 948:	ff852703          	lw	a4,-8(a0)
 94c:	9f31                	addw	a4,a4,a2
 94e:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 950:	ff053683          	ld	a3,-16(a0)
 954:	bfd1                	j	928 <free+0x58>

0000000000000956 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 956:	7139                	addi	sp,sp,-64
 958:	fc06                	sd	ra,56(sp)
 95a:	f822                	sd	s0,48(sp)
 95c:	f04a                	sd	s2,32(sp)
 95e:	ec4e                	sd	s3,24(sp)
 960:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 962:	02051993          	slli	s3,a0,0x20
 966:	0209d993          	srli	s3,s3,0x20
 96a:	09bd                	addi	s3,s3,15
 96c:	0049d993          	srli	s3,s3,0x4
 970:	2985                	addiw	s3,s3,1
 972:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 974:	00000517          	auipc	a0,0x0
 978:	6a453503          	ld	a0,1700(a0) # 1018 <freep>
 97c:	c905                	beqz	a0,9ac <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 97e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 980:	4798                	lw	a4,8(a5)
 982:	09377663          	bgeu	a4,s3,a0e <malloc+0xb8>
 986:	f426                	sd	s1,40(sp)
 988:	e852                	sd	s4,16(sp)
 98a:	e456                	sd	s5,8(sp)
 98c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 98e:	8a4e                	mv	s4,s3
 990:	6705                	lui	a4,0x1
 992:	00e9f363          	bgeu	s3,a4,998 <malloc+0x42>
 996:	6a05                	lui	s4,0x1
 998:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 99c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9a0:	00000497          	auipc	s1,0x0
 9a4:	67848493          	addi	s1,s1,1656 # 1018 <freep>
  if(p == SBRK_ERROR)
 9a8:	5afd                	li	s5,-1
 9aa:	a83d                	j	9e8 <malloc+0x92>
 9ac:	f426                	sd	s1,40(sp)
 9ae:	e852                	sd	s4,16(sp)
 9b0:	e456                	sd	s5,8(sp)
 9b2:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9b4:	00000797          	auipc	a5,0x0
 9b8:	66c78793          	addi	a5,a5,1644 # 1020 <base>
 9bc:	00000717          	auipc	a4,0x0
 9c0:	64f73e23          	sd	a5,1628(a4) # 1018 <freep>
 9c4:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9c6:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9ca:	b7d1                	j	98e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9cc:	6398                	ld	a4,0(a5)
 9ce:	e118                	sd	a4,0(a0)
 9d0:	a899                	j	a26 <malloc+0xd0>
  hp->s.size = nu;
 9d2:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9d6:	0541                	addi	a0,a0,16
 9d8:	ef9ff0ef          	jal	8d0 <free>
  return freep;
 9dc:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 9de:	c125                	beqz	a0,a3e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9e0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9e2:	4798                	lw	a4,8(a5)
 9e4:	03277163          	bgeu	a4,s2,a06 <malloc+0xb0>
    if(p == freep)
 9e8:	6098                	ld	a4,0(s1)
 9ea:	853e                	mv	a0,a5
 9ec:	fef71ae3          	bne	a4,a5,9e0 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9f0:	8552                	mv	a0,s4
 9f2:	a2bff0ef          	jal	41c <sbrk>
  if(p == SBRK_ERROR)
 9f6:	fd551ee3          	bne	a0,s5,9d2 <malloc+0x7c>
        return 0;
 9fa:	4501                	li	a0,0
 9fc:	74a2                	ld	s1,40(sp)
 9fe:	6a42                	ld	s4,16(sp)
 a00:	6aa2                	ld	s5,8(sp)
 a02:	6b02                	ld	s6,0(sp)
 a04:	a03d                	j	a32 <malloc+0xdc>
 a06:	74a2                	ld	s1,40(sp)
 a08:	6a42                	ld	s4,16(sp)
 a0a:	6aa2                	ld	s5,8(sp)
 a0c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a0e:	fae90fe3          	beq	s2,a4,9cc <malloc+0x76>
        p->s.size -= nunits;
 a12:	4137073b          	subw	a4,a4,s3
 a16:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a18:	02071693          	slli	a3,a4,0x20
 a1c:	01c6d713          	srli	a4,a3,0x1c
 a20:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a22:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a26:	00000717          	auipc	a4,0x0
 a2a:	5ea73923          	sd	a0,1522(a4) # 1018 <freep>
      return (void*)(p + 1);
 a2e:	01078513          	addi	a0,a5,16
  }
}
 a32:	70e2                	ld	ra,56(sp)
 a34:	7442                	ld	s0,48(sp)
 a36:	7902                	ld	s2,32(sp)
 a38:	69e2                	ld	s3,24(sp)
 a3a:	6121                	addi	sp,sp,64
 a3c:	8082                	ret
 a3e:	74a2                	ld	s1,40(sp)
 a40:	6a42                	ld	s4,16(sp)
 a42:	6aa2                	ld	s5,8(sp)
 a44:	6b02                	ld	s6,0(sp)
 a46:	b7f5                	j	a32 <malloc+0xdc>
