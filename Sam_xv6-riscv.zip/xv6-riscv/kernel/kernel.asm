
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	87010113          	addi	sp,sp,-1936 # 80007870 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddc87>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e2a78793          	addi	a5,a5,-470 # 80000eae <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	1b6020ef          	jal	800022d0 <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	0000f517          	auipc	a0,0xf
    80000196:	6de50513          	addi	a0,a0,1758 # 8000f870 <cons>
    8000019a:	28f000ef          	jal	80000c28 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	0000f497          	auipc	s1,0xf
    800001a2:	6d248493          	addi	s1,s1,1746 # 8000f870 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	0000f917          	auipc	s2,0xf
    800001aa:	76290913          	addi	s2,s2,1890 # 8000f908 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	770010ef          	jal	8000192e <myproc>
    800001c2:	7a7010ef          	jal	80002168 <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	561010ef          	jal	80001f2c <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	0000f717          	auipc	a4,0xf
    800001e2:	69270713          	addi	a4,a4,1682 # 8000f870 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	076020ef          	jal	80002286 <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	0000f517          	auipc	a0,0xf
    8000022c:	64850513          	addi	a0,a0,1608 # 8000f870 <cons>
    80000230:	28d000ef          	jal	80000cbc <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	0000f717          	auipc	a4,0xf
    80000252:	6af72d23          	sw	a5,1722(a4) # 8000f908 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	0000f517          	auipc	a0,0xf
    80000268:	60c50513          	addi	a0,a0,1548 # 8000f870 <cons>
    8000026c:	251000ef          	jal	80000cbc <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	0000f517          	auipc	a0,0xf
    800002bc:	5b850513          	addi	a0,a0,1464 # 8000f870 <cons>
    800002c0:	169000ef          	jal	80000c28 <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	040020ef          	jal	8000231a <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	0000f517          	auipc	a0,0xf
    800002e2:	59250513          	addi	a0,a0,1426 # 8000f870 <cons>
    800002e6:	1d7000ef          	jal	80000cbc <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	0000f717          	auipc	a4,0xf
    80000300:	57470713          	addi	a4,a4,1396 # 8000f870 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	0000f717          	auipc	a4,0xf
    80000326:	54e70713          	addi	a4,a4,1358 # 8000f870 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	0000f717          	auipc	a4,0xf
    80000350:	5bc72703          	lw	a4,1468(a4) # 8000f908 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	0000f717          	auipc	a4,0xf
    80000366:	50e70713          	addi	a4,a4,1294 # 8000f870 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	0000f497          	auipc	s1,0xf
    80000376:	4fe48493          	addi	s1,s1,1278 # 8000f870 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	0000f717          	auipc	a4,0xf
    800003b8:	4bc70713          	addi	a4,a4,1212 # 8000f870 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	0000f717          	auipc	a4,0xf
    800003ce:	54f72323          	sw	a5,1350(a4) # 8000f910 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	0000f797          	auipc	a5,0xf
    800003ec:	48878793          	addi	a5,a5,1160 # 8000f870 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	0000f797          	auipc	a5,0xf
    8000040e:	50c7a123          	sw	a2,1282(a5) # 8000f90c <cons+0x9c>
        wakeup(&cons.r);
    80000412:	0000f517          	auipc	a0,0xf
    80000416:	4f650513          	addi	a0,a0,1270 # 8000f908 <cons+0x98>
    8000041a:	35f010ef          	jal	80001f78 <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00007597          	auipc	a1,0x7
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80007000 <etext>
    80000430:	0000f517          	auipc	a0,0xf
    80000434:	44050513          	addi	a0,a0,1088 # 8000f870 <cons>
    80000438:	766000ef          	jal	80000b9e <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	0001f797          	auipc	a5,0x1f
    80000444:	5a078793          	addi	a5,a5,1440 # 8001f9e0 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007817          	auipc	a6,0x7
    80000482:	29280813          	addi	a6,a6,658 # 80007710 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	32c7a783          	lw	a5,812(a5) # 80007844 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	0000f517          	auipc	a0,0xf
    80000562:	3ba50513          	addi	a0,a0,954 # 8000f918 <pr>
    80000566:	6c2000ef          	jal	80000c28 <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00007c97          	auipc	s9,0x7
    800006d6:	03ec8c93          	addi	s9,s9,62 # 80007710 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00007a17          	auipc	s4,0x7
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80007008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	00007797          	auipc	a5,0x7
    8000075e:	0ea7a783          	lw	a5,234(a5) # 80007844 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
    release(&pr.lock);

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
    release(&pr.lock);
    80000784:	0000f517          	auipc	a0,0xf
    80000788:	19450513          	addi	a0,a0,404 # 8000f918 <pr>
    8000078c:	530000ef          	jal	80000cbc <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	00007797          	auipc	a5,0x7
    80000838:	0097a823          	sw	s1,16(a5) # 80007844 <panicking>
  printf("panic: ");
    8000083c:	00006517          	auipc	a0,0x6
    80000840:	7dc50513          	addi	a0,a0,2012 # 80007018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7d650513          	addi	a0,a0,2006 # 80007020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	00007797          	auipc	a5,0x7
    8000085a:	fe97a523          	sw	s1,-22(a5) # 80007840 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00006597          	auipc	a1,0x6
    8000086c:	7c058593          	addi	a1,a1,1984 # 80007028 <etext+0x28>
    80000870:	0000f517          	auipc	a0,0xf
    80000874:	0a850513          	addi	a0,a0,168 # 8000f918 <pr>
    80000878:	326000ef          	jal	80000b9e <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00006597          	auipc	a1,0x6
    800008c2:	77258593          	addi	a1,a1,1906 # 80007030 <etext+0x30>
    800008c6:	0000f517          	auipc	a0,0xf
    800008ca:	06a50513          	addi	a0,a0,106 # 8000f930 <tx_lock>
    800008ce:	2d0000ef          	jal	80000b9e <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	0000f517          	auipc	a0,0xf
    800008ee:	04650513          	addi	a0,a0,70 # 8000f930 <tx_lock>
    800008f2:	336000ef          	jal	80000c28 <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	00007497          	auipc	s1,0x7
    8000090c:	f4448493          	addi	s1,s1,-188 # 8000784c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	0000f997          	auipc	s3,0xf
    80000914:	02098993          	addi	s3,s3,32 # 8000f930 <tx_lock>
    80000918:	00007917          	auipc	s2,0x7
    8000091c:	f3090913          	addi	s2,s2,-208 # 80007848 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	600010ef          	jal	80001f2c <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	0000f517          	auipc	a0,0xf
    8000095a:	fda50513          	addi	a0,a0,-38 # 8000f930 <tx_lock>
    8000095e:	35e000ef          	jal	80000cbc <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	00007797          	auipc	a5,0x7
    8000097e:	eca7a783          	lw	a5,-310(a5) # 80007844 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	00007797          	auipc	a5,0x7
    80000988:	ebc7a783          	lw	a5,-324(a5) # 80007840 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	00007797          	auipc	a5,0x7
    800009ae:	e9a7a783          	lw	a5,-358(a5) # 80007844 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	226000ef          	jal	80000be4 <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	2a6000ef          	jal	80000c6c <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	0000f517          	auipc	a0,0xf
    80000a0a:	f2a50513          	addi	a0,a0,-214 # 8000f930 <tx_lock>
    80000a0e:	21a000ef          	jal	80000c28 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	0000f517          	auipc	a0,0xf
    80000a24:	f1050513          	addi	a0,a0,-240 # 8000f930 <tx_lock>
    80000a28:	294000ef          	jal	80000cbc <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	00007797          	auipc	a5,0x7
    80000a40:	e007a823          	sw	zero,-496(a5) # 8000784c <tx_busy>
    wakeup(&tx_chan);
    80000a44:	00007517          	auipc	a0,0x7
    80000a48:	e0450513          	addi	a0,a0,-508 # 80007848 <tx_chan>
    80000a4c:	52c010ef          	jal	80001f78 <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	e04a                	sd	s2,0(sp)
    80000a66:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a68:	00020797          	auipc	a5,0x20
    80000a6c:	11078793          	addi	a5,a5,272 # 80020b78 <end>
    80000a70:	00f53733          	sltu	a4,a0,a5
    80000a74:	47c5                	li	a5,17
    80000a76:	07ee                	slli	a5,a5,0x1b
    80000a78:	17fd                	addi	a5,a5,-1
    80000a7a:	00a7b7b3          	sltu	a5,a5,a0
    80000a7e:	8fd9                	or	a5,a5,a4
    80000a80:	ef95                	bnez	a5,80000abc <kfree+0x60>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	03451793          	slli	a5,a0,0x34
    80000a88:	eb95                	bnez	a5,80000abc <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a8a:	6605                	lui	a2,0x1
    80000a8c:	4585                	li	a1,1
    80000a8e:	26a000ef          	jal	80000cf8 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a92:	0000f917          	auipc	s2,0xf
    80000a96:	eb690913          	addi	s2,s2,-330 # 8000f948 <kmem>
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	18c000ef          	jal	80000c28 <acquire>
  r->next = kmem.freelist;
    80000aa0:	01893783          	ld	a5,24(s2)
    80000aa4:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000aa6:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000aaa:	854a                	mv	a0,s2
    80000aac:	210000ef          	jal	80000cbc <release>
}
    80000ab0:	60e2                	ld	ra,24(sp)
    80000ab2:	6442                	ld	s0,16(sp)
    80000ab4:	64a2                	ld	s1,8(sp)
    80000ab6:	6902                	ld	s2,0(sp)
    80000ab8:	6105                	addi	sp,sp,32
    80000aba:	8082                	ret
    panic("kfree");
    80000abc:	00006517          	auipc	a0,0x6
    80000ac0:	57c50513          	addi	a0,a0,1404 # 80007038 <etext+0x38>
    80000ac4:	d61ff0ef          	jal	80000824 <panic>

0000000080000ac8 <freerange>:
{
    80000ac8:	7179                	addi	sp,sp,-48
    80000aca:	f406                	sd	ra,40(sp)
    80000acc:	f022                	sd	s0,32(sp)
    80000ace:	ec26                	sd	s1,24(sp)
    80000ad0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ad2:	6785                	lui	a5,0x1
    80000ad4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad8:	00e504b3          	add	s1,a0,a4
    80000adc:	777d                	lui	a4,0xfffff
    80000ade:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae0:	94be                	add	s1,s1,a5
    80000ae2:	0295e263          	bltu	a1,s1,80000b06 <freerange+0x3e>
    80000ae6:	e84a                	sd	s2,16(sp)
    80000ae8:	e44e                	sd	s3,8(sp)
    80000aea:	e052                	sd	s4,0(sp)
    80000aec:	892e                	mv	s2,a1
    kfree(p);
    80000aee:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af0:	89be                	mv	s3,a5
    kfree(p);
    80000af2:	01448533          	add	a0,s1,s4
    80000af6:	f67ff0ef          	jal	80000a5c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000afa:	94ce                	add	s1,s1,s3
    80000afc:	fe997be3          	bgeu	s2,s1,80000af2 <freerange+0x2a>
    80000b00:	6942                	ld	s2,16(sp)
    80000b02:	69a2                	ld	s3,8(sp)
    80000b04:	6a02                	ld	s4,0(sp)
}
    80000b06:	70a2                	ld	ra,40(sp)
    80000b08:	7402                	ld	s0,32(sp)
    80000b0a:	64e2                	ld	s1,24(sp)
    80000b0c:	6145                	addi	sp,sp,48
    80000b0e:	8082                	ret

0000000080000b10 <kinit>:
{
    80000b10:	1141                	addi	sp,sp,-16
    80000b12:	e406                	sd	ra,8(sp)
    80000b14:	e022                	sd	s0,0(sp)
    80000b16:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b18:	00006597          	auipc	a1,0x6
    80000b1c:	52858593          	addi	a1,a1,1320 # 80007040 <etext+0x40>
    80000b20:	0000f517          	auipc	a0,0xf
    80000b24:	e2850513          	addi	a0,a0,-472 # 8000f948 <kmem>
    80000b28:	076000ef          	jal	80000b9e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00020517          	auipc	a0,0x20
    80000b34:	04850513          	addi	a0,a0,72 # 80020b78 <end>
    80000b38:	f91ff0ef          	jal	80000ac8 <freerange>
}
    80000b3c:	60a2                	ld	ra,8(sp)
    80000b3e:	6402                	ld	s0,0(sp)
    80000b40:	0141                	addi	sp,sp,16
    80000b42:	8082                	ret

0000000080000b44 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b44:	1101                	addi	sp,sp,-32
    80000b46:	ec06                	sd	ra,24(sp)
    80000b48:	e822                	sd	s0,16(sp)
    80000b4a:	e426                	sd	s1,8(sp)
    80000b4c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4e:	0000f517          	auipc	a0,0xf
    80000b52:	dfa50513          	addi	a0,a0,-518 # 8000f948 <kmem>
    80000b56:	0d2000ef          	jal	80000c28 <acquire>
  r = kmem.freelist;
    80000b5a:	0000f497          	auipc	s1,0xf
    80000b5e:	e064b483          	ld	s1,-506(s1) # 8000f960 <kmem+0x18>
  if(r)
    80000b62:	c49d                	beqz	s1,80000b90 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b64:	609c                	ld	a5,0(s1)
    80000b66:	0000f717          	auipc	a4,0xf
    80000b6a:	def73d23          	sd	a5,-518(a4) # 8000f960 <kmem+0x18>
  release(&kmem.lock);
    80000b6e:	0000f517          	auipc	a0,0xf
    80000b72:	dda50513          	addi	a0,a0,-550 # 8000f948 <kmem>
    80000b76:	146000ef          	jal	80000cbc <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	178000ef          	jal	80000cf8 <memset>
  return (void*)r;
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	0000f517          	auipc	a0,0xf
    80000b94:	db850513          	addi	a0,a0,-584 # 8000f948 <kmem>
    80000b98:	124000ef          	jal	80000cbc <release>
  if(r)
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x40>

0000000080000b9e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b9e:	1141                	addi	sp,sp,-16
    80000ba0:	e406                	sd	ra,8(sp)
    80000ba2:	e022                	sd	s0,0(sp)
    80000ba4:	0800                	addi	s0,sp,16
  lk->name = name;
    80000ba6:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000ba8:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bac:	00053823          	sd	zero,16(a0)
}
    80000bb0:	60a2                	ld	ra,8(sp)
    80000bb2:	6402                	ld	s0,0(sp)
    80000bb4:	0141                	addi	sp,sp,16
    80000bb6:	8082                	ret

0000000080000bb8 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bb8:	411c                	lw	a5,0(a0)
    80000bba:	e399                	bnez	a5,80000bc0 <holding+0x8>
    80000bbc:	4501                	li	a0,0
  return r;
}
    80000bbe:	8082                	ret
{
    80000bc0:	1101                	addi	sp,sp,-32
    80000bc2:	ec06                	sd	ra,24(sp)
    80000bc4:	e822                	sd	s0,16(sp)
    80000bc6:	e426                	sd	s1,8(sp)
    80000bc8:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bca:	691c                	ld	a5,16(a0)
    80000bcc:	84be                	mv	s1,a5
    80000bce:	541000ef          	jal	8000190e <mycpu>
    80000bd2:	40a48533          	sub	a0,s1,a0
    80000bd6:	00153513          	seqz	a0,a0
}
    80000bda:	60e2                	ld	ra,24(sp)
    80000bdc:	6442                	ld	s0,16(sp)
    80000bde:	64a2                	ld	s1,8(sp)
    80000be0:	6105                	addi	sp,sp,32
    80000be2:	8082                	ret

0000000080000be4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000be4:	1101                	addi	sp,sp,-32
    80000be6:	ec06                	sd	ra,24(sp)
    80000be8:	e822                	sd	s0,16(sp)
    80000bea:	e426                	sd	s1,8(sp)
    80000bec:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bee:	100027f3          	csrr	a5,sstatus
    80000bf2:	84be                	mv	s1,a5
    80000bf4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bf8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bfa:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000bfe:	511000ef          	jal	8000190e <mycpu>
    80000c02:	5d3c                	lw	a5,120(a0)
    80000c04:	cb99                	beqz	a5,80000c1a <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c06:	509000ef          	jal	8000190e <mycpu>
    80000c0a:	5d3c                	lw	a5,120(a0)
    80000c0c:	2785                	addiw	a5,a5,1
    80000c0e:	dd3c                	sw	a5,120(a0)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    mycpu()->intena = old;
    80000c1a:	4f5000ef          	jal	8000190e <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c1e:	0014d793          	srli	a5,s1,0x1
    80000c22:	8b85                	andi	a5,a5,1
    80000c24:	dd7c                	sw	a5,124(a0)
    80000c26:	b7c5                	j	80000c06 <push_off+0x22>

0000000080000c28 <acquire>:
{
    80000c28:	1101                	addi	sp,sp,-32
    80000c2a:	ec06                	sd	ra,24(sp)
    80000c2c:	e822                	sd	s0,16(sp)
    80000c2e:	e426                	sd	s1,8(sp)
    80000c30:	1000                	addi	s0,sp,32
    80000c32:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c34:	fb1ff0ef          	jal	80000be4 <push_off>
  if(holding(lk))
    80000c38:	8526                	mv	a0,s1
    80000c3a:	f7fff0ef          	jal	80000bb8 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c3e:	4705                	li	a4,1
  if(holding(lk))
    80000c40:	e105                	bnez	a0,80000c60 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c42:	87ba                	mv	a5,a4
    80000c44:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c48:	2781                	sext.w	a5,a5
    80000c4a:	ffe5                	bnez	a5,80000c42 <acquire+0x1a>
  __sync_synchronize();
    80000c4c:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c50:	4bf000ef          	jal	8000190e <mycpu>
    80000c54:	e888                	sd	a0,16(s1)
}
    80000c56:	60e2                	ld	ra,24(sp)
    80000c58:	6442                	ld	s0,16(sp)
    80000c5a:	64a2                	ld	s1,8(sp)
    80000c5c:	6105                	addi	sp,sp,32
    80000c5e:	8082                	ret
    panic("acquire");
    80000c60:	00006517          	auipc	a0,0x6
    80000c64:	3e850513          	addi	a0,a0,1000 # 80007048 <etext+0x48>
    80000c68:	bbdff0ef          	jal	80000824 <panic>

0000000080000c6c <pop_off>:

void
pop_off(void)
{
    80000c6c:	1141                	addi	sp,sp,-16
    80000c6e:	e406                	sd	ra,8(sp)
    80000c70:	e022                	sd	s0,0(sp)
    80000c72:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c74:	49b000ef          	jal	8000190e <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c7c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c7e:	e39d                	bnez	a5,80000ca4 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c80:	5d3c                	lw	a5,120(a0)
    80000c82:	02f05763          	blez	a5,80000cb0 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000c86:	37fd                	addiw	a5,a5,-1
    80000c88:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c8a:	eb89                	bnez	a5,80000c9c <pop_off+0x30>
    80000c8c:	5d7c                	lw	a5,124(a0)
    80000c8e:	c799                	beqz	a5,80000c9c <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c90:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c94:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c98:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c9c:	60a2                	ld	ra,8(sp)
    80000c9e:	6402                	ld	s0,0(sp)
    80000ca0:	0141                	addi	sp,sp,16
    80000ca2:	8082                	ret
    panic("pop_off - interruptible");
    80000ca4:	00006517          	auipc	a0,0x6
    80000ca8:	3ac50513          	addi	a0,a0,940 # 80007050 <etext+0x50>
    80000cac:	b79ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000cb0:	00006517          	auipc	a0,0x6
    80000cb4:	3b850513          	addi	a0,a0,952 # 80007068 <etext+0x68>
    80000cb8:	b6dff0ef          	jal	80000824 <panic>

0000000080000cbc <release>:
{
    80000cbc:	1101                	addi	sp,sp,-32
    80000cbe:	ec06                	sd	ra,24(sp)
    80000cc0:	e822                	sd	s0,16(sp)
    80000cc2:	e426                	sd	s1,8(sp)
    80000cc4:	1000                	addi	s0,sp,32
    80000cc6:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cc8:	ef1ff0ef          	jal	80000bb8 <holding>
    80000ccc:	c105                	beqz	a0,80000cec <release+0x30>
  lk->cpu = 0;
    80000cce:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cd2:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000cd6:	0310000f          	fence	rw,w
    80000cda:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cde:	f8fff0ef          	jal	80000c6c <pop_off>
}
    80000ce2:	60e2                	ld	ra,24(sp)
    80000ce4:	6442                	ld	s0,16(sp)
    80000ce6:	64a2                	ld	s1,8(sp)
    80000ce8:	6105                	addi	sp,sp,32
    80000cea:	8082                	ret
    panic("release");
    80000cec:	00006517          	auipc	a0,0x6
    80000cf0:	38450513          	addi	a0,a0,900 # 80007070 <etext+0x70>
    80000cf4:	b31ff0ef          	jal	80000824 <panic>

0000000080000cf8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cf8:	1141                	addi	sp,sp,-16
    80000cfa:	e406                	sd	ra,8(sp)
    80000cfc:	e022                	sd	s0,0(sp)
    80000cfe:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d00:	ca19                	beqz	a2,80000d16 <memset+0x1e>
    80000d02:	87aa                	mv	a5,a0
    80000d04:	1602                	slli	a2,a2,0x20
    80000d06:	9201                	srli	a2,a2,0x20
    80000d08:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d0c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d10:	0785                	addi	a5,a5,1
    80000d12:	fee79de3          	bne	a5,a4,80000d0c <memset+0x14>
  }
  return dst;
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret

0000000080000d1e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e406                	sd	ra,8(sp)
    80000d22:	e022                	sd	s0,0(sp)
    80000d24:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d26:	c61d                	beqz	a2,80000d54 <memcmp+0x36>
    80000d28:	1602                	slli	a2,a2,0x20
    80000d2a:	9201                	srli	a2,a2,0x20
    80000d2c:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d30:	00054783          	lbu	a5,0(a0)
    80000d34:	0005c703          	lbu	a4,0(a1)
    80000d38:	00e79863          	bne	a5,a4,80000d48 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d3c:	0505                	addi	a0,a0,1
    80000d3e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d40:	fed518e3          	bne	a0,a3,80000d30 <memcmp+0x12>
  }

  return 0;
    80000d44:	4501                	li	a0,0
    80000d46:	a019                	j	80000d4c <memcmp+0x2e>
      return *s1 - *s2;
    80000d48:	40e7853b          	subw	a0,a5,a4
}
    80000d4c:	60a2                	ld	ra,8(sp)
    80000d4e:	6402                	ld	s0,0(sp)
    80000d50:	0141                	addi	sp,sp,16
    80000d52:	8082                	ret
  return 0;
    80000d54:	4501                	li	a0,0
    80000d56:	bfdd                	j	80000d4c <memcmp+0x2e>

0000000080000d58 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d58:	1141                	addi	sp,sp,-16
    80000d5a:	e406                	sd	ra,8(sp)
    80000d5c:	e022                	sd	s0,0(sp)
    80000d5e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d60:	c205                	beqz	a2,80000d80 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d62:	02a5e363          	bltu	a1,a0,80000d88 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d66:	1602                	slli	a2,a2,0x20
    80000d68:	9201                	srli	a2,a2,0x20
    80000d6a:	00c587b3          	add	a5,a1,a2
{
    80000d6e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	0705                	addi	a4,a4,1
    80000d74:	fff5c683          	lbu	a3,-1(a1)
    80000d78:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d7c:	feb79ae3          	bne	a5,a1,80000d70 <memmove+0x18>

  return dst;
}
    80000d80:	60a2                	ld	ra,8(sp)
    80000d82:	6402                	ld	s0,0(sp)
    80000d84:	0141                	addi	sp,sp,16
    80000d86:	8082                	ret
  if(s < d && s + n > d){
    80000d88:	02061693          	slli	a3,a2,0x20
    80000d8c:	9281                	srli	a3,a3,0x20
    80000d8e:	00d58733          	add	a4,a1,a3
    80000d92:	fce57ae3          	bgeu	a0,a4,80000d66 <memmove+0xe>
    d += n;
    80000d96:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d98:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d9c:	1782                	slli	a5,a5,0x20
    80000d9e:	9381                	srli	a5,a5,0x20
    80000da0:	fff7c793          	not	a5,a5
    80000da4:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000da6:	177d                	addi	a4,a4,-1
    80000da8:	16fd                	addi	a3,a3,-1
    80000daa:	00074603          	lbu	a2,0(a4)
    80000dae:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000db2:	fee79ae3          	bne	a5,a4,80000da6 <memmove+0x4e>
    80000db6:	b7e9                	j	80000d80 <memmove+0x28>

0000000080000db8 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000db8:	1141                	addi	sp,sp,-16
    80000dba:	e406                	sd	ra,8(sp)
    80000dbc:	e022                	sd	s0,0(sp)
    80000dbe:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dc0:	f99ff0ef          	jal	80000d58 <memmove>
}
    80000dc4:	60a2                	ld	ra,8(sp)
    80000dc6:	6402                	ld	s0,0(sp)
    80000dc8:	0141                	addi	sp,sp,16
    80000dca:	8082                	ret

0000000080000dcc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000dcc:	1141                	addi	sp,sp,-16
    80000dce:	e406                	sd	ra,8(sp)
    80000dd0:	e022                	sd	s0,0(sp)
    80000dd2:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dd4:	ce11                	beqz	a2,80000df0 <strncmp+0x24>
    80000dd6:	00054783          	lbu	a5,0(a0)
    80000dda:	cf89                	beqz	a5,80000df4 <strncmp+0x28>
    80000ddc:	0005c703          	lbu	a4,0(a1)
    80000de0:	00f71a63          	bne	a4,a5,80000df4 <strncmp+0x28>
    n--, p++, q++;
    80000de4:	367d                	addiw	a2,a2,-1
    80000de6:	0505                	addi	a0,a0,1
    80000de8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dea:	f675                	bnez	a2,80000dd6 <strncmp+0xa>
  if(n == 0)
    return 0;
    80000dec:	4501                	li	a0,0
    80000dee:	a801                	j	80000dfe <strncmp+0x32>
    80000df0:	4501                	li	a0,0
    80000df2:	a031                	j	80000dfe <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000df4:	00054503          	lbu	a0,0(a0)
    80000df8:	0005c783          	lbu	a5,0(a1)
    80000dfc:	9d1d                	subw	a0,a0,a5
}
    80000dfe:	60a2                	ld	ra,8(sp)
    80000e00:	6402                	ld	s0,0(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e406                	sd	ra,8(sp)
    80000e0a:	e022                	sd	s0,0(sp)
    80000e0c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e0e:	87aa                	mv	a5,a0
    80000e10:	a011                	j	80000e14 <strncpy+0xe>
    80000e12:	8636                	mv	a2,a3
    80000e14:	02c05863          	blez	a2,80000e44 <strncpy+0x3e>
    80000e18:	fff6069b          	addiw	a3,a2,-1
    80000e1c:	8836                	mv	a6,a3
    80000e1e:	0785                	addi	a5,a5,1
    80000e20:	0005c703          	lbu	a4,0(a1)
    80000e24:	fee78fa3          	sb	a4,-1(a5)
    80000e28:	0585                	addi	a1,a1,1
    80000e2a:	f765                	bnez	a4,80000e12 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e2c:	873e                	mv	a4,a5
    80000e2e:	01005b63          	blez	a6,80000e44 <strncpy+0x3e>
    80000e32:	9fb1                	addw	a5,a5,a2
    80000e34:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e36:	0705                	addi	a4,a4,1
    80000e38:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e3c:	40e786bb          	subw	a3,a5,a4
    80000e40:	fed04be3          	bgtz	a3,80000e36 <strncpy+0x30>
  return os;
}
    80000e44:	60a2                	ld	ra,8(sp)
    80000e46:	6402                	ld	s0,0(sp)
    80000e48:	0141                	addi	sp,sp,16
    80000e4a:	8082                	ret

0000000080000e4c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e4c:	1141                	addi	sp,sp,-16
    80000e4e:	e406                	sd	ra,8(sp)
    80000e50:	e022                	sd	s0,0(sp)
    80000e52:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e54:	02c05363          	blez	a2,80000e7a <safestrcpy+0x2e>
    80000e58:	fff6069b          	addiw	a3,a2,-1
    80000e5c:	1682                	slli	a3,a3,0x20
    80000e5e:	9281                	srli	a3,a3,0x20
    80000e60:	96ae                	add	a3,a3,a1
    80000e62:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e64:	00d58963          	beq	a1,a3,80000e76 <safestrcpy+0x2a>
    80000e68:	0585                	addi	a1,a1,1
    80000e6a:	0785                	addi	a5,a5,1
    80000e6c:	fff5c703          	lbu	a4,-1(a1)
    80000e70:	fee78fa3          	sb	a4,-1(a5)
    80000e74:	fb65                	bnez	a4,80000e64 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e76:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e7a:	60a2                	ld	ra,8(sp)
    80000e7c:	6402                	ld	s0,0(sp)
    80000e7e:	0141                	addi	sp,sp,16
    80000e80:	8082                	ret

0000000080000e82 <strlen>:

int
strlen(const char *s)
{
    80000e82:	1141                	addi	sp,sp,-16
    80000e84:	e406                	sd	ra,8(sp)
    80000e86:	e022                	sd	s0,0(sp)
    80000e88:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e8a:	00054783          	lbu	a5,0(a0)
    80000e8e:	cf91                	beqz	a5,80000eaa <strlen+0x28>
    80000e90:	00150793          	addi	a5,a0,1
    80000e94:	86be                	mv	a3,a5
    80000e96:	0785                	addi	a5,a5,1
    80000e98:	fff7c703          	lbu	a4,-1(a5)
    80000e9c:	ff65                	bnez	a4,80000e94 <strlen+0x12>
    80000e9e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ea2:	60a2                	ld	ra,8(sp)
    80000ea4:	6402                	ld	s0,0(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret
  for(n = 0; s[n]; n++)
    80000eaa:	4501                	li	a0,0
    80000eac:	bfdd                	j	80000ea2 <strlen+0x20>

0000000080000eae <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000eae:	1141                	addi	sp,sp,-16
    80000eb0:	e406                	sd	ra,8(sp)
    80000eb2:	e022                	sd	s0,0(sp)
    80000eb4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000eb6:	245000ef          	jal	800018fa <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000eba:	00007717          	auipc	a4,0x7
    80000ebe:	99670713          	addi	a4,a4,-1642 # 80007850 <started>
  if(cpuid() == 0){
    80000ec2:	c51d                	beqz	a0,80000ef0 <main+0x42>
    while(started == 0)
    80000ec4:	431c                	lw	a5,0(a4)
    80000ec6:	2781                	sext.w	a5,a5
    80000ec8:	dff5                	beqz	a5,80000ec4 <main+0x16>
      ;
    __sync_synchronize();
    80000eca:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ece:	22d000ef          	jal	800018fa <cpuid>
    80000ed2:	85aa                	mv	a1,a0
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	1c450513          	addi	a0,a0,452 # 80007098 <etext+0x98>
    80000edc:	e1eff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000ee0:	080000ef          	jal	80000f60 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ee4:	5d6010ef          	jal	800024ba <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ee8:	600040ef          	jal	800054e8 <plicinithart>
  }

  scheduler();        
    80000eec:	6a7000ef          	jal	80001d92 <scheduler>
    consoleinit();
    80000ef0:	d30ff0ef          	jal	80000420 <consoleinit>
    printfinit();
    80000ef4:	96dff0ef          	jal	80000860 <printfinit>
    printf("\n");
    80000ef8:	00006517          	auipc	a0,0x6
    80000efc:	18050513          	addi	a0,a0,384 # 80007078 <etext+0x78>
    80000f00:	dfaff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000f04:	00006517          	auipc	a0,0x6
    80000f08:	17c50513          	addi	a0,a0,380 # 80007080 <etext+0x80>
    80000f0c:	deeff0ef          	jal	800004fa <printf>
    printf("\n");
    80000f10:	00006517          	auipc	a0,0x6
    80000f14:	16850513          	addi	a0,a0,360 # 80007078 <etext+0x78>
    80000f18:	de2ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000f1c:	bf5ff0ef          	jal	80000b10 <kinit>
    kvminit();       // create kernel page table
    80000f20:	2cc000ef          	jal	800011ec <kvminit>
    kvminithart();   // turn on paging
    80000f24:	03c000ef          	jal	80000f60 <kvminithart>
    procinit();      // process table
    80000f28:	11d000ef          	jal	80001844 <procinit>
    trapinit();      // trap vectors
    80000f2c:	56a010ef          	jal	80002496 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f30:	58a010ef          	jal	800024ba <trapinithart>
    plicinit();      // set up interrupt controller
    80000f34:	59a040ef          	jal	800054ce <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f38:	5b0040ef          	jal	800054e8 <plicinithart>
    binit();         // buffer cache
    80000f3c:	427010ef          	jal	80002b62 <binit>
    iinit();         // inode table
    80000f40:	178020ef          	jal	800030b8 <iinit>
    fileinit();      // file table
    80000f44:	0a4030ef          	jal	80003fe8 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f48:	690040ef          	jal	800055d8 <virtio_disk_init>
    userinit();      // first user process
    80000f4c:	4ad000ef          	jal	80001bf8 <userinit>
    __sync_synchronize();
    80000f50:	0330000f          	fence	rw,rw
    started = 1;
    80000f54:	4785                	li	a5,1
    80000f56:	00007717          	auipc	a4,0x7
    80000f5a:	8ef72d23          	sw	a5,-1798(a4) # 80007850 <started>
    80000f5e:	b779                	j	80000eec <main+0x3e>

0000000080000f60 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f60:	1141                	addi	sp,sp,-16
    80000f62:	e406                	sd	ra,8(sp)
    80000f64:	e022                	sd	s0,0(sp)
    80000f66:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f68:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f6c:	00007797          	auipc	a5,0x7
    80000f70:	8ec7b783          	ld	a5,-1812(a5) # 80007858 <kernel_pagetable>
    80000f74:	83b1                	srli	a5,a5,0xc
    80000f76:	577d                	li	a4,-1
    80000f78:	177e                	slli	a4,a4,0x3f
    80000f7a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f7c:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f80:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f84:	60a2                	ld	ra,8(sp)
    80000f86:	6402                	ld	s0,0(sp)
    80000f88:	0141                	addi	sp,sp,16
    80000f8a:	8082                	ret

0000000080000f8c <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f8c:	7139                	addi	sp,sp,-64
    80000f8e:	fc06                	sd	ra,56(sp)
    80000f90:	f822                	sd	s0,48(sp)
    80000f92:	f426                	sd	s1,40(sp)
    80000f94:	f04a                	sd	s2,32(sp)
    80000f96:	ec4e                	sd	s3,24(sp)
    80000f98:	e852                	sd	s4,16(sp)
    80000f9a:	e456                	sd	s5,8(sp)
    80000f9c:	e05a                	sd	s6,0(sp)
    80000f9e:	0080                	addi	s0,sp,64
    80000fa0:	84aa                	mv	s1,a0
    80000fa2:	89ae                	mv	s3,a1
    80000fa4:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fa6:	57fd                	li	a5,-1
    80000fa8:	83e9                	srli	a5,a5,0x1a
    80000faa:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fac:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fae:	04b7e263          	bltu	a5,a1,80000ff2 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fb2:	0149d933          	srl	s2,s3,s4
    80000fb6:	1ff97913          	andi	s2,s2,511
    80000fba:	090e                	slli	s2,s2,0x3
    80000fbc:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fbe:	00093483          	ld	s1,0(s2)
    80000fc2:	0014f793          	andi	a5,s1,1
    80000fc6:	cf85                	beqz	a5,80000ffe <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fc8:	80a9                	srli	s1,s1,0xa
    80000fca:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000fcc:	3a5d                	addiw	s4,s4,-9
    80000fce:	ff5a12e3          	bne	s4,s5,80000fb2 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000fd2:	00c9d513          	srli	a0,s3,0xc
    80000fd6:	1ff57513          	andi	a0,a0,511
    80000fda:	050e                	slli	a0,a0,0x3
    80000fdc:	9526                	add	a0,a0,s1
}
    80000fde:	70e2                	ld	ra,56(sp)
    80000fe0:	7442                	ld	s0,48(sp)
    80000fe2:	74a2                	ld	s1,40(sp)
    80000fe4:	7902                	ld	s2,32(sp)
    80000fe6:	69e2                	ld	s3,24(sp)
    80000fe8:	6a42                	ld	s4,16(sp)
    80000fea:	6aa2                	ld	s5,8(sp)
    80000fec:	6b02                	ld	s6,0(sp)
    80000fee:	6121                	addi	sp,sp,64
    80000ff0:	8082                	ret
    panic("walk");
    80000ff2:	00006517          	auipc	a0,0x6
    80000ff6:	0be50513          	addi	a0,a0,190 # 800070b0 <etext+0xb0>
    80000ffa:	82bff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000ffe:	020b0263          	beqz	s6,80001022 <walk+0x96>
    80001002:	b43ff0ef          	jal	80000b44 <kalloc>
    80001006:	84aa                	mv	s1,a0
    80001008:	d979                	beqz	a0,80000fde <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    8000100a:	6605                	lui	a2,0x1
    8000100c:	4581                	li	a1,0
    8000100e:	cebff0ef          	jal	80000cf8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001012:	00c4d793          	srli	a5,s1,0xc
    80001016:	07aa                	slli	a5,a5,0xa
    80001018:	0017e793          	ori	a5,a5,1
    8000101c:	00f93023          	sd	a5,0(s2)
    80001020:	b775                	j	80000fcc <walk+0x40>
        return 0;
    80001022:	4501                	li	a0,0
    80001024:	bf6d                	j	80000fde <walk+0x52>

0000000080001026 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001026:	57fd                	li	a5,-1
    80001028:	83e9                	srli	a5,a5,0x1a
    8000102a:	00b7f463          	bgeu	a5,a1,80001032 <walkaddr+0xc>
    return 0;
    8000102e:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001030:	8082                	ret
{
    80001032:	1141                	addi	sp,sp,-16
    80001034:	e406                	sd	ra,8(sp)
    80001036:	e022                	sd	s0,0(sp)
    80001038:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000103a:	4601                	li	a2,0
    8000103c:	f51ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    80001040:	c901                	beqz	a0,80001050 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    80001042:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001044:	0117f693          	andi	a3,a5,17
    80001048:	4745                	li	a4,17
    return 0;
    8000104a:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    8000104c:	00e68663          	beq	a3,a4,80001058 <walkaddr+0x32>
}
    80001050:	60a2                	ld	ra,8(sp)
    80001052:	6402                	ld	s0,0(sp)
    80001054:	0141                	addi	sp,sp,16
    80001056:	8082                	ret
  pa = PTE2PA(*pte);
    80001058:	83a9                	srli	a5,a5,0xa
    8000105a:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000105e:	bfcd                	j	80001050 <walkaddr+0x2a>

0000000080001060 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001060:	715d                	addi	sp,sp,-80
    80001062:	e486                	sd	ra,72(sp)
    80001064:	e0a2                	sd	s0,64(sp)
    80001066:	fc26                	sd	s1,56(sp)
    80001068:	f84a                	sd	s2,48(sp)
    8000106a:	f44e                	sd	s3,40(sp)
    8000106c:	f052                	sd	s4,32(sp)
    8000106e:	ec56                	sd	s5,24(sp)
    80001070:	e85a                	sd	s6,16(sp)
    80001072:	e45e                	sd	s7,8(sp)
    80001074:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001076:	03459793          	slli	a5,a1,0x34
    8000107a:	eba1                	bnez	a5,800010ca <mappages+0x6a>
    8000107c:	8a2a                	mv	s4,a0
    8000107e:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001080:	03461793          	slli	a5,a2,0x34
    80001084:	eba9                	bnez	a5,800010d6 <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    80001086:	ce31                	beqz	a2,800010e2 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001088:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    8000108c:	80060613          	addi	a2,a2,-2048
    80001090:	00b60933          	add	s2,a2,a1
  a = va;
    80001094:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    80001096:	4b05                	li	s6,1
    80001098:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000109c:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    8000109e:	865a                	mv	a2,s6
    800010a0:	85a6                	mv	a1,s1
    800010a2:	8552                	mv	a0,s4
    800010a4:	ee9ff0ef          	jal	80000f8c <walk>
    800010a8:	c929                	beqz	a0,800010fa <mappages+0x9a>
    if(*pte & PTE_V)
    800010aa:	611c                	ld	a5,0(a0)
    800010ac:	8b85                	andi	a5,a5,1
    800010ae:	e3a1                	bnez	a5,800010ee <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010b0:	013487b3          	add	a5,s1,s3
    800010b4:	83b1                	srli	a5,a5,0xc
    800010b6:	07aa                	slli	a5,a5,0xa
    800010b8:	0157e7b3          	or	a5,a5,s5
    800010bc:	0017e793          	ori	a5,a5,1
    800010c0:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010c2:	05248863          	beq	s1,s2,80001112 <mappages+0xb2>
    a += PGSIZE;
    800010c6:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c8:	bfd9                	j	8000109e <mappages+0x3e>
    panic("mappages: va not aligned");
    800010ca:	00006517          	auipc	a0,0x6
    800010ce:	fee50513          	addi	a0,a0,-18 # 800070b8 <etext+0xb8>
    800010d2:	f52ff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    800010d6:	00006517          	auipc	a0,0x6
    800010da:	00250513          	addi	a0,a0,2 # 800070d8 <etext+0xd8>
    800010de:	f46ff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    800010e2:	00006517          	auipc	a0,0x6
    800010e6:	01650513          	addi	a0,a0,22 # 800070f8 <etext+0xf8>
    800010ea:	f3aff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    800010ee:	00006517          	auipc	a0,0x6
    800010f2:	01a50513          	addi	a0,a0,26 # 80007108 <etext+0x108>
    800010f6:	f2eff0ef          	jal	80000824 <panic>
      return -1;
    800010fa:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010fc:	60a6                	ld	ra,72(sp)
    800010fe:	6406                	ld	s0,64(sp)
    80001100:	74e2                	ld	s1,56(sp)
    80001102:	7942                	ld	s2,48(sp)
    80001104:	79a2                	ld	s3,40(sp)
    80001106:	7a02                	ld	s4,32(sp)
    80001108:	6ae2                	ld	s5,24(sp)
    8000110a:	6b42                	ld	s6,16(sp)
    8000110c:	6ba2                	ld	s7,8(sp)
    8000110e:	6161                	addi	sp,sp,80
    80001110:	8082                	ret
  return 0;
    80001112:	4501                	li	a0,0
    80001114:	b7e5                	j	800010fc <mappages+0x9c>

0000000080001116 <kvmmap>:
{
    80001116:	1141                	addi	sp,sp,-16
    80001118:	e406                	sd	ra,8(sp)
    8000111a:	e022                	sd	s0,0(sp)
    8000111c:	0800                	addi	s0,sp,16
    8000111e:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001120:	86b2                	mv	a3,a2
    80001122:	863e                	mv	a2,a5
    80001124:	f3dff0ef          	jal	80001060 <mappages>
    80001128:	e509                	bnez	a0,80001132 <kvmmap+0x1c>
}
    8000112a:	60a2                	ld	ra,8(sp)
    8000112c:	6402                	ld	s0,0(sp)
    8000112e:	0141                	addi	sp,sp,16
    80001130:	8082                	ret
    panic("kvmmap");
    80001132:	00006517          	auipc	a0,0x6
    80001136:	fe650513          	addi	a0,a0,-26 # 80007118 <etext+0x118>
    8000113a:	eeaff0ef          	jal	80000824 <panic>

000000008000113e <kvmmake>:
{
    8000113e:	1101                	addi	sp,sp,-32
    80001140:	ec06                	sd	ra,24(sp)
    80001142:	e822                	sd	s0,16(sp)
    80001144:	e426                	sd	s1,8(sp)
    80001146:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001148:	9fdff0ef          	jal	80000b44 <kalloc>
    8000114c:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000114e:	6605                	lui	a2,0x1
    80001150:	4581                	li	a1,0
    80001152:	ba7ff0ef          	jal	80000cf8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001156:	4719                	li	a4,6
    80001158:	6685                	lui	a3,0x1
    8000115a:	10000637          	lui	a2,0x10000
    8000115e:	85b2                	mv	a1,a2
    80001160:	8526                	mv	a0,s1
    80001162:	fb5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001166:	4719                	li	a4,6
    80001168:	6685                	lui	a3,0x1
    8000116a:	10001637          	lui	a2,0x10001
    8000116e:	85b2                	mv	a1,a2
    80001170:	8526                	mv	a0,s1
    80001172:	fa5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001176:	4719                	li	a4,6
    80001178:	040006b7          	lui	a3,0x4000
    8000117c:	0c000637          	lui	a2,0xc000
    80001180:	85b2                	mv	a1,a2
    80001182:	8526                	mv	a0,s1
    80001184:	f93ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001188:	4729                	li	a4,10
    8000118a:	80006697          	auipc	a3,0x80006
    8000118e:	e7668693          	addi	a3,a3,-394 # 7000 <_entry-0x7fff9000>
    80001192:	4605                	li	a2,1
    80001194:	067e                	slli	a2,a2,0x1f
    80001196:	85b2                	mv	a1,a2
    80001198:	8526                	mv	a0,s1
    8000119a:	f7dff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000119e:	4719                	li	a4,6
    800011a0:	00006697          	auipc	a3,0x6
    800011a4:	e6068693          	addi	a3,a3,-416 # 80007000 <etext>
    800011a8:	47c5                	li	a5,17
    800011aa:	07ee                	slli	a5,a5,0x1b
    800011ac:	40d786b3          	sub	a3,a5,a3
    800011b0:	00006617          	auipc	a2,0x6
    800011b4:	e5060613          	addi	a2,a2,-432 # 80007000 <etext>
    800011b8:	85b2                	mv	a1,a2
    800011ba:	8526                	mv	a0,s1
    800011bc:	f5bff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011c0:	4729                	li	a4,10
    800011c2:	6685                	lui	a3,0x1
    800011c4:	00005617          	auipc	a2,0x5
    800011c8:	e3c60613          	addi	a2,a2,-452 # 80006000 <_trampoline>
    800011cc:	040005b7          	lui	a1,0x4000
    800011d0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011d2:	05b2                	slli	a1,a1,0xc
    800011d4:	8526                	mv	a0,s1
    800011d6:	f41ff0ef          	jal	80001116 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011da:	8526                	mv	a0,s1
    800011dc:	5c4000ef          	jal	800017a0 <proc_mapstacks>
}
    800011e0:	8526                	mv	a0,s1
    800011e2:	60e2                	ld	ra,24(sp)
    800011e4:	6442                	ld	s0,16(sp)
    800011e6:	64a2                	ld	s1,8(sp)
    800011e8:	6105                	addi	sp,sp,32
    800011ea:	8082                	ret

00000000800011ec <kvminit>:
{
    800011ec:	1141                	addi	sp,sp,-16
    800011ee:	e406                	sd	ra,8(sp)
    800011f0:	e022                	sd	s0,0(sp)
    800011f2:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011f4:	f4bff0ef          	jal	8000113e <kvmmake>
    800011f8:	00006797          	auipc	a5,0x6
    800011fc:	66a7b023          	sd	a0,1632(a5) # 80007858 <kernel_pagetable>
}
    80001200:	60a2                	ld	ra,8(sp)
    80001202:	6402                	ld	s0,0(sp)
    80001204:	0141                	addi	sp,sp,16
    80001206:	8082                	ret

0000000080001208 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001208:	1101                	addi	sp,sp,-32
    8000120a:	ec06                	sd	ra,24(sp)
    8000120c:	e822                	sd	s0,16(sp)
    8000120e:	e426                	sd	s1,8(sp)
    80001210:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001212:	933ff0ef          	jal	80000b44 <kalloc>
    80001216:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001218:	c509                	beqz	a0,80001222 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000121a:	6605                	lui	a2,0x1
    8000121c:	4581                	li	a1,0
    8000121e:	adbff0ef          	jal	80000cf8 <memset>
  return pagetable;
}
    80001222:	8526                	mv	a0,s1
    80001224:	60e2                	ld	ra,24(sp)
    80001226:	6442                	ld	s0,16(sp)
    80001228:	64a2                	ld	s1,8(sp)
    8000122a:	6105                	addi	sp,sp,32
    8000122c:	8082                	ret

000000008000122e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000122e:	7139                	addi	sp,sp,-64
    80001230:	fc06                	sd	ra,56(sp)
    80001232:	f822                	sd	s0,48(sp)
    80001234:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001236:	03459793          	slli	a5,a1,0x34
    8000123a:	e38d                	bnez	a5,8000125c <uvmunmap+0x2e>
    8000123c:	f04a                	sd	s2,32(sp)
    8000123e:	ec4e                	sd	s3,24(sp)
    80001240:	e852                	sd	s4,16(sp)
    80001242:	e456                	sd	s5,8(sp)
    80001244:	e05a                	sd	s6,0(sp)
    80001246:	8a2a                	mv	s4,a0
    80001248:	892e                	mv	s2,a1
    8000124a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000124c:	0632                	slli	a2,a2,0xc
    8000124e:	00b609b3          	add	s3,a2,a1
    80001252:	6b05                	lui	s6,0x1
    80001254:	0535f963          	bgeu	a1,s3,800012a6 <uvmunmap+0x78>
    80001258:	f426                	sd	s1,40(sp)
    8000125a:	a015                	j	8000127e <uvmunmap+0x50>
    8000125c:	f426                	sd	s1,40(sp)
    8000125e:	f04a                	sd	s2,32(sp)
    80001260:	ec4e                	sd	s3,24(sp)
    80001262:	e852                	sd	s4,16(sp)
    80001264:	e456                	sd	s5,8(sp)
    80001266:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001268:	00006517          	auipc	a0,0x6
    8000126c:	eb850513          	addi	a0,a0,-328 # 80007120 <etext+0x120>
    80001270:	db4ff0ef          	jal	80000824 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001274:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001278:	995a                	add	s2,s2,s6
    8000127a:	03397563          	bgeu	s2,s3,800012a4 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000127e:	4601                	li	a2,0
    80001280:	85ca                	mv	a1,s2
    80001282:	8552                	mv	a0,s4
    80001284:	d09ff0ef          	jal	80000f8c <walk>
    80001288:	84aa                	mv	s1,a0
    8000128a:	d57d                	beqz	a0,80001278 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    8000128c:	611c                	ld	a5,0(a0)
    8000128e:	0017f713          	andi	a4,a5,1
    80001292:	d37d                	beqz	a4,80001278 <uvmunmap+0x4a>
    if(do_free){
    80001294:	fe0a80e3          	beqz	s5,80001274 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001298:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    8000129a:	00c79513          	slli	a0,a5,0xc
    8000129e:	fbeff0ef          	jal	80000a5c <kfree>
    800012a2:	bfc9                	j	80001274 <uvmunmap+0x46>
    800012a4:	74a2                	ld	s1,40(sp)
    800012a6:	7902                	ld	s2,32(sp)
    800012a8:	69e2                	ld	s3,24(sp)
    800012aa:	6a42                	ld	s4,16(sp)
    800012ac:	6aa2                	ld	s5,8(sp)
    800012ae:	6b02                	ld	s6,0(sp)
  }
}
    800012b0:	70e2                	ld	ra,56(sp)
    800012b2:	7442                	ld	s0,48(sp)
    800012b4:	6121                	addi	sp,sp,64
    800012b6:	8082                	ret

00000000800012b8 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012b8:	1101                	addi	sp,sp,-32
    800012ba:	ec06                	sd	ra,24(sp)
    800012bc:	e822                	sd	s0,16(sp)
    800012be:	e426                	sd	s1,8(sp)
    800012c0:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800012c2:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800012c4:	00b67d63          	bgeu	a2,a1,800012de <uvmdealloc+0x26>
    800012c8:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800012ca:	6785                	lui	a5,0x1
    800012cc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012ce:	00f60733          	add	a4,a2,a5
    800012d2:	76fd                	lui	a3,0xfffff
    800012d4:	8f75                	and	a4,a4,a3
    800012d6:	97ae                	add	a5,a5,a1
    800012d8:	8ff5                	and	a5,a5,a3
    800012da:	00f76863          	bltu	a4,a5,800012ea <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012de:	8526                	mv	a0,s1
    800012e0:	60e2                	ld	ra,24(sp)
    800012e2:	6442                	ld	s0,16(sp)
    800012e4:	64a2                	ld	s1,8(sp)
    800012e6:	6105                	addi	sp,sp,32
    800012e8:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012ea:	8f99                	sub	a5,a5,a4
    800012ec:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012ee:	4685                	li	a3,1
    800012f0:	0007861b          	sext.w	a2,a5
    800012f4:	85ba                	mv	a1,a4
    800012f6:	f39ff0ef          	jal	8000122e <uvmunmap>
    800012fa:	b7d5                	j	800012de <uvmdealloc+0x26>

00000000800012fc <uvmalloc>:
  if(newsz < oldsz)
    800012fc:	0ab66163          	bltu	a2,a1,8000139e <uvmalloc+0xa2>
{
    80001300:	715d                	addi	sp,sp,-80
    80001302:	e486                	sd	ra,72(sp)
    80001304:	e0a2                	sd	s0,64(sp)
    80001306:	f84a                	sd	s2,48(sp)
    80001308:	f052                	sd	s4,32(sp)
    8000130a:	ec56                	sd	s5,24(sp)
    8000130c:	e45e                	sd	s7,8(sp)
    8000130e:	0880                	addi	s0,sp,80
    80001310:	8aaa                	mv	s5,a0
    80001312:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001314:	6785                	lui	a5,0x1
    80001316:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001318:	95be                	add	a1,a1,a5
    8000131a:	77fd                	lui	a5,0xfffff
    8000131c:	00f5f933          	and	s2,a1,a5
    80001320:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001322:	08c97063          	bgeu	s2,a2,800013a2 <uvmalloc+0xa6>
    80001326:	fc26                	sd	s1,56(sp)
    80001328:	f44e                	sd	s3,40(sp)
    8000132a:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    8000132c:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000132e:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001332:	813ff0ef          	jal	80000b44 <kalloc>
    80001336:	84aa                	mv	s1,a0
    if(mem == 0){
    80001338:	c50d                	beqz	a0,80001362 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    8000133a:	864e                	mv	a2,s3
    8000133c:	4581                	li	a1,0
    8000133e:	9bbff0ef          	jal	80000cf8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001342:	875a                	mv	a4,s6
    80001344:	86a6                	mv	a3,s1
    80001346:	864e                	mv	a2,s3
    80001348:	85ca                	mv	a1,s2
    8000134a:	8556                	mv	a0,s5
    8000134c:	d15ff0ef          	jal	80001060 <mappages>
    80001350:	e915                	bnez	a0,80001384 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001352:	994e                	add	s2,s2,s3
    80001354:	fd496fe3          	bltu	s2,s4,80001332 <uvmalloc+0x36>
  return newsz;
    80001358:	8552                	mv	a0,s4
    8000135a:	74e2                	ld	s1,56(sp)
    8000135c:	79a2                	ld	s3,40(sp)
    8000135e:	6b42                	ld	s6,16(sp)
    80001360:	a811                	j	80001374 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001362:	865e                	mv	a2,s7
    80001364:	85ca                	mv	a1,s2
    80001366:	8556                	mv	a0,s5
    80001368:	f51ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    8000136c:	4501                	li	a0,0
    8000136e:	74e2                	ld	s1,56(sp)
    80001370:	79a2                	ld	s3,40(sp)
    80001372:	6b42                	ld	s6,16(sp)
}
    80001374:	60a6                	ld	ra,72(sp)
    80001376:	6406                	ld	s0,64(sp)
    80001378:	7942                	ld	s2,48(sp)
    8000137a:	7a02                	ld	s4,32(sp)
    8000137c:	6ae2                	ld	s5,24(sp)
    8000137e:	6ba2                	ld	s7,8(sp)
    80001380:	6161                	addi	sp,sp,80
    80001382:	8082                	ret
      kfree(mem);
    80001384:	8526                	mv	a0,s1
    80001386:	ed6ff0ef          	jal	80000a5c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000138a:	865e                	mv	a2,s7
    8000138c:	85ca                	mv	a1,s2
    8000138e:	8556                	mv	a0,s5
    80001390:	f29ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    80001394:	4501                	li	a0,0
    80001396:	74e2                	ld	s1,56(sp)
    80001398:	79a2                	ld	s3,40(sp)
    8000139a:	6b42                	ld	s6,16(sp)
    8000139c:	bfe1                	j	80001374 <uvmalloc+0x78>
    return oldsz;
    8000139e:	852e                	mv	a0,a1
}
    800013a0:	8082                	ret
  return newsz;
    800013a2:	8532                	mv	a0,a2
    800013a4:	bfc1                	j	80001374 <uvmalloc+0x78>

00000000800013a6 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013a6:	7179                	addi	sp,sp,-48
    800013a8:	f406                	sd	ra,40(sp)
    800013aa:	f022                	sd	s0,32(sp)
    800013ac:	ec26                	sd	s1,24(sp)
    800013ae:	e84a                	sd	s2,16(sp)
    800013b0:	e44e                	sd	s3,8(sp)
    800013b2:	1800                	addi	s0,sp,48
    800013b4:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013b6:	84aa                	mv	s1,a0
    800013b8:	6905                	lui	s2,0x1
    800013ba:	992a                	add	s2,s2,a0
    800013bc:	a811                	j	800013d0 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800013be:	00006517          	auipc	a0,0x6
    800013c2:	d7a50513          	addi	a0,a0,-646 # 80007138 <etext+0x138>
    800013c6:	c5eff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    800013ca:	04a1                	addi	s1,s1,8
    800013cc:	03248163          	beq	s1,s2,800013ee <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013d0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013d2:	0017f713          	andi	a4,a5,1
    800013d6:	db75                	beqz	a4,800013ca <freewalk+0x24>
    800013d8:	00e7f713          	andi	a4,a5,14
    800013dc:	f36d                	bnez	a4,800013be <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800013de:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013e0:	00c79513          	slli	a0,a5,0xc
    800013e4:	fc3ff0ef          	jal	800013a6 <freewalk>
      pagetable[i] = 0;
    800013e8:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013ec:	bff9                	j	800013ca <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800013ee:	854e                	mv	a0,s3
    800013f0:	e6cff0ef          	jal	80000a5c <kfree>
}
    800013f4:	70a2                	ld	ra,40(sp)
    800013f6:	7402                	ld	s0,32(sp)
    800013f8:	64e2                	ld	s1,24(sp)
    800013fa:	6942                	ld	s2,16(sp)
    800013fc:	69a2                	ld	s3,8(sp)
    800013fe:	6145                	addi	sp,sp,48
    80001400:	8082                	ret

0000000080001402 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001402:	1101                	addi	sp,sp,-32
    80001404:	ec06                	sd	ra,24(sp)
    80001406:	e822                	sd	s0,16(sp)
    80001408:	e426                	sd	s1,8(sp)
    8000140a:	1000                	addi	s0,sp,32
    8000140c:	84aa                	mv	s1,a0
  if(sz > 0)
    8000140e:	e989                	bnez	a1,80001420 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001410:	8526                	mv	a0,s1
    80001412:	f95ff0ef          	jal	800013a6 <freewalk>
}
    80001416:	60e2                	ld	ra,24(sp)
    80001418:	6442                	ld	s0,16(sp)
    8000141a:	64a2                	ld	s1,8(sp)
    8000141c:	6105                	addi	sp,sp,32
    8000141e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001420:	6785                	lui	a5,0x1
    80001422:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001424:	95be                	add	a1,a1,a5
    80001426:	4685                	li	a3,1
    80001428:	00c5d613          	srli	a2,a1,0xc
    8000142c:	4581                	li	a1,0
    8000142e:	e01ff0ef          	jal	8000122e <uvmunmap>
    80001432:	bff9                	j	80001410 <uvmfree+0xe>

0000000080001434 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001434:	ca59                	beqz	a2,800014ca <uvmcopy+0x96>
{
    80001436:	715d                	addi	sp,sp,-80
    80001438:	e486                	sd	ra,72(sp)
    8000143a:	e0a2                	sd	s0,64(sp)
    8000143c:	fc26                	sd	s1,56(sp)
    8000143e:	f84a                	sd	s2,48(sp)
    80001440:	f44e                	sd	s3,40(sp)
    80001442:	f052                	sd	s4,32(sp)
    80001444:	ec56                	sd	s5,24(sp)
    80001446:	e85a                	sd	s6,16(sp)
    80001448:	e45e                	sd	s7,8(sp)
    8000144a:	0880                	addi	s0,sp,80
    8000144c:	8b2a                	mv	s6,a0
    8000144e:	8bae                	mv	s7,a1
    80001450:	8ab2                	mv	s5,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001452:	4481                	li	s1,0
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001454:	6a05                	lui	s4,0x1
    80001456:	a021                	j	8000145e <uvmcopy+0x2a>
  for(i = 0; i < sz; i += PGSIZE){
    80001458:	94d2                	add	s1,s1,s4
    8000145a:	0554fc63          	bgeu	s1,s5,800014b2 <uvmcopy+0x7e>
    if((pte = walk(old, i, 0)) == 0)
    8000145e:	4601                	li	a2,0
    80001460:	85a6                	mv	a1,s1
    80001462:	855a                	mv	a0,s6
    80001464:	b29ff0ef          	jal	80000f8c <walk>
    80001468:	d965                	beqz	a0,80001458 <uvmcopy+0x24>
    if((*pte & PTE_V) == 0)
    8000146a:	00053983          	ld	s3,0(a0)
    8000146e:	0019f793          	andi	a5,s3,1
    80001472:	d3fd                	beqz	a5,80001458 <uvmcopy+0x24>
    if((mem = kalloc()) == 0)
    80001474:	ed0ff0ef          	jal	80000b44 <kalloc>
    80001478:	892a                	mv	s2,a0
    8000147a:	c11d                	beqz	a0,800014a0 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    8000147c:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80001480:	8652                	mv	a2,s4
    80001482:	05b2                	slli	a1,a1,0xc
    80001484:	8d5ff0ef          	jal	80000d58 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001488:	3ff9f713          	andi	a4,s3,1023
    8000148c:	86ca                	mv	a3,s2
    8000148e:	8652                	mv	a2,s4
    80001490:	85a6                	mv	a1,s1
    80001492:	855e                	mv	a0,s7
    80001494:	bcdff0ef          	jal	80001060 <mappages>
    80001498:	d161                	beqz	a0,80001458 <uvmcopy+0x24>
      kfree(mem);
    8000149a:	854a                	mv	a0,s2
    8000149c:	dc0ff0ef          	jal	80000a5c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014a0:	4685                	li	a3,1
    800014a2:	00c4d613          	srli	a2,s1,0xc
    800014a6:	4581                	li	a1,0
    800014a8:	855e                	mv	a0,s7
    800014aa:	d85ff0ef          	jal	8000122e <uvmunmap>
  return -1;
    800014ae:	557d                	li	a0,-1
    800014b0:	a011                	j	800014b4 <uvmcopy+0x80>
  return 0;
    800014b2:	4501                	li	a0,0
}
    800014b4:	60a6                	ld	ra,72(sp)
    800014b6:	6406                	ld	s0,64(sp)
    800014b8:	74e2                	ld	s1,56(sp)
    800014ba:	7942                	ld	s2,48(sp)
    800014bc:	79a2                	ld	s3,40(sp)
    800014be:	7a02                	ld	s4,32(sp)
    800014c0:	6ae2                	ld	s5,24(sp)
    800014c2:	6b42                	ld	s6,16(sp)
    800014c4:	6ba2                	ld	s7,8(sp)
    800014c6:	6161                	addi	sp,sp,80
    800014c8:	8082                	ret
  return 0;
    800014ca:	4501                	li	a0,0
}
    800014cc:	8082                	ret

00000000800014ce <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014ce:	1141                	addi	sp,sp,-16
    800014d0:	e406                	sd	ra,8(sp)
    800014d2:	e022                	sd	s0,0(sp)
    800014d4:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014d6:	4601                	li	a2,0
    800014d8:	ab5ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    800014dc:	c901                	beqz	a0,800014ec <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014de:	611c                	ld	a5,0(a0)
    800014e0:	9bbd                	andi	a5,a5,-17
    800014e2:	e11c                	sd	a5,0(a0)
}
    800014e4:	60a2                	ld	ra,8(sp)
    800014e6:	6402                	ld	s0,0(sp)
    800014e8:	0141                	addi	sp,sp,16
    800014ea:	8082                	ret
    panic("uvmclear");
    800014ec:	00006517          	auipc	a0,0x6
    800014f0:	c5c50513          	addi	a0,a0,-932 # 80007148 <etext+0x148>
    800014f4:	b30ff0ef          	jal	80000824 <panic>

00000000800014f8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800014f8:	cac5                	beqz	a3,800015a8 <copyinstr+0xb0>
{
    800014fa:	715d                	addi	sp,sp,-80
    800014fc:	e486                	sd	ra,72(sp)
    800014fe:	e0a2                	sd	s0,64(sp)
    80001500:	fc26                	sd	s1,56(sp)
    80001502:	f84a                	sd	s2,48(sp)
    80001504:	f44e                	sd	s3,40(sp)
    80001506:	f052                	sd	s4,32(sp)
    80001508:	ec56                	sd	s5,24(sp)
    8000150a:	e85a                	sd	s6,16(sp)
    8000150c:	e45e                	sd	s7,8(sp)
    8000150e:	0880                	addi	s0,sp,80
    80001510:	8aaa                	mv	s5,a0
    80001512:	84ae                	mv	s1,a1
    80001514:	8bb2                	mv	s7,a2
    80001516:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001518:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000151a:	6a05                	lui	s4,0x1
    8000151c:	a82d                	j	80001556 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000151e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001522:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001524:	0017c793          	xori	a5,a5,1
    80001528:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000152c:	60a6                	ld	ra,72(sp)
    8000152e:	6406                	ld	s0,64(sp)
    80001530:	74e2                	ld	s1,56(sp)
    80001532:	7942                	ld	s2,48(sp)
    80001534:	79a2                	ld	s3,40(sp)
    80001536:	7a02                	ld	s4,32(sp)
    80001538:	6ae2                	ld	s5,24(sp)
    8000153a:	6b42                	ld	s6,16(sp)
    8000153c:	6ba2                	ld	s7,8(sp)
    8000153e:	6161                	addi	sp,sp,80
    80001540:	8082                	ret
    80001542:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001546:	9726                	add	a4,a4,s1
      --max;
    80001548:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000154c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001550:	04e58463          	beq	a1,a4,80001598 <copyinstr+0xa0>
{
    80001554:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001556:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000155a:	85ca                	mv	a1,s2
    8000155c:	8556                	mv	a0,s5
    8000155e:	ac9ff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0)
    80001562:	cd0d                	beqz	a0,8000159c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001564:	417906b3          	sub	a3,s2,s7
    80001568:	96d2                	add	a3,a3,s4
    if(n > max)
    8000156a:	00d9f363          	bgeu	s3,a3,80001570 <copyinstr+0x78>
    8000156e:	86ce                	mv	a3,s3
    while(n > 0){
    80001570:	ca85                	beqz	a3,800015a0 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001572:	01750633          	add	a2,a0,s7
    80001576:	41260633          	sub	a2,a2,s2
    8000157a:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000157c:	8e05                	sub	a2,a2,s1
    while(n > 0){
    8000157e:	96a6                	add	a3,a3,s1
    80001580:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001582:	00f60733          	add	a4,a2,a5
    80001586:	00074703          	lbu	a4,0(a4)
    8000158a:	db51                	beqz	a4,8000151e <copyinstr+0x26>
        *dst = *p;
    8000158c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001590:	0785                	addi	a5,a5,1
    while(n > 0){
    80001592:	fed797e3          	bne	a5,a3,80001580 <copyinstr+0x88>
    80001596:	b775                	j	80001542 <copyinstr+0x4a>
    80001598:	4781                	li	a5,0
    8000159a:	b769                	j	80001524 <copyinstr+0x2c>
      return -1;
    8000159c:	557d                	li	a0,-1
    8000159e:	b779                	j	8000152c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    800015a0:	6b85                	lui	s7,0x1
    800015a2:	9bca                	add	s7,s7,s2
    800015a4:	87a6                	mv	a5,s1
    800015a6:	b77d                	j	80001554 <copyinstr+0x5c>
  int got_null = 0;
    800015a8:	4781                	li	a5,0
  if(got_null){
    800015aa:	0017c793          	xori	a5,a5,1
    800015ae:	40f0053b          	negw	a0,a5
}
    800015b2:	8082                	ret

00000000800015b4 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800015b4:	1141                	addi	sp,sp,-16
    800015b6:	e406                	sd	ra,8(sp)
    800015b8:	e022                	sd	s0,0(sp)
    800015ba:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800015bc:	4601                	li	a2,0
    800015be:	9cfff0ef          	jal	80000f8c <walk>
  if (pte == 0) {
    800015c2:	c119                	beqz	a0,800015c8 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V){
    800015c4:	6108                	ld	a0,0(a0)
    800015c6:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800015c8:	60a2                	ld	ra,8(sp)
    800015ca:	6402                	ld	s0,0(sp)
    800015cc:	0141                	addi	sp,sp,16
    800015ce:	8082                	ret

00000000800015d0 <vmfault>:
{
    800015d0:	7179                	addi	sp,sp,-48
    800015d2:	f406                	sd	ra,40(sp)
    800015d4:	f022                	sd	s0,32(sp)
    800015d6:	e84a                	sd	s2,16(sp)
    800015d8:	e44e                	sd	s3,8(sp)
    800015da:	1800                	addi	s0,sp,48
    800015dc:	89aa                	mv	s3,a0
    800015de:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800015e0:	34e000ef          	jal	8000192e <myproc>
  if (va >= p->sz)
    800015e4:	653c                	ld	a5,72(a0)
    800015e6:	00f96a63          	bltu	s2,a5,800015fa <vmfault+0x2a>
    return 0;
    800015ea:	4981                	li	s3,0
}
    800015ec:	854e                	mv	a0,s3
    800015ee:	70a2                	ld	ra,40(sp)
    800015f0:	7402                	ld	s0,32(sp)
    800015f2:	6942                	ld	s2,16(sp)
    800015f4:	69a2                	ld	s3,8(sp)
    800015f6:	6145                	addi	sp,sp,48
    800015f8:	8082                	ret
    800015fa:	ec26                	sd	s1,24(sp)
    800015fc:	e052                	sd	s4,0(sp)
    800015fe:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    80001600:	77fd                	lui	a5,0xfffff
    80001602:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    80001606:	85d2                	mv	a1,s4
    80001608:	854e                	mv	a0,s3
    8000160a:	fabff0ef          	jal	800015b4 <ismapped>
    return 0;
    8000160e:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001610:	c501                	beqz	a0,80001618 <vmfault+0x48>
    80001612:	64e2                	ld	s1,24(sp)
    80001614:	6a02                	ld	s4,0(sp)
    80001616:	bfd9                	j	800015ec <vmfault+0x1c>
  mem = (uint64) kalloc();
    80001618:	d2cff0ef          	jal	80000b44 <kalloc>
    8000161c:	892a                	mv	s2,a0
  if(mem == 0)
    8000161e:	c905                	beqz	a0,8000164e <vmfault+0x7e>
  mem = (uint64) kalloc();
    80001620:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    80001622:	6605                	lui	a2,0x1
    80001624:	4581                	li	a1,0
    80001626:	ed2ff0ef          	jal	80000cf8 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    8000162a:	4759                	li	a4,22
    8000162c:	86ca                	mv	a3,s2
    8000162e:	6605                	lui	a2,0x1
    80001630:	85d2                	mv	a1,s4
    80001632:	68a8                	ld	a0,80(s1)
    80001634:	a2dff0ef          	jal	80001060 <mappages>
    80001638:	e501                	bnez	a0,80001640 <vmfault+0x70>
    8000163a:	64e2                	ld	s1,24(sp)
    8000163c:	6a02                	ld	s4,0(sp)
    8000163e:	b77d                	j	800015ec <vmfault+0x1c>
    kfree((void *)mem);
    80001640:	854a                	mv	a0,s2
    80001642:	c1aff0ef          	jal	80000a5c <kfree>
    return 0;
    80001646:	4981                	li	s3,0
    80001648:	64e2                	ld	s1,24(sp)
    8000164a:	6a02                	ld	s4,0(sp)
    8000164c:	b745                	j	800015ec <vmfault+0x1c>
    8000164e:	64e2                	ld	s1,24(sp)
    80001650:	6a02                	ld	s4,0(sp)
    80001652:	bf69                	j	800015ec <vmfault+0x1c>

0000000080001654 <copyout>:
  while(len > 0){
    80001654:	cad1                	beqz	a3,800016e8 <copyout+0x94>
{
    80001656:	711d                	addi	sp,sp,-96
    80001658:	ec86                	sd	ra,88(sp)
    8000165a:	e8a2                	sd	s0,80(sp)
    8000165c:	e4a6                	sd	s1,72(sp)
    8000165e:	e0ca                	sd	s2,64(sp)
    80001660:	fc4e                	sd	s3,56(sp)
    80001662:	f852                	sd	s4,48(sp)
    80001664:	f456                	sd	s5,40(sp)
    80001666:	f05a                	sd	s6,32(sp)
    80001668:	ec5e                	sd	s7,24(sp)
    8000166a:	e862                	sd	s8,16(sp)
    8000166c:	e466                	sd	s9,8(sp)
    8000166e:	e06a                	sd	s10,0(sp)
    80001670:	1080                	addi	s0,sp,96
    80001672:	8baa                	mv	s7,a0
    80001674:	8a2e                	mv	s4,a1
    80001676:	8b32                	mv	s6,a2
    80001678:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    8000167a:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    8000167c:	5cfd                	li	s9,-1
    8000167e:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001682:	6c05                	lui	s8,0x1
    80001684:	a005                	j	800016a4 <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001686:	409a0533          	sub	a0,s4,s1
    8000168a:	0009061b          	sext.w	a2,s2
    8000168e:	85da                	mv	a1,s6
    80001690:	954e                	add	a0,a0,s3
    80001692:	ec6ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001696:	412a8ab3          	sub	s5,s5,s2
    src += n;
    8000169a:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000169c:	01848a33          	add	s4,s1,s8
  while(len > 0){
    800016a0:	040a8263          	beqz	s5,800016e4 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    800016a4:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    800016a8:	049ce263          	bltu	s9,s1,800016ec <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    800016ac:	85a6                	mv	a1,s1
    800016ae:	855e                	mv	a0,s7
    800016b0:	977ff0ef          	jal	80001026 <walkaddr>
    800016b4:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    800016b6:	e901                	bnez	a0,800016c6 <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016b8:	4601                	li	a2,0
    800016ba:	85a6                	mv	a1,s1
    800016bc:	855e                	mv	a0,s7
    800016be:	f13ff0ef          	jal	800015d0 <vmfault>
    800016c2:	89aa                	mv	s3,a0
    800016c4:	c139                	beqz	a0,8000170a <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    800016c6:	4601                	li	a2,0
    800016c8:	85a6                	mv	a1,s1
    800016ca:	855e                	mv	a0,s7
    800016cc:	8c1ff0ef          	jal	80000f8c <walk>
    if((*pte & PTE_W) == 0)
    800016d0:	611c                	ld	a5,0(a0)
    800016d2:	8b91                	andi	a5,a5,4
    800016d4:	cf8d                	beqz	a5,8000170e <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    800016d6:	41448933          	sub	s2,s1,s4
    800016da:	9962                	add	s2,s2,s8
    if(n > len)
    800016dc:	fb2af5e3          	bgeu	s5,s2,80001686 <copyout+0x32>
    800016e0:	8956                	mv	s2,s5
    800016e2:	b755                	j	80001686 <copyout+0x32>
  return 0;
    800016e4:	4501                	li	a0,0
    800016e6:	a021                	j	800016ee <copyout+0x9a>
    800016e8:	4501                	li	a0,0
}
    800016ea:	8082                	ret
      return -1;
    800016ec:	557d                	li	a0,-1
}
    800016ee:	60e6                	ld	ra,88(sp)
    800016f0:	6446                	ld	s0,80(sp)
    800016f2:	64a6                	ld	s1,72(sp)
    800016f4:	6906                	ld	s2,64(sp)
    800016f6:	79e2                	ld	s3,56(sp)
    800016f8:	7a42                	ld	s4,48(sp)
    800016fa:	7aa2                	ld	s5,40(sp)
    800016fc:	7b02                	ld	s6,32(sp)
    800016fe:	6be2                	ld	s7,24(sp)
    80001700:	6c42                	ld	s8,16(sp)
    80001702:	6ca2                	ld	s9,8(sp)
    80001704:	6d02                	ld	s10,0(sp)
    80001706:	6125                	addi	sp,sp,96
    80001708:	8082                	ret
        return -1;
    8000170a:	557d                	li	a0,-1
    8000170c:	b7cd                	j	800016ee <copyout+0x9a>
      return -1;
    8000170e:	557d                	li	a0,-1
    80001710:	bff9                	j	800016ee <copyout+0x9a>

0000000080001712 <copyin>:
  while(len > 0){
    80001712:	c6c9                	beqz	a3,8000179c <copyin+0x8a>
{
    80001714:	715d                	addi	sp,sp,-80
    80001716:	e486                	sd	ra,72(sp)
    80001718:	e0a2                	sd	s0,64(sp)
    8000171a:	fc26                	sd	s1,56(sp)
    8000171c:	f84a                	sd	s2,48(sp)
    8000171e:	f44e                	sd	s3,40(sp)
    80001720:	f052                	sd	s4,32(sp)
    80001722:	ec56                	sd	s5,24(sp)
    80001724:	e85a                	sd	s6,16(sp)
    80001726:	e45e                	sd	s7,8(sp)
    80001728:	e062                	sd	s8,0(sp)
    8000172a:	0880                	addi	s0,sp,80
    8000172c:	8baa                	mv	s7,a0
    8000172e:	8aae                	mv	s5,a1
    80001730:	8932                	mv	s2,a2
    80001732:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001734:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001736:	6b05                	lui	s6,0x1
    80001738:	a035                	j	80001764 <copyin+0x52>
    8000173a:	412984b3          	sub	s1,s3,s2
    8000173e:	94da                	add	s1,s1,s6
    if(n > len)
    80001740:	009a7363          	bgeu	s4,s1,80001746 <copyin+0x34>
    80001744:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001746:	413905b3          	sub	a1,s2,s3
    8000174a:	0004861b          	sext.w	a2,s1
    8000174e:	95aa                	add	a1,a1,a0
    80001750:	8556                	mv	a0,s5
    80001752:	e06ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001756:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000175a:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000175c:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001760:	020a0163          	beqz	s4,80001782 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001764:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001768:	85ce                	mv	a1,s3
    8000176a:	855e                	mv	a0,s7
    8000176c:	8bbff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0) {
    80001770:	f569                	bnez	a0,8000173a <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001772:	4601                	li	a2,0
    80001774:	85ce                	mv	a1,s3
    80001776:	855e                	mv	a0,s7
    80001778:	e59ff0ef          	jal	800015d0 <vmfault>
    8000177c:	fd5d                	bnez	a0,8000173a <copyin+0x28>
        return -1;
    8000177e:	557d                	li	a0,-1
    80001780:	a011                	j	80001784 <copyin+0x72>
  return 0;
    80001782:	4501                	li	a0,0
}
    80001784:	60a6                	ld	ra,72(sp)
    80001786:	6406                	ld	s0,64(sp)
    80001788:	74e2                	ld	s1,56(sp)
    8000178a:	7942                	ld	s2,48(sp)
    8000178c:	79a2                	ld	s3,40(sp)
    8000178e:	7a02                	ld	s4,32(sp)
    80001790:	6ae2                	ld	s5,24(sp)
    80001792:	6b42                	ld	s6,16(sp)
    80001794:	6ba2                	ld	s7,8(sp)
    80001796:	6c02                	ld	s8,0(sp)
    80001798:	6161                	addi	sp,sp,80
    8000179a:	8082                	ret
  return 0;
    8000179c:	4501                	li	a0,0
}
    8000179e:	8082                	ret

00000000800017a0 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017a0:	715d                	addi	sp,sp,-80
    800017a2:	e486                	sd	ra,72(sp)
    800017a4:	e0a2                	sd	s0,64(sp)
    800017a6:	fc26                	sd	s1,56(sp)
    800017a8:	f84a                	sd	s2,48(sp)
    800017aa:	f44e                	sd	s3,40(sp)
    800017ac:	f052                	sd	s4,32(sp)
    800017ae:	ec56                	sd	s5,24(sp)
    800017b0:	e85a                	sd	s6,16(sp)
    800017b2:	e45e                	sd	s7,8(sp)
    800017b4:	e062                	sd	s8,0(sp)
    800017b6:	0880                	addi	s0,sp,80
    800017b8:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ba:	0000e497          	auipc	s1,0xe
    800017be:	5de48493          	addi	s1,s1,1502 # 8000fd98 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017c2:	8c26                	mv	s8,s1
    800017c4:	000a57b7          	lui	a5,0xa5
    800017c8:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017cc:	07b2                	slli	a5,a5,0xc
    800017ce:	fa578793          	addi	a5,a5,-91
    800017d2:	4fa50937          	lui	s2,0x4fa50
    800017d6:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017da:	1902                	slli	s2,s2,0x20
    800017dc:	993e                	add	s2,s2,a5
    800017de:	040009b7          	lui	s3,0x4000
    800017e2:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017e4:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e6:	4b99                	li	s7,6
    800017e8:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ea:	00014a97          	auipc	s5,0x14
    800017ee:	faea8a93          	addi	s5,s5,-82 # 80015798 <tickslock>
    char *pa = kalloc();
    800017f2:	b52ff0ef          	jal	80000b44 <kalloc>
    800017f6:	862a                	mv	a2,a0
    if(pa == 0)
    800017f8:	c121                	beqz	a0,80001838 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    800017fa:	418485b3          	sub	a1,s1,s8
    800017fe:	858d                	srai	a1,a1,0x3
    80001800:	032585b3          	mul	a1,a1,s2
    80001804:	05b6                	slli	a1,a1,0xd
    80001806:	6789                	lui	a5,0x2
    80001808:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000180a:	875e                	mv	a4,s7
    8000180c:	86da                	mv	a3,s6
    8000180e:	40b985b3          	sub	a1,s3,a1
    80001812:	8552                	mv	a0,s4
    80001814:	903ff0ef          	jal	80001116 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001818:	16848493          	addi	s1,s1,360
    8000181c:	fd549be3          	bne	s1,s5,800017f2 <proc_mapstacks+0x52>
  }
}
    80001820:	60a6                	ld	ra,72(sp)
    80001822:	6406                	ld	s0,64(sp)
    80001824:	74e2                	ld	s1,56(sp)
    80001826:	7942                	ld	s2,48(sp)
    80001828:	79a2                	ld	s3,40(sp)
    8000182a:	7a02                	ld	s4,32(sp)
    8000182c:	6ae2                	ld	s5,24(sp)
    8000182e:	6b42                	ld	s6,16(sp)
    80001830:	6ba2                	ld	s7,8(sp)
    80001832:	6c02                	ld	s8,0(sp)
    80001834:	6161                	addi	sp,sp,80
    80001836:	8082                	ret
      panic("kalloc");
    80001838:	00006517          	auipc	a0,0x6
    8000183c:	92050513          	addi	a0,a0,-1760 # 80007158 <etext+0x158>
    80001840:	fe5fe0ef          	jal	80000824 <panic>

0000000080001844 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001844:	7139                	addi	sp,sp,-64
    80001846:	fc06                	sd	ra,56(sp)
    80001848:	f822                	sd	s0,48(sp)
    8000184a:	f426                	sd	s1,40(sp)
    8000184c:	f04a                	sd	s2,32(sp)
    8000184e:	ec4e                	sd	s3,24(sp)
    80001850:	e852                	sd	s4,16(sp)
    80001852:	e456                	sd	s5,8(sp)
    80001854:	e05a                	sd	s6,0(sp)
    80001856:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001858:	00006597          	auipc	a1,0x6
    8000185c:	90858593          	addi	a1,a1,-1784 # 80007160 <etext+0x160>
    80001860:	0000e517          	auipc	a0,0xe
    80001864:	10850513          	addi	a0,a0,264 # 8000f968 <pid_lock>
    80001868:	b36ff0ef          	jal	80000b9e <initlock>
  initlock(&wait_lock, "wait_lock");
    8000186c:	00006597          	auipc	a1,0x6
    80001870:	8fc58593          	addi	a1,a1,-1796 # 80007168 <etext+0x168>
    80001874:	0000e517          	auipc	a0,0xe
    80001878:	10c50513          	addi	a0,a0,268 # 8000f980 <wait_lock>
    8000187c:	b22ff0ef          	jal	80000b9e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001880:	0000e497          	auipc	s1,0xe
    80001884:	51848493          	addi	s1,s1,1304 # 8000fd98 <proc>
      initlock(&p->lock, "proc");
    80001888:	00006b17          	auipc	s6,0x6
    8000188c:	8f0b0b13          	addi	s6,s6,-1808 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001890:	8aa6                	mv	s5,s1
    80001892:	000a57b7          	lui	a5,0xa5
    80001896:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    8000189a:	07b2                	slli	a5,a5,0xc
    8000189c:	fa578793          	addi	a5,a5,-91
    800018a0:	4fa50937          	lui	s2,0x4fa50
    800018a4:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800018a8:	1902                	slli	s2,s2,0x20
    800018aa:	993e                	add	s2,s2,a5
    800018ac:	040009b7          	lui	s3,0x4000
    800018b0:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018b2:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018b4:	00014a17          	auipc	s4,0x14
    800018b8:	ee4a0a13          	addi	s4,s4,-284 # 80015798 <tickslock>
      initlock(&p->lock, "proc");
    800018bc:	85da                	mv	a1,s6
    800018be:	8526                	mv	a0,s1
    800018c0:	adeff0ef          	jal	80000b9e <initlock>
      p->state = UNUSED;
    800018c4:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018c8:	415487b3          	sub	a5,s1,s5
    800018cc:	878d                	srai	a5,a5,0x3
    800018ce:	032787b3          	mul	a5,a5,s2
    800018d2:	07b6                	slli	a5,a5,0xd
    800018d4:	6709                	lui	a4,0x2
    800018d6:	9fb9                	addw	a5,a5,a4
    800018d8:	40f987b3          	sub	a5,s3,a5
    800018dc:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018de:	16848493          	addi	s1,s1,360
    800018e2:	fd449de3          	bne	s1,s4,800018bc <procinit+0x78>
  }
}
    800018e6:	70e2                	ld	ra,56(sp)
    800018e8:	7442                	ld	s0,48(sp)
    800018ea:	74a2                	ld	s1,40(sp)
    800018ec:	7902                	ld	s2,32(sp)
    800018ee:	69e2                	ld	s3,24(sp)
    800018f0:	6a42                	ld	s4,16(sp)
    800018f2:	6aa2                	ld	s5,8(sp)
    800018f4:	6b02                	ld	s6,0(sp)
    800018f6:	6121                	addi	sp,sp,64
    800018f8:	8082                	ret

00000000800018fa <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018fa:	1141                	addi	sp,sp,-16
    800018fc:	e406                	sd	ra,8(sp)
    800018fe:	e022                	sd	s0,0(sp)
    80001900:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001902:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001904:	2501                	sext.w	a0,a0
    80001906:	60a2                	ld	ra,8(sp)
    80001908:	6402                	ld	s0,0(sp)
    8000190a:	0141                	addi	sp,sp,16
    8000190c:	8082                	ret

000000008000190e <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    8000190e:	1141                	addi	sp,sp,-16
    80001910:	e406                	sd	ra,8(sp)
    80001912:	e022                	sd	s0,0(sp)
    80001914:	0800                	addi	s0,sp,16
    80001916:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001918:	2781                	sext.w	a5,a5
    8000191a:	079e                	slli	a5,a5,0x7
  return c;
}
    8000191c:	0000e517          	auipc	a0,0xe
    80001920:	07c50513          	addi	a0,a0,124 # 8000f998 <cpus>
    80001924:	953e                	add	a0,a0,a5
    80001926:	60a2                	ld	ra,8(sp)
    80001928:	6402                	ld	s0,0(sp)
    8000192a:	0141                	addi	sp,sp,16
    8000192c:	8082                	ret

000000008000192e <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    8000192e:	1101                	addi	sp,sp,-32
    80001930:	ec06                	sd	ra,24(sp)
    80001932:	e822                	sd	s0,16(sp)
    80001934:	e426                	sd	s1,8(sp)
    80001936:	1000                	addi	s0,sp,32
  push_off();
    80001938:	aacff0ef          	jal	80000be4 <push_off>
    8000193c:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    8000193e:	2781                	sext.w	a5,a5
    80001940:	079e                	slli	a5,a5,0x7
    80001942:	0000e717          	auipc	a4,0xe
    80001946:	02670713          	addi	a4,a4,38 # 8000f968 <pid_lock>
    8000194a:	97ba                	add	a5,a5,a4
    8000194c:	7b9c                	ld	a5,48(a5)
    8000194e:	84be                	mv	s1,a5
  pop_off();
    80001950:	b1cff0ef          	jal	80000c6c <pop_off>
  return p;
}
    80001954:	8526                	mv	a0,s1
    80001956:	60e2                	ld	ra,24(sp)
    80001958:	6442                	ld	s0,16(sp)
    8000195a:	64a2                	ld	s1,8(sp)
    8000195c:	6105                	addi	sp,sp,32
    8000195e:	8082                	ret

0000000080001960 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001960:	7179                	addi	sp,sp,-48
    80001962:	f406                	sd	ra,40(sp)
    80001964:	f022                	sd	s0,32(sp)
    80001966:	ec26                	sd	s1,24(sp)
    80001968:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    8000196a:	fc5ff0ef          	jal	8000192e <myproc>
    8000196e:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001970:	b4cff0ef          	jal	80000cbc <release>

  if (first) {
    80001974:	00006797          	auipc	a5,0x6
    80001978:	ebc7a783          	lw	a5,-324(a5) # 80007830 <first.1>
    8000197c:	cf95                	beqz	a5,800019b8 <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000197e:	4505                	li	a0,1
    80001980:	3f5010ef          	jal	80003574 <fsinit>

    first = 0;
    80001984:	00006797          	auipc	a5,0x6
    80001988:	ea07a623          	sw	zero,-340(a5) # 80007830 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000198c:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001990:	00005797          	auipc	a5,0x5
    80001994:	7f078793          	addi	a5,a5,2032 # 80007180 <etext+0x180>
    80001998:	fcf43823          	sd	a5,-48(s0)
    8000199c:	fc043c23          	sd	zero,-40(s0)
    800019a0:	fd040593          	addi	a1,s0,-48
    800019a4:	853e                	mv	a0,a5
    800019a6:	54d020ef          	jal	800046f2 <kexec>
    800019aa:	6cbc                	ld	a5,88(s1)
    800019ac:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800019ae:	6cbc                	ld	a5,88(s1)
    800019b0:	7bb8                	ld	a4,112(a5)
    800019b2:	57fd                	li	a5,-1
    800019b4:	02f70d63          	beq	a4,a5,800019ee <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800019b8:	31f000ef          	jal	800024d6 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019bc:	68a8                	ld	a0,80(s1)
    800019be:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019c0:	04000737          	lui	a4,0x4000
    800019c4:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019c6:	0732                	slli	a4,a4,0xc
    800019c8:	00004797          	auipc	a5,0x4
    800019cc:	6d478793          	addi	a5,a5,1748 # 8000609c <userret>
    800019d0:	00004697          	auipc	a3,0x4
    800019d4:	63068693          	addi	a3,a3,1584 # 80006000 <_trampoline>
    800019d8:	8f95                	sub	a5,a5,a3
    800019da:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019dc:	577d                	li	a4,-1
    800019de:	177e                	slli	a4,a4,0x3f
    800019e0:	8d59                	or	a0,a0,a4
    800019e2:	9782                	jalr	a5
}
    800019e4:	70a2                	ld	ra,40(sp)
    800019e6:	7402                	ld	s0,32(sp)
    800019e8:	64e2                	ld	s1,24(sp)
    800019ea:	6145                	addi	sp,sp,48
    800019ec:	8082                	ret
      panic("exec");
    800019ee:	00005517          	auipc	a0,0x5
    800019f2:	79a50513          	addi	a0,a0,1946 # 80007188 <etext+0x188>
    800019f6:	e2ffe0ef          	jal	80000824 <panic>

00000000800019fa <allocpid>:
{
    800019fa:	1101                	addi	sp,sp,-32
    800019fc:	ec06                	sd	ra,24(sp)
    800019fe:	e822                	sd	s0,16(sp)
    80001a00:	e426                	sd	s1,8(sp)
    80001a02:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a04:	0000e517          	auipc	a0,0xe
    80001a08:	f6450513          	addi	a0,a0,-156 # 8000f968 <pid_lock>
    80001a0c:	a1cff0ef          	jal	80000c28 <acquire>
  pid = nextpid;
    80001a10:	00006797          	auipc	a5,0x6
    80001a14:	e2478793          	addi	a5,a5,-476 # 80007834 <nextpid>
    80001a18:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a1a:	0014871b          	addiw	a4,s1,1
    80001a1e:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a20:	0000e517          	auipc	a0,0xe
    80001a24:	f4850513          	addi	a0,a0,-184 # 8000f968 <pid_lock>
    80001a28:	a94ff0ef          	jal	80000cbc <release>
}
    80001a2c:	8526                	mv	a0,s1
    80001a2e:	60e2                	ld	ra,24(sp)
    80001a30:	6442                	ld	s0,16(sp)
    80001a32:	64a2                	ld	s1,8(sp)
    80001a34:	6105                	addi	sp,sp,32
    80001a36:	8082                	ret

0000000080001a38 <proc_pagetable>:
{
    80001a38:	1101                	addi	sp,sp,-32
    80001a3a:	ec06                	sd	ra,24(sp)
    80001a3c:	e822                	sd	s0,16(sp)
    80001a3e:	e426                	sd	s1,8(sp)
    80001a40:	e04a                	sd	s2,0(sp)
    80001a42:	1000                	addi	s0,sp,32
    80001a44:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a46:	fc2ff0ef          	jal	80001208 <uvmcreate>
    80001a4a:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a4c:	cd05                	beqz	a0,80001a84 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a4e:	4729                	li	a4,10
    80001a50:	00004697          	auipc	a3,0x4
    80001a54:	5b068693          	addi	a3,a3,1456 # 80006000 <_trampoline>
    80001a58:	6605                	lui	a2,0x1
    80001a5a:	040005b7          	lui	a1,0x4000
    80001a5e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a60:	05b2                	slli	a1,a1,0xc
    80001a62:	dfeff0ef          	jal	80001060 <mappages>
    80001a66:	02054663          	bltz	a0,80001a92 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a6a:	4719                	li	a4,6
    80001a6c:	05893683          	ld	a3,88(s2)
    80001a70:	6605                	lui	a2,0x1
    80001a72:	020005b7          	lui	a1,0x2000
    80001a76:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a78:	05b6                	slli	a1,a1,0xd
    80001a7a:	8526                	mv	a0,s1
    80001a7c:	de4ff0ef          	jal	80001060 <mappages>
    80001a80:	00054f63          	bltz	a0,80001a9e <proc_pagetable+0x66>
}
    80001a84:	8526                	mv	a0,s1
    80001a86:	60e2                	ld	ra,24(sp)
    80001a88:	6442                	ld	s0,16(sp)
    80001a8a:	64a2                	ld	s1,8(sp)
    80001a8c:	6902                	ld	s2,0(sp)
    80001a8e:	6105                	addi	sp,sp,32
    80001a90:	8082                	ret
    uvmfree(pagetable, 0);
    80001a92:	4581                	li	a1,0
    80001a94:	8526                	mv	a0,s1
    80001a96:	96dff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001a9a:	4481                	li	s1,0
    80001a9c:	b7e5                	j	80001a84 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a9e:	4681                	li	a3,0
    80001aa0:	4605                	li	a2,1
    80001aa2:	040005b7          	lui	a1,0x4000
    80001aa6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aa8:	05b2                	slli	a1,a1,0xc
    80001aaa:	8526                	mv	a0,s1
    80001aac:	f82ff0ef          	jal	8000122e <uvmunmap>
    uvmfree(pagetable, 0);
    80001ab0:	4581                	li	a1,0
    80001ab2:	8526                	mv	a0,s1
    80001ab4:	94fff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001ab8:	4481                	li	s1,0
    80001aba:	b7e9                	j	80001a84 <proc_pagetable+0x4c>

0000000080001abc <proc_freepagetable>:
{
    80001abc:	1101                	addi	sp,sp,-32
    80001abe:	ec06                	sd	ra,24(sp)
    80001ac0:	e822                	sd	s0,16(sp)
    80001ac2:	e426                	sd	s1,8(sp)
    80001ac4:	e04a                	sd	s2,0(sp)
    80001ac6:	1000                	addi	s0,sp,32
    80001ac8:	84aa                	mv	s1,a0
    80001aca:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001acc:	4681                	li	a3,0
    80001ace:	4605                	li	a2,1
    80001ad0:	040005b7          	lui	a1,0x4000
    80001ad4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ad6:	05b2                	slli	a1,a1,0xc
    80001ad8:	f56ff0ef          	jal	8000122e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001adc:	4681                	li	a3,0
    80001ade:	4605                	li	a2,1
    80001ae0:	020005b7          	lui	a1,0x2000
    80001ae4:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ae6:	05b6                	slli	a1,a1,0xd
    80001ae8:	8526                	mv	a0,s1
    80001aea:	f44ff0ef          	jal	8000122e <uvmunmap>
  uvmfree(pagetable, sz);
    80001aee:	85ca                	mv	a1,s2
    80001af0:	8526                	mv	a0,s1
    80001af2:	911ff0ef          	jal	80001402 <uvmfree>
}
    80001af6:	60e2                	ld	ra,24(sp)
    80001af8:	6442                	ld	s0,16(sp)
    80001afa:	64a2                	ld	s1,8(sp)
    80001afc:	6902                	ld	s2,0(sp)
    80001afe:	6105                	addi	sp,sp,32
    80001b00:	8082                	ret

0000000080001b02 <freeproc>:
{
    80001b02:	1101                	addi	sp,sp,-32
    80001b04:	ec06                	sd	ra,24(sp)
    80001b06:	e822                	sd	s0,16(sp)
    80001b08:	e426                	sd	s1,8(sp)
    80001b0a:	1000                	addi	s0,sp,32
    80001b0c:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001b0e:	6d28                	ld	a0,88(a0)
    80001b10:	c119                	beqz	a0,80001b16 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001b12:	f4bfe0ef          	jal	80000a5c <kfree>
  p->trapframe = 0;
    80001b16:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001b1a:	68a8                	ld	a0,80(s1)
    80001b1c:	c501                	beqz	a0,80001b24 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b1e:	64ac                	ld	a1,72(s1)
    80001b20:	f9dff0ef          	jal	80001abc <proc_freepagetable>
  p->pagetable = 0;
    80001b24:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b28:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b2c:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001b30:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001b34:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b38:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b3c:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b40:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b44:	0004ac23          	sw	zero,24(s1)
}
    80001b48:	60e2                	ld	ra,24(sp)
    80001b4a:	6442                	ld	s0,16(sp)
    80001b4c:	64a2                	ld	s1,8(sp)
    80001b4e:	6105                	addi	sp,sp,32
    80001b50:	8082                	ret

0000000080001b52 <allocproc>:
{
    80001b52:	1101                	addi	sp,sp,-32
    80001b54:	ec06                	sd	ra,24(sp)
    80001b56:	e822                	sd	s0,16(sp)
    80001b58:	e426                	sd	s1,8(sp)
    80001b5a:	e04a                	sd	s2,0(sp)
    80001b5c:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b5e:	0000e497          	auipc	s1,0xe
    80001b62:	23a48493          	addi	s1,s1,570 # 8000fd98 <proc>
    80001b66:	00014917          	auipc	s2,0x14
    80001b6a:	c3290913          	addi	s2,s2,-974 # 80015798 <tickslock>
    acquire(&p->lock);
    80001b6e:	8526                	mv	a0,s1
    80001b70:	8b8ff0ef          	jal	80000c28 <acquire>
    if(p->state == UNUSED) {
    80001b74:	4c9c                	lw	a5,24(s1)
    80001b76:	cb91                	beqz	a5,80001b8a <allocproc+0x38>
      release(&p->lock);
    80001b78:	8526                	mv	a0,s1
    80001b7a:	942ff0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b7e:	16848493          	addi	s1,s1,360
    80001b82:	ff2496e3          	bne	s1,s2,80001b6e <allocproc+0x1c>
  return 0;
    80001b86:	4481                	li	s1,0
    80001b88:	a089                	j	80001bca <allocproc+0x78>
  p->pid = allocpid();
    80001b8a:	e71ff0ef          	jal	800019fa <allocpid>
    80001b8e:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b90:	4785                	li	a5,1
    80001b92:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b94:	fb1fe0ef          	jal	80000b44 <kalloc>
    80001b98:	892a                	mv	s2,a0
    80001b9a:	eca8                	sd	a0,88(s1)
    80001b9c:	cd15                	beqz	a0,80001bd8 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b9e:	8526                	mv	a0,s1
    80001ba0:	e99ff0ef          	jal	80001a38 <proc_pagetable>
    80001ba4:	892a                	mv	s2,a0
    80001ba6:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001ba8:	c121                	beqz	a0,80001be8 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001baa:	07000613          	li	a2,112
    80001bae:	4581                	li	a1,0
    80001bb0:	06048513          	addi	a0,s1,96
    80001bb4:	944ff0ef          	jal	80000cf8 <memset>
  p->context.ra = (uint64)forkret;
    80001bb8:	00000797          	auipc	a5,0x0
    80001bbc:	da878793          	addi	a5,a5,-600 # 80001960 <forkret>
    80001bc0:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001bc2:	60bc                	ld	a5,64(s1)
    80001bc4:	6705                	lui	a4,0x1
    80001bc6:	97ba                	add	a5,a5,a4
    80001bc8:	f4bc                	sd	a5,104(s1)
}
    80001bca:	8526                	mv	a0,s1
    80001bcc:	60e2                	ld	ra,24(sp)
    80001bce:	6442                	ld	s0,16(sp)
    80001bd0:	64a2                	ld	s1,8(sp)
    80001bd2:	6902                	ld	s2,0(sp)
    80001bd4:	6105                	addi	sp,sp,32
    80001bd6:	8082                	ret
    freeproc(p);
    80001bd8:	8526                	mv	a0,s1
    80001bda:	f29ff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001bde:	8526                	mv	a0,s1
    80001be0:	8dcff0ef          	jal	80000cbc <release>
    return 0;
    80001be4:	84ca                	mv	s1,s2
    80001be6:	b7d5                	j	80001bca <allocproc+0x78>
    freeproc(p);
    80001be8:	8526                	mv	a0,s1
    80001bea:	f19ff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001bee:	8526                	mv	a0,s1
    80001bf0:	8ccff0ef          	jal	80000cbc <release>
    return 0;
    80001bf4:	84ca                	mv	s1,s2
    80001bf6:	bfd1                	j	80001bca <allocproc+0x78>

0000000080001bf8 <userinit>:
{
    80001bf8:	1101                	addi	sp,sp,-32
    80001bfa:	ec06                	sd	ra,24(sp)
    80001bfc:	e822                	sd	s0,16(sp)
    80001bfe:	e426                	sd	s1,8(sp)
    80001c00:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c02:	f51ff0ef          	jal	80001b52 <allocproc>
    80001c06:	84aa                	mv	s1,a0
  initproc = p;
    80001c08:	00006797          	auipc	a5,0x6
    80001c0c:	c4a7bc23          	sd	a0,-936(a5) # 80007860 <initproc>
  p->cwd = namei("/");
    80001c10:	00005517          	auipc	a0,0x5
    80001c14:	58050513          	addi	a0,a0,1408 # 80007190 <etext+0x190>
    80001c18:	697010ef          	jal	80003aae <namei>
    80001c1c:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c20:	478d                	li	a5,3
    80001c22:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c24:	8526                	mv	a0,s1
    80001c26:	896ff0ef          	jal	80000cbc <release>
}
    80001c2a:	60e2                	ld	ra,24(sp)
    80001c2c:	6442                	ld	s0,16(sp)
    80001c2e:	64a2                	ld	s1,8(sp)
    80001c30:	6105                	addi	sp,sp,32
    80001c32:	8082                	ret

0000000080001c34 <growproc>:
{
    80001c34:	1101                	addi	sp,sp,-32
    80001c36:	ec06                	sd	ra,24(sp)
    80001c38:	e822                	sd	s0,16(sp)
    80001c3a:	e426                	sd	s1,8(sp)
    80001c3c:	e04a                	sd	s2,0(sp)
    80001c3e:	1000                	addi	s0,sp,32
    80001c40:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c42:	cedff0ef          	jal	8000192e <myproc>
    80001c46:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c48:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c4a:	01204c63          	bgtz	s2,80001c62 <growproc+0x2e>
  } else if(n < 0){
    80001c4e:	02094463          	bltz	s2,80001c76 <growproc+0x42>
  p->sz = sz;
    80001c52:	e4ac                	sd	a1,72(s1)
  return 0;
    80001c54:	4501                	li	a0,0
}
    80001c56:	60e2                	ld	ra,24(sp)
    80001c58:	6442                	ld	s0,16(sp)
    80001c5a:	64a2                	ld	s1,8(sp)
    80001c5c:	6902                	ld	s2,0(sp)
    80001c5e:	6105                	addi	sp,sp,32
    80001c60:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c62:	4691                	li	a3,4
    80001c64:	00b90633          	add	a2,s2,a1
    80001c68:	6928                	ld	a0,80(a0)
    80001c6a:	e92ff0ef          	jal	800012fc <uvmalloc>
    80001c6e:	85aa                	mv	a1,a0
    80001c70:	f16d                	bnez	a0,80001c52 <growproc+0x1e>
      return -1;
    80001c72:	557d                	li	a0,-1
    80001c74:	b7cd                	j	80001c56 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c76:	00b90633          	add	a2,s2,a1
    80001c7a:	6928                	ld	a0,80(a0)
    80001c7c:	e3cff0ef          	jal	800012b8 <uvmdealloc>
    80001c80:	85aa                	mv	a1,a0
    80001c82:	bfc1                	j	80001c52 <growproc+0x1e>

0000000080001c84 <kfork>:
{
    80001c84:	7139                	addi	sp,sp,-64
    80001c86:	fc06                	sd	ra,56(sp)
    80001c88:	f822                	sd	s0,48(sp)
    80001c8a:	f426                	sd	s1,40(sp)
    80001c8c:	e456                	sd	s5,8(sp)
    80001c8e:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c90:	c9fff0ef          	jal	8000192e <myproc>
    80001c94:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c96:	ebdff0ef          	jal	80001b52 <allocproc>
    80001c9a:	0e050a63          	beqz	a0,80001d8e <kfork+0x10a>
    80001c9e:	e852                	sd	s4,16(sp)
    80001ca0:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001ca2:	048ab603          	ld	a2,72(s5)
    80001ca6:	692c                	ld	a1,80(a0)
    80001ca8:	050ab503          	ld	a0,80(s5)
    80001cac:	f88ff0ef          	jal	80001434 <uvmcopy>
    80001cb0:	04054863          	bltz	a0,80001d00 <kfork+0x7c>
    80001cb4:	f04a                	sd	s2,32(sp)
    80001cb6:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001cb8:	048ab783          	ld	a5,72(s5)
    80001cbc:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cc0:	058ab683          	ld	a3,88(s5)
    80001cc4:	87b6                	mv	a5,a3
    80001cc6:	058a3703          	ld	a4,88(s4)
    80001cca:	12068693          	addi	a3,a3,288
    80001cce:	6388                	ld	a0,0(a5)
    80001cd0:	678c                	ld	a1,8(a5)
    80001cd2:	6b90                	ld	a2,16(a5)
    80001cd4:	e308                	sd	a0,0(a4)
    80001cd6:	e70c                	sd	a1,8(a4)
    80001cd8:	eb10                	sd	a2,16(a4)
    80001cda:	6f90                	ld	a2,24(a5)
    80001cdc:	ef10                	sd	a2,24(a4)
    80001cde:	02078793          	addi	a5,a5,32
    80001ce2:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001ce6:	fed794e3          	bne	a5,a3,80001cce <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001cea:	058a3783          	ld	a5,88(s4)
    80001cee:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cf2:	0d0a8493          	addi	s1,s5,208
    80001cf6:	0d0a0913          	addi	s2,s4,208
    80001cfa:	150a8993          	addi	s3,s5,336
    80001cfe:	a831                	j	80001d1a <kfork+0x96>
    freeproc(np);
    80001d00:	8552                	mv	a0,s4
    80001d02:	e01ff0ef          	jal	80001b02 <freeproc>
    release(&np->lock);
    80001d06:	8552                	mv	a0,s4
    80001d08:	fb5fe0ef          	jal	80000cbc <release>
    return -1;
    80001d0c:	54fd                	li	s1,-1
    80001d0e:	6a42                	ld	s4,16(sp)
    80001d10:	a885                	j	80001d80 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001d12:	04a1                	addi	s1,s1,8
    80001d14:	0921                	addi	s2,s2,8
    80001d16:	01348963          	beq	s1,s3,80001d28 <kfork+0xa4>
    if(p->ofile[i])
    80001d1a:	6088                	ld	a0,0(s1)
    80001d1c:	d97d                	beqz	a0,80001d12 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d1e:	34c020ef          	jal	8000406a <filedup>
    80001d22:	00a93023          	sd	a0,0(s2)
    80001d26:	b7f5                	j	80001d12 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001d28:	150ab503          	ld	a0,336(s5)
    80001d2c:	51e010ef          	jal	8000324a <idup>
    80001d30:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d34:	4641                	li	a2,16
    80001d36:	158a8593          	addi	a1,s5,344
    80001d3a:	158a0513          	addi	a0,s4,344
    80001d3e:	90eff0ef          	jal	80000e4c <safestrcpy>
  pid = np->pid;
    80001d42:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d46:	8552                	mv	a0,s4
    80001d48:	f75fe0ef          	jal	80000cbc <release>
  acquire(&wait_lock);
    80001d4c:	0000e517          	auipc	a0,0xe
    80001d50:	c3450513          	addi	a0,a0,-972 # 8000f980 <wait_lock>
    80001d54:	ed5fe0ef          	jal	80000c28 <acquire>
  np->parent = p;
    80001d58:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d5c:	0000e517          	auipc	a0,0xe
    80001d60:	c2450513          	addi	a0,a0,-988 # 8000f980 <wait_lock>
    80001d64:	f59fe0ef          	jal	80000cbc <release>
  acquire(&np->lock);
    80001d68:	8552                	mv	a0,s4
    80001d6a:	ebffe0ef          	jal	80000c28 <acquire>
  np->state = RUNNABLE;
    80001d6e:	478d                	li	a5,3
    80001d70:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d74:	8552                	mv	a0,s4
    80001d76:	f47fe0ef          	jal	80000cbc <release>
  return pid;
    80001d7a:	7902                	ld	s2,32(sp)
    80001d7c:	69e2                	ld	s3,24(sp)
    80001d7e:	6a42                	ld	s4,16(sp)
}
    80001d80:	8526                	mv	a0,s1
    80001d82:	70e2                	ld	ra,56(sp)
    80001d84:	7442                	ld	s0,48(sp)
    80001d86:	74a2                	ld	s1,40(sp)
    80001d88:	6aa2                	ld	s5,8(sp)
    80001d8a:	6121                	addi	sp,sp,64
    80001d8c:	8082                	ret
    return -1;
    80001d8e:	54fd                	li	s1,-1
    80001d90:	bfc5                	j	80001d80 <kfork+0xfc>

0000000080001d92 <scheduler>:
{
    80001d92:	715d                	addi	sp,sp,-80
    80001d94:	e486                	sd	ra,72(sp)
    80001d96:	e0a2                	sd	s0,64(sp)
    80001d98:	fc26                	sd	s1,56(sp)
    80001d9a:	f84a                	sd	s2,48(sp)
    80001d9c:	f44e                	sd	s3,40(sp)
    80001d9e:	f052                	sd	s4,32(sp)
    80001da0:	ec56                	sd	s5,24(sp)
    80001da2:	e85a                	sd	s6,16(sp)
    80001da4:	e45e                	sd	s7,8(sp)
    80001da6:	e062                	sd	s8,0(sp)
    80001da8:	0880                	addi	s0,sp,80
    80001daa:	8792                	mv	a5,tp
  int id = r_tp();
    80001dac:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001dae:	00779b13          	slli	s6,a5,0x7
    80001db2:	0000e717          	auipc	a4,0xe
    80001db6:	bb670713          	addi	a4,a4,-1098 # 8000f968 <pid_lock>
    80001dba:	975a                	add	a4,a4,s6
    80001dbc:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001dc0:	0000e717          	auipc	a4,0xe
    80001dc4:	be070713          	addi	a4,a4,-1056 # 8000f9a0 <cpus+0x8>
    80001dc8:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001dca:	4c11                	li	s8,4
        c->proc = p;
    80001dcc:	079e                	slli	a5,a5,0x7
    80001dce:	0000ea17          	auipc	s4,0xe
    80001dd2:	b9aa0a13          	addi	s4,s4,-1126 # 8000f968 <pid_lock>
    80001dd6:	9a3e                	add	s4,s4,a5
        found = 1;
    80001dd8:	4b85                	li	s7,1
    80001dda:	a83d                	j	80001e18 <scheduler+0x86>
      release(&p->lock);
    80001ddc:	8526                	mv	a0,s1
    80001dde:	edffe0ef          	jal	80000cbc <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001de2:	16848493          	addi	s1,s1,360
    80001de6:	03248563          	beq	s1,s2,80001e10 <scheduler+0x7e>
      acquire(&p->lock);
    80001dea:	8526                	mv	a0,s1
    80001dec:	e3dfe0ef          	jal	80000c28 <acquire>
      if(p->state == RUNNABLE) {
    80001df0:	4c9c                	lw	a5,24(s1)
    80001df2:	ff3795e3          	bne	a5,s3,80001ddc <scheduler+0x4a>
        p->state = RUNNING;
    80001df6:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001dfa:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001dfe:	06048593          	addi	a1,s1,96
    80001e02:	855a                	mv	a0,s6
    80001e04:	628000ef          	jal	8000242c <swtch>
        c->proc = 0;
    80001e08:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001e0c:	8ade                	mv	s5,s7
    80001e0e:	b7f9                	j	80001ddc <scheduler+0x4a>
    if(found == 0) {
    80001e10:	000a9463          	bnez	s5,80001e18 <scheduler+0x86>
      asm volatile("wfi");
    80001e14:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e18:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e1c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e20:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e24:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001e28:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e2a:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001e2e:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e30:	0000e497          	auipc	s1,0xe
    80001e34:	f6848493          	addi	s1,s1,-152 # 8000fd98 <proc>
      if(p->state == RUNNABLE) {
    80001e38:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e3a:	00014917          	auipc	s2,0x14
    80001e3e:	95e90913          	addi	s2,s2,-1698 # 80015798 <tickslock>
    80001e42:	b765                	j	80001dea <scheduler+0x58>

0000000080001e44 <sched>:
{
    80001e44:	7179                	addi	sp,sp,-48
    80001e46:	f406                	sd	ra,40(sp)
    80001e48:	f022                	sd	s0,32(sp)
    80001e4a:	ec26                	sd	s1,24(sp)
    80001e4c:	e84a                	sd	s2,16(sp)
    80001e4e:	e44e                	sd	s3,8(sp)
    80001e50:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e52:	addff0ef          	jal	8000192e <myproc>
    80001e56:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e58:	d61fe0ef          	jal	80000bb8 <holding>
    80001e5c:	c935                	beqz	a0,80001ed0 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e5e:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e60:	2781                	sext.w	a5,a5
    80001e62:	079e                	slli	a5,a5,0x7
    80001e64:	0000e717          	auipc	a4,0xe
    80001e68:	b0470713          	addi	a4,a4,-1276 # 8000f968 <pid_lock>
    80001e6c:	97ba                	add	a5,a5,a4
    80001e6e:	0a87a703          	lw	a4,168(a5)
    80001e72:	4785                	li	a5,1
    80001e74:	06f71463          	bne	a4,a5,80001edc <sched+0x98>
  if(p->state == RUNNING)
    80001e78:	4c98                	lw	a4,24(s1)
    80001e7a:	4791                	li	a5,4
    80001e7c:	06f70663          	beq	a4,a5,80001ee8 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e80:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e84:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e86:	e7bd                	bnez	a5,80001ef4 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e88:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e8a:	0000e917          	auipc	s2,0xe
    80001e8e:	ade90913          	addi	s2,s2,-1314 # 8000f968 <pid_lock>
    80001e92:	2781                	sext.w	a5,a5
    80001e94:	079e                	slli	a5,a5,0x7
    80001e96:	97ca                	add	a5,a5,s2
    80001e98:	0ac7a983          	lw	s3,172(a5)
    80001e9c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e9e:	2781                	sext.w	a5,a5
    80001ea0:	079e                	slli	a5,a5,0x7
    80001ea2:	07a1                	addi	a5,a5,8
    80001ea4:	0000e597          	auipc	a1,0xe
    80001ea8:	af458593          	addi	a1,a1,-1292 # 8000f998 <cpus>
    80001eac:	95be                	add	a1,a1,a5
    80001eae:	06048513          	addi	a0,s1,96
    80001eb2:	57a000ef          	jal	8000242c <swtch>
    80001eb6:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001eb8:	2781                	sext.w	a5,a5
    80001eba:	079e                	slli	a5,a5,0x7
    80001ebc:	993e                	add	s2,s2,a5
    80001ebe:	0b392623          	sw	s3,172(s2)
}
    80001ec2:	70a2                	ld	ra,40(sp)
    80001ec4:	7402                	ld	s0,32(sp)
    80001ec6:	64e2                	ld	s1,24(sp)
    80001ec8:	6942                	ld	s2,16(sp)
    80001eca:	69a2                	ld	s3,8(sp)
    80001ecc:	6145                	addi	sp,sp,48
    80001ece:	8082                	ret
    panic("sched p->lock");
    80001ed0:	00005517          	auipc	a0,0x5
    80001ed4:	2c850513          	addi	a0,a0,712 # 80007198 <etext+0x198>
    80001ed8:	94dfe0ef          	jal	80000824 <panic>
    panic("sched locks");
    80001edc:	00005517          	auipc	a0,0x5
    80001ee0:	2cc50513          	addi	a0,a0,716 # 800071a8 <etext+0x1a8>
    80001ee4:	941fe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    80001ee8:	00005517          	auipc	a0,0x5
    80001eec:	2d050513          	addi	a0,a0,720 # 800071b8 <etext+0x1b8>
    80001ef0:	935fe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    80001ef4:	00005517          	auipc	a0,0x5
    80001ef8:	2d450513          	addi	a0,a0,724 # 800071c8 <etext+0x1c8>
    80001efc:	929fe0ef          	jal	80000824 <panic>

0000000080001f00 <yield>:
{
    80001f00:	1101                	addi	sp,sp,-32
    80001f02:	ec06                	sd	ra,24(sp)
    80001f04:	e822                	sd	s0,16(sp)
    80001f06:	e426                	sd	s1,8(sp)
    80001f08:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f0a:	a25ff0ef          	jal	8000192e <myproc>
    80001f0e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f10:	d19fe0ef          	jal	80000c28 <acquire>
  p->state = RUNNABLE;
    80001f14:	478d                	li	a5,3
    80001f16:	cc9c                	sw	a5,24(s1)
  sched();
    80001f18:	f2dff0ef          	jal	80001e44 <sched>
  release(&p->lock);
    80001f1c:	8526                	mv	a0,s1
    80001f1e:	d9ffe0ef          	jal	80000cbc <release>
}
    80001f22:	60e2                	ld	ra,24(sp)
    80001f24:	6442                	ld	s0,16(sp)
    80001f26:	64a2                	ld	s1,8(sp)
    80001f28:	6105                	addi	sp,sp,32
    80001f2a:	8082                	ret

0000000080001f2c <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001f2c:	7179                	addi	sp,sp,-48
    80001f2e:	f406                	sd	ra,40(sp)
    80001f30:	f022                	sd	s0,32(sp)
    80001f32:	ec26                	sd	s1,24(sp)
    80001f34:	e84a                	sd	s2,16(sp)
    80001f36:	e44e                	sd	s3,8(sp)
    80001f38:	1800                	addi	s0,sp,48
    80001f3a:	89aa                	mv	s3,a0
    80001f3c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001f3e:	9f1ff0ef          	jal	8000192e <myproc>
    80001f42:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f44:	ce5fe0ef          	jal	80000c28 <acquire>
  release(lk);
    80001f48:	854a                	mv	a0,s2
    80001f4a:	d73fe0ef          	jal	80000cbc <release>

  // Go to sleep.
  p->chan = chan;
    80001f4e:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f52:	4789                	li	a5,2
    80001f54:	cc9c                	sw	a5,24(s1)

  sched();
    80001f56:	eefff0ef          	jal	80001e44 <sched>

  // Tidy up.
  p->chan = 0;
    80001f5a:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f5e:	8526                	mv	a0,s1
    80001f60:	d5dfe0ef          	jal	80000cbc <release>
  acquire(lk);
    80001f64:	854a                	mv	a0,s2
    80001f66:	cc3fe0ef          	jal	80000c28 <acquire>
}
    80001f6a:	70a2                	ld	ra,40(sp)
    80001f6c:	7402                	ld	s0,32(sp)
    80001f6e:	64e2                	ld	s1,24(sp)
    80001f70:	6942                	ld	s2,16(sp)
    80001f72:	69a2                	ld	s3,8(sp)
    80001f74:	6145                	addi	sp,sp,48
    80001f76:	8082                	ret

0000000080001f78 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f78:	7139                	addi	sp,sp,-64
    80001f7a:	fc06                	sd	ra,56(sp)
    80001f7c:	f822                	sd	s0,48(sp)
    80001f7e:	f426                	sd	s1,40(sp)
    80001f80:	f04a                	sd	s2,32(sp)
    80001f82:	ec4e                	sd	s3,24(sp)
    80001f84:	e852                	sd	s4,16(sp)
    80001f86:	e456                	sd	s5,8(sp)
    80001f88:	0080                	addi	s0,sp,64
    80001f8a:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f8c:	0000e497          	auipc	s1,0xe
    80001f90:	e0c48493          	addi	s1,s1,-500 # 8000fd98 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f94:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f96:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f98:	00014917          	auipc	s2,0x14
    80001f9c:	80090913          	addi	s2,s2,-2048 # 80015798 <tickslock>
    80001fa0:	a801                	j	80001fb0 <wakeup+0x38>
      }
      release(&p->lock);
    80001fa2:	8526                	mv	a0,s1
    80001fa4:	d19fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001fa8:	16848493          	addi	s1,s1,360
    80001fac:	03248263          	beq	s1,s2,80001fd0 <wakeup+0x58>
    if(p != myproc()){
    80001fb0:	97fff0ef          	jal	8000192e <myproc>
    80001fb4:	fe950ae3          	beq	a0,s1,80001fa8 <wakeup+0x30>
      acquire(&p->lock);
    80001fb8:	8526                	mv	a0,s1
    80001fba:	c6ffe0ef          	jal	80000c28 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001fbe:	4c9c                	lw	a5,24(s1)
    80001fc0:	ff3791e3          	bne	a5,s3,80001fa2 <wakeup+0x2a>
    80001fc4:	709c                	ld	a5,32(s1)
    80001fc6:	fd479ee3          	bne	a5,s4,80001fa2 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fca:	0154ac23          	sw	s5,24(s1)
    80001fce:	bfd1                	j	80001fa2 <wakeup+0x2a>
    }
  }
}
    80001fd0:	70e2                	ld	ra,56(sp)
    80001fd2:	7442                	ld	s0,48(sp)
    80001fd4:	74a2                	ld	s1,40(sp)
    80001fd6:	7902                	ld	s2,32(sp)
    80001fd8:	69e2                	ld	s3,24(sp)
    80001fda:	6a42                	ld	s4,16(sp)
    80001fdc:	6aa2                	ld	s5,8(sp)
    80001fde:	6121                	addi	sp,sp,64
    80001fe0:	8082                	ret

0000000080001fe2 <reparent>:
{
    80001fe2:	7179                	addi	sp,sp,-48
    80001fe4:	f406                	sd	ra,40(sp)
    80001fe6:	f022                	sd	s0,32(sp)
    80001fe8:	ec26                	sd	s1,24(sp)
    80001fea:	e84a                	sd	s2,16(sp)
    80001fec:	e44e                	sd	s3,8(sp)
    80001fee:	e052                	sd	s4,0(sp)
    80001ff0:	1800                	addi	s0,sp,48
    80001ff2:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001ff4:	0000e497          	auipc	s1,0xe
    80001ff8:	da448493          	addi	s1,s1,-604 # 8000fd98 <proc>
      pp->parent = initproc;
    80001ffc:	00006a17          	auipc	s4,0x6
    80002000:	864a0a13          	addi	s4,s4,-1948 # 80007860 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002004:	00013997          	auipc	s3,0x13
    80002008:	79498993          	addi	s3,s3,1940 # 80015798 <tickslock>
    8000200c:	a029                	j	80002016 <reparent+0x34>
    8000200e:	16848493          	addi	s1,s1,360
    80002012:	01348b63          	beq	s1,s3,80002028 <reparent+0x46>
    if(pp->parent == p){
    80002016:	7c9c                	ld	a5,56(s1)
    80002018:	ff279be3          	bne	a5,s2,8000200e <reparent+0x2c>
      pp->parent = initproc;
    8000201c:	000a3503          	ld	a0,0(s4)
    80002020:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002022:	f57ff0ef          	jal	80001f78 <wakeup>
    80002026:	b7e5                	j	8000200e <reparent+0x2c>
}
    80002028:	70a2                	ld	ra,40(sp)
    8000202a:	7402                	ld	s0,32(sp)
    8000202c:	64e2                	ld	s1,24(sp)
    8000202e:	6942                	ld	s2,16(sp)
    80002030:	69a2                	ld	s3,8(sp)
    80002032:	6a02                	ld	s4,0(sp)
    80002034:	6145                	addi	sp,sp,48
    80002036:	8082                	ret

0000000080002038 <kexit>:
{
    80002038:	7179                	addi	sp,sp,-48
    8000203a:	f406                	sd	ra,40(sp)
    8000203c:	f022                	sd	s0,32(sp)
    8000203e:	ec26                	sd	s1,24(sp)
    80002040:	e84a                	sd	s2,16(sp)
    80002042:	e44e                	sd	s3,8(sp)
    80002044:	e052                	sd	s4,0(sp)
    80002046:	1800                	addi	s0,sp,48
    80002048:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000204a:	8e5ff0ef          	jal	8000192e <myproc>
    8000204e:	89aa                	mv	s3,a0
  if(p == initproc)
    80002050:	00006797          	auipc	a5,0x6
    80002054:	8107b783          	ld	a5,-2032(a5) # 80007860 <initproc>
    80002058:	0d050493          	addi	s1,a0,208
    8000205c:	15050913          	addi	s2,a0,336
    80002060:	00a79b63          	bne	a5,a0,80002076 <kexit+0x3e>
    panic("init exiting");
    80002064:	00005517          	auipc	a0,0x5
    80002068:	17c50513          	addi	a0,a0,380 # 800071e0 <etext+0x1e0>
    8000206c:	fb8fe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002070:	04a1                	addi	s1,s1,8
    80002072:	01248963          	beq	s1,s2,80002084 <kexit+0x4c>
    if(p->ofile[fd]){
    80002076:	6088                	ld	a0,0(s1)
    80002078:	dd65                	beqz	a0,80002070 <kexit+0x38>
      fileclose(f);
    8000207a:	036020ef          	jal	800040b0 <fileclose>
      p->ofile[fd] = 0;
    8000207e:	0004b023          	sd	zero,0(s1)
    80002082:	b7fd                	j	80002070 <kexit+0x38>
  begin_op();
    80002084:	409010ef          	jal	80003c8c <begin_op>
  iput(p->cwd);
    80002088:	1509b503          	ld	a0,336(s3)
    8000208c:	376010ef          	jal	80003402 <iput>
  end_op();
    80002090:	46d010ef          	jal	80003cfc <end_op>
  p->cwd = 0;
    80002094:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002098:	0000e517          	auipc	a0,0xe
    8000209c:	8e850513          	addi	a0,a0,-1816 # 8000f980 <wait_lock>
    800020a0:	b89fe0ef          	jal	80000c28 <acquire>
  reparent(p);
    800020a4:	854e                	mv	a0,s3
    800020a6:	f3dff0ef          	jal	80001fe2 <reparent>
  wakeup(p->parent);
    800020aa:	0389b503          	ld	a0,56(s3)
    800020ae:	ecbff0ef          	jal	80001f78 <wakeup>
  acquire(&p->lock);
    800020b2:	854e                	mv	a0,s3
    800020b4:	b75fe0ef          	jal	80000c28 <acquire>
  p->xstate = status;
    800020b8:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020bc:	4795                	li	a5,5
    800020be:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020c2:	0000e517          	auipc	a0,0xe
    800020c6:	8be50513          	addi	a0,a0,-1858 # 8000f980 <wait_lock>
    800020ca:	bf3fe0ef          	jal	80000cbc <release>
  sched();
    800020ce:	d77ff0ef          	jal	80001e44 <sched>
  panic("zombie exit");
    800020d2:	00005517          	auipc	a0,0x5
    800020d6:	11e50513          	addi	a0,a0,286 # 800071f0 <etext+0x1f0>
    800020da:	f4afe0ef          	jal	80000824 <panic>

00000000800020de <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800020de:	7179                	addi	sp,sp,-48
    800020e0:	f406                	sd	ra,40(sp)
    800020e2:	f022                	sd	s0,32(sp)
    800020e4:	ec26                	sd	s1,24(sp)
    800020e6:	e84a                	sd	s2,16(sp)
    800020e8:	e44e                	sd	s3,8(sp)
    800020ea:	1800                	addi	s0,sp,48
    800020ec:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020ee:	0000e497          	auipc	s1,0xe
    800020f2:	caa48493          	addi	s1,s1,-854 # 8000fd98 <proc>
    800020f6:	00013997          	auipc	s3,0x13
    800020fa:	6a298993          	addi	s3,s3,1698 # 80015798 <tickslock>
    acquire(&p->lock);
    800020fe:	8526                	mv	a0,s1
    80002100:	b29fe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    80002104:	589c                	lw	a5,48(s1)
    80002106:	01278b63          	beq	a5,s2,8000211c <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000210a:	8526                	mv	a0,s1
    8000210c:	bb1fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002110:	16848493          	addi	s1,s1,360
    80002114:	ff3495e3          	bne	s1,s3,800020fe <kkill+0x20>
  }
  return -1;
    80002118:	557d                	li	a0,-1
    8000211a:	a819                	j	80002130 <kkill+0x52>
      p->killed = 1;
    8000211c:	4785                	li	a5,1
    8000211e:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002120:	4c98                	lw	a4,24(s1)
    80002122:	4789                	li	a5,2
    80002124:	00f70d63          	beq	a4,a5,8000213e <kkill+0x60>
      release(&p->lock);
    80002128:	8526                	mv	a0,s1
    8000212a:	b93fe0ef          	jal	80000cbc <release>
      return 0;
    8000212e:	4501                	li	a0,0
}
    80002130:	70a2                	ld	ra,40(sp)
    80002132:	7402                	ld	s0,32(sp)
    80002134:	64e2                	ld	s1,24(sp)
    80002136:	6942                	ld	s2,16(sp)
    80002138:	69a2                	ld	s3,8(sp)
    8000213a:	6145                	addi	sp,sp,48
    8000213c:	8082                	ret
        p->state = RUNNABLE;
    8000213e:	478d                	li	a5,3
    80002140:	cc9c                	sw	a5,24(s1)
    80002142:	b7dd                	j	80002128 <kkill+0x4a>

0000000080002144 <setkilled>:

void
setkilled(struct proc *p)
{
    80002144:	1101                	addi	sp,sp,-32
    80002146:	ec06                	sd	ra,24(sp)
    80002148:	e822                	sd	s0,16(sp)
    8000214a:	e426                	sd	s1,8(sp)
    8000214c:	1000                	addi	s0,sp,32
    8000214e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002150:	ad9fe0ef          	jal	80000c28 <acquire>
  p->killed = 1;
    80002154:	4785                	li	a5,1
    80002156:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002158:	8526                	mv	a0,s1
    8000215a:	b63fe0ef          	jal	80000cbc <release>
}
    8000215e:	60e2                	ld	ra,24(sp)
    80002160:	6442                	ld	s0,16(sp)
    80002162:	64a2                	ld	s1,8(sp)
    80002164:	6105                	addi	sp,sp,32
    80002166:	8082                	ret

0000000080002168 <killed>:

int
killed(struct proc *p)
{
    80002168:	1101                	addi	sp,sp,-32
    8000216a:	ec06                	sd	ra,24(sp)
    8000216c:	e822                	sd	s0,16(sp)
    8000216e:	e426                	sd	s1,8(sp)
    80002170:	e04a                	sd	s2,0(sp)
    80002172:	1000                	addi	s0,sp,32
    80002174:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002176:	ab3fe0ef          	jal	80000c28 <acquire>
  k = p->killed;
    8000217a:	549c                	lw	a5,40(s1)
    8000217c:	893e                	mv	s2,a5
  release(&p->lock);
    8000217e:	8526                	mv	a0,s1
    80002180:	b3dfe0ef          	jal	80000cbc <release>
  return k;
}
    80002184:	854a                	mv	a0,s2
    80002186:	60e2                	ld	ra,24(sp)
    80002188:	6442                	ld	s0,16(sp)
    8000218a:	64a2                	ld	s1,8(sp)
    8000218c:	6902                	ld	s2,0(sp)
    8000218e:	6105                	addi	sp,sp,32
    80002190:	8082                	ret

0000000080002192 <kwait>:
{
    80002192:	715d                	addi	sp,sp,-80
    80002194:	e486                	sd	ra,72(sp)
    80002196:	e0a2                	sd	s0,64(sp)
    80002198:	fc26                	sd	s1,56(sp)
    8000219a:	f84a                	sd	s2,48(sp)
    8000219c:	f44e                	sd	s3,40(sp)
    8000219e:	f052                	sd	s4,32(sp)
    800021a0:	ec56                	sd	s5,24(sp)
    800021a2:	e85a                	sd	s6,16(sp)
    800021a4:	e45e                	sd	s7,8(sp)
    800021a6:	0880                	addi	s0,sp,80
    800021a8:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800021aa:	f84ff0ef          	jal	8000192e <myproc>
    800021ae:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021b0:	0000d517          	auipc	a0,0xd
    800021b4:	7d050513          	addi	a0,a0,2000 # 8000f980 <wait_lock>
    800021b8:	a71fe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    800021bc:	4a15                	li	s4,5
        havekids = 1;
    800021be:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021c0:	00013997          	auipc	s3,0x13
    800021c4:	5d898993          	addi	s3,s3,1496 # 80015798 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800021c8:	0000db17          	auipc	s6,0xd
    800021cc:	7b8b0b13          	addi	s6,s6,1976 # 8000f980 <wait_lock>
    800021d0:	a869                	j	8000226a <kwait+0xd8>
          pid = pp->pid;
    800021d2:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800021d6:	000b8c63          	beqz	s7,800021ee <kwait+0x5c>
    800021da:	4691                	li	a3,4
    800021dc:	02c48613          	addi	a2,s1,44
    800021e0:	85de                	mv	a1,s7
    800021e2:	05093503          	ld	a0,80(s2)
    800021e6:	c6eff0ef          	jal	80001654 <copyout>
    800021ea:	02054a63          	bltz	a0,8000221e <kwait+0x8c>
          freeproc(pp);
    800021ee:	8526                	mv	a0,s1
    800021f0:	913ff0ef          	jal	80001b02 <freeproc>
          release(&pp->lock);
    800021f4:	8526                	mv	a0,s1
    800021f6:	ac7fe0ef          	jal	80000cbc <release>
          release(&wait_lock);
    800021fa:	0000d517          	auipc	a0,0xd
    800021fe:	78650513          	addi	a0,a0,1926 # 8000f980 <wait_lock>
    80002202:	abbfe0ef          	jal	80000cbc <release>
}
    80002206:	854e                	mv	a0,s3
    80002208:	60a6                	ld	ra,72(sp)
    8000220a:	6406                	ld	s0,64(sp)
    8000220c:	74e2                	ld	s1,56(sp)
    8000220e:	7942                	ld	s2,48(sp)
    80002210:	79a2                	ld	s3,40(sp)
    80002212:	7a02                	ld	s4,32(sp)
    80002214:	6ae2                	ld	s5,24(sp)
    80002216:	6b42                	ld	s6,16(sp)
    80002218:	6ba2                	ld	s7,8(sp)
    8000221a:	6161                	addi	sp,sp,80
    8000221c:	8082                	ret
            release(&pp->lock);
    8000221e:	8526                	mv	a0,s1
    80002220:	a9dfe0ef          	jal	80000cbc <release>
            release(&wait_lock);
    80002224:	0000d517          	auipc	a0,0xd
    80002228:	75c50513          	addi	a0,a0,1884 # 8000f980 <wait_lock>
    8000222c:	a91fe0ef          	jal	80000cbc <release>
            return -1;
    80002230:	59fd                	li	s3,-1
    80002232:	bfd1                	j	80002206 <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002234:	16848493          	addi	s1,s1,360
    80002238:	03348063          	beq	s1,s3,80002258 <kwait+0xc6>
      if(pp->parent == p){
    8000223c:	7c9c                	ld	a5,56(s1)
    8000223e:	ff279be3          	bne	a5,s2,80002234 <kwait+0xa2>
        acquire(&pp->lock);
    80002242:	8526                	mv	a0,s1
    80002244:	9e5fe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    80002248:	4c9c                	lw	a5,24(s1)
    8000224a:	f94784e3          	beq	a5,s4,800021d2 <kwait+0x40>
        release(&pp->lock);
    8000224e:	8526                	mv	a0,s1
    80002250:	a6dfe0ef          	jal	80000cbc <release>
        havekids = 1;
    80002254:	8756                	mv	a4,s5
    80002256:	bff9                	j	80002234 <kwait+0xa2>
    if(!havekids || killed(p)){
    80002258:	cf19                	beqz	a4,80002276 <kwait+0xe4>
    8000225a:	854a                	mv	a0,s2
    8000225c:	f0dff0ef          	jal	80002168 <killed>
    80002260:	e919                	bnez	a0,80002276 <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002262:	85da                	mv	a1,s6
    80002264:	854a                	mv	a0,s2
    80002266:	cc7ff0ef          	jal	80001f2c <sleep>
    havekids = 0;
    8000226a:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000226c:	0000e497          	auipc	s1,0xe
    80002270:	b2c48493          	addi	s1,s1,-1236 # 8000fd98 <proc>
    80002274:	b7e1                	j	8000223c <kwait+0xaa>
      release(&wait_lock);
    80002276:	0000d517          	auipc	a0,0xd
    8000227a:	70a50513          	addi	a0,a0,1802 # 8000f980 <wait_lock>
    8000227e:	a3ffe0ef          	jal	80000cbc <release>
      return -1;
    80002282:	59fd                	li	s3,-1
    80002284:	b749                	j	80002206 <kwait+0x74>

0000000080002286 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002286:	7179                	addi	sp,sp,-48
    80002288:	f406                	sd	ra,40(sp)
    8000228a:	f022                	sd	s0,32(sp)
    8000228c:	ec26                	sd	s1,24(sp)
    8000228e:	e84a                	sd	s2,16(sp)
    80002290:	e44e                	sd	s3,8(sp)
    80002292:	e052                	sd	s4,0(sp)
    80002294:	1800                	addi	s0,sp,48
    80002296:	84aa                	mv	s1,a0
    80002298:	8a2e                	mv	s4,a1
    8000229a:	89b2                	mv	s3,a2
    8000229c:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000229e:	e90ff0ef          	jal	8000192e <myproc>
  if(user_dst){
    800022a2:	cc99                	beqz	s1,800022c0 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800022a4:	86ca                	mv	a3,s2
    800022a6:	864e                	mv	a2,s3
    800022a8:	85d2                	mv	a1,s4
    800022aa:	6928                	ld	a0,80(a0)
    800022ac:	ba8ff0ef          	jal	80001654 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022b0:	70a2                	ld	ra,40(sp)
    800022b2:	7402                	ld	s0,32(sp)
    800022b4:	64e2                	ld	s1,24(sp)
    800022b6:	6942                	ld	s2,16(sp)
    800022b8:	69a2                	ld	s3,8(sp)
    800022ba:	6a02                	ld	s4,0(sp)
    800022bc:	6145                	addi	sp,sp,48
    800022be:	8082                	ret
    memmove((char *)dst, src, len);
    800022c0:	0009061b          	sext.w	a2,s2
    800022c4:	85ce                	mv	a1,s3
    800022c6:	8552                	mv	a0,s4
    800022c8:	a91fe0ef          	jal	80000d58 <memmove>
    return 0;
    800022cc:	8526                	mv	a0,s1
    800022ce:	b7cd                	j	800022b0 <either_copyout+0x2a>

00000000800022d0 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800022d0:	7179                	addi	sp,sp,-48
    800022d2:	f406                	sd	ra,40(sp)
    800022d4:	f022                	sd	s0,32(sp)
    800022d6:	ec26                	sd	s1,24(sp)
    800022d8:	e84a                	sd	s2,16(sp)
    800022da:	e44e                	sd	s3,8(sp)
    800022dc:	e052                	sd	s4,0(sp)
    800022de:	1800                	addi	s0,sp,48
    800022e0:	8a2a                	mv	s4,a0
    800022e2:	84ae                	mv	s1,a1
    800022e4:	89b2                	mv	s3,a2
    800022e6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800022e8:	e46ff0ef          	jal	8000192e <myproc>
  if(user_src){
    800022ec:	cc99                	beqz	s1,8000230a <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022ee:	86ca                	mv	a3,s2
    800022f0:	864e                	mv	a2,s3
    800022f2:	85d2                	mv	a1,s4
    800022f4:	6928                	ld	a0,80(a0)
    800022f6:	c1cff0ef          	jal	80001712 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022fa:	70a2                	ld	ra,40(sp)
    800022fc:	7402                	ld	s0,32(sp)
    800022fe:	64e2                	ld	s1,24(sp)
    80002300:	6942                	ld	s2,16(sp)
    80002302:	69a2                	ld	s3,8(sp)
    80002304:	6a02                	ld	s4,0(sp)
    80002306:	6145                	addi	sp,sp,48
    80002308:	8082                	ret
    memmove(dst, (char*)src, len);
    8000230a:	0009061b          	sext.w	a2,s2
    8000230e:	85ce                	mv	a1,s3
    80002310:	8552                	mv	a0,s4
    80002312:	a47fe0ef          	jal	80000d58 <memmove>
    return 0;
    80002316:	8526                	mv	a0,s1
    80002318:	b7cd                	j	800022fa <either_copyin+0x2a>

000000008000231a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000231a:	715d                	addi	sp,sp,-80
    8000231c:	e486                	sd	ra,72(sp)
    8000231e:	e0a2                	sd	s0,64(sp)
    80002320:	fc26                	sd	s1,56(sp)
    80002322:	f84a                	sd	s2,48(sp)
    80002324:	f44e                	sd	s3,40(sp)
    80002326:	f052                	sd	s4,32(sp)
    80002328:	ec56                	sd	s5,24(sp)
    8000232a:	e85a                	sd	s6,16(sp)
    8000232c:	e45e                	sd	s7,8(sp)
    8000232e:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002330:	00005517          	auipc	a0,0x5
    80002334:	d4850513          	addi	a0,a0,-696 # 80007078 <etext+0x78>
    80002338:	9c2fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000233c:	0000e497          	auipc	s1,0xe
    80002340:	bb448493          	addi	s1,s1,-1100 # 8000fef0 <proc+0x158>
    80002344:	00013917          	auipc	s2,0x13
    80002348:	5ac90913          	addi	s2,s2,1452 # 800158f0 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000234c:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000234e:	00005997          	auipc	s3,0x5
    80002352:	eb298993          	addi	s3,s3,-334 # 80007200 <etext+0x200>
    printf("%d %s %s", p->pid, state, p->name);
    80002356:	00005a97          	auipc	s5,0x5
    8000235a:	eb2a8a93          	addi	s5,s5,-334 # 80007208 <etext+0x208>
    printf("\n");
    8000235e:	00005a17          	auipc	s4,0x5
    80002362:	d1aa0a13          	addi	s4,s4,-742 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002366:	00005b97          	auipc	s7,0x5
    8000236a:	3c2b8b93          	addi	s7,s7,962 # 80007728 <states.0>
    8000236e:	a829                	j	80002388 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002370:	ed86a583          	lw	a1,-296(a3)
    80002374:	8556                	mv	a0,s5
    80002376:	984fe0ef          	jal	800004fa <printf>
    printf("\n");
    8000237a:	8552                	mv	a0,s4
    8000237c:	97efe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002380:	16848493          	addi	s1,s1,360
    80002384:	03248263          	beq	s1,s2,800023a8 <procdump+0x8e>
    if(p->state == UNUSED)
    80002388:	86a6                	mv	a3,s1
    8000238a:	ec04a783          	lw	a5,-320(s1)
    8000238e:	dbed                	beqz	a5,80002380 <procdump+0x66>
      state = "???";
    80002390:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002392:	fcfb6fe3          	bltu	s6,a5,80002370 <procdump+0x56>
    80002396:	02079713          	slli	a4,a5,0x20
    8000239a:	01d75793          	srli	a5,a4,0x1d
    8000239e:	97de                	add	a5,a5,s7
    800023a0:	6390                	ld	a2,0(a5)
    800023a2:	f679                	bnez	a2,80002370 <procdump+0x56>
      state = "???";
    800023a4:	864e                	mv	a2,s3
    800023a6:	b7e9                	j	80002370 <procdump+0x56>
  }
}
    800023a8:	60a6                	ld	ra,72(sp)
    800023aa:	6406                	ld	s0,64(sp)
    800023ac:	74e2                	ld	s1,56(sp)
    800023ae:	7942                	ld	s2,48(sp)
    800023b0:	79a2                	ld	s3,40(sp)
    800023b2:	7a02                	ld	s4,32(sp)
    800023b4:	6ae2                	ld	s5,24(sp)
    800023b6:	6b42                	ld	s6,16(sp)
    800023b8:	6ba2                	ld	s7,8(sp)
    800023ba:	6161                	addi	sp,sp,80
    800023bc:	8082                	ret

00000000800023be <getfilenum>:

int getfilenum(int pid){
    800023be:	7179                	addi	sp,sp,-48
    800023c0:	f406                	sd	ra,40(sp)
    800023c2:	f022                	sd	s0,32(sp)
    800023c4:	ec26                	sd	s1,24(sp)
    800023c6:	e84a                	sd	s2,16(sp)
    800023c8:	e44e                	sd	s3,8(sp)
    800023ca:	1800                	addi	s0,sp,48
    800023cc:	892a                	mv	s2,a0
  struct proc *p;
  int count = 0;
  for (p=proc; p <&proc[NPROC];p++){
    800023ce:	0000e497          	auipc	s1,0xe
    800023d2:	9ca48493          	addi	s1,s1,-1590 # 8000fd98 <proc>
    800023d6:	00013997          	auipc	s3,0x13
    800023da:	3c298993          	addi	s3,s3,962 # 80015798 <tickslock>
    acquire(&p->lock);
    800023de:	8526                	mv	a0,s1
    800023e0:	849fe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    800023e4:	589c                	lw	a5,48(s1)
    800023e6:	01278b63          	beq	a5,s2,800023fc <getfilenum+0x3e>
        }
      }
      release(&p->lock);
      return count;
    }
    release(&p->lock);
    800023ea:	8526                	mv	a0,s1
    800023ec:	8d1fe0ef          	jal	80000cbc <release>
  for (p=proc; p <&proc[NPROC];p++){
    800023f0:	16848493          	addi	s1,s1,360
    800023f4:	ff3495e3          	bne	s1,s3,800023de <getfilenum+0x20>
  }
  return count;
    800023f8:	4901                	li	s2,0
    800023fa:	a00d                	j	8000241c <getfilenum+0x5e>
    800023fc:	0d048793          	addi	a5,s1,208
    80002400:	15048693          	addi	a3,s1,336
  int count = 0;
    80002404:	4901                	li	s2,0
    80002406:	a021                	j	8000240e <getfilenum+0x50>
      for(int i = 0; i<NOFILE; i++){
    80002408:	07a1                	addi	a5,a5,8
    8000240a:	00d78663          	beq	a5,a3,80002416 <getfilenum+0x58>
        if(p->ofile[i] != 0){
    8000240e:	6398                	ld	a4,0(a5)
    80002410:	df65                	beqz	a4,80002408 <getfilenum+0x4a>
          count++;
    80002412:	2905                	addiw	s2,s2,1
    80002414:	bfd5                	j	80002408 <getfilenum+0x4a>
      release(&p->lock);
    80002416:	8526                	mv	a0,s1
    80002418:	8a5fe0ef          	jal	80000cbc <release>
    8000241c:	854a                	mv	a0,s2
    8000241e:	70a2                	ld	ra,40(sp)
    80002420:	7402                	ld	s0,32(sp)
    80002422:	64e2                	ld	s1,24(sp)
    80002424:	6942                	ld	s2,16(sp)
    80002426:	69a2                	ld	s3,8(sp)
    80002428:	6145                	addi	sp,sp,48
    8000242a:	8082                	ret

000000008000242c <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000242c:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002430:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002434:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002436:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002438:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000243c:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002440:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002444:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002448:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    8000244c:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002450:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002454:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002458:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    8000245c:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002460:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002464:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002468:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    8000246a:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    8000246c:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002470:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002474:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002478:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    8000247c:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002480:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002484:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002488:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    8000248c:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002490:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002494:	8082                	ret

0000000080002496 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002496:	1141                	addi	sp,sp,-16
    80002498:	e406                	sd	ra,8(sp)
    8000249a:	e022                	sd	s0,0(sp)
    8000249c:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000249e:	00005597          	auipc	a1,0x5
    800024a2:	daa58593          	addi	a1,a1,-598 # 80007248 <etext+0x248>
    800024a6:	00013517          	auipc	a0,0x13
    800024aa:	2f250513          	addi	a0,a0,754 # 80015798 <tickslock>
    800024ae:	ef0fe0ef          	jal	80000b9e <initlock>
}
    800024b2:	60a2                	ld	ra,8(sp)
    800024b4:	6402                	ld	s0,0(sp)
    800024b6:	0141                	addi	sp,sp,16
    800024b8:	8082                	ret

00000000800024ba <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800024ba:	1141                	addi	sp,sp,-16
    800024bc:	e406                	sd	ra,8(sp)
    800024be:	e022                	sd	s0,0(sp)
    800024c0:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800024c2:	00003797          	auipc	a5,0x3
    800024c6:	fae78793          	addi	a5,a5,-82 # 80005470 <kernelvec>
    800024ca:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800024ce:	60a2                	ld	ra,8(sp)
    800024d0:	6402                	ld	s0,0(sp)
    800024d2:	0141                	addi	sp,sp,16
    800024d4:	8082                	ret

00000000800024d6 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800024d6:	1141                	addi	sp,sp,-16
    800024d8:	e406                	sd	ra,8(sp)
    800024da:	e022                	sd	s0,0(sp)
    800024dc:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800024de:	c50ff0ef          	jal	8000192e <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800024e2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800024e6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800024e8:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800024ec:	04000737          	lui	a4,0x4000
    800024f0:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024f2:	0732                	slli	a4,a4,0xc
    800024f4:	00004797          	auipc	a5,0x4
    800024f8:	b0c78793          	addi	a5,a5,-1268 # 80006000 <_trampoline>
    800024fc:	00004697          	auipc	a3,0x4
    80002500:	b0468693          	addi	a3,a3,-1276 # 80006000 <_trampoline>
    80002504:	8f95                	sub	a5,a5,a3
    80002506:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002508:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000250c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    8000250e:	18002773          	csrr	a4,satp
    80002512:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002514:	6d38                	ld	a4,88(a0)
    80002516:	613c                	ld	a5,64(a0)
    80002518:	6685                	lui	a3,0x1
    8000251a:	97b6                	add	a5,a5,a3
    8000251c:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000251e:	6d3c                	ld	a5,88(a0)
    80002520:	00000717          	auipc	a4,0x0
    80002524:	0fc70713          	addi	a4,a4,252 # 8000261c <usertrap>
    80002528:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    8000252a:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    8000252c:	8712                	mv	a4,tp
    8000252e:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002530:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002534:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002538:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000253c:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002540:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002542:	6f9c                	ld	a5,24(a5)
    80002544:	14179073          	csrw	sepc,a5
}
    80002548:	60a2                	ld	ra,8(sp)
    8000254a:	6402                	ld	s0,0(sp)
    8000254c:	0141                	addi	sp,sp,16
    8000254e:	8082                	ret

0000000080002550 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002550:	1141                	addi	sp,sp,-16
    80002552:	e406                	sd	ra,8(sp)
    80002554:	e022                	sd	s0,0(sp)
    80002556:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80002558:	ba2ff0ef          	jal	800018fa <cpuid>
    8000255c:	cd11                	beqz	a0,80002578 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    8000255e:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002562:	000f4737          	lui	a4,0xf4
    80002566:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000256a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    8000256c:	14d79073          	csrw	stimecmp,a5
}
    80002570:	60a2                	ld	ra,8(sp)
    80002572:	6402                	ld	s0,0(sp)
    80002574:	0141                	addi	sp,sp,16
    80002576:	8082                	ret
    acquire(&tickslock);
    80002578:	00013517          	auipc	a0,0x13
    8000257c:	22050513          	addi	a0,a0,544 # 80015798 <tickslock>
    80002580:	ea8fe0ef          	jal	80000c28 <acquire>
    ticks++;
    80002584:	00005717          	auipc	a4,0x5
    80002588:	2e470713          	addi	a4,a4,740 # 80007868 <ticks>
    8000258c:	431c                	lw	a5,0(a4)
    8000258e:	2785                	addiw	a5,a5,1
    80002590:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002592:	853a                	mv	a0,a4
    80002594:	9e5ff0ef          	jal	80001f78 <wakeup>
    release(&tickslock);
    80002598:	00013517          	auipc	a0,0x13
    8000259c:	20050513          	addi	a0,a0,512 # 80015798 <tickslock>
    800025a0:	f1cfe0ef          	jal	80000cbc <release>
    800025a4:	bf6d                	j	8000255e <clockintr+0xe>

00000000800025a6 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800025a6:	1101                	addi	sp,sp,-32
    800025a8:	ec06                	sd	ra,24(sp)
    800025aa:	e822                	sd	s0,16(sp)
    800025ac:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800025ae:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800025b2:	57fd                	li	a5,-1
    800025b4:	17fe                	slli	a5,a5,0x3f
    800025b6:	07a5                	addi	a5,a5,9
    800025b8:	00f70c63          	beq	a4,a5,800025d0 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    800025bc:	57fd                	li	a5,-1
    800025be:	17fe                	slli	a5,a5,0x3f
    800025c0:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800025c2:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    800025c4:	04f70863          	beq	a4,a5,80002614 <devintr+0x6e>
  }
}
    800025c8:	60e2                	ld	ra,24(sp)
    800025ca:	6442                	ld	s0,16(sp)
    800025cc:	6105                	addi	sp,sp,32
    800025ce:	8082                	ret
    800025d0:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800025d2:	74b020ef          	jal	8000551c <plic_claim>
    800025d6:	872a                	mv	a4,a0
    800025d8:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800025da:	47a9                	li	a5,10
    800025dc:	00f50963          	beq	a0,a5,800025ee <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    800025e0:	4785                	li	a5,1
    800025e2:	00f50963          	beq	a0,a5,800025f4 <devintr+0x4e>
    return 1;
    800025e6:	4505                	li	a0,1
    } else if(irq){
    800025e8:	eb09                	bnez	a4,800025fa <devintr+0x54>
    800025ea:	64a2                	ld	s1,8(sp)
    800025ec:	bff1                	j	800025c8 <devintr+0x22>
      uartintr();
    800025ee:	c06fe0ef          	jal	800009f4 <uartintr>
    if(irq)
    800025f2:	a819                	j	80002608 <devintr+0x62>
      virtio_disk_intr();
    800025f4:	3be030ef          	jal	800059b2 <virtio_disk_intr>
    if(irq)
    800025f8:	a801                	j	80002608 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800025fa:	85ba                	mv	a1,a4
    800025fc:	00005517          	auipc	a0,0x5
    80002600:	c5450513          	addi	a0,a0,-940 # 80007250 <etext+0x250>
    80002604:	ef7fd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    80002608:	8526                	mv	a0,s1
    8000260a:	733020ef          	jal	8000553c <plic_complete>
    return 1;
    8000260e:	4505                	li	a0,1
    80002610:	64a2                	ld	s1,8(sp)
    80002612:	bf5d                	j	800025c8 <devintr+0x22>
    clockintr();
    80002614:	f3dff0ef          	jal	80002550 <clockintr>
    return 2;
    80002618:	4509                	li	a0,2
    8000261a:	b77d                	j	800025c8 <devintr+0x22>

000000008000261c <usertrap>:
{
    8000261c:	1101                	addi	sp,sp,-32
    8000261e:	ec06                	sd	ra,24(sp)
    80002620:	e822                	sd	s0,16(sp)
    80002622:	e426                	sd	s1,8(sp)
    80002624:	e04a                	sd	s2,0(sp)
    80002626:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002628:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000262c:	1007f793          	andi	a5,a5,256
    80002630:	eba5                	bnez	a5,800026a0 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002632:	00003797          	auipc	a5,0x3
    80002636:	e3e78793          	addi	a5,a5,-450 # 80005470 <kernelvec>
    8000263a:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000263e:	af0ff0ef          	jal	8000192e <myproc>
    80002642:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002644:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002646:	14102773          	csrr	a4,sepc
    8000264a:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000264c:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80002650:	47a1                	li	a5,8
    80002652:	04f70d63          	beq	a4,a5,800026ac <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002656:	f51ff0ef          	jal	800025a6 <devintr>
    8000265a:	892a                	mv	s2,a0
    8000265c:	e945                	bnez	a0,8000270c <usertrap+0xf0>
    8000265e:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002662:	47bd                	li	a5,15
    80002664:	08f70863          	beq	a4,a5,800026f4 <usertrap+0xd8>
    80002668:	14202773          	csrr	a4,scause
    8000266c:	47b5                	li	a5,13
    8000266e:	08f70363          	beq	a4,a5,800026f4 <usertrap+0xd8>
    80002672:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002676:	5890                	lw	a2,48(s1)
    80002678:	00005517          	auipc	a0,0x5
    8000267c:	c1850513          	addi	a0,a0,-1000 # 80007290 <etext+0x290>
    80002680:	e7bfd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002684:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002688:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000268c:	00005517          	auipc	a0,0x5
    80002690:	c3450513          	addi	a0,a0,-972 # 800072c0 <etext+0x2c0>
    80002694:	e67fd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002698:	8526                	mv	a0,s1
    8000269a:	aabff0ef          	jal	80002144 <setkilled>
    8000269e:	a035                	j	800026ca <usertrap+0xae>
    panic("usertrap: not from user mode");
    800026a0:	00005517          	auipc	a0,0x5
    800026a4:	bd050513          	addi	a0,a0,-1072 # 80007270 <etext+0x270>
    800026a8:	97cfe0ef          	jal	80000824 <panic>
    if(killed(p))
    800026ac:	abdff0ef          	jal	80002168 <killed>
    800026b0:	ed15                	bnez	a0,800026ec <usertrap+0xd0>
    p->trapframe->epc += 4;
    800026b2:	6cb8                	ld	a4,88(s1)
    800026b4:	6f1c                	ld	a5,24(a4)
    800026b6:	0791                	addi	a5,a5,4
    800026b8:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026ba:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800026be:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800026c2:	10079073          	csrw	sstatus,a5
    syscall();
    800026c6:	240000ef          	jal	80002906 <syscall>
  if(killed(p))
    800026ca:	8526                	mv	a0,s1
    800026cc:	a9dff0ef          	jal	80002168 <killed>
    800026d0:	e139                	bnez	a0,80002716 <usertrap+0xfa>
  prepare_return();
    800026d2:	e05ff0ef          	jal	800024d6 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800026d6:	68a8                	ld	a0,80(s1)
    800026d8:	8131                	srli	a0,a0,0xc
    800026da:	57fd                	li	a5,-1
    800026dc:	17fe                	slli	a5,a5,0x3f
    800026de:	8d5d                	or	a0,a0,a5
}
    800026e0:	60e2                	ld	ra,24(sp)
    800026e2:	6442                	ld	s0,16(sp)
    800026e4:	64a2                	ld	s1,8(sp)
    800026e6:	6902                	ld	s2,0(sp)
    800026e8:	6105                	addi	sp,sp,32
    800026ea:	8082                	ret
      kexit(-1);
    800026ec:	557d                	li	a0,-1
    800026ee:	94bff0ef          	jal	80002038 <kexit>
    800026f2:	b7c1                	j	800026b2 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026f4:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026f8:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800026fc:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    800026fe:	00163613          	seqz	a2,a2
    80002702:	68a8                	ld	a0,80(s1)
    80002704:	ecdfe0ef          	jal	800015d0 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002708:	f169                	bnez	a0,800026ca <usertrap+0xae>
    8000270a:	b7a5                	j	80002672 <usertrap+0x56>
  if(killed(p))
    8000270c:	8526                	mv	a0,s1
    8000270e:	a5bff0ef          	jal	80002168 <killed>
    80002712:	c511                	beqz	a0,8000271e <usertrap+0x102>
    80002714:	a011                	j	80002718 <usertrap+0xfc>
    80002716:	4901                	li	s2,0
    kexit(-1);
    80002718:	557d                	li	a0,-1
    8000271a:	91fff0ef          	jal	80002038 <kexit>
  if(which_dev == 2)
    8000271e:	4789                	li	a5,2
    80002720:	faf919e3          	bne	s2,a5,800026d2 <usertrap+0xb6>
    yield();
    80002724:	fdcff0ef          	jal	80001f00 <yield>
    80002728:	b76d                	j	800026d2 <usertrap+0xb6>

000000008000272a <kerneltrap>:
{
    8000272a:	7179                	addi	sp,sp,-48
    8000272c:	f406                	sd	ra,40(sp)
    8000272e:	f022                	sd	s0,32(sp)
    80002730:	ec26                	sd	s1,24(sp)
    80002732:	e84a                	sd	s2,16(sp)
    80002734:	e44e                	sd	s3,8(sp)
    80002736:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002738:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000273c:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002740:	142027f3          	csrr	a5,scause
    80002744:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80002746:	1004f793          	andi	a5,s1,256
    8000274a:	c795                	beqz	a5,80002776 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000274c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002750:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002752:	eb85                	bnez	a5,80002782 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80002754:	e53ff0ef          	jal	800025a6 <devintr>
    80002758:	c91d                	beqz	a0,8000278e <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    8000275a:	4789                	li	a5,2
    8000275c:	04f50a63          	beq	a0,a5,800027b0 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002760:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002764:	10049073          	csrw	sstatus,s1
}
    80002768:	70a2                	ld	ra,40(sp)
    8000276a:	7402                	ld	s0,32(sp)
    8000276c:	64e2                	ld	s1,24(sp)
    8000276e:	6942                	ld	s2,16(sp)
    80002770:	69a2                	ld	s3,8(sp)
    80002772:	6145                	addi	sp,sp,48
    80002774:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002776:	00005517          	auipc	a0,0x5
    8000277a:	b7250513          	addi	a0,a0,-1166 # 800072e8 <etext+0x2e8>
    8000277e:	8a6fe0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    80002782:	00005517          	auipc	a0,0x5
    80002786:	b8e50513          	addi	a0,a0,-1138 # 80007310 <etext+0x310>
    8000278a:	89afe0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000278e:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002792:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002796:	85ce                	mv	a1,s3
    80002798:	00005517          	auipc	a0,0x5
    8000279c:	b9850513          	addi	a0,a0,-1128 # 80007330 <etext+0x330>
    800027a0:	d5bfd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    800027a4:	00005517          	auipc	a0,0x5
    800027a8:	bb450513          	addi	a0,a0,-1100 # 80007358 <etext+0x358>
    800027ac:	878fe0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    800027b0:	97eff0ef          	jal	8000192e <myproc>
    800027b4:	d555                	beqz	a0,80002760 <kerneltrap+0x36>
    yield();
    800027b6:	f4aff0ef          	jal	80001f00 <yield>
    800027ba:	b75d                	j	80002760 <kerneltrap+0x36>

00000000800027bc <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800027bc:	1101                	addi	sp,sp,-32
    800027be:	ec06                	sd	ra,24(sp)
    800027c0:	e822                	sd	s0,16(sp)
    800027c2:	e426                	sd	s1,8(sp)
    800027c4:	1000                	addi	s0,sp,32
    800027c6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800027c8:	966ff0ef          	jal	8000192e <myproc>
  switch (n) {
    800027cc:	4795                	li	a5,5
    800027ce:	0497e163          	bltu	a5,s1,80002810 <argraw+0x54>
    800027d2:	048a                	slli	s1,s1,0x2
    800027d4:	00005717          	auipc	a4,0x5
    800027d8:	f8470713          	addi	a4,a4,-124 # 80007758 <states.0+0x30>
    800027dc:	94ba                	add	s1,s1,a4
    800027de:	409c                	lw	a5,0(s1)
    800027e0:	97ba                	add	a5,a5,a4
    800027e2:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800027e4:	6d3c                	ld	a5,88(a0)
    800027e6:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800027e8:	60e2                	ld	ra,24(sp)
    800027ea:	6442                	ld	s0,16(sp)
    800027ec:	64a2                	ld	s1,8(sp)
    800027ee:	6105                	addi	sp,sp,32
    800027f0:	8082                	ret
    return p->trapframe->a1;
    800027f2:	6d3c                	ld	a5,88(a0)
    800027f4:	7fa8                	ld	a0,120(a5)
    800027f6:	bfcd                	j	800027e8 <argraw+0x2c>
    return p->trapframe->a2;
    800027f8:	6d3c                	ld	a5,88(a0)
    800027fa:	63c8                	ld	a0,128(a5)
    800027fc:	b7f5                	j	800027e8 <argraw+0x2c>
    return p->trapframe->a3;
    800027fe:	6d3c                	ld	a5,88(a0)
    80002800:	67c8                	ld	a0,136(a5)
    80002802:	b7dd                	j	800027e8 <argraw+0x2c>
    return p->trapframe->a4;
    80002804:	6d3c                	ld	a5,88(a0)
    80002806:	6bc8                	ld	a0,144(a5)
    80002808:	b7c5                	j	800027e8 <argraw+0x2c>
    return p->trapframe->a5;
    8000280a:	6d3c                	ld	a5,88(a0)
    8000280c:	6fc8                	ld	a0,152(a5)
    8000280e:	bfe9                	j	800027e8 <argraw+0x2c>
  panic("argraw");
    80002810:	00005517          	auipc	a0,0x5
    80002814:	b5850513          	addi	a0,a0,-1192 # 80007368 <etext+0x368>
    80002818:	80cfe0ef          	jal	80000824 <panic>

000000008000281c <fetchaddr>:
{
    8000281c:	1101                	addi	sp,sp,-32
    8000281e:	ec06                	sd	ra,24(sp)
    80002820:	e822                	sd	s0,16(sp)
    80002822:	e426                	sd	s1,8(sp)
    80002824:	e04a                	sd	s2,0(sp)
    80002826:	1000                	addi	s0,sp,32
    80002828:	84aa                	mv	s1,a0
    8000282a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000282c:	902ff0ef          	jal	8000192e <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002830:	653c                	ld	a5,72(a0)
    80002832:	02f4f663          	bgeu	s1,a5,8000285e <fetchaddr+0x42>
    80002836:	00848713          	addi	a4,s1,8
    8000283a:	02e7e463          	bltu	a5,a4,80002862 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000283e:	46a1                	li	a3,8
    80002840:	8626                	mv	a2,s1
    80002842:	85ca                	mv	a1,s2
    80002844:	6928                	ld	a0,80(a0)
    80002846:	ecdfe0ef          	jal	80001712 <copyin>
    8000284a:	00a03533          	snez	a0,a0
    8000284e:	40a0053b          	negw	a0,a0
}
    80002852:	60e2                	ld	ra,24(sp)
    80002854:	6442                	ld	s0,16(sp)
    80002856:	64a2                	ld	s1,8(sp)
    80002858:	6902                	ld	s2,0(sp)
    8000285a:	6105                	addi	sp,sp,32
    8000285c:	8082                	ret
    return -1;
    8000285e:	557d                	li	a0,-1
    80002860:	bfcd                	j	80002852 <fetchaddr+0x36>
    80002862:	557d                	li	a0,-1
    80002864:	b7fd                	j	80002852 <fetchaddr+0x36>

0000000080002866 <fetchstr>:
{
    80002866:	7179                	addi	sp,sp,-48
    80002868:	f406                	sd	ra,40(sp)
    8000286a:	f022                	sd	s0,32(sp)
    8000286c:	ec26                	sd	s1,24(sp)
    8000286e:	e84a                	sd	s2,16(sp)
    80002870:	e44e                	sd	s3,8(sp)
    80002872:	1800                	addi	s0,sp,48
    80002874:	89aa                	mv	s3,a0
    80002876:	84ae                	mv	s1,a1
    80002878:	8932                	mv	s2,a2
  struct proc *p = myproc();
    8000287a:	8b4ff0ef          	jal	8000192e <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    8000287e:	86ca                	mv	a3,s2
    80002880:	864e                	mv	a2,s3
    80002882:	85a6                	mv	a1,s1
    80002884:	6928                	ld	a0,80(a0)
    80002886:	c73fe0ef          	jal	800014f8 <copyinstr>
    8000288a:	00054c63          	bltz	a0,800028a2 <fetchstr+0x3c>
  return strlen(buf);
    8000288e:	8526                	mv	a0,s1
    80002890:	df2fe0ef          	jal	80000e82 <strlen>
}
    80002894:	70a2                	ld	ra,40(sp)
    80002896:	7402                	ld	s0,32(sp)
    80002898:	64e2                	ld	s1,24(sp)
    8000289a:	6942                	ld	s2,16(sp)
    8000289c:	69a2                	ld	s3,8(sp)
    8000289e:	6145                	addi	sp,sp,48
    800028a0:	8082                	ret
    return -1;
    800028a2:	557d                	li	a0,-1
    800028a4:	bfc5                	j	80002894 <fetchstr+0x2e>

00000000800028a6 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800028a6:	1101                	addi	sp,sp,-32
    800028a8:	ec06                	sd	ra,24(sp)
    800028aa:	e822                	sd	s0,16(sp)
    800028ac:	e426                	sd	s1,8(sp)
    800028ae:	1000                	addi	s0,sp,32
    800028b0:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028b2:	f0bff0ef          	jal	800027bc <argraw>
    800028b6:	c088                	sw	a0,0(s1)
}
    800028b8:	60e2                	ld	ra,24(sp)
    800028ba:	6442                	ld	s0,16(sp)
    800028bc:	64a2                	ld	s1,8(sp)
    800028be:	6105                	addi	sp,sp,32
    800028c0:	8082                	ret

00000000800028c2 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800028c2:	1101                	addi	sp,sp,-32
    800028c4:	ec06                	sd	ra,24(sp)
    800028c6:	e822                	sd	s0,16(sp)
    800028c8:	e426                	sd	s1,8(sp)
    800028ca:	1000                	addi	s0,sp,32
    800028cc:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028ce:	eefff0ef          	jal	800027bc <argraw>
    800028d2:	e088                	sd	a0,0(s1)
}
    800028d4:	60e2                	ld	ra,24(sp)
    800028d6:	6442                	ld	s0,16(sp)
    800028d8:	64a2                	ld	s1,8(sp)
    800028da:	6105                	addi	sp,sp,32
    800028dc:	8082                	ret

00000000800028de <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800028de:	1101                	addi	sp,sp,-32
    800028e0:	ec06                	sd	ra,24(sp)
    800028e2:	e822                	sd	s0,16(sp)
    800028e4:	e426                	sd	s1,8(sp)
    800028e6:	e04a                	sd	s2,0(sp)
    800028e8:	1000                	addi	s0,sp,32
    800028ea:	892e                	mv	s2,a1
    800028ec:	84b2                	mv	s1,a2
  *ip = argraw(n);
    800028ee:	ecfff0ef          	jal	800027bc <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    800028f2:	8626                	mv	a2,s1
    800028f4:	85ca                	mv	a1,s2
    800028f6:	f71ff0ef          	jal	80002866 <fetchstr>
}
    800028fa:	60e2                	ld	ra,24(sp)
    800028fc:	6442                	ld	s0,16(sp)
    800028fe:	64a2                	ld	s1,8(sp)
    80002900:	6902                	ld	s2,0(sp)
    80002902:	6105                	addi	sp,sp,32
    80002904:	8082                	ret

0000000080002906 <syscall>:
[SYS_getfilenum] sys_getfilenum,
};

void
syscall(void)
{
    80002906:	1101                	addi	sp,sp,-32
    80002908:	ec06                	sd	ra,24(sp)
    8000290a:	e822                	sd	s0,16(sp)
    8000290c:	e426                	sd	s1,8(sp)
    8000290e:	e04a                	sd	s2,0(sp)
    80002910:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002912:	81cff0ef          	jal	8000192e <myproc>
    80002916:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002918:	05853903          	ld	s2,88(a0)
    8000291c:	0a893783          	ld	a5,168(s2)
    80002920:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002924:	37fd                	addiw	a5,a5,-1
    80002926:	4755                	li	a4,21
    80002928:	00f76f63          	bltu	a4,a5,80002946 <syscall+0x40>
    8000292c:	00369713          	slli	a4,a3,0x3
    80002930:	00005797          	auipc	a5,0x5
    80002934:	e4078793          	addi	a5,a5,-448 # 80007770 <syscalls>
    80002938:	97ba                	add	a5,a5,a4
    8000293a:	639c                	ld	a5,0(a5)
    8000293c:	c789                	beqz	a5,80002946 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000293e:	9782                	jalr	a5
    80002940:	06a93823          	sd	a0,112(s2)
    80002944:	a829                	j	8000295e <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002946:	15848613          	addi	a2,s1,344
    8000294a:	588c                	lw	a1,48(s1)
    8000294c:	00005517          	auipc	a0,0x5
    80002950:	a2450513          	addi	a0,a0,-1500 # 80007370 <etext+0x370>
    80002954:	ba7fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002958:	6cbc                	ld	a5,88(s1)
    8000295a:	577d                	li	a4,-1
    8000295c:	fbb8                	sd	a4,112(a5)
  }
}
    8000295e:	60e2                	ld	ra,24(sp)
    80002960:	6442                	ld	s0,16(sp)
    80002962:	64a2                	ld	s1,8(sp)
    80002964:	6902                	ld	s2,0(sp)
    80002966:	6105                	addi	sp,sp,32
    80002968:	8082                	ret

000000008000296a <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    8000296a:	1101                	addi	sp,sp,-32
    8000296c:	ec06                	sd	ra,24(sp)
    8000296e:	e822                	sd	s0,16(sp)
    80002970:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002972:	fec40593          	addi	a1,s0,-20
    80002976:	4501                	li	a0,0
    80002978:	f2fff0ef          	jal	800028a6 <argint>
  kexit(n);
    8000297c:	fec42503          	lw	a0,-20(s0)
    80002980:	eb8ff0ef          	jal	80002038 <kexit>
  return 0;  // not reached
}
    80002984:	4501                	li	a0,0
    80002986:	60e2                	ld	ra,24(sp)
    80002988:	6442                	ld	s0,16(sp)
    8000298a:	6105                	addi	sp,sp,32
    8000298c:	8082                	ret

000000008000298e <sys_getpid>:

uint64
sys_getpid(void)
{
    8000298e:	1141                	addi	sp,sp,-16
    80002990:	e406                	sd	ra,8(sp)
    80002992:	e022                	sd	s0,0(sp)
    80002994:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002996:	f99fe0ef          	jal	8000192e <myproc>
}
    8000299a:	5908                	lw	a0,48(a0)
    8000299c:	60a2                	ld	ra,8(sp)
    8000299e:	6402                	ld	s0,0(sp)
    800029a0:	0141                	addi	sp,sp,16
    800029a2:	8082                	ret

00000000800029a4 <sys_fork>:

uint64
sys_fork(void)
{
    800029a4:	1141                	addi	sp,sp,-16
    800029a6:	e406                	sd	ra,8(sp)
    800029a8:	e022                	sd	s0,0(sp)
    800029aa:	0800                	addi	s0,sp,16
  return kfork();
    800029ac:	ad8ff0ef          	jal	80001c84 <kfork>
}
    800029b0:	60a2                	ld	ra,8(sp)
    800029b2:	6402                	ld	s0,0(sp)
    800029b4:	0141                	addi	sp,sp,16
    800029b6:	8082                	ret

00000000800029b8 <sys_wait>:

uint64
sys_wait(void)
{
    800029b8:	1101                	addi	sp,sp,-32
    800029ba:	ec06                	sd	ra,24(sp)
    800029bc:	e822                	sd	s0,16(sp)
    800029be:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800029c0:	fe840593          	addi	a1,s0,-24
    800029c4:	4501                	li	a0,0
    800029c6:	efdff0ef          	jal	800028c2 <argaddr>
  return kwait(p);
    800029ca:	fe843503          	ld	a0,-24(s0)
    800029ce:	fc4ff0ef          	jal	80002192 <kwait>
}
    800029d2:	60e2                	ld	ra,24(sp)
    800029d4:	6442                	ld	s0,16(sp)
    800029d6:	6105                	addi	sp,sp,32
    800029d8:	8082                	ret

00000000800029da <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800029da:	7179                	addi	sp,sp,-48
    800029dc:	f406                	sd	ra,40(sp)
    800029de:	f022                	sd	s0,32(sp)
    800029e0:	ec26                	sd	s1,24(sp)
    800029e2:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    800029e4:	fd840593          	addi	a1,s0,-40
    800029e8:	4501                	li	a0,0
    800029ea:	ebdff0ef          	jal	800028a6 <argint>
  argint(1, &t);
    800029ee:	fdc40593          	addi	a1,s0,-36
    800029f2:	4505                	li	a0,1
    800029f4:	eb3ff0ef          	jal	800028a6 <argint>
  addr = myproc()->sz;
    800029f8:	f37fe0ef          	jal	8000192e <myproc>
    800029fc:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    800029fe:	fdc42703          	lw	a4,-36(s0)
    80002a02:	4785                	li	a5,1
    80002a04:	02f70163          	beq	a4,a5,80002a26 <sys_sbrk+0x4c>
    80002a08:	fd842783          	lw	a5,-40(s0)
    80002a0c:	0007cd63          	bltz	a5,80002a26 <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002a10:	97a6                	add	a5,a5,s1
    80002a12:	0297e863          	bltu	a5,s1,80002a42 <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002a16:	f19fe0ef          	jal	8000192e <myproc>
    80002a1a:	fd842703          	lw	a4,-40(s0)
    80002a1e:	653c                	ld	a5,72(a0)
    80002a20:	97ba                	add	a5,a5,a4
    80002a22:	e53c                	sd	a5,72(a0)
    80002a24:	a039                	j	80002a32 <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002a26:	fd842503          	lw	a0,-40(s0)
    80002a2a:	a0aff0ef          	jal	80001c34 <growproc>
    80002a2e:	00054863          	bltz	a0,80002a3e <sys_sbrk+0x64>
  }
  return addr;
}
    80002a32:	8526                	mv	a0,s1
    80002a34:	70a2                	ld	ra,40(sp)
    80002a36:	7402                	ld	s0,32(sp)
    80002a38:	64e2                	ld	s1,24(sp)
    80002a3a:	6145                	addi	sp,sp,48
    80002a3c:	8082                	ret
      return -1;
    80002a3e:	54fd                	li	s1,-1
    80002a40:	bfcd                	j	80002a32 <sys_sbrk+0x58>
      return -1;
    80002a42:	54fd                	li	s1,-1
    80002a44:	b7fd                	j	80002a32 <sys_sbrk+0x58>

0000000080002a46 <sys_pause>:

uint64
sys_pause(void)
{
    80002a46:	7139                	addi	sp,sp,-64
    80002a48:	fc06                	sd	ra,56(sp)
    80002a4a:	f822                	sd	s0,48(sp)
    80002a4c:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a4e:	fcc40593          	addi	a1,s0,-52
    80002a52:	4501                	li	a0,0
    80002a54:	e53ff0ef          	jal	800028a6 <argint>
  if(n < 0)
    80002a58:	fcc42783          	lw	a5,-52(s0)
    80002a5c:	0607c863          	bltz	a5,80002acc <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002a60:	00013517          	auipc	a0,0x13
    80002a64:	d3850513          	addi	a0,a0,-712 # 80015798 <tickslock>
    80002a68:	9c0fe0ef          	jal	80000c28 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002a6c:	fcc42783          	lw	a5,-52(s0)
    80002a70:	c3b9                	beqz	a5,80002ab6 <sys_pause+0x70>
    80002a72:	f426                	sd	s1,40(sp)
    80002a74:	f04a                	sd	s2,32(sp)
    80002a76:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002a78:	00005997          	auipc	s3,0x5
    80002a7c:	df09a983          	lw	s3,-528(s3) # 80007868 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002a80:	00013917          	auipc	s2,0x13
    80002a84:	d1890913          	addi	s2,s2,-744 # 80015798 <tickslock>
    80002a88:	00005497          	auipc	s1,0x5
    80002a8c:	de048493          	addi	s1,s1,-544 # 80007868 <ticks>
    if(killed(myproc())){
    80002a90:	e9ffe0ef          	jal	8000192e <myproc>
    80002a94:	ed4ff0ef          	jal	80002168 <killed>
    80002a98:	ed0d                	bnez	a0,80002ad2 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002a9a:	85ca                	mv	a1,s2
    80002a9c:	8526                	mv	a0,s1
    80002a9e:	c8eff0ef          	jal	80001f2c <sleep>
  while(ticks - ticks0 < n){
    80002aa2:	409c                	lw	a5,0(s1)
    80002aa4:	413787bb          	subw	a5,a5,s3
    80002aa8:	fcc42703          	lw	a4,-52(s0)
    80002aac:	fee7e2e3          	bltu	a5,a4,80002a90 <sys_pause+0x4a>
    80002ab0:	74a2                	ld	s1,40(sp)
    80002ab2:	7902                	ld	s2,32(sp)
    80002ab4:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002ab6:	00013517          	auipc	a0,0x13
    80002aba:	ce250513          	addi	a0,a0,-798 # 80015798 <tickslock>
    80002abe:	9fefe0ef          	jal	80000cbc <release>
  return 0;
    80002ac2:	4501                	li	a0,0
}
    80002ac4:	70e2                	ld	ra,56(sp)
    80002ac6:	7442                	ld	s0,48(sp)
    80002ac8:	6121                	addi	sp,sp,64
    80002aca:	8082                	ret
    n = 0;
    80002acc:	fc042623          	sw	zero,-52(s0)
    80002ad0:	bf41                	j	80002a60 <sys_pause+0x1a>
      release(&tickslock);
    80002ad2:	00013517          	auipc	a0,0x13
    80002ad6:	cc650513          	addi	a0,a0,-826 # 80015798 <tickslock>
    80002ada:	9e2fe0ef          	jal	80000cbc <release>
      return -1;
    80002ade:	557d                	li	a0,-1
    80002ae0:	74a2                	ld	s1,40(sp)
    80002ae2:	7902                	ld	s2,32(sp)
    80002ae4:	69e2                	ld	s3,24(sp)
    80002ae6:	bff9                	j	80002ac4 <sys_pause+0x7e>

0000000080002ae8 <sys_kill>:

uint64
sys_kill(void)
{
    80002ae8:	1101                	addi	sp,sp,-32
    80002aea:	ec06                	sd	ra,24(sp)
    80002aec:	e822                	sd	s0,16(sp)
    80002aee:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002af0:	fec40593          	addi	a1,s0,-20
    80002af4:	4501                	li	a0,0
    80002af6:	db1ff0ef          	jal	800028a6 <argint>
  return kkill(pid);
    80002afa:	fec42503          	lw	a0,-20(s0)
    80002afe:	de0ff0ef          	jal	800020de <kkill>
}
    80002b02:	60e2                	ld	ra,24(sp)
    80002b04:	6442                	ld	s0,16(sp)
    80002b06:	6105                	addi	sp,sp,32
    80002b08:	8082                	ret

0000000080002b0a <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b0a:	1101                	addi	sp,sp,-32
    80002b0c:	ec06                	sd	ra,24(sp)
    80002b0e:	e822                	sd	s0,16(sp)
    80002b10:	e426                	sd	s1,8(sp)
    80002b12:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b14:	00013517          	auipc	a0,0x13
    80002b18:	c8450513          	addi	a0,a0,-892 # 80015798 <tickslock>
    80002b1c:	90cfe0ef          	jal	80000c28 <acquire>
  xticks = ticks;
    80002b20:	00005797          	auipc	a5,0x5
    80002b24:	d487a783          	lw	a5,-696(a5) # 80007868 <ticks>
    80002b28:	84be                	mv	s1,a5
  release(&tickslock);
    80002b2a:	00013517          	auipc	a0,0x13
    80002b2e:	c6e50513          	addi	a0,a0,-914 # 80015798 <tickslock>
    80002b32:	98afe0ef          	jal	80000cbc <release>
  return xticks;
}
    80002b36:	02049513          	slli	a0,s1,0x20
    80002b3a:	9101                	srli	a0,a0,0x20
    80002b3c:	60e2                	ld	ra,24(sp)
    80002b3e:	6442                	ld	s0,16(sp)
    80002b40:	64a2                	ld	s1,8(sp)
    80002b42:	6105                	addi	sp,sp,32
    80002b44:	8082                	ret

0000000080002b46 <sys_getfilenum>:

uint64 
sys_getfilenum(void){
    80002b46:	1101                	addi	sp,sp,-32
    80002b48:	ec06                	sd	ra,24(sp)
    80002b4a:	e822                	sd	s0,16(sp)
    80002b4c:	1000                	addi	s0,sp,32
  int pid;
  argint(0,&pid);
    80002b4e:	fec40593          	addi	a1,s0,-20
    80002b52:	4501                	li	a0,0
    80002b54:	d53ff0ef          	jal	800028a6 <argint>
  return 0;
    80002b58:	4501                	li	a0,0
    80002b5a:	60e2                	ld	ra,24(sp)
    80002b5c:	6442                	ld	s0,16(sp)
    80002b5e:	6105                	addi	sp,sp,32
    80002b60:	8082                	ret

0000000080002b62 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b62:	7179                	addi	sp,sp,-48
    80002b64:	f406                	sd	ra,40(sp)
    80002b66:	f022                	sd	s0,32(sp)
    80002b68:	ec26                	sd	s1,24(sp)
    80002b6a:	e84a                	sd	s2,16(sp)
    80002b6c:	e44e                	sd	s3,8(sp)
    80002b6e:	e052                	sd	s4,0(sp)
    80002b70:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b72:	00005597          	auipc	a1,0x5
    80002b76:	81e58593          	addi	a1,a1,-2018 # 80007390 <etext+0x390>
    80002b7a:	00013517          	auipc	a0,0x13
    80002b7e:	c3650513          	addi	a0,a0,-970 # 800157b0 <bcache>
    80002b82:	81cfe0ef          	jal	80000b9e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b86:	0001b797          	auipc	a5,0x1b
    80002b8a:	c2a78793          	addi	a5,a5,-982 # 8001d7b0 <bcache+0x8000>
    80002b8e:	0001b717          	auipc	a4,0x1b
    80002b92:	e8a70713          	addi	a4,a4,-374 # 8001da18 <bcache+0x8268>
    80002b96:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002b9a:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002b9e:	00013497          	auipc	s1,0x13
    80002ba2:	c2a48493          	addi	s1,s1,-982 # 800157c8 <bcache+0x18>
    b->next = bcache.head.next;
    80002ba6:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002ba8:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002baa:	00004a17          	auipc	s4,0x4
    80002bae:	7eea0a13          	addi	s4,s4,2030 # 80007398 <etext+0x398>
    b->next = bcache.head.next;
    80002bb2:	2b893783          	ld	a5,696(s2)
    80002bb6:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002bb8:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002bbc:	85d2                	mv	a1,s4
    80002bbe:	01048513          	addi	a0,s1,16
    80002bc2:	328010ef          	jal	80003eea <initsleeplock>
    bcache.head.next->prev = b;
    80002bc6:	2b893783          	ld	a5,696(s2)
    80002bca:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002bcc:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002bd0:	45848493          	addi	s1,s1,1112
    80002bd4:	fd349fe3          	bne	s1,s3,80002bb2 <binit+0x50>
  }
}
    80002bd8:	70a2                	ld	ra,40(sp)
    80002bda:	7402                	ld	s0,32(sp)
    80002bdc:	64e2                	ld	s1,24(sp)
    80002bde:	6942                	ld	s2,16(sp)
    80002be0:	69a2                	ld	s3,8(sp)
    80002be2:	6a02                	ld	s4,0(sp)
    80002be4:	6145                	addi	sp,sp,48
    80002be6:	8082                	ret

0000000080002be8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002be8:	7179                	addi	sp,sp,-48
    80002bea:	f406                	sd	ra,40(sp)
    80002bec:	f022                	sd	s0,32(sp)
    80002bee:	ec26                	sd	s1,24(sp)
    80002bf0:	e84a                	sd	s2,16(sp)
    80002bf2:	e44e                	sd	s3,8(sp)
    80002bf4:	1800                	addi	s0,sp,48
    80002bf6:	892a                	mv	s2,a0
    80002bf8:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002bfa:	00013517          	auipc	a0,0x13
    80002bfe:	bb650513          	addi	a0,a0,-1098 # 800157b0 <bcache>
    80002c02:	826fe0ef          	jal	80000c28 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002c06:	0001b497          	auipc	s1,0x1b
    80002c0a:	e624b483          	ld	s1,-414(s1) # 8001da68 <bcache+0x82b8>
    80002c0e:	0001b797          	auipc	a5,0x1b
    80002c12:	e0a78793          	addi	a5,a5,-502 # 8001da18 <bcache+0x8268>
    80002c16:	02f48b63          	beq	s1,a5,80002c4c <bread+0x64>
    80002c1a:	873e                	mv	a4,a5
    80002c1c:	a021                	j	80002c24 <bread+0x3c>
    80002c1e:	68a4                	ld	s1,80(s1)
    80002c20:	02e48663          	beq	s1,a4,80002c4c <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002c24:	449c                	lw	a5,8(s1)
    80002c26:	ff279ce3          	bne	a5,s2,80002c1e <bread+0x36>
    80002c2a:	44dc                	lw	a5,12(s1)
    80002c2c:	ff3799e3          	bne	a5,s3,80002c1e <bread+0x36>
      b->refcnt++;
    80002c30:	40bc                	lw	a5,64(s1)
    80002c32:	2785                	addiw	a5,a5,1
    80002c34:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c36:	00013517          	auipc	a0,0x13
    80002c3a:	b7a50513          	addi	a0,a0,-1158 # 800157b0 <bcache>
    80002c3e:	87efe0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002c42:	01048513          	addi	a0,s1,16
    80002c46:	2da010ef          	jal	80003f20 <acquiresleep>
      return b;
    80002c4a:	a889                	j	80002c9c <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c4c:	0001b497          	auipc	s1,0x1b
    80002c50:	e144b483          	ld	s1,-492(s1) # 8001da60 <bcache+0x82b0>
    80002c54:	0001b797          	auipc	a5,0x1b
    80002c58:	dc478793          	addi	a5,a5,-572 # 8001da18 <bcache+0x8268>
    80002c5c:	00f48863          	beq	s1,a5,80002c6c <bread+0x84>
    80002c60:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002c62:	40bc                	lw	a5,64(s1)
    80002c64:	cb91                	beqz	a5,80002c78 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c66:	64a4                	ld	s1,72(s1)
    80002c68:	fee49de3          	bne	s1,a4,80002c62 <bread+0x7a>
  panic("bget: no buffers");
    80002c6c:	00004517          	auipc	a0,0x4
    80002c70:	73450513          	addi	a0,a0,1844 # 800073a0 <etext+0x3a0>
    80002c74:	bb1fd0ef          	jal	80000824 <panic>
      b->dev = dev;
    80002c78:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c7c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c80:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c84:	4785                	li	a5,1
    80002c86:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c88:	00013517          	auipc	a0,0x13
    80002c8c:	b2850513          	addi	a0,a0,-1240 # 800157b0 <bcache>
    80002c90:	82cfe0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002c94:	01048513          	addi	a0,s1,16
    80002c98:	288010ef          	jal	80003f20 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002c9c:	409c                	lw	a5,0(s1)
    80002c9e:	cb89                	beqz	a5,80002cb0 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ca0:	8526                	mv	a0,s1
    80002ca2:	70a2                	ld	ra,40(sp)
    80002ca4:	7402                	ld	s0,32(sp)
    80002ca6:	64e2                	ld	s1,24(sp)
    80002ca8:	6942                	ld	s2,16(sp)
    80002caa:	69a2                	ld	s3,8(sp)
    80002cac:	6145                	addi	sp,sp,48
    80002cae:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cb0:	4581                	li	a1,0
    80002cb2:	8526                	mv	a0,s1
    80002cb4:	2ed020ef          	jal	800057a0 <virtio_disk_rw>
    b->valid = 1;
    80002cb8:	4785                	li	a5,1
    80002cba:	c09c                	sw	a5,0(s1)
  return b;
    80002cbc:	b7d5                	j	80002ca0 <bread+0xb8>

0000000080002cbe <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002cbe:	1101                	addi	sp,sp,-32
    80002cc0:	ec06                	sd	ra,24(sp)
    80002cc2:	e822                	sd	s0,16(sp)
    80002cc4:	e426                	sd	s1,8(sp)
    80002cc6:	1000                	addi	s0,sp,32
    80002cc8:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002cca:	0541                	addi	a0,a0,16
    80002ccc:	2d2010ef          	jal	80003f9e <holdingsleep>
    80002cd0:	c911                	beqz	a0,80002ce4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002cd2:	4585                	li	a1,1
    80002cd4:	8526                	mv	a0,s1
    80002cd6:	2cb020ef          	jal	800057a0 <virtio_disk_rw>
}
    80002cda:	60e2                	ld	ra,24(sp)
    80002cdc:	6442                	ld	s0,16(sp)
    80002cde:	64a2                	ld	s1,8(sp)
    80002ce0:	6105                	addi	sp,sp,32
    80002ce2:	8082                	ret
    panic("bwrite");
    80002ce4:	00004517          	auipc	a0,0x4
    80002ce8:	6d450513          	addi	a0,a0,1748 # 800073b8 <etext+0x3b8>
    80002cec:	b39fd0ef          	jal	80000824 <panic>

0000000080002cf0 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002cf0:	1101                	addi	sp,sp,-32
    80002cf2:	ec06                	sd	ra,24(sp)
    80002cf4:	e822                	sd	s0,16(sp)
    80002cf6:	e426                	sd	s1,8(sp)
    80002cf8:	e04a                	sd	s2,0(sp)
    80002cfa:	1000                	addi	s0,sp,32
    80002cfc:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002cfe:	01050913          	addi	s2,a0,16
    80002d02:	854a                	mv	a0,s2
    80002d04:	29a010ef          	jal	80003f9e <holdingsleep>
    80002d08:	c125                	beqz	a0,80002d68 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002d0a:	854a                	mv	a0,s2
    80002d0c:	25a010ef          	jal	80003f66 <releasesleep>

  acquire(&bcache.lock);
    80002d10:	00013517          	auipc	a0,0x13
    80002d14:	aa050513          	addi	a0,a0,-1376 # 800157b0 <bcache>
    80002d18:	f11fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002d1c:	40bc                	lw	a5,64(s1)
    80002d1e:	37fd                	addiw	a5,a5,-1
    80002d20:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d22:	e79d                	bnez	a5,80002d50 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d24:	68b8                	ld	a4,80(s1)
    80002d26:	64bc                	ld	a5,72(s1)
    80002d28:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d2a:	68b8                	ld	a4,80(s1)
    80002d2c:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d2e:	0001b797          	auipc	a5,0x1b
    80002d32:	a8278793          	addi	a5,a5,-1406 # 8001d7b0 <bcache+0x8000>
    80002d36:	2b87b703          	ld	a4,696(a5)
    80002d3a:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d3c:	0001b717          	auipc	a4,0x1b
    80002d40:	cdc70713          	addi	a4,a4,-804 # 8001da18 <bcache+0x8268>
    80002d44:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d46:	2b87b703          	ld	a4,696(a5)
    80002d4a:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d4c:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002d50:	00013517          	auipc	a0,0x13
    80002d54:	a6050513          	addi	a0,a0,-1440 # 800157b0 <bcache>
    80002d58:	f65fd0ef          	jal	80000cbc <release>
}
    80002d5c:	60e2                	ld	ra,24(sp)
    80002d5e:	6442                	ld	s0,16(sp)
    80002d60:	64a2                	ld	s1,8(sp)
    80002d62:	6902                	ld	s2,0(sp)
    80002d64:	6105                	addi	sp,sp,32
    80002d66:	8082                	ret
    panic("brelse");
    80002d68:	00004517          	auipc	a0,0x4
    80002d6c:	65850513          	addi	a0,a0,1624 # 800073c0 <etext+0x3c0>
    80002d70:	ab5fd0ef          	jal	80000824 <panic>

0000000080002d74 <bpin>:

void
bpin(struct buf *b) {
    80002d74:	1101                	addi	sp,sp,-32
    80002d76:	ec06                	sd	ra,24(sp)
    80002d78:	e822                	sd	s0,16(sp)
    80002d7a:	e426                	sd	s1,8(sp)
    80002d7c:	1000                	addi	s0,sp,32
    80002d7e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d80:	00013517          	auipc	a0,0x13
    80002d84:	a3050513          	addi	a0,a0,-1488 # 800157b0 <bcache>
    80002d88:	ea1fd0ef          	jal	80000c28 <acquire>
  b->refcnt++;
    80002d8c:	40bc                	lw	a5,64(s1)
    80002d8e:	2785                	addiw	a5,a5,1
    80002d90:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d92:	00013517          	auipc	a0,0x13
    80002d96:	a1e50513          	addi	a0,a0,-1506 # 800157b0 <bcache>
    80002d9a:	f23fd0ef          	jal	80000cbc <release>
}
    80002d9e:	60e2                	ld	ra,24(sp)
    80002da0:	6442                	ld	s0,16(sp)
    80002da2:	64a2                	ld	s1,8(sp)
    80002da4:	6105                	addi	sp,sp,32
    80002da6:	8082                	ret

0000000080002da8 <bunpin>:

void
bunpin(struct buf *b) {
    80002da8:	1101                	addi	sp,sp,-32
    80002daa:	ec06                	sd	ra,24(sp)
    80002dac:	e822                	sd	s0,16(sp)
    80002dae:	e426                	sd	s1,8(sp)
    80002db0:	1000                	addi	s0,sp,32
    80002db2:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002db4:	00013517          	auipc	a0,0x13
    80002db8:	9fc50513          	addi	a0,a0,-1540 # 800157b0 <bcache>
    80002dbc:	e6dfd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002dc0:	40bc                	lw	a5,64(s1)
    80002dc2:	37fd                	addiw	a5,a5,-1
    80002dc4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dc6:	00013517          	auipc	a0,0x13
    80002dca:	9ea50513          	addi	a0,a0,-1558 # 800157b0 <bcache>
    80002dce:	eeffd0ef          	jal	80000cbc <release>
}
    80002dd2:	60e2                	ld	ra,24(sp)
    80002dd4:	6442                	ld	s0,16(sp)
    80002dd6:	64a2                	ld	s1,8(sp)
    80002dd8:	6105                	addi	sp,sp,32
    80002dda:	8082                	ret

0000000080002ddc <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002ddc:	1101                	addi	sp,sp,-32
    80002dde:	ec06                	sd	ra,24(sp)
    80002de0:	e822                	sd	s0,16(sp)
    80002de2:	e426                	sd	s1,8(sp)
    80002de4:	e04a                	sd	s2,0(sp)
    80002de6:	1000                	addi	s0,sp,32
    80002de8:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002dea:	00d5d79b          	srliw	a5,a1,0xd
    80002dee:	0001b597          	auipc	a1,0x1b
    80002df2:	09e5a583          	lw	a1,158(a1) # 8001de8c <sb+0x1c>
    80002df6:	9dbd                	addw	a1,a1,a5
    80002df8:	df1ff0ef          	jal	80002be8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002dfc:	0074f713          	andi	a4,s1,7
    80002e00:	4785                	li	a5,1
    80002e02:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002e06:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002e08:	90d9                	srli	s1,s1,0x36
    80002e0a:	00950733          	add	a4,a0,s1
    80002e0e:	05874703          	lbu	a4,88(a4)
    80002e12:	00e7f6b3          	and	a3,a5,a4
    80002e16:	c29d                	beqz	a3,80002e3c <bfree+0x60>
    80002e18:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002e1a:	94aa                	add	s1,s1,a0
    80002e1c:	fff7c793          	not	a5,a5
    80002e20:	8f7d                	and	a4,a4,a5
    80002e22:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e26:	000010ef          	jal	80003e26 <log_write>
  brelse(bp);
    80002e2a:	854a                	mv	a0,s2
    80002e2c:	ec5ff0ef          	jal	80002cf0 <brelse>
}
    80002e30:	60e2                	ld	ra,24(sp)
    80002e32:	6442                	ld	s0,16(sp)
    80002e34:	64a2                	ld	s1,8(sp)
    80002e36:	6902                	ld	s2,0(sp)
    80002e38:	6105                	addi	sp,sp,32
    80002e3a:	8082                	ret
    panic("freeing free block");
    80002e3c:	00004517          	auipc	a0,0x4
    80002e40:	58c50513          	addi	a0,a0,1420 # 800073c8 <etext+0x3c8>
    80002e44:	9e1fd0ef          	jal	80000824 <panic>

0000000080002e48 <balloc>:
{
    80002e48:	715d                	addi	sp,sp,-80
    80002e4a:	e486                	sd	ra,72(sp)
    80002e4c:	e0a2                	sd	s0,64(sp)
    80002e4e:	fc26                	sd	s1,56(sp)
    80002e50:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002e52:	0001b797          	auipc	a5,0x1b
    80002e56:	0227a783          	lw	a5,34(a5) # 8001de74 <sb+0x4>
    80002e5a:	0e078263          	beqz	a5,80002f3e <balloc+0xf6>
    80002e5e:	f84a                	sd	s2,48(sp)
    80002e60:	f44e                	sd	s3,40(sp)
    80002e62:	f052                	sd	s4,32(sp)
    80002e64:	ec56                	sd	s5,24(sp)
    80002e66:	e85a                	sd	s6,16(sp)
    80002e68:	e45e                	sd	s7,8(sp)
    80002e6a:	e062                	sd	s8,0(sp)
    80002e6c:	8baa                	mv	s7,a0
    80002e6e:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e70:	0001bb17          	auipc	s6,0x1b
    80002e74:	000b0b13          	mv	s6,s6
      m = 1 << (bi % 8);
    80002e78:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e7a:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002e7c:	6c09                	lui	s8,0x2
    80002e7e:	a09d                	j	80002ee4 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002e80:	97ca                	add	a5,a5,s2
    80002e82:	8e55                	or	a2,a2,a3
    80002e84:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002e88:	854a                	mv	a0,s2
    80002e8a:	79d000ef          	jal	80003e26 <log_write>
        brelse(bp);
    80002e8e:	854a                	mv	a0,s2
    80002e90:	e61ff0ef          	jal	80002cf0 <brelse>
  bp = bread(dev, bno);
    80002e94:	85a6                	mv	a1,s1
    80002e96:	855e                	mv	a0,s7
    80002e98:	d51ff0ef          	jal	80002be8 <bread>
    80002e9c:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002e9e:	40000613          	li	a2,1024
    80002ea2:	4581                	li	a1,0
    80002ea4:	05850513          	addi	a0,a0,88
    80002ea8:	e51fd0ef          	jal	80000cf8 <memset>
  log_write(bp);
    80002eac:	854a                	mv	a0,s2
    80002eae:	779000ef          	jal	80003e26 <log_write>
  brelse(bp);
    80002eb2:	854a                	mv	a0,s2
    80002eb4:	e3dff0ef          	jal	80002cf0 <brelse>
}
    80002eb8:	7942                	ld	s2,48(sp)
    80002eba:	79a2                	ld	s3,40(sp)
    80002ebc:	7a02                	ld	s4,32(sp)
    80002ebe:	6ae2                	ld	s5,24(sp)
    80002ec0:	6b42                	ld	s6,16(sp)
    80002ec2:	6ba2                	ld	s7,8(sp)
    80002ec4:	6c02                	ld	s8,0(sp)
}
    80002ec6:	8526                	mv	a0,s1
    80002ec8:	60a6                	ld	ra,72(sp)
    80002eca:	6406                	ld	s0,64(sp)
    80002ecc:	74e2                	ld	s1,56(sp)
    80002ece:	6161                	addi	sp,sp,80
    80002ed0:	8082                	ret
    brelse(bp);
    80002ed2:	854a                	mv	a0,s2
    80002ed4:	e1dff0ef          	jal	80002cf0 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002ed8:	015c0abb          	addw	s5,s8,s5
    80002edc:	004b2783          	lw	a5,4(s6) # 8001de74 <sb+0x4>
    80002ee0:	04faf863          	bgeu	s5,a5,80002f30 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002ee4:	40dad59b          	sraiw	a1,s5,0xd
    80002ee8:	01cb2783          	lw	a5,28(s6)
    80002eec:	9dbd                	addw	a1,a1,a5
    80002eee:	855e                	mv	a0,s7
    80002ef0:	cf9ff0ef          	jal	80002be8 <bread>
    80002ef4:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002ef6:	004b2503          	lw	a0,4(s6)
    80002efa:	84d6                	mv	s1,s5
    80002efc:	4701                	li	a4,0
    80002efe:	fca4fae3          	bgeu	s1,a0,80002ed2 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f02:	00777693          	andi	a3,a4,7
    80002f06:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002f0a:	41f7579b          	sraiw	a5,a4,0x1f
    80002f0e:	01d7d79b          	srliw	a5,a5,0x1d
    80002f12:	9fb9                	addw	a5,a5,a4
    80002f14:	4037d79b          	sraiw	a5,a5,0x3
    80002f18:	00f90633          	add	a2,s2,a5
    80002f1c:	05864603          	lbu	a2,88(a2)
    80002f20:	00c6f5b3          	and	a1,a3,a2
    80002f24:	ddb1                	beqz	a1,80002e80 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f26:	2705                	addiw	a4,a4,1
    80002f28:	2485                	addiw	s1,s1,1
    80002f2a:	fd471ae3          	bne	a4,s4,80002efe <balloc+0xb6>
    80002f2e:	b755                	j	80002ed2 <balloc+0x8a>
    80002f30:	7942                	ld	s2,48(sp)
    80002f32:	79a2                	ld	s3,40(sp)
    80002f34:	7a02                	ld	s4,32(sp)
    80002f36:	6ae2                	ld	s5,24(sp)
    80002f38:	6b42                	ld	s6,16(sp)
    80002f3a:	6ba2                	ld	s7,8(sp)
    80002f3c:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002f3e:	00004517          	auipc	a0,0x4
    80002f42:	4a250513          	addi	a0,a0,1186 # 800073e0 <etext+0x3e0>
    80002f46:	db4fd0ef          	jal	800004fa <printf>
  return 0;
    80002f4a:	4481                	li	s1,0
    80002f4c:	bfad                	j	80002ec6 <balloc+0x7e>

0000000080002f4e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f4e:	7179                	addi	sp,sp,-48
    80002f50:	f406                	sd	ra,40(sp)
    80002f52:	f022                	sd	s0,32(sp)
    80002f54:	ec26                	sd	s1,24(sp)
    80002f56:	e84a                	sd	s2,16(sp)
    80002f58:	e44e                	sd	s3,8(sp)
    80002f5a:	1800                	addi	s0,sp,48
    80002f5c:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002f5e:	47ad                	li	a5,11
    80002f60:	02b7e363          	bltu	a5,a1,80002f86 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002f64:	02059793          	slli	a5,a1,0x20
    80002f68:	01e7d593          	srli	a1,a5,0x1e
    80002f6c:	00b509b3          	add	s3,a0,a1
    80002f70:	0509a483          	lw	s1,80(s3)
    80002f74:	e0b5                	bnez	s1,80002fd8 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002f76:	4108                	lw	a0,0(a0)
    80002f78:	ed1ff0ef          	jal	80002e48 <balloc>
    80002f7c:	84aa                	mv	s1,a0
      if(addr == 0)
    80002f7e:	cd29                	beqz	a0,80002fd8 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002f80:	04a9a823          	sw	a0,80(s3)
    80002f84:	a891                	j	80002fd8 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002f86:	ff45879b          	addiw	a5,a1,-12
    80002f8a:	873e                	mv	a4,a5
    80002f8c:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002f8e:	0ff00793          	li	a5,255
    80002f92:	06e7e763          	bltu	a5,a4,80003000 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002f96:	08052483          	lw	s1,128(a0)
    80002f9a:	e891                	bnez	s1,80002fae <bmap+0x60>
      addr = balloc(ip->dev);
    80002f9c:	4108                	lw	a0,0(a0)
    80002f9e:	eabff0ef          	jal	80002e48 <balloc>
    80002fa2:	84aa                	mv	s1,a0
      if(addr == 0)
    80002fa4:	c915                	beqz	a0,80002fd8 <bmap+0x8a>
    80002fa6:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002fa8:	08a92023          	sw	a0,128(s2)
    80002fac:	a011                	j	80002fb0 <bmap+0x62>
    80002fae:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002fb0:	85a6                	mv	a1,s1
    80002fb2:	00092503          	lw	a0,0(s2)
    80002fb6:	c33ff0ef          	jal	80002be8 <bread>
    80002fba:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002fbc:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002fc0:	02099713          	slli	a4,s3,0x20
    80002fc4:	01e75593          	srli	a1,a4,0x1e
    80002fc8:	97ae                	add	a5,a5,a1
    80002fca:	89be                	mv	s3,a5
    80002fcc:	4384                	lw	s1,0(a5)
    80002fce:	cc89                	beqz	s1,80002fe8 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002fd0:	8552                	mv	a0,s4
    80002fd2:	d1fff0ef          	jal	80002cf0 <brelse>
    return addr;
    80002fd6:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002fd8:	8526                	mv	a0,s1
    80002fda:	70a2                	ld	ra,40(sp)
    80002fdc:	7402                	ld	s0,32(sp)
    80002fde:	64e2                	ld	s1,24(sp)
    80002fe0:	6942                	ld	s2,16(sp)
    80002fe2:	69a2                	ld	s3,8(sp)
    80002fe4:	6145                	addi	sp,sp,48
    80002fe6:	8082                	ret
      addr = balloc(ip->dev);
    80002fe8:	00092503          	lw	a0,0(s2)
    80002fec:	e5dff0ef          	jal	80002e48 <balloc>
    80002ff0:	84aa                	mv	s1,a0
      if(addr){
    80002ff2:	dd79                	beqz	a0,80002fd0 <bmap+0x82>
        a[bn] = addr;
    80002ff4:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002ff8:	8552                	mv	a0,s4
    80002ffa:	62d000ef          	jal	80003e26 <log_write>
    80002ffe:	bfc9                	j	80002fd0 <bmap+0x82>
    80003000:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003002:	00004517          	auipc	a0,0x4
    80003006:	3f650513          	addi	a0,a0,1014 # 800073f8 <etext+0x3f8>
    8000300a:	81bfd0ef          	jal	80000824 <panic>

000000008000300e <iget>:
{
    8000300e:	7179                	addi	sp,sp,-48
    80003010:	f406                	sd	ra,40(sp)
    80003012:	f022                	sd	s0,32(sp)
    80003014:	ec26                	sd	s1,24(sp)
    80003016:	e84a                	sd	s2,16(sp)
    80003018:	e44e                	sd	s3,8(sp)
    8000301a:	e052                	sd	s4,0(sp)
    8000301c:	1800                	addi	s0,sp,48
    8000301e:	892a                	mv	s2,a0
    80003020:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003022:	0001b517          	auipc	a0,0x1b
    80003026:	e6e50513          	addi	a0,a0,-402 # 8001de90 <itable>
    8000302a:	bfffd0ef          	jal	80000c28 <acquire>
  empty = 0;
    8000302e:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003030:	0001b497          	auipc	s1,0x1b
    80003034:	e7848493          	addi	s1,s1,-392 # 8001dea8 <itable+0x18>
    80003038:	0001d697          	auipc	a3,0x1d
    8000303c:	90068693          	addi	a3,a3,-1792 # 8001f938 <log>
    80003040:	a809                	j	80003052 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003042:	e781                	bnez	a5,8000304a <iget+0x3c>
    80003044:	00099363          	bnez	s3,8000304a <iget+0x3c>
      empty = ip;
    80003048:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000304a:	08848493          	addi	s1,s1,136
    8000304e:	02d48563          	beq	s1,a3,80003078 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003052:	449c                	lw	a5,8(s1)
    80003054:	fef057e3          	blez	a5,80003042 <iget+0x34>
    80003058:	4098                	lw	a4,0(s1)
    8000305a:	ff2718e3          	bne	a4,s2,8000304a <iget+0x3c>
    8000305e:	40d8                	lw	a4,4(s1)
    80003060:	ff4715e3          	bne	a4,s4,8000304a <iget+0x3c>
      ip->ref++;
    80003064:	2785                	addiw	a5,a5,1
    80003066:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003068:	0001b517          	auipc	a0,0x1b
    8000306c:	e2850513          	addi	a0,a0,-472 # 8001de90 <itable>
    80003070:	c4dfd0ef          	jal	80000cbc <release>
      return ip;
    80003074:	89a6                	mv	s3,s1
    80003076:	a015                	j	8000309a <iget+0x8c>
  if(empty == 0)
    80003078:	02098a63          	beqz	s3,800030ac <iget+0x9e>
  ip->dev = dev;
    8000307c:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80003080:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80003084:	4785                	li	a5,1
    80003086:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    8000308a:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000308e:	0001b517          	auipc	a0,0x1b
    80003092:	e0250513          	addi	a0,a0,-510 # 8001de90 <itable>
    80003096:	c27fd0ef          	jal	80000cbc <release>
}
    8000309a:	854e                	mv	a0,s3
    8000309c:	70a2                	ld	ra,40(sp)
    8000309e:	7402                	ld	s0,32(sp)
    800030a0:	64e2                	ld	s1,24(sp)
    800030a2:	6942                	ld	s2,16(sp)
    800030a4:	69a2                	ld	s3,8(sp)
    800030a6:	6a02                	ld	s4,0(sp)
    800030a8:	6145                	addi	sp,sp,48
    800030aa:	8082                	ret
    panic("iget: no inodes");
    800030ac:	00004517          	auipc	a0,0x4
    800030b0:	36450513          	addi	a0,a0,868 # 80007410 <etext+0x410>
    800030b4:	f70fd0ef          	jal	80000824 <panic>

00000000800030b8 <iinit>:
{
    800030b8:	7179                	addi	sp,sp,-48
    800030ba:	f406                	sd	ra,40(sp)
    800030bc:	f022                	sd	s0,32(sp)
    800030be:	ec26                	sd	s1,24(sp)
    800030c0:	e84a                	sd	s2,16(sp)
    800030c2:	e44e                	sd	s3,8(sp)
    800030c4:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800030c6:	00004597          	auipc	a1,0x4
    800030ca:	35a58593          	addi	a1,a1,858 # 80007420 <etext+0x420>
    800030ce:	0001b517          	auipc	a0,0x1b
    800030d2:	dc250513          	addi	a0,a0,-574 # 8001de90 <itable>
    800030d6:	ac9fd0ef          	jal	80000b9e <initlock>
  for(i = 0; i < NINODE; i++) {
    800030da:	0001b497          	auipc	s1,0x1b
    800030de:	dde48493          	addi	s1,s1,-546 # 8001deb8 <itable+0x28>
    800030e2:	0001d997          	auipc	s3,0x1d
    800030e6:	86698993          	addi	s3,s3,-1946 # 8001f948 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800030ea:	00004917          	auipc	s2,0x4
    800030ee:	33e90913          	addi	s2,s2,830 # 80007428 <etext+0x428>
    800030f2:	85ca                	mv	a1,s2
    800030f4:	8526                	mv	a0,s1
    800030f6:	5f5000ef          	jal	80003eea <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800030fa:	08848493          	addi	s1,s1,136
    800030fe:	ff349ae3          	bne	s1,s3,800030f2 <iinit+0x3a>
}
    80003102:	70a2                	ld	ra,40(sp)
    80003104:	7402                	ld	s0,32(sp)
    80003106:	64e2                	ld	s1,24(sp)
    80003108:	6942                	ld	s2,16(sp)
    8000310a:	69a2                	ld	s3,8(sp)
    8000310c:	6145                	addi	sp,sp,48
    8000310e:	8082                	ret

0000000080003110 <ialloc>:
{
    80003110:	7139                	addi	sp,sp,-64
    80003112:	fc06                	sd	ra,56(sp)
    80003114:	f822                	sd	s0,48(sp)
    80003116:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003118:	0001b717          	auipc	a4,0x1b
    8000311c:	d6472703          	lw	a4,-668(a4) # 8001de7c <sb+0xc>
    80003120:	4785                	li	a5,1
    80003122:	06e7f063          	bgeu	a5,a4,80003182 <ialloc+0x72>
    80003126:	f426                	sd	s1,40(sp)
    80003128:	f04a                	sd	s2,32(sp)
    8000312a:	ec4e                	sd	s3,24(sp)
    8000312c:	e852                	sd	s4,16(sp)
    8000312e:	e456                	sd	s5,8(sp)
    80003130:	e05a                	sd	s6,0(sp)
    80003132:	8aaa                	mv	s5,a0
    80003134:	8b2e                	mv	s6,a1
    80003136:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003138:	0001ba17          	auipc	s4,0x1b
    8000313c:	d38a0a13          	addi	s4,s4,-712 # 8001de70 <sb>
    80003140:	00495593          	srli	a1,s2,0x4
    80003144:	018a2783          	lw	a5,24(s4)
    80003148:	9dbd                	addw	a1,a1,a5
    8000314a:	8556                	mv	a0,s5
    8000314c:	a9dff0ef          	jal	80002be8 <bread>
    80003150:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003152:	05850993          	addi	s3,a0,88
    80003156:	00f97793          	andi	a5,s2,15
    8000315a:	079a                	slli	a5,a5,0x6
    8000315c:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000315e:	00099783          	lh	a5,0(s3)
    80003162:	cb9d                	beqz	a5,80003198 <ialloc+0x88>
    brelse(bp);
    80003164:	b8dff0ef          	jal	80002cf0 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003168:	0905                	addi	s2,s2,1
    8000316a:	00ca2703          	lw	a4,12(s4)
    8000316e:	0009079b          	sext.w	a5,s2
    80003172:	fce7e7e3          	bltu	a5,a4,80003140 <ialloc+0x30>
    80003176:	74a2                	ld	s1,40(sp)
    80003178:	7902                	ld	s2,32(sp)
    8000317a:	69e2                	ld	s3,24(sp)
    8000317c:	6a42                	ld	s4,16(sp)
    8000317e:	6aa2                	ld	s5,8(sp)
    80003180:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80003182:	00004517          	auipc	a0,0x4
    80003186:	2ae50513          	addi	a0,a0,686 # 80007430 <etext+0x430>
    8000318a:	b70fd0ef          	jal	800004fa <printf>
  return 0;
    8000318e:	4501                	li	a0,0
}
    80003190:	70e2                	ld	ra,56(sp)
    80003192:	7442                	ld	s0,48(sp)
    80003194:	6121                	addi	sp,sp,64
    80003196:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003198:	04000613          	li	a2,64
    8000319c:	4581                	li	a1,0
    8000319e:	854e                	mv	a0,s3
    800031a0:	b59fd0ef          	jal	80000cf8 <memset>
      dip->type = type;
    800031a4:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800031a8:	8526                	mv	a0,s1
    800031aa:	47d000ef          	jal	80003e26 <log_write>
      brelse(bp);
    800031ae:	8526                	mv	a0,s1
    800031b0:	b41ff0ef          	jal	80002cf0 <brelse>
      return iget(dev, inum);
    800031b4:	0009059b          	sext.w	a1,s2
    800031b8:	8556                	mv	a0,s5
    800031ba:	e55ff0ef          	jal	8000300e <iget>
    800031be:	74a2                	ld	s1,40(sp)
    800031c0:	7902                	ld	s2,32(sp)
    800031c2:	69e2                	ld	s3,24(sp)
    800031c4:	6a42                	ld	s4,16(sp)
    800031c6:	6aa2                	ld	s5,8(sp)
    800031c8:	6b02                	ld	s6,0(sp)
    800031ca:	b7d9                	j	80003190 <ialloc+0x80>

00000000800031cc <iupdate>:
{
    800031cc:	1101                	addi	sp,sp,-32
    800031ce:	ec06                	sd	ra,24(sp)
    800031d0:	e822                	sd	s0,16(sp)
    800031d2:	e426                	sd	s1,8(sp)
    800031d4:	e04a                	sd	s2,0(sp)
    800031d6:	1000                	addi	s0,sp,32
    800031d8:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031da:	415c                	lw	a5,4(a0)
    800031dc:	0047d79b          	srliw	a5,a5,0x4
    800031e0:	0001b597          	auipc	a1,0x1b
    800031e4:	ca85a583          	lw	a1,-856(a1) # 8001de88 <sb+0x18>
    800031e8:	9dbd                	addw	a1,a1,a5
    800031ea:	4108                	lw	a0,0(a0)
    800031ec:	9fdff0ef          	jal	80002be8 <bread>
    800031f0:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800031f2:	05850793          	addi	a5,a0,88
    800031f6:	40d8                	lw	a4,4(s1)
    800031f8:	8b3d                	andi	a4,a4,15
    800031fa:	071a                	slli	a4,a4,0x6
    800031fc:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800031fe:	04449703          	lh	a4,68(s1)
    80003202:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003206:	04649703          	lh	a4,70(s1)
    8000320a:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000320e:	04849703          	lh	a4,72(s1)
    80003212:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003216:	04a49703          	lh	a4,74(s1)
    8000321a:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000321e:	44f8                	lw	a4,76(s1)
    80003220:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003222:	03400613          	li	a2,52
    80003226:	05048593          	addi	a1,s1,80
    8000322a:	00c78513          	addi	a0,a5,12
    8000322e:	b2bfd0ef          	jal	80000d58 <memmove>
  log_write(bp);
    80003232:	854a                	mv	a0,s2
    80003234:	3f3000ef          	jal	80003e26 <log_write>
  brelse(bp);
    80003238:	854a                	mv	a0,s2
    8000323a:	ab7ff0ef          	jal	80002cf0 <brelse>
}
    8000323e:	60e2                	ld	ra,24(sp)
    80003240:	6442                	ld	s0,16(sp)
    80003242:	64a2                	ld	s1,8(sp)
    80003244:	6902                	ld	s2,0(sp)
    80003246:	6105                	addi	sp,sp,32
    80003248:	8082                	ret

000000008000324a <idup>:
{
    8000324a:	1101                	addi	sp,sp,-32
    8000324c:	ec06                	sd	ra,24(sp)
    8000324e:	e822                	sd	s0,16(sp)
    80003250:	e426                	sd	s1,8(sp)
    80003252:	1000                	addi	s0,sp,32
    80003254:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003256:	0001b517          	auipc	a0,0x1b
    8000325a:	c3a50513          	addi	a0,a0,-966 # 8001de90 <itable>
    8000325e:	9cbfd0ef          	jal	80000c28 <acquire>
  ip->ref++;
    80003262:	449c                	lw	a5,8(s1)
    80003264:	2785                	addiw	a5,a5,1
    80003266:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003268:	0001b517          	auipc	a0,0x1b
    8000326c:	c2850513          	addi	a0,a0,-984 # 8001de90 <itable>
    80003270:	a4dfd0ef          	jal	80000cbc <release>
}
    80003274:	8526                	mv	a0,s1
    80003276:	60e2                	ld	ra,24(sp)
    80003278:	6442                	ld	s0,16(sp)
    8000327a:	64a2                	ld	s1,8(sp)
    8000327c:	6105                	addi	sp,sp,32
    8000327e:	8082                	ret

0000000080003280 <ilock>:
{
    80003280:	1101                	addi	sp,sp,-32
    80003282:	ec06                	sd	ra,24(sp)
    80003284:	e822                	sd	s0,16(sp)
    80003286:	e426                	sd	s1,8(sp)
    80003288:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000328a:	cd19                	beqz	a0,800032a8 <ilock+0x28>
    8000328c:	84aa                	mv	s1,a0
    8000328e:	451c                	lw	a5,8(a0)
    80003290:	00f05c63          	blez	a5,800032a8 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003294:	0541                	addi	a0,a0,16
    80003296:	48b000ef          	jal	80003f20 <acquiresleep>
  if(ip->valid == 0){
    8000329a:	40bc                	lw	a5,64(s1)
    8000329c:	cf89                	beqz	a5,800032b6 <ilock+0x36>
}
    8000329e:	60e2                	ld	ra,24(sp)
    800032a0:	6442                	ld	s0,16(sp)
    800032a2:	64a2                	ld	s1,8(sp)
    800032a4:	6105                	addi	sp,sp,32
    800032a6:	8082                	ret
    800032a8:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800032aa:	00004517          	auipc	a0,0x4
    800032ae:	19e50513          	addi	a0,a0,414 # 80007448 <etext+0x448>
    800032b2:	d72fd0ef          	jal	80000824 <panic>
    800032b6:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800032b8:	40dc                	lw	a5,4(s1)
    800032ba:	0047d79b          	srliw	a5,a5,0x4
    800032be:	0001b597          	auipc	a1,0x1b
    800032c2:	bca5a583          	lw	a1,-1078(a1) # 8001de88 <sb+0x18>
    800032c6:	9dbd                	addw	a1,a1,a5
    800032c8:	4088                	lw	a0,0(s1)
    800032ca:	91fff0ef          	jal	80002be8 <bread>
    800032ce:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800032d0:	05850593          	addi	a1,a0,88
    800032d4:	40dc                	lw	a5,4(s1)
    800032d6:	8bbd                	andi	a5,a5,15
    800032d8:	079a                	slli	a5,a5,0x6
    800032da:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800032dc:	00059783          	lh	a5,0(a1)
    800032e0:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800032e4:	00259783          	lh	a5,2(a1)
    800032e8:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800032ec:	00459783          	lh	a5,4(a1)
    800032f0:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800032f4:	00659783          	lh	a5,6(a1)
    800032f8:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800032fc:	459c                	lw	a5,8(a1)
    800032fe:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003300:	03400613          	li	a2,52
    80003304:	05b1                	addi	a1,a1,12
    80003306:	05048513          	addi	a0,s1,80
    8000330a:	a4ffd0ef          	jal	80000d58 <memmove>
    brelse(bp);
    8000330e:	854a                	mv	a0,s2
    80003310:	9e1ff0ef          	jal	80002cf0 <brelse>
    ip->valid = 1;
    80003314:	4785                	li	a5,1
    80003316:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003318:	04449783          	lh	a5,68(s1)
    8000331c:	c399                	beqz	a5,80003322 <ilock+0xa2>
    8000331e:	6902                	ld	s2,0(sp)
    80003320:	bfbd                	j	8000329e <ilock+0x1e>
      panic("ilock: no type");
    80003322:	00004517          	auipc	a0,0x4
    80003326:	12e50513          	addi	a0,a0,302 # 80007450 <etext+0x450>
    8000332a:	cfafd0ef          	jal	80000824 <panic>

000000008000332e <iunlock>:
{
    8000332e:	1101                	addi	sp,sp,-32
    80003330:	ec06                	sd	ra,24(sp)
    80003332:	e822                	sd	s0,16(sp)
    80003334:	e426                	sd	s1,8(sp)
    80003336:	e04a                	sd	s2,0(sp)
    80003338:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000333a:	c505                	beqz	a0,80003362 <iunlock+0x34>
    8000333c:	84aa                	mv	s1,a0
    8000333e:	01050913          	addi	s2,a0,16
    80003342:	854a                	mv	a0,s2
    80003344:	45b000ef          	jal	80003f9e <holdingsleep>
    80003348:	cd09                	beqz	a0,80003362 <iunlock+0x34>
    8000334a:	449c                	lw	a5,8(s1)
    8000334c:	00f05b63          	blez	a5,80003362 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003350:	854a                	mv	a0,s2
    80003352:	415000ef          	jal	80003f66 <releasesleep>
}
    80003356:	60e2                	ld	ra,24(sp)
    80003358:	6442                	ld	s0,16(sp)
    8000335a:	64a2                	ld	s1,8(sp)
    8000335c:	6902                	ld	s2,0(sp)
    8000335e:	6105                	addi	sp,sp,32
    80003360:	8082                	ret
    panic("iunlock");
    80003362:	00004517          	auipc	a0,0x4
    80003366:	0fe50513          	addi	a0,a0,254 # 80007460 <etext+0x460>
    8000336a:	cbafd0ef          	jal	80000824 <panic>

000000008000336e <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000336e:	7179                	addi	sp,sp,-48
    80003370:	f406                	sd	ra,40(sp)
    80003372:	f022                	sd	s0,32(sp)
    80003374:	ec26                	sd	s1,24(sp)
    80003376:	e84a                	sd	s2,16(sp)
    80003378:	e44e                	sd	s3,8(sp)
    8000337a:	1800                	addi	s0,sp,48
    8000337c:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000337e:	05050493          	addi	s1,a0,80
    80003382:	08050913          	addi	s2,a0,128
    80003386:	a021                	j	8000338e <itrunc+0x20>
    80003388:	0491                	addi	s1,s1,4
    8000338a:	01248b63          	beq	s1,s2,800033a0 <itrunc+0x32>
    if(ip->addrs[i]){
    8000338e:	408c                	lw	a1,0(s1)
    80003390:	dde5                	beqz	a1,80003388 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003392:	0009a503          	lw	a0,0(s3)
    80003396:	a47ff0ef          	jal	80002ddc <bfree>
      ip->addrs[i] = 0;
    8000339a:	0004a023          	sw	zero,0(s1)
    8000339e:	b7ed                	j	80003388 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800033a0:	0809a583          	lw	a1,128(s3)
    800033a4:	ed89                	bnez	a1,800033be <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800033a6:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800033aa:	854e                	mv	a0,s3
    800033ac:	e21ff0ef          	jal	800031cc <iupdate>
}
    800033b0:	70a2                	ld	ra,40(sp)
    800033b2:	7402                	ld	s0,32(sp)
    800033b4:	64e2                	ld	s1,24(sp)
    800033b6:	6942                	ld	s2,16(sp)
    800033b8:	69a2                	ld	s3,8(sp)
    800033ba:	6145                	addi	sp,sp,48
    800033bc:	8082                	ret
    800033be:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800033c0:	0009a503          	lw	a0,0(s3)
    800033c4:	825ff0ef          	jal	80002be8 <bread>
    800033c8:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800033ca:	05850493          	addi	s1,a0,88
    800033ce:	45850913          	addi	s2,a0,1112
    800033d2:	a021                	j	800033da <itrunc+0x6c>
    800033d4:	0491                	addi	s1,s1,4
    800033d6:	01248963          	beq	s1,s2,800033e8 <itrunc+0x7a>
      if(a[j])
    800033da:	408c                	lw	a1,0(s1)
    800033dc:	dde5                	beqz	a1,800033d4 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800033de:	0009a503          	lw	a0,0(s3)
    800033e2:	9fbff0ef          	jal	80002ddc <bfree>
    800033e6:	b7fd                	j	800033d4 <itrunc+0x66>
    brelse(bp);
    800033e8:	8552                	mv	a0,s4
    800033ea:	907ff0ef          	jal	80002cf0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800033ee:	0809a583          	lw	a1,128(s3)
    800033f2:	0009a503          	lw	a0,0(s3)
    800033f6:	9e7ff0ef          	jal	80002ddc <bfree>
    ip->addrs[NDIRECT] = 0;
    800033fa:	0809a023          	sw	zero,128(s3)
    800033fe:	6a02                	ld	s4,0(sp)
    80003400:	b75d                	j	800033a6 <itrunc+0x38>

0000000080003402 <iput>:
{
    80003402:	1101                	addi	sp,sp,-32
    80003404:	ec06                	sd	ra,24(sp)
    80003406:	e822                	sd	s0,16(sp)
    80003408:	e426                	sd	s1,8(sp)
    8000340a:	1000                	addi	s0,sp,32
    8000340c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000340e:	0001b517          	auipc	a0,0x1b
    80003412:	a8250513          	addi	a0,a0,-1406 # 8001de90 <itable>
    80003416:	813fd0ef          	jal	80000c28 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000341a:	4498                	lw	a4,8(s1)
    8000341c:	4785                	li	a5,1
    8000341e:	02f70063          	beq	a4,a5,8000343e <iput+0x3c>
  ip->ref--;
    80003422:	449c                	lw	a5,8(s1)
    80003424:	37fd                	addiw	a5,a5,-1
    80003426:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003428:	0001b517          	auipc	a0,0x1b
    8000342c:	a6850513          	addi	a0,a0,-1432 # 8001de90 <itable>
    80003430:	88dfd0ef          	jal	80000cbc <release>
}
    80003434:	60e2                	ld	ra,24(sp)
    80003436:	6442                	ld	s0,16(sp)
    80003438:	64a2                	ld	s1,8(sp)
    8000343a:	6105                	addi	sp,sp,32
    8000343c:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000343e:	40bc                	lw	a5,64(s1)
    80003440:	d3ed                	beqz	a5,80003422 <iput+0x20>
    80003442:	04a49783          	lh	a5,74(s1)
    80003446:	fff1                	bnez	a5,80003422 <iput+0x20>
    80003448:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    8000344a:	01048793          	addi	a5,s1,16
    8000344e:	893e                	mv	s2,a5
    80003450:	853e                	mv	a0,a5
    80003452:	2cf000ef          	jal	80003f20 <acquiresleep>
    release(&itable.lock);
    80003456:	0001b517          	auipc	a0,0x1b
    8000345a:	a3a50513          	addi	a0,a0,-1478 # 8001de90 <itable>
    8000345e:	85ffd0ef          	jal	80000cbc <release>
    itrunc(ip);
    80003462:	8526                	mv	a0,s1
    80003464:	f0bff0ef          	jal	8000336e <itrunc>
    ip->type = 0;
    80003468:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000346c:	8526                	mv	a0,s1
    8000346e:	d5fff0ef          	jal	800031cc <iupdate>
    ip->valid = 0;
    80003472:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003476:	854a                	mv	a0,s2
    80003478:	2ef000ef          	jal	80003f66 <releasesleep>
    acquire(&itable.lock);
    8000347c:	0001b517          	auipc	a0,0x1b
    80003480:	a1450513          	addi	a0,a0,-1516 # 8001de90 <itable>
    80003484:	fa4fd0ef          	jal	80000c28 <acquire>
    80003488:	6902                	ld	s2,0(sp)
    8000348a:	bf61                	j	80003422 <iput+0x20>

000000008000348c <iunlockput>:
{
    8000348c:	1101                	addi	sp,sp,-32
    8000348e:	ec06                	sd	ra,24(sp)
    80003490:	e822                	sd	s0,16(sp)
    80003492:	e426                	sd	s1,8(sp)
    80003494:	1000                	addi	s0,sp,32
    80003496:	84aa                	mv	s1,a0
  iunlock(ip);
    80003498:	e97ff0ef          	jal	8000332e <iunlock>
  iput(ip);
    8000349c:	8526                	mv	a0,s1
    8000349e:	f65ff0ef          	jal	80003402 <iput>
}
    800034a2:	60e2                	ld	ra,24(sp)
    800034a4:	6442                	ld	s0,16(sp)
    800034a6:	64a2                	ld	s1,8(sp)
    800034a8:	6105                	addi	sp,sp,32
    800034aa:	8082                	ret

00000000800034ac <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800034ac:	0001b717          	auipc	a4,0x1b
    800034b0:	9d072703          	lw	a4,-1584(a4) # 8001de7c <sb+0xc>
    800034b4:	4785                	li	a5,1
    800034b6:	0ae7fe63          	bgeu	a5,a4,80003572 <ireclaim+0xc6>
{
    800034ba:	7139                	addi	sp,sp,-64
    800034bc:	fc06                	sd	ra,56(sp)
    800034be:	f822                	sd	s0,48(sp)
    800034c0:	f426                	sd	s1,40(sp)
    800034c2:	f04a                	sd	s2,32(sp)
    800034c4:	ec4e                	sd	s3,24(sp)
    800034c6:	e852                	sd	s4,16(sp)
    800034c8:	e456                	sd	s5,8(sp)
    800034ca:	e05a                	sd	s6,0(sp)
    800034cc:	0080                	addi	s0,sp,64
    800034ce:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800034d0:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034d2:	0001ba17          	auipc	s4,0x1b
    800034d6:	99ea0a13          	addi	s4,s4,-1634 # 8001de70 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    800034da:	00004b17          	auipc	s6,0x4
    800034de:	f8eb0b13          	addi	s6,s6,-114 # 80007468 <etext+0x468>
    800034e2:	a099                	j	80003528 <ireclaim+0x7c>
    800034e4:	85ce                	mv	a1,s3
    800034e6:	855a                	mv	a0,s6
    800034e8:	812fd0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    800034ec:	85ce                	mv	a1,s3
    800034ee:	8556                	mv	a0,s5
    800034f0:	b1fff0ef          	jal	8000300e <iget>
    800034f4:	89aa                	mv	s3,a0
    brelse(bp);
    800034f6:	854a                	mv	a0,s2
    800034f8:	ff8ff0ef          	jal	80002cf0 <brelse>
    if (ip) {
    800034fc:	00098f63          	beqz	s3,8000351a <ireclaim+0x6e>
      begin_op();
    80003500:	78c000ef          	jal	80003c8c <begin_op>
      ilock(ip);
    80003504:	854e                	mv	a0,s3
    80003506:	d7bff0ef          	jal	80003280 <ilock>
      iunlock(ip);
    8000350a:	854e                	mv	a0,s3
    8000350c:	e23ff0ef          	jal	8000332e <iunlock>
      iput(ip);
    80003510:	854e                	mv	a0,s3
    80003512:	ef1ff0ef          	jal	80003402 <iput>
      end_op();
    80003516:	7e6000ef          	jal	80003cfc <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000351a:	0485                	addi	s1,s1,1
    8000351c:	00ca2703          	lw	a4,12(s4)
    80003520:	0004879b          	sext.w	a5,s1
    80003524:	02e7fd63          	bgeu	a5,a4,8000355e <ireclaim+0xb2>
    80003528:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000352c:	0044d593          	srli	a1,s1,0x4
    80003530:	018a2783          	lw	a5,24(s4)
    80003534:	9dbd                	addw	a1,a1,a5
    80003536:	8556                	mv	a0,s5
    80003538:	eb0ff0ef          	jal	80002be8 <bread>
    8000353c:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000353e:	05850793          	addi	a5,a0,88
    80003542:	00f9f713          	andi	a4,s3,15
    80003546:	071a                	slli	a4,a4,0x6
    80003548:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    8000354a:	00079703          	lh	a4,0(a5)
    8000354e:	c701                	beqz	a4,80003556 <ireclaim+0xaa>
    80003550:	00679783          	lh	a5,6(a5)
    80003554:	dbc1                	beqz	a5,800034e4 <ireclaim+0x38>
    brelse(bp);
    80003556:	854a                	mv	a0,s2
    80003558:	f98ff0ef          	jal	80002cf0 <brelse>
    if (ip) {
    8000355c:	bf7d                	j	8000351a <ireclaim+0x6e>
}
    8000355e:	70e2                	ld	ra,56(sp)
    80003560:	7442                	ld	s0,48(sp)
    80003562:	74a2                	ld	s1,40(sp)
    80003564:	7902                	ld	s2,32(sp)
    80003566:	69e2                	ld	s3,24(sp)
    80003568:	6a42                	ld	s4,16(sp)
    8000356a:	6aa2                	ld	s5,8(sp)
    8000356c:	6b02                	ld	s6,0(sp)
    8000356e:	6121                	addi	sp,sp,64
    80003570:	8082                	ret
    80003572:	8082                	ret

0000000080003574 <fsinit>:
fsinit(int dev) {
    80003574:	1101                	addi	sp,sp,-32
    80003576:	ec06                	sd	ra,24(sp)
    80003578:	e822                	sd	s0,16(sp)
    8000357a:	e426                	sd	s1,8(sp)
    8000357c:	e04a                	sd	s2,0(sp)
    8000357e:	1000                	addi	s0,sp,32
    80003580:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003582:	4585                	li	a1,1
    80003584:	e64ff0ef          	jal	80002be8 <bread>
    80003588:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000358a:	02000613          	li	a2,32
    8000358e:	05850593          	addi	a1,a0,88
    80003592:	0001b517          	auipc	a0,0x1b
    80003596:	8de50513          	addi	a0,a0,-1826 # 8001de70 <sb>
    8000359a:	fbefd0ef          	jal	80000d58 <memmove>
  brelse(bp);
    8000359e:	8526                	mv	a0,s1
    800035a0:	f50ff0ef          	jal	80002cf0 <brelse>
  if(sb.magic != FSMAGIC)
    800035a4:	0001b717          	auipc	a4,0x1b
    800035a8:	8cc72703          	lw	a4,-1844(a4) # 8001de70 <sb>
    800035ac:	102037b7          	lui	a5,0x10203
    800035b0:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800035b4:	02f71263          	bne	a4,a5,800035d8 <fsinit+0x64>
  initlog(dev, &sb);
    800035b8:	0001b597          	auipc	a1,0x1b
    800035bc:	8b858593          	addi	a1,a1,-1864 # 8001de70 <sb>
    800035c0:	854a                	mv	a0,s2
    800035c2:	648000ef          	jal	80003c0a <initlog>
  ireclaim(dev);
    800035c6:	854a                	mv	a0,s2
    800035c8:	ee5ff0ef          	jal	800034ac <ireclaim>
}
    800035cc:	60e2                	ld	ra,24(sp)
    800035ce:	6442                	ld	s0,16(sp)
    800035d0:	64a2                	ld	s1,8(sp)
    800035d2:	6902                	ld	s2,0(sp)
    800035d4:	6105                	addi	sp,sp,32
    800035d6:	8082                	ret
    panic("invalid file system");
    800035d8:	00004517          	auipc	a0,0x4
    800035dc:	eb050513          	addi	a0,a0,-336 # 80007488 <etext+0x488>
    800035e0:	a44fd0ef          	jal	80000824 <panic>

00000000800035e4 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800035e4:	1141                	addi	sp,sp,-16
    800035e6:	e406                	sd	ra,8(sp)
    800035e8:	e022                	sd	s0,0(sp)
    800035ea:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800035ec:	411c                	lw	a5,0(a0)
    800035ee:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800035f0:	415c                	lw	a5,4(a0)
    800035f2:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800035f4:	04451783          	lh	a5,68(a0)
    800035f8:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800035fc:	04a51783          	lh	a5,74(a0)
    80003600:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003604:	04c56783          	lwu	a5,76(a0)
    80003608:	e99c                	sd	a5,16(a1)
}
    8000360a:	60a2                	ld	ra,8(sp)
    8000360c:	6402                	ld	s0,0(sp)
    8000360e:	0141                	addi	sp,sp,16
    80003610:	8082                	ret

0000000080003612 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003612:	457c                	lw	a5,76(a0)
    80003614:	0ed7e663          	bltu	a5,a3,80003700 <readi+0xee>
{
    80003618:	7159                	addi	sp,sp,-112
    8000361a:	f486                	sd	ra,104(sp)
    8000361c:	f0a2                	sd	s0,96(sp)
    8000361e:	eca6                	sd	s1,88(sp)
    80003620:	e0d2                	sd	s4,64(sp)
    80003622:	fc56                	sd	s5,56(sp)
    80003624:	f85a                	sd	s6,48(sp)
    80003626:	f45e                	sd	s7,40(sp)
    80003628:	1880                	addi	s0,sp,112
    8000362a:	8b2a                	mv	s6,a0
    8000362c:	8bae                	mv	s7,a1
    8000362e:	8a32                	mv	s4,a2
    80003630:	84b6                	mv	s1,a3
    80003632:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003634:	9f35                	addw	a4,a4,a3
    return 0;
    80003636:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003638:	0ad76b63          	bltu	a4,a3,800036ee <readi+0xdc>
    8000363c:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    8000363e:	00e7f463          	bgeu	a5,a4,80003646 <readi+0x34>
    n = ip->size - off;
    80003642:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003646:	080a8b63          	beqz	s5,800036dc <readi+0xca>
    8000364a:	e8ca                	sd	s2,80(sp)
    8000364c:	f062                	sd	s8,32(sp)
    8000364e:	ec66                	sd	s9,24(sp)
    80003650:	e86a                	sd	s10,16(sp)
    80003652:	e46e                	sd	s11,8(sp)
    80003654:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003656:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000365a:	5c7d                	li	s8,-1
    8000365c:	a80d                	j	8000368e <readi+0x7c>
    8000365e:	020d1d93          	slli	s11,s10,0x20
    80003662:	020ddd93          	srli	s11,s11,0x20
    80003666:	05890613          	addi	a2,s2,88
    8000366a:	86ee                	mv	a3,s11
    8000366c:	963e                	add	a2,a2,a5
    8000366e:	85d2                	mv	a1,s4
    80003670:	855e                	mv	a0,s7
    80003672:	c15fe0ef          	jal	80002286 <either_copyout>
    80003676:	05850363          	beq	a0,s8,800036bc <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000367a:	854a                	mv	a0,s2
    8000367c:	e74ff0ef          	jal	80002cf0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003680:	013d09bb          	addw	s3,s10,s3
    80003684:	009d04bb          	addw	s1,s10,s1
    80003688:	9a6e                	add	s4,s4,s11
    8000368a:	0559f363          	bgeu	s3,s5,800036d0 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000368e:	00a4d59b          	srliw	a1,s1,0xa
    80003692:	855a                	mv	a0,s6
    80003694:	8bbff0ef          	jal	80002f4e <bmap>
    80003698:	85aa                	mv	a1,a0
    if(addr == 0)
    8000369a:	c139                	beqz	a0,800036e0 <readi+0xce>
    bp = bread(ip->dev, addr);
    8000369c:	000b2503          	lw	a0,0(s6)
    800036a0:	d48ff0ef          	jal	80002be8 <bread>
    800036a4:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800036a6:	3ff4f793          	andi	a5,s1,1023
    800036aa:	40fc873b          	subw	a4,s9,a5
    800036ae:	413a86bb          	subw	a3,s5,s3
    800036b2:	8d3a                	mv	s10,a4
    800036b4:	fae6f5e3          	bgeu	a3,a4,8000365e <readi+0x4c>
    800036b8:	8d36                	mv	s10,a3
    800036ba:	b755                	j	8000365e <readi+0x4c>
      brelse(bp);
    800036bc:	854a                	mv	a0,s2
    800036be:	e32ff0ef          	jal	80002cf0 <brelse>
      tot = -1;
    800036c2:	59fd                	li	s3,-1
      break;
    800036c4:	6946                	ld	s2,80(sp)
    800036c6:	7c02                	ld	s8,32(sp)
    800036c8:	6ce2                	ld	s9,24(sp)
    800036ca:	6d42                	ld	s10,16(sp)
    800036cc:	6da2                	ld	s11,8(sp)
    800036ce:	a831                	j	800036ea <readi+0xd8>
    800036d0:	6946                	ld	s2,80(sp)
    800036d2:	7c02                	ld	s8,32(sp)
    800036d4:	6ce2                	ld	s9,24(sp)
    800036d6:	6d42                	ld	s10,16(sp)
    800036d8:	6da2                	ld	s11,8(sp)
    800036da:	a801                	j	800036ea <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800036dc:	89d6                	mv	s3,s5
    800036de:	a031                	j	800036ea <readi+0xd8>
    800036e0:	6946                	ld	s2,80(sp)
    800036e2:	7c02                	ld	s8,32(sp)
    800036e4:	6ce2                	ld	s9,24(sp)
    800036e6:	6d42                	ld	s10,16(sp)
    800036e8:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800036ea:	854e                	mv	a0,s3
    800036ec:	69a6                	ld	s3,72(sp)
}
    800036ee:	70a6                	ld	ra,104(sp)
    800036f0:	7406                	ld	s0,96(sp)
    800036f2:	64e6                	ld	s1,88(sp)
    800036f4:	6a06                	ld	s4,64(sp)
    800036f6:	7ae2                	ld	s5,56(sp)
    800036f8:	7b42                	ld	s6,48(sp)
    800036fa:	7ba2                	ld	s7,40(sp)
    800036fc:	6165                	addi	sp,sp,112
    800036fe:	8082                	ret
    return 0;
    80003700:	4501                	li	a0,0
}
    80003702:	8082                	ret

0000000080003704 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003704:	457c                	lw	a5,76(a0)
    80003706:	0ed7eb63          	bltu	a5,a3,800037fc <writei+0xf8>
{
    8000370a:	7159                	addi	sp,sp,-112
    8000370c:	f486                	sd	ra,104(sp)
    8000370e:	f0a2                	sd	s0,96(sp)
    80003710:	e8ca                	sd	s2,80(sp)
    80003712:	e0d2                	sd	s4,64(sp)
    80003714:	fc56                	sd	s5,56(sp)
    80003716:	f85a                	sd	s6,48(sp)
    80003718:	f45e                	sd	s7,40(sp)
    8000371a:	1880                	addi	s0,sp,112
    8000371c:	8aaa                	mv	s5,a0
    8000371e:	8bae                	mv	s7,a1
    80003720:	8a32                	mv	s4,a2
    80003722:	8936                	mv	s2,a3
    80003724:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003726:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    8000372a:	00043737          	lui	a4,0x43
    8000372e:	0cf76963          	bltu	a4,a5,80003800 <writei+0xfc>
    80003732:	0cd7e763          	bltu	a5,a3,80003800 <writei+0xfc>
    80003736:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003738:	0a0b0a63          	beqz	s6,800037ec <writei+0xe8>
    8000373c:	eca6                	sd	s1,88(sp)
    8000373e:	f062                	sd	s8,32(sp)
    80003740:	ec66                	sd	s9,24(sp)
    80003742:	e86a                	sd	s10,16(sp)
    80003744:	e46e                	sd	s11,8(sp)
    80003746:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003748:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000374c:	5c7d                	li	s8,-1
    8000374e:	a825                	j	80003786 <writei+0x82>
    80003750:	020d1d93          	slli	s11,s10,0x20
    80003754:	020ddd93          	srli	s11,s11,0x20
    80003758:	05848513          	addi	a0,s1,88
    8000375c:	86ee                	mv	a3,s11
    8000375e:	8652                	mv	a2,s4
    80003760:	85de                	mv	a1,s7
    80003762:	953e                	add	a0,a0,a5
    80003764:	b6dfe0ef          	jal	800022d0 <either_copyin>
    80003768:	05850663          	beq	a0,s8,800037b4 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    8000376c:	8526                	mv	a0,s1
    8000376e:	6b8000ef          	jal	80003e26 <log_write>
    brelse(bp);
    80003772:	8526                	mv	a0,s1
    80003774:	d7cff0ef          	jal	80002cf0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003778:	013d09bb          	addw	s3,s10,s3
    8000377c:	012d093b          	addw	s2,s10,s2
    80003780:	9a6e                	add	s4,s4,s11
    80003782:	0369fc63          	bgeu	s3,s6,800037ba <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003786:	00a9559b          	srliw	a1,s2,0xa
    8000378a:	8556                	mv	a0,s5
    8000378c:	fc2ff0ef          	jal	80002f4e <bmap>
    80003790:	85aa                	mv	a1,a0
    if(addr == 0)
    80003792:	c505                	beqz	a0,800037ba <writei+0xb6>
    bp = bread(ip->dev, addr);
    80003794:	000aa503          	lw	a0,0(s5)
    80003798:	c50ff0ef          	jal	80002be8 <bread>
    8000379c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000379e:	3ff97793          	andi	a5,s2,1023
    800037a2:	40fc873b          	subw	a4,s9,a5
    800037a6:	413b06bb          	subw	a3,s6,s3
    800037aa:	8d3a                	mv	s10,a4
    800037ac:	fae6f2e3          	bgeu	a3,a4,80003750 <writei+0x4c>
    800037b0:	8d36                	mv	s10,a3
    800037b2:	bf79                	j	80003750 <writei+0x4c>
      brelse(bp);
    800037b4:	8526                	mv	a0,s1
    800037b6:	d3aff0ef          	jal	80002cf0 <brelse>
  }

  if(off > ip->size)
    800037ba:	04caa783          	lw	a5,76(s5)
    800037be:	0327f963          	bgeu	a5,s2,800037f0 <writei+0xec>
    ip->size = off;
    800037c2:	052aa623          	sw	s2,76(s5)
    800037c6:	64e6                	ld	s1,88(sp)
    800037c8:	7c02                	ld	s8,32(sp)
    800037ca:	6ce2                	ld	s9,24(sp)
    800037cc:	6d42                	ld	s10,16(sp)
    800037ce:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800037d0:	8556                	mv	a0,s5
    800037d2:	9fbff0ef          	jal	800031cc <iupdate>

  return tot;
    800037d6:	854e                	mv	a0,s3
    800037d8:	69a6                	ld	s3,72(sp)
}
    800037da:	70a6                	ld	ra,104(sp)
    800037dc:	7406                	ld	s0,96(sp)
    800037de:	6946                	ld	s2,80(sp)
    800037e0:	6a06                	ld	s4,64(sp)
    800037e2:	7ae2                	ld	s5,56(sp)
    800037e4:	7b42                	ld	s6,48(sp)
    800037e6:	7ba2                	ld	s7,40(sp)
    800037e8:	6165                	addi	sp,sp,112
    800037ea:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800037ec:	89da                	mv	s3,s6
    800037ee:	b7cd                	j	800037d0 <writei+0xcc>
    800037f0:	64e6                	ld	s1,88(sp)
    800037f2:	7c02                	ld	s8,32(sp)
    800037f4:	6ce2                	ld	s9,24(sp)
    800037f6:	6d42                	ld	s10,16(sp)
    800037f8:	6da2                	ld	s11,8(sp)
    800037fa:	bfd9                	j	800037d0 <writei+0xcc>
    return -1;
    800037fc:	557d                	li	a0,-1
}
    800037fe:	8082                	ret
    return -1;
    80003800:	557d                	li	a0,-1
    80003802:	bfe1                	j	800037da <writei+0xd6>

0000000080003804 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003804:	1141                	addi	sp,sp,-16
    80003806:	e406                	sd	ra,8(sp)
    80003808:	e022                	sd	s0,0(sp)
    8000380a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000380c:	4639                	li	a2,14
    8000380e:	dbefd0ef          	jal	80000dcc <strncmp>
}
    80003812:	60a2                	ld	ra,8(sp)
    80003814:	6402                	ld	s0,0(sp)
    80003816:	0141                	addi	sp,sp,16
    80003818:	8082                	ret

000000008000381a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000381a:	711d                	addi	sp,sp,-96
    8000381c:	ec86                	sd	ra,88(sp)
    8000381e:	e8a2                	sd	s0,80(sp)
    80003820:	e4a6                	sd	s1,72(sp)
    80003822:	e0ca                	sd	s2,64(sp)
    80003824:	fc4e                	sd	s3,56(sp)
    80003826:	f852                	sd	s4,48(sp)
    80003828:	f456                	sd	s5,40(sp)
    8000382a:	f05a                	sd	s6,32(sp)
    8000382c:	ec5e                	sd	s7,24(sp)
    8000382e:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003830:	04451703          	lh	a4,68(a0)
    80003834:	4785                	li	a5,1
    80003836:	00f71f63          	bne	a4,a5,80003854 <dirlookup+0x3a>
    8000383a:	892a                	mv	s2,a0
    8000383c:	8aae                	mv	s5,a1
    8000383e:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003840:	457c                	lw	a5,76(a0)
    80003842:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003844:	fa040a13          	addi	s4,s0,-96
    80003848:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    8000384a:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000384e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003850:	e39d                	bnez	a5,80003876 <dirlookup+0x5c>
    80003852:	a8b9                	j	800038b0 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003854:	00004517          	auipc	a0,0x4
    80003858:	c4c50513          	addi	a0,a0,-948 # 800074a0 <etext+0x4a0>
    8000385c:	fc9fc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    80003860:	00004517          	auipc	a0,0x4
    80003864:	c5850513          	addi	a0,a0,-936 # 800074b8 <etext+0x4b8>
    80003868:	fbdfc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000386c:	24c1                	addiw	s1,s1,16
    8000386e:	04c92783          	lw	a5,76(s2)
    80003872:	02f4fe63          	bgeu	s1,a5,800038ae <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003876:	874e                	mv	a4,s3
    80003878:	86a6                	mv	a3,s1
    8000387a:	8652                	mv	a2,s4
    8000387c:	4581                	li	a1,0
    8000387e:	854a                	mv	a0,s2
    80003880:	d93ff0ef          	jal	80003612 <readi>
    80003884:	fd351ee3          	bne	a0,s3,80003860 <dirlookup+0x46>
    if(de.inum == 0)
    80003888:	fa045783          	lhu	a5,-96(s0)
    8000388c:	d3e5                	beqz	a5,8000386c <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    8000388e:	85da                	mv	a1,s6
    80003890:	8556                	mv	a0,s5
    80003892:	f73ff0ef          	jal	80003804 <namecmp>
    80003896:	f979                	bnez	a0,8000386c <dirlookup+0x52>
      if(poff)
    80003898:	000b8463          	beqz	s7,800038a0 <dirlookup+0x86>
        *poff = off;
    8000389c:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800038a0:	fa045583          	lhu	a1,-96(s0)
    800038a4:	00092503          	lw	a0,0(s2)
    800038a8:	f66ff0ef          	jal	8000300e <iget>
    800038ac:	a011                	j	800038b0 <dirlookup+0x96>
  return 0;
    800038ae:	4501                	li	a0,0
}
    800038b0:	60e6                	ld	ra,88(sp)
    800038b2:	6446                	ld	s0,80(sp)
    800038b4:	64a6                	ld	s1,72(sp)
    800038b6:	6906                	ld	s2,64(sp)
    800038b8:	79e2                	ld	s3,56(sp)
    800038ba:	7a42                	ld	s4,48(sp)
    800038bc:	7aa2                	ld	s5,40(sp)
    800038be:	7b02                	ld	s6,32(sp)
    800038c0:	6be2                	ld	s7,24(sp)
    800038c2:	6125                	addi	sp,sp,96
    800038c4:	8082                	ret

00000000800038c6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    800038c6:	711d                	addi	sp,sp,-96
    800038c8:	ec86                	sd	ra,88(sp)
    800038ca:	e8a2                	sd	s0,80(sp)
    800038cc:	e4a6                	sd	s1,72(sp)
    800038ce:	e0ca                	sd	s2,64(sp)
    800038d0:	fc4e                	sd	s3,56(sp)
    800038d2:	f852                	sd	s4,48(sp)
    800038d4:	f456                	sd	s5,40(sp)
    800038d6:	f05a                	sd	s6,32(sp)
    800038d8:	ec5e                	sd	s7,24(sp)
    800038da:	e862                	sd	s8,16(sp)
    800038dc:	e466                	sd	s9,8(sp)
    800038de:	e06a                	sd	s10,0(sp)
    800038e0:	1080                	addi	s0,sp,96
    800038e2:	84aa                	mv	s1,a0
    800038e4:	8b2e                	mv	s6,a1
    800038e6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    800038e8:	00054703          	lbu	a4,0(a0)
    800038ec:	02f00793          	li	a5,47
    800038f0:	00f70f63          	beq	a4,a5,8000390e <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800038f4:	83afe0ef          	jal	8000192e <myproc>
    800038f8:	15053503          	ld	a0,336(a0)
    800038fc:	94fff0ef          	jal	8000324a <idup>
    80003900:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003902:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003906:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003908:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    8000390a:	4b85                	li	s7,1
    8000390c:	a879                	j	800039aa <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    8000390e:	4585                	li	a1,1
    80003910:	852e                	mv	a0,a1
    80003912:	efcff0ef          	jal	8000300e <iget>
    80003916:	8a2a                	mv	s4,a0
    80003918:	b7ed                	j	80003902 <namex+0x3c>
      iunlockput(ip);
    8000391a:	8552                	mv	a0,s4
    8000391c:	b71ff0ef          	jal	8000348c <iunlockput>
      return 0;
    80003920:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003922:	8552                	mv	a0,s4
    80003924:	60e6                	ld	ra,88(sp)
    80003926:	6446                	ld	s0,80(sp)
    80003928:	64a6                	ld	s1,72(sp)
    8000392a:	6906                	ld	s2,64(sp)
    8000392c:	79e2                	ld	s3,56(sp)
    8000392e:	7a42                	ld	s4,48(sp)
    80003930:	7aa2                	ld	s5,40(sp)
    80003932:	7b02                	ld	s6,32(sp)
    80003934:	6be2                	ld	s7,24(sp)
    80003936:	6c42                	ld	s8,16(sp)
    80003938:	6ca2                	ld	s9,8(sp)
    8000393a:	6d02                	ld	s10,0(sp)
    8000393c:	6125                	addi	sp,sp,96
    8000393e:	8082                	ret
      iunlock(ip);
    80003940:	8552                	mv	a0,s4
    80003942:	9edff0ef          	jal	8000332e <iunlock>
      return ip;
    80003946:	bff1                	j	80003922 <namex+0x5c>
      iunlockput(ip);
    80003948:	8552                	mv	a0,s4
    8000394a:	b43ff0ef          	jal	8000348c <iunlockput>
      return 0;
    8000394e:	8a4a                	mv	s4,s2
    80003950:	bfc9                	j	80003922 <namex+0x5c>
  len = path - s;
    80003952:	40990633          	sub	a2,s2,s1
    80003956:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    8000395a:	09ac5463          	bge	s8,s10,800039e2 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    8000395e:	8666                	mv	a2,s9
    80003960:	85a6                	mv	a1,s1
    80003962:	8556                	mv	a0,s5
    80003964:	bf4fd0ef          	jal	80000d58 <memmove>
    80003968:	84ca                	mv	s1,s2
  while(*path == '/')
    8000396a:	0004c783          	lbu	a5,0(s1)
    8000396e:	01379763          	bne	a5,s3,8000397c <namex+0xb6>
    path++;
    80003972:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003974:	0004c783          	lbu	a5,0(s1)
    80003978:	ff378de3          	beq	a5,s3,80003972 <namex+0xac>
    ilock(ip);
    8000397c:	8552                	mv	a0,s4
    8000397e:	903ff0ef          	jal	80003280 <ilock>
    if(ip->type != T_DIR){
    80003982:	044a1783          	lh	a5,68(s4)
    80003986:	f9779ae3          	bne	a5,s7,8000391a <namex+0x54>
    if(nameiparent && *path == '\0'){
    8000398a:	000b0563          	beqz	s6,80003994 <namex+0xce>
    8000398e:	0004c783          	lbu	a5,0(s1)
    80003992:	d7dd                	beqz	a5,80003940 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003994:	4601                	li	a2,0
    80003996:	85d6                	mv	a1,s5
    80003998:	8552                	mv	a0,s4
    8000399a:	e81ff0ef          	jal	8000381a <dirlookup>
    8000399e:	892a                	mv	s2,a0
    800039a0:	d545                	beqz	a0,80003948 <namex+0x82>
    iunlockput(ip);
    800039a2:	8552                	mv	a0,s4
    800039a4:	ae9ff0ef          	jal	8000348c <iunlockput>
    ip = next;
    800039a8:	8a4a                	mv	s4,s2
  while(*path == '/')
    800039aa:	0004c783          	lbu	a5,0(s1)
    800039ae:	01379763          	bne	a5,s3,800039bc <namex+0xf6>
    path++;
    800039b2:	0485                	addi	s1,s1,1
  while(*path == '/')
    800039b4:	0004c783          	lbu	a5,0(s1)
    800039b8:	ff378de3          	beq	a5,s3,800039b2 <namex+0xec>
  if(*path == 0)
    800039bc:	cf8d                	beqz	a5,800039f6 <namex+0x130>
  while(*path != '/' && *path != 0)
    800039be:	0004c783          	lbu	a5,0(s1)
    800039c2:	fd178713          	addi	a4,a5,-47
    800039c6:	cb19                	beqz	a4,800039dc <namex+0x116>
    800039c8:	cb91                	beqz	a5,800039dc <namex+0x116>
    800039ca:	8926                	mv	s2,s1
    path++;
    800039cc:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    800039ce:	00094783          	lbu	a5,0(s2)
    800039d2:	fd178713          	addi	a4,a5,-47
    800039d6:	df35                	beqz	a4,80003952 <namex+0x8c>
    800039d8:	fbf5                	bnez	a5,800039cc <namex+0x106>
    800039da:	bfa5                	j	80003952 <namex+0x8c>
    800039dc:	8926                	mv	s2,s1
  len = path - s;
    800039de:	4d01                	li	s10,0
    800039e0:	4601                	li	a2,0
    memmove(name, s, len);
    800039e2:	2601                	sext.w	a2,a2
    800039e4:	85a6                	mv	a1,s1
    800039e6:	8556                	mv	a0,s5
    800039e8:	b70fd0ef          	jal	80000d58 <memmove>
    name[len] = 0;
    800039ec:	9d56                	add	s10,s10,s5
    800039ee:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde488>
    800039f2:	84ca                	mv	s1,s2
    800039f4:	bf9d                	j	8000396a <namex+0xa4>
  if(nameiparent){
    800039f6:	f20b06e3          	beqz	s6,80003922 <namex+0x5c>
    iput(ip);
    800039fa:	8552                	mv	a0,s4
    800039fc:	a07ff0ef          	jal	80003402 <iput>
    return 0;
    80003a00:	4a01                	li	s4,0
    80003a02:	b705                	j	80003922 <namex+0x5c>

0000000080003a04 <dirlink>:
{
    80003a04:	715d                	addi	sp,sp,-80
    80003a06:	e486                	sd	ra,72(sp)
    80003a08:	e0a2                	sd	s0,64(sp)
    80003a0a:	f84a                	sd	s2,48(sp)
    80003a0c:	ec56                	sd	s5,24(sp)
    80003a0e:	e85a                	sd	s6,16(sp)
    80003a10:	0880                	addi	s0,sp,80
    80003a12:	892a                	mv	s2,a0
    80003a14:	8aae                	mv	s5,a1
    80003a16:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003a18:	4601                	li	a2,0
    80003a1a:	e01ff0ef          	jal	8000381a <dirlookup>
    80003a1e:	ed1d                	bnez	a0,80003a5c <dirlink+0x58>
    80003a20:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a22:	04c92483          	lw	s1,76(s2)
    80003a26:	c4b9                	beqz	s1,80003a74 <dirlink+0x70>
    80003a28:	f44e                	sd	s3,40(sp)
    80003a2a:	f052                	sd	s4,32(sp)
    80003a2c:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a2e:	fb040a13          	addi	s4,s0,-80
    80003a32:	49c1                	li	s3,16
    80003a34:	874e                	mv	a4,s3
    80003a36:	86a6                	mv	a3,s1
    80003a38:	8652                	mv	a2,s4
    80003a3a:	4581                	li	a1,0
    80003a3c:	854a                	mv	a0,s2
    80003a3e:	bd5ff0ef          	jal	80003612 <readi>
    80003a42:	03351163          	bne	a0,s3,80003a64 <dirlink+0x60>
    if(de.inum == 0)
    80003a46:	fb045783          	lhu	a5,-80(s0)
    80003a4a:	c39d                	beqz	a5,80003a70 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a4c:	24c1                	addiw	s1,s1,16
    80003a4e:	04c92783          	lw	a5,76(s2)
    80003a52:	fef4e1e3          	bltu	s1,a5,80003a34 <dirlink+0x30>
    80003a56:	79a2                	ld	s3,40(sp)
    80003a58:	7a02                	ld	s4,32(sp)
    80003a5a:	a829                	j	80003a74 <dirlink+0x70>
    iput(ip);
    80003a5c:	9a7ff0ef          	jal	80003402 <iput>
    return -1;
    80003a60:	557d                	li	a0,-1
    80003a62:	a83d                	j	80003aa0 <dirlink+0x9c>
      panic("dirlink read");
    80003a64:	00004517          	auipc	a0,0x4
    80003a68:	a6450513          	addi	a0,a0,-1436 # 800074c8 <etext+0x4c8>
    80003a6c:	db9fc0ef          	jal	80000824 <panic>
    80003a70:	79a2                	ld	s3,40(sp)
    80003a72:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003a74:	4639                	li	a2,14
    80003a76:	85d6                	mv	a1,s5
    80003a78:	fb240513          	addi	a0,s0,-78
    80003a7c:	b8afd0ef          	jal	80000e06 <strncpy>
  de.inum = inum;
    80003a80:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a84:	4741                	li	a4,16
    80003a86:	86a6                	mv	a3,s1
    80003a88:	fb040613          	addi	a2,s0,-80
    80003a8c:	4581                	li	a1,0
    80003a8e:	854a                	mv	a0,s2
    80003a90:	c75ff0ef          	jal	80003704 <writei>
    80003a94:	1541                	addi	a0,a0,-16
    80003a96:	00a03533          	snez	a0,a0
    80003a9a:	40a0053b          	negw	a0,a0
    80003a9e:	74e2                	ld	s1,56(sp)
}
    80003aa0:	60a6                	ld	ra,72(sp)
    80003aa2:	6406                	ld	s0,64(sp)
    80003aa4:	7942                	ld	s2,48(sp)
    80003aa6:	6ae2                	ld	s5,24(sp)
    80003aa8:	6b42                	ld	s6,16(sp)
    80003aaa:	6161                	addi	sp,sp,80
    80003aac:	8082                	ret

0000000080003aae <namei>:

struct inode*
namei(char *path)
{
    80003aae:	1101                	addi	sp,sp,-32
    80003ab0:	ec06                	sd	ra,24(sp)
    80003ab2:	e822                	sd	s0,16(sp)
    80003ab4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003ab6:	fe040613          	addi	a2,s0,-32
    80003aba:	4581                	li	a1,0
    80003abc:	e0bff0ef          	jal	800038c6 <namex>
}
    80003ac0:	60e2                	ld	ra,24(sp)
    80003ac2:	6442                	ld	s0,16(sp)
    80003ac4:	6105                	addi	sp,sp,32
    80003ac6:	8082                	ret

0000000080003ac8 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003ac8:	1141                	addi	sp,sp,-16
    80003aca:	e406                	sd	ra,8(sp)
    80003acc:	e022                	sd	s0,0(sp)
    80003ace:	0800                	addi	s0,sp,16
    80003ad0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003ad2:	4585                	li	a1,1
    80003ad4:	df3ff0ef          	jal	800038c6 <namex>
}
    80003ad8:	60a2                	ld	ra,8(sp)
    80003ada:	6402                	ld	s0,0(sp)
    80003adc:	0141                	addi	sp,sp,16
    80003ade:	8082                	ret

0000000080003ae0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003ae0:	1101                	addi	sp,sp,-32
    80003ae2:	ec06                	sd	ra,24(sp)
    80003ae4:	e822                	sd	s0,16(sp)
    80003ae6:	e426                	sd	s1,8(sp)
    80003ae8:	e04a                	sd	s2,0(sp)
    80003aea:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003aec:	0001c917          	auipc	s2,0x1c
    80003af0:	e4c90913          	addi	s2,s2,-436 # 8001f938 <log>
    80003af4:	01892583          	lw	a1,24(s2)
    80003af8:	02492503          	lw	a0,36(s2)
    80003afc:	8ecff0ef          	jal	80002be8 <bread>
    80003b00:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003b02:	02892603          	lw	a2,40(s2)
    80003b06:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003b08:	00c05f63          	blez	a2,80003b26 <write_head+0x46>
    80003b0c:	0001c717          	auipc	a4,0x1c
    80003b10:	e5870713          	addi	a4,a4,-424 # 8001f964 <log+0x2c>
    80003b14:	87aa                	mv	a5,a0
    80003b16:	060a                	slli	a2,a2,0x2
    80003b18:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003b1a:	4314                	lw	a3,0(a4)
    80003b1c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003b1e:	0711                	addi	a4,a4,4
    80003b20:	0791                	addi	a5,a5,4
    80003b22:	fec79ce3          	bne	a5,a2,80003b1a <write_head+0x3a>
  }
  bwrite(buf);
    80003b26:	8526                	mv	a0,s1
    80003b28:	996ff0ef          	jal	80002cbe <bwrite>
  brelse(buf);
    80003b2c:	8526                	mv	a0,s1
    80003b2e:	9c2ff0ef          	jal	80002cf0 <brelse>
}
    80003b32:	60e2                	ld	ra,24(sp)
    80003b34:	6442                	ld	s0,16(sp)
    80003b36:	64a2                	ld	s1,8(sp)
    80003b38:	6902                	ld	s2,0(sp)
    80003b3a:	6105                	addi	sp,sp,32
    80003b3c:	8082                	ret

0000000080003b3e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b3e:	0001c797          	auipc	a5,0x1c
    80003b42:	e227a783          	lw	a5,-478(a5) # 8001f960 <log+0x28>
    80003b46:	0cf05163          	blez	a5,80003c08 <install_trans+0xca>
{
    80003b4a:	715d                	addi	sp,sp,-80
    80003b4c:	e486                	sd	ra,72(sp)
    80003b4e:	e0a2                	sd	s0,64(sp)
    80003b50:	fc26                	sd	s1,56(sp)
    80003b52:	f84a                	sd	s2,48(sp)
    80003b54:	f44e                	sd	s3,40(sp)
    80003b56:	f052                	sd	s4,32(sp)
    80003b58:	ec56                	sd	s5,24(sp)
    80003b5a:	e85a                	sd	s6,16(sp)
    80003b5c:	e45e                	sd	s7,8(sp)
    80003b5e:	e062                	sd	s8,0(sp)
    80003b60:	0880                	addi	s0,sp,80
    80003b62:	8b2a                	mv	s6,a0
    80003b64:	0001ca97          	auipc	s5,0x1c
    80003b68:	e00a8a93          	addi	s5,s5,-512 # 8001f964 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b6c:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003b6e:	00004c17          	auipc	s8,0x4
    80003b72:	96ac0c13          	addi	s8,s8,-1686 # 800074d8 <etext+0x4d8>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003b76:	0001ca17          	auipc	s4,0x1c
    80003b7a:	dc2a0a13          	addi	s4,s4,-574 # 8001f938 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003b7e:	40000b93          	li	s7,1024
    80003b82:	a025                	j	80003baa <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003b84:	000aa603          	lw	a2,0(s5)
    80003b88:	85ce                	mv	a1,s3
    80003b8a:	8562                	mv	a0,s8
    80003b8c:	96ffc0ef          	jal	800004fa <printf>
    80003b90:	a839                	j	80003bae <install_trans+0x70>
    brelse(lbuf);
    80003b92:	854a                	mv	a0,s2
    80003b94:	95cff0ef          	jal	80002cf0 <brelse>
    brelse(dbuf);
    80003b98:	8526                	mv	a0,s1
    80003b9a:	956ff0ef          	jal	80002cf0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b9e:	2985                	addiw	s3,s3,1
    80003ba0:	0a91                	addi	s5,s5,4
    80003ba2:	028a2783          	lw	a5,40(s4)
    80003ba6:	04f9d563          	bge	s3,a5,80003bf0 <install_trans+0xb2>
    if(recovering) {
    80003baa:	fc0b1de3          	bnez	s6,80003b84 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003bae:	018a2583          	lw	a1,24(s4)
    80003bb2:	013585bb          	addw	a1,a1,s3
    80003bb6:	2585                	addiw	a1,a1,1
    80003bb8:	024a2503          	lw	a0,36(s4)
    80003bbc:	82cff0ef          	jal	80002be8 <bread>
    80003bc0:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003bc2:	000aa583          	lw	a1,0(s5)
    80003bc6:	024a2503          	lw	a0,36(s4)
    80003bca:	81eff0ef          	jal	80002be8 <bread>
    80003bce:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003bd0:	865e                	mv	a2,s7
    80003bd2:	05890593          	addi	a1,s2,88
    80003bd6:	05850513          	addi	a0,a0,88
    80003bda:	97efd0ef          	jal	80000d58 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003bde:	8526                	mv	a0,s1
    80003be0:	8deff0ef          	jal	80002cbe <bwrite>
    if(recovering == 0)
    80003be4:	fa0b17e3          	bnez	s6,80003b92 <install_trans+0x54>
      bunpin(dbuf);
    80003be8:	8526                	mv	a0,s1
    80003bea:	9beff0ef          	jal	80002da8 <bunpin>
    80003bee:	b755                	j	80003b92 <install_trans+0x54>
}
    80003bf0:	60a6                	ld	ra,72(sp)
    80003bf2:	6406                	ld	s0,64(sp)
    80003bf4:	74e2                	ld	s1,56(sp)
    80003bf6:	7942                	ld	s2,48(sp)
    80003bf8:	79a2                	ld	s3,40(sp)
    80003bfa:	7a02                	ld	s4,32(sp)
    80003bfc:	6ae2                	ld	s5,24(sp)
    80003bfe:	6b42                	ld	s6,16(sp)
    80003c00:	6ba2                	ld	s7,8(sp)
    80003c02:	6c02                	ld	s8,0(sp)
    80003c04:	6161                	addi	sp,sp,80
    80003c06:	8082                	ret
    80003c08:	8082                	ret

0000000080003c0a <initlog>:
{
    80003c0a:	7179                	addi	sp,sp,-48
    80003c0c:	f406                	sd	ra,40(sp)
    80003c0e:	f022                	sd	s0,32(sp)
    80003c10:	ec26                	sd	s1,24(sp)
    80003c12:	e84a                	sd	s2,16(sp)
    80003c14:	e44e                	sd	s3,8(sp)
    80003c16:	1800                	addi	s0,sp,48
    80003c18:	84aa                	mv	s1,a0
    80003c1a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003c1c:	0001c917          	auipc	s2,0x1c
    80003c20:	d1c90913          	addi	s2,s2,-740 # 8001f938 <log>
    80003c24:	00004597          	auipc	a1,0x4
    80003c28:	8d458593          	addi	a1,a1,-1836 # 800074f8 <etext+0x4f8>
    80003c2c:	854a                	mv	a0,s2
    80003c2e:	f71fc0ef          	jal	80000b9e <initlock>
  log.start = sb->logstart;
    80003c32:	0149a583          	lw	a1,20(s3)
    80003c36:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003c3a:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003c3e:	8526                	mv	a0,s1
    80003c40:	fa9fe0ef          	jal	80002be8 <bread>
  log.lh.n = lh->n;
    80003c44:	4d30                	lw	a2,88(a0)
    80003c46:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003c4a:	00c05f63          	blez	a2,80003c68 <initlog+0x5e>
    80003c4e:	87aa                	mv	a5,a0
    80003c50:	0001c717          	auipc	a4,0x1c
    80003c54:	d1470713          	addi	a4,a4,-748 # 8001f964 <log+0x2c>
    80003c58:	060a                	slli	a2,a2,0x2
    80003c5a:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003c5c:	4ff4                	lw	a3,92(a5)
    80003c5e:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003c60:	0791                	addi	a5,a5,4
    80003c62:	0711                	addi	a4,a4,4
    80003c64:	fec79ce3          	bne	a5,a2,80003c5c <initlog+0x52>
  brelse(buf);
    80003c68:	888ff0ef          	jal	80002cf0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003c6c:	4505                	li	a0,1
    80003c6e:	ed1ff0ef          	jal	80003b3e <install_trans>
  log.lh.n = 0;
    80003c72:	0001c797          	auipc	a5,0x1c
    80003c76:	ce07a723          	sw	zero,-786(a5) # 8001f960 <log+0x28>
  write_head(); // clear the log
    80003c7a:	e67ff0ef          	jal	80003ae0 <write_head>
}
    80003c7e:	70a2                	ld	ra,40(sp)
    80003c80:	7402                	ld	s0,32(sp)
    80003c82:	64e2                	ld	s1,24(sp)
    80003c84:	6942                	ld	s2,16(sp)
    80003c86:	69a2                	ld	s3,8(sp)
    80003c88:	6145                	addi	sp,sp,48
    80003c8a:	8082                	ret

0000000080003c8c <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003c8c:	1101                	addi	sp,sp,-32
    80003c8e:	ec06                	sd	ra,24(sp)
    80003c90:	e822                	sd	s0,16(sp)
    80003c92:	e426                	sd	s1,8(sp)
    80003c94:	e04a                	sd	s2,0(sp)
    80003c96:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003c98:	0001c517          	auipc	a0,0x1c
    80003c9c:	ca050513          	addi	a0,a0,-864 # 8001f938 <log>
    80003ca0:	f89fc0ef          	jal	80000c28 <acquire>
  while(1){
    if(log.committing){
    80003ca4:	0001c497          	auipc	s1,0x1c
    80003ca8:	c9448493          	addi	s1,s1,-876 # 8001f938 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003cac:	4979                	li	s2,30
    80003cae:	a029                	j	80003cb8 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003cb0:	85a6                	mv	a1,s1
    80003cb2:	8526                	mv	a0,s1
    80003cb4:	a78fe0ef          	jal	80001f2c <sleep>
    if(log.committing){
    80003cb8:	509c                	lw	a5,32(s1)
    80003cba:	fbfd                	bnez	a5,80003cb0 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003cbc:	4cd8                	lw	a4,28(s1)
    80003cbe:	2705                	addiw	a4,a4,1
    80003cc0:	0027179b          	slliw	a5,a4,0x2
    80003cc4:	9fb9                	addw	a5,a5,a4
    80003cc6:	0017979b          	slliw	a5,a5,0x1
    80003cca:	5494                	lw	a3,40(s1)
    80003ccc:	9fb5                	addw	a5,a5,a3
    80003cce:	00f95763          	bge	s2,a5,80003cdc <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003cd2:	85a6                	mv	a1,s1
    80003cd4:	8526                	mv	a0,s1
    80003cd6:	a56fe0ef          	jal	80001f2c <sleep>
    80003cda:	bff9                	j	80003cb8 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003cdc:	0001c797          	auipc	a5,0x1c
    80003ce0:	c6e7ac23          	sw	a4,-904(a5) # 8001f954 <log+0x1c>
      release(&log.lock);
    80003ce4:	0001c517          	auipc	a0,0x1c
    80003ce8:	c5450513          	addi	a0,a0,-940 # 8001f938 <log>
    80003cec:	fd1fc0ef          	jal	80000cbc <release>
      break;
    }
  }
}
    80003cf0:	60e2                	ld	ra,24(sp)
    80003cf2:	6442                	ld	s0,16(sp)
    80003cf4:	64a2                	ld	s1,8(sp)
    80003cf6:	6902                	ld	s2,0(sp)
    80003cf8:	6105                	addi	sp,sp,32
    80003cfa:	8082                	ret

0000000080003cfc <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003cfc:	7139                	addi	sp,sp,-64
    80003cfe:	fc06                	sd	ra,56(sp)
    80003d00:	f822                	sd	s0,48(sp)
    80003d02:	f426                	sd	s1,40(sp)
    80003d04:	f04a                	sd	s2,32(sp)
    80003d06:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003d08:	0001c497          	auipc	s1,0x1c
    80003d0c:	c3048493          	addi	s1,s1,-976 # 8001f938 <log>
    80003d10:	8526                	mv	a0,s1
    80003d12:	f17fc0ef          	jal	80000c28 <acquire>
  log.outstanding -= 1;
    80003d16:	4cdc                	lw	a5,28(s1)
    80003d18:	37fd                	addiw	a5,a5,-1
    80003d1a:	893e                	mv	s2,a5
    80003d1c:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003d1e:	509c                	lw	a5,32(s1)
    80003d20:	e7b1                	bnez	a5,80003d6c <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003d22:	04091e63          	bnez	s2,80003d7e <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80003d26:	0001c497          	auipc	s1,0x1c
    80003d2a:	c1248493          	addi	s1,s1,-1006 # 8001f938 <log>
    80003d2e:	4785                	li	a5,1
    80003d30:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003d32:	8526                	mv	a0,s1
    80003d34:	f89fc0ef          	jal	80000cbc <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003d38:	549c                	lw	a5,40(s1)
    80003d3a:	06f04463          	bgtz	a5,80003da2 <end_op+0xa6>
    acquire(&log.lock);
    80003d3e:	0001c517          	auipc	a0,0x1c
    80003d42:	bfa50513          	addi	a0,a0,-1030 # 8001f938 <log>
    80003d46:	ee3fc0ef          	jal	80000c28 <acquire>
    log.committing = 0;
    80003d4a:	0001c797          	auipc	a5,0x1c
    80003d4e:	c007a723          	sw	zero,-1010(a5) # 8001f958 <log+0x20>
    wakeup(&log);
    80003d52:	0001c517          	auipc	a0,0x1c
    80003d56:	be650513          	addi	a0,a0,-1050 # 8001f938 <log>
    80003d5a:	a1efe0ef          	jal	80001f78 <wakeup>
    release(&log.lock);
    80003d5e:	0001c517          	auipc	a0,0x1c
    80003d62:	bda50513          	addi	a0,a0,-1062 # 8001f938 <log>
    80003d66:	f57fc0ef          	jal	80000cbc <release>
}
    80003d6a:	a035                	j	80003d96 <end_op+0x9a>
    80003d6c:	ec4e                	sd	s3,24(sp)
    80003d6e:	e852                	sd	s4,16(sp)
    80003d70:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003d72:	00003517          	auipc	a0,0x3
    80003d76:	78e50513          	addi	a0,a0,1934 # 80007500 <etext+0x500>
    80003d7a:	aabfc0ef          	jal	80000824 <panic>
    wakeup(&log);
    80003d7e:	0001c517          	auipc	a0,0x1c
    80003d82:	bba50513          	addi	a0,a0,-1094 # 8001f938 <log>
    80003d86:	9f2fe0ef          	jal	80001f78 <wakeup>
  release(&log.lock);
    80003d8a:	0001c517          	auipc	a0,0x1c
    80003d8e:	bae50513          	addi	a0,a0,-1106 # 8001f938 <log>
    80003d92:	f2bfc0ef          	jal	80000cbc <release>
}
    80003d96:	70e2                	ld	ra,56(sp)
    80003d98:	7442                	ld	s0,48(sp)
    80003d9a:	74a2                	ld	s1,40(sp)
    80003d9c:	7902                	ld	s2,32(sp)
    80003d9e:	6121                	addi	sp,sp,64
    80003da0:	8082                	ret
    80003da2:	ec4e                	sd	s3,24(sp)
    80003da4:	e852                	sd	s4,16(sp)
    80003da6:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003da8:	0001ca97          	auipc	s5,0x1c
    80003dac:	bbca8a93          	addi	s5,s5,-1092 # 8001f964 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003db0:	0001ca17          	auipc	s4,0x1c
    80003db4:	b88a0a13          	addi	s4,s4,-1144 # 8001f938 <log>
    80003db8:	018a2583          	lw	a1,24(s4)
    80003dbc:	012585bb          	addw	a1,a1,s2
    80003dc0:	2585                	addiw	a1,a1,1
    80003dc2:	024a2503          	lw	a0,36(s4)
    80003dc6:	e23fe0ef          	jal	80002be8 <bread>
    80003dca:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003dcc:	000aa583          	lw	a1,0(s5)
    80003dd0:	024a2503          	lw	a0,36(s4)
    80003dd4:	e15fe0ef          	jal	80002be8 <bread>
    80003dd8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003dda:	40000613          	li	a2,1024
    80003dde:	05850593          	addi	a1,a0,88
    80003de2:	05848513          	addi	a0,s1,88
    80003de6:	f73fc0ef          	jal	80000d58 <memmove>
    bwrite(to);  // write the log
    80003dea:	8526                	mv	a0,s1
    80003dec:	ed3fe0ef          	jal	80002cbe <bwrite>
    brelse(from);
    80003df0:	854e                	mv	a0,s3
    80003df2:	efffe0ef          	jal	80002cf0 <brelse>
    brelse(to);
    80003df6:	8526                	mv	a0,s1
    80003df8:	ef9fe0ef          	jal	80002cf0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003dfc:	2905                	addiw	s2,s2,1
    80003dfe:	0a91                	addi	s5,s5,4
    80003e00:	028a2783          	lw	a5,40(s4)
    80003e04:	faf94ae3          	blt	s2,a5,80003db8 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003e08:	cd9ff0ef          	jal	80003ae0 <write_head>
    install_trans(0); // Now install writes to home locations
    80003e0c:	4501                	li	a0,0
    80003e0e:	d31ff0ef          	jal	80003b3e <install_trans>
    log.lh.n = 0;
    80003e12:	0001c797          	auipc	a5,0x1c
    80003e16:	b407a723          	sw	zero,-1202(a5) # 8001f960 <log+0x28>
    write_head();    // Erase the transaction from the log
    80003e1a:	cc7ff0ef          	jal	80003ae0 <write_head>
    80003e1e:	69e2                	ld	s3,24(sp)
    80003e20:	6a42                	ld	s4,16(sp)
    80003e22:	6aa2                	ld	s5,8(sp)
    80003e24:	bf29                	j	80003d3e <end_op+0x42>

0000000080003e26 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003e26:	1101                	addi	sp,sp,-32
    80003e28:	ec06                	sd	ra,24(sp)
    80003e2a:	e822                	sd	s0,16(sp)
    80003e2c:	e426                	sd	s1,8(sp)
    80003e2e:	1000                	addi	s0,sp,32
    80003e30:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003e32:	0001c517          	auipc	a0,0x1c
    80003e36:	b0650513          	addi	a0,a0,-1274 # 8001f938 <log>
    80003e3a:	deffc0ef          	jal	80000c28 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003e3e:	0001c617          	auipc	a2,0x1c
    80003e42:	b2262603          	lw	a2,-1246(a2) # 8001f960 <log+0x28>
    80003e46:	47f5                	li	a5,29
    80003e48:	04c7cd63          	blt	a5,a2,80003ea2 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003e4c:	0001c797          	auipc	a5,0x1c
    80003e50:	b087a783          	lw	a5,-1272(a5) # 8001f954 <log+0x1c>
    80003e54:	04f05d63          	blez	a5,80003eae <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003e58:	4781                	li	a5,0
    80003e5a:	06c05063          	blez	a2,80003eba <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003e5e:	44cc                	lw	a1,12(s1)
    80003e60:	0001c717          	auipc	a4,0x1c
    80003e64:	b0470713          	addi	a4,a4,-1276 # 8001f964 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80003e68:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003e6a:	4314                	lw	a3,0(a4)
    80003e6c:	04b68763          	beq	a3,a1,80003eba <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80003e70:	2785                	addiw	a5,a5,1
    80003e72:	0711                	addi	a4,a4,4
    80003e74:	fef61be3          	bne	a2,a5,80003e6a <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003e78:	060a                	slli	a2,a2,0x2
    80003e7a:	02060613          	addi	a2,a2,32
    80003e7e:	0001c797          	auipc	a5,0x1c
    80003e82:	aba78793          	addi	a5,a5,-1350 # 8001f938 <log>
    80003e86:	97b2                	add	a5,a5,a2
    80003e88:	44d8                	lw	a4,12(s1)
    80003e8a:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003e8c:	8526                	mv	a0,s1
    80003e8e:	ee7fe0ef          	jal	80002d74 <bpin>
    log.lh.n++;
    80003e92:	0001c717          	auipc	a4,0x1c
    80003e96:	aa670713          	addi	a4,a4,-1370 # 8001f938 <log>
    80003e9a:	571c                	lw	a5,40(a4)
    80003e9c:	2785                	addiw	a5,a5,1
    80003e9e:	d71c                	sw	a5,40(a4)
    80003ea0:	a815                	j	80003ed4 <log_write+0xae>
    panic("too big a transaction");
    80003ea2:	00003517          	auipc	a0,0x3
    80003ea6:	66e50513          	addi	a0,a0,1646 # 80007510 <etext+0x510>
    80003eaa:	97bfc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    80003eae:	00003517          	auipc	a0,0x3
    80003eb2:	67a50513          	addi	a0,a0,1658 # 80007528 <etext+0x528>
    80003eb6:	96ffc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    80003eba:	00279693          	slli	a3,a5,0x2
    80003ebe:	02068693          	addi	a3,a3,32
    80003ec2:	0001c717          	auipc	a4,0x1c
    80003ec6:	a7670713          	addi	a4,a4,-1418 # 8001f938 <log>
    80003eca:	9736                	add	a4,a4,a3
    80003ecc:	44d4                	lw	a3,12(s1)
    80003ece:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003ed0:	faf60ee3          	beq	a2,a5,80003e8c <log_write+0x66>
  }
  release(&log.lock);
    80003ed4:	0001c517          	auipc	a0,0x1c
    80003ed8:	a6450513          	addi	a0,a0,-1436 # 8001f938 <log>
    80003edc:	de1fc0ef          	jal	80000cbc <release>
}
    80003ee0:	60e2                	ld	ra,24(sp)
    80003ee2:	6442                	ld	s0,16(sp)
    80003ee4:	64a2                	ld	s1,8(sp)
    80003ee6:	6105                	addi	sp,sp,32
    80003ee8:	8082                	ret

0000000080003eea <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003eea:	1101                	addi	sp,sp,-32
    80003eec:	ec06                	sd	ra,24(sp)
    80003eee:	e822                	sd	s0,16(sp)
    80003ef0:	e426                	sd	s1,8(sp)
    80003ef2:	e04a                	sd	s2,0(sp)
    80003ef4:	1000                	addi	s0,sp,32
    80003ef6:	84aa                	mv	s1,a0
    80003ef8:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003efa:	00003597          	auipc	a1,0x3
    80003efe:	64e58593          	addi	a1,a1,1614 # 80007548 <etext+0x548>
    80003f02:	0521                	addi	a0,a0,8
    80003f04:	c9bfc0ef          	jal	80000b9e <initlock>
  lk->name = name;
    80003f08:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003f0c:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003f10:	0204a423          	sw	zero,40(s1)
}
    80003f14:	60e2                	ld	ra,24(sp)
    80003f16:	6442                	ld	s0,16(sp)
    80003f18:	64a2                	ld	s1,8(sp)
    80003f1a:	6902                	ld	s2,0(sp)
    80003f1c:	6105                	addi	sp,sp,32
    80003f1e:	8082                	ret

0000000080003f20 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003f20:	1101                	addi	sp,sp,-32
    80003f22:	ec06                	sd	ra,24(sp)
    80003f24:	e822                	sd	s0,16(sp)
    80003f26:	e426                	sd	s1,8(sp)
    80003f28:	e04a                	sd	s2,0(sp)
    80003f2a:	1000                	addi	s0,sp,32
    80003f2c:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003f2e:	00850913          	addi	s2,a0,8
    80003f32:	854a                	mv	a0,s2
    80003f34:	cf5fc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    80003f38:	409c                	lw	a5,0(s1)
    80003f3a:	c799                	beqz	a5,80003f48 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003f3c:	85ca                	mv	a1,s2
    80003f3e:	8526                	mv	a0,s1
    80003f40:	fedfd0ef          	jal	80001f2c <sleep>
  while (lk->locked) {
    80003f44:	409c                	lw	a5,0(s1)
    80003f46:	fbfd                	bnez	a5,80003f3c <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003f48:	4785                	li	a5,1
    80003f4a:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003f4c:	9e3fd0ef          	jal	8000192e <myproc>
    80003f50:	591c                	lw	a5,48(a0)
    80003f52:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003f54:	854a                	mv	a0,s2
    80003f56:	d67fc0ef          	jal	80000cbc <release>
}
    80003f5a:	60e2                	ld	ra,24(sp)
    80003f5c:	6442                	ld	s0,16(sp)
    80003f5e:	64a2                	ld	s1,8(sp)
    80003f60:	6902                	ld	s2,0(sp)
    80003f62:	6105                	addi	sp,sp,32
    80003f64:	8082                	ret

0000000080003f66 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003f66:	1101                	addi	sp,sp,-32
    80003f68:	ec06                	sd	ra,24(sp)
    80003f6a:	e822                	sd	s0,16(sp)
    80003f6c:	e426                	sd	s1,8(sp)
    80003f6e:	e04a                	sd	s2,0(sp)
    80003f70:	1000                	addi	s0,sp,32
    80003f72:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003f74:	00850913          	addi	s2,a0,8
    80003f78:	854a                	mv	a0,s2
    80003f7a:	caffc0ef          	jal	80000c28 <acquire>
  lk->locked = 0;
    80003f7e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003f82:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003f86:	8526                	mv	a0,s1
    80003f88:	ff1fd0ef          	jal	80001f78 <wakeup>
  release(&lk->lk);
    80003f8c:	854a                	mv	a0,s2
    80003f8e:	d2ffc0ef          	jal	80000cbc <release>
}
    80003f92:	60e2                	ld	ra,24(sp)
    80003f94:	6442                	ld	s0,16(sp)
    80003f96:	64a2                	ld	s1,8(sp)
    80003f98:	6902                	ld	s2,0(sp)
    80003f9a:	6105                	addi	sp,sp,32
    80003f9c:	8082                	ret

0000000080003f9e <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003f9e:	7179                	addi	sp,sp,-48
    80003fa0:	f406                	sd	ra,40(sp)
    80003fa2:	f022                	sd	s0,32(sp)
    80003fa4:	ec26                	sd	s1,24(sp)
    80003fa6:	e84a                	sd	s2,16(sp)
    80003fa8:	1800                	addi	s0,sp,48
    80003faa:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003fac:	00850913          	addi	s2,a0,8
    80003fb0:	854a                	mv	a0,s2
    80003fb2:	c77fc0ef          	jal	80000c28 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003fb6:	409c                	lw	a5,0(s1)
    80003fb8:	ef81                	bnez	a5,80003fd0 <holdingsleep+0x32>
    80003fba:	4481                	li	s1,0
  release(&lk->lk);
    80003fbc:	854a                	mv	a0,s2
    80003fbe:	cfffc0ef          	jal	80000cbc <release>
  return r;
}
    80003fc2:	8526                	mv	a0,s1
    80003fc4:	70a2                	ld	ra,40(sp)
    80003fc6:	7402                	ld	s0,32(sp)
    80003fc8:	64e2                	ld	s1,24(sp)
    80003fca:	6942                	ld	s2,16(sp)
    80003fcc:	6145                	addi	sp,sp,48
    80003fce:	8082                	ret
    80003fd0:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003fd2:	0284a983          	lw	s3,40(s1)
    80003fd6:	959fd0ef          	jal	8000192e <myproc>
    80003fda:	5904                	lw	s1,48(a0)
    80003fdc:	413484b3          	sub	s1,s1,s3
    80003fe0:	0014b493          	seqz	s1,s1
    80003fe4:	69a2                	ld	s3,8(sp)
    80003fe6:	bfd9                	j	80003fbc <holdingsleep+0x1e>

0000000080003fe8 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003fe8:	1141                	addi	sp,sp,-16
    80003fea:	e406                	sd	ra,8(sp)
    80003fec:	e022                	sd	s0,0(sp)
    80003fee:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003ff0:	00003597          	auipc	a1,0x3
    80003ff4:	56858593          	addi	a1,a1,1384 # 80007558 <etext+0x558>
    80003ff8:	0001c517          	auipc	a0,0x1c
    80003ffc:	a8850513          	addi	a0,a0,-1400 # 8001fa80 <ftable>
    80004000:	b9ffc0ef          	jal	80000b9e <initlock>
}
    80004004:	60a2                	ld	ra,8(sp)
    80004006:	6402                	ld	s0,0(sp)
    80004008:	0141                	addi	sp,sp,16
    8000400a:	8082                	ret

000000008000400c <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000400c:	1101                	addi	sp,sp,-32
    8000400e:	ec06                	sd	ra,24(sp)
    80004010:	e822                	sd	s0,16(sp)
    80004012:	e426                	sd	s1,8(sp)
    80004014:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004016:	0001c517          	auipc	a0,0x1c
    8000401a:	a6a50513          	addi	a0,a0,-1430 # 8001fa80 <ftable>
    8000401e:	c0bfc0ef          	jal	80000c28 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004022:	0001c497          	auipc	s1,0x1c
    80004026:	a7648493          	addi	s1,s1,-1418 # 8001fa98 <ftable+0x18>
    8000402a:	0001d717          	auipc	a4,0x1d
    8000402e:	a0e70713          	addi	a4,a4,-1522 # 80020a38 <disk>
    if(f->ref == 0){
    80004032:	40dc                	lw	a5,4(s1)
    80004034:	cf89                	beqz	a5,8000404e <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004036:	02848493          	addi	s1,s1,40
    8000403a:	fee49ce3          	bne	s1,a4,80004032 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000403e:	0001c517          	auipc	a0,0x1c
    80004042:	a4250513          	addi	a0,a0,-1470 # 8001fa80 <ftable>
    80004046:	c77fc0ef          	jal	80000cbc <release>
  return 0;
    8000404a:	4481                	li	s1,0
    8000404c:	a809                	j	8000405e <filealloc+0x52>
      f->ref = 1;
    8000404e:	4785                	li	a5,1
    80004050:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004052:	0001c517          	auipc	a0,0x1c
    80004056:	a2e50513          	addi	a0,a0,-1490 # 8001fa80 <ftable>
    8000405a:	c63fc0ef          	jal	80000cbc <release>
}
    8000405e:	8526                	mv	a0,s1
    80004060:	60e2                	ld	ra,24(sp)
    80004062:	6442                	ld	s0,16(sp)
    80004064:	64a2                	ld	s1,8(sp)
    80004066:	6105                	addi	sp,sp,32
    80004068:	8082                	ret

000000008000406a <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    8000406a:	1101                	addi	sp,sp,-32
    8000406c:	ec06                	sd	ra,24(sp)
    8000406e:	e822                	sd	s0,16(sp)
    80004070:	e426                	sd	s1,8(sp)
    80004072:	1000                	addi	s0,sp,32
    80004074:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004076:	0001c517          	auipc	a0,0x1c
    8000407a:	a0a50513          	addi	a0,a0,-1526 # 8001fa80 <ftable>
    8000407e:	babfc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    80004082:	40dc                	lw	a5,4(s1)
    80004084:	02f05063          	blez	a5,800040a4 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004088:	2785                	addiw	a5,a5,1
    8000408a:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000408c:	0001c517          	auipc	a0,0x1c
    80004090:	9f450513          	addi	a0,a0,-1548 # 8001fa80 <ftable>
    80004094:	c29fc0ef          	jal	80000cbc <release>
  return f;
}
    80004098:	8526                	mv	a0,s1
    8000409a:	60e2                	ld	ra,24(sp)
    8000409c:	6442                	ld	s0,16(sp)
    8000409e:	64a2                	ld	s1,8(sp)
    800040a0:	6105                	addi	sp,sp,32
    800040a2:	8082                	ret
    panic("filedup");
    800040a4:	00003517          	auipc	a0,0x3
    800040a8:	4bc50513          	addi	a0,a0,1212 # 80007560 <etext+0x560>
    800040ac:	f78fc0ef          	jal	80000824 <panic>

00000000800040b0 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800040b0:	7139                	addi	sp,sp,-64
    800040b2:	fc06                	sd	ra,56(sp)
    800040b4:	f822                	sd	s0,48(sp)
    800040b6:	f426                	sd	s1,40(sp)
    800040b8:	0080                	addi	s0,sp,64
    800040ba:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800040bc:	0001c517          	auipc	a0,0x1c
    800040c0:	9c450513          	addi	a0,a0,-1596 # 8001fa80 <ftable>
    800040c4:	b65fc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    800040c8:	40dc                	lw	a5,4(s1)
    800040ca:	04f05a63          	blez	a5,8000411e <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800040ce:	37fd                	addiw	a5,a5,-1
    800040d0:	c0dc                	sw	a5,4(s1)
    800040d2:	06f04063          	bgtz	a5,80004132 <fileclose+0x82>
    800040d6:	f04a                	sd	s2,32(sp)
    800040d8:	ec4e                	sd	s3,24(sp)
    800040da:	e852                	sd	s4,16(sp)
    800040dc:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800040de:	0004a903          	lw	s2,0(s1)
    800040e2:	0094c783          	lbu	a5,9(s1)
    800040e6:	89be                	mv	s3,a5
    800040e8:	689c                	ld	a5,16(s1)
    800040ea:	8a3e                	mv	s4,a5
    800040ec:	6c9c                	ld	a5,24(s1)
    800040ee:	8abe                	mv	s5,a5
  f->ref = 0;
    800040f0:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800040f4:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800040f8:	0001c517          	auipc	a0,0x1c
    800040fc:	98850513          	addi	a0,a0,-1656 # 8001fa80 <ftable>
    80004100:	bbdfc0ef          	jal	80000cbc <release>

  if(ff.type == FD_PIPE){
    80004104:	4785                	li	a5,1
    80004106:	04f90163          	beq	s2,a5,80004148 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000410a:	ffe9079b          	addiw	a5,s2,-2
    8000410e:	4705                	li	a4,1
    80004110:	04f77563          	bgeu	a4,a5,8000415a <fileclose+0xaa>
    80004114:	7902                	ld	s2,32(sp)
    80004116:	69e2                	ld	s3,24(sp)
    80004118:	6a42                	ld	s4,16(sp)
    8000411a:	6aa2                	ld	s5,8(sp)
    8000411c:	a00d                	j	8000413e <fileclose+0x8e>
    8000411e:	f04a                	sd	s2,32(sp)
    80004120:	ec4e                	sd	s3,24(sp)
    80004122:	e852                	sd	s4,16(sp)
    80004124:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004126:	00003517          	auipc	a0,0x3
    8000412a:	44250513          	addi	a0,a0,1090 # 80007568 <etext+0x568>
    8000412e:	ef6fc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    80004132:	0001c517          	auipc	a0,0x1c
    80004136:	94e50513          	addi	a0,a0,-1714 # 8001fa80 <ftable>
    8000413a:	b83fc0ef          	jal	80000cbc <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000413e:	70e2                	ld	ra,56(sp)
    80004140:	7442                	ld	s0,48(sp)
    80004142:	74a2                	ld	s1,40(sp)
    80004144:	6121                	addi	sp,sp,64
    80004146:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004148:	85ce                	mv	a1,s3
    8000414a:	8552                	mv	a0,s4
    8000414c:	348000ef          	jal	80004494 <pipeclose>
    80004150:	7902                	ld	s2,32(sp)
    80004152:	69e2                	ld	s3,24(sp)
    80004154:	6a42                	ld	s4,16(sp)
    80004156:	6aa2                	ld	s5,8(sp)
    80004158:	b7dd                	j	8000413e <fileclose+0x8e>
    begin_op();
    8000415a:	b33ff0ef          	jal	80003c8c <begin_op>
    iput(ff.ip);
    8000415e:	8556                	mv	a0,s5
    80004160:	aa2ff0ef          	jal	80003402 <iput>
    end_op();
    80004164:	b99ff0ef          	jal	80003cfc <end_op>
    80004168:	7902                	ld	s2,32(sp)
    8000416a:	69e2                	ld	s3,24(sp)
    8000416c:	6a42                	ld	s4,16(sp)
    8000416e:	6aa2                	ld	s5,8(sp)
    80004170:	b7f9                	j	8000413e <fileclose+0x8e>

0000000080004172 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004172:	715d                	addi	sp,sp,-80
    80004174:	e486                	sd	ra,72(sp)
    80004176:	e0a2                	sd	s0,64(sp)
    80004178:	fc26                	sd	s1,56(sp)
    8000417a:	f052                	sd	s4,32(sp)
    8000417c:	0880                	addi	s0,sp,80
    8000417e:	84aa                	mv	s1,a0
    80004180:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004182:	facfd0ef          	jal	8000192e <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004186:	409c                	lw	a5,0(s1)
    80004188:	37f9                	addiw	a5,a5,-2
    8000418a:	4705                	li	a4,1
    8000418c:	04f76263          	bltu	a4,a5,800041d0 <filestat+0x5e>
    80004190:	f84a                	sd	s2,48(sp)
    80004192:	f44e                	sd	s3,40(sp)
    80004194:	89aa                	mv	s3,a0
    ilock(f->ip);
    80004196:	6c88                	ld	a0,24(s1)
    80004198:	8e8ff0ef          	jal	80003280 <ilock>
    stati(f->ip, &st);
    8000419c:	fb840913          	addi	s2,s0,-72
    800041a0:	85ca                	mv	a1,s2
    800041a2:	6c88                	ld	a0,24(s1)
    800041a4:	c40ff0ef          	jal	800035e4 <stati>
    iunlock(f->ip);
    800041a8:	6c88                	ld	a0,24(s1)
    800041aa:	984ff0ef          	jal	8000332e <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800041ae:	46e1                	li	a3,24
    800041b0:	864a                	mv	a2,s2
    800041b2:	85d2                	mv	a1,s4
    800041b4:	0509b503          	ld	a0,80(s3)
    800041b8:	c9cfd0ef          	jal	80001654 <copyout>
    800041bc:	41f5551b          	sraiw	a0,a0,0x1f
    800041c0:	7942                	ld	s2,48(sp)
    800041c2:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800041c4:	60a6                	ld	ra,72(sp)
    800041c6:	6406                	ld	s0,64(sp)
    800041c8:	74e2                	ld	s1,56(sp)
    800041ca:	7a02                	ld	s4,32(sp)
    800041cc:	6161                	addi	sp,sp,80
    800041ce:	8082                	ret
  return -1;
    800041d0:	557d                	li	a0,-1
    800041d2:	bfcd                	j	800041c4 <filestat+0x52>

00000000800041d4 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800041d4:	7179                	addi	sp,sp,-48
    800041d6:	f406                	sd	ra,40(sp)
    800041d8:	f022                	sd	s0,32(sp)
    800041da:	e84a                	sd	s2,16(sp)
    800041dc:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800041de:	00854783          	lbu	a5,8(a0)
    800041e2:	cfd1                	beqz	a5,8000427e <fileread+0xaa>
    800041e4:	ec26                	sd	s1,24(sp)
    800041e6:	e44e                	sd	s3,8(sp)
    800041e8:	84aa                	mv	s1,a0
    800041ea:	892e                	mv	s2,a1
    800041ec:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800041ee:	411c                	lw	a5,0(a0)
    800041f0:	4705                	li	a4,1
    800041f2:	04e78363          	beq	a5,a4,80004238 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800041f6:	470d                	li	a4,3
    800041f8:	04e78763          	beq	a5,a4,80004246 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800041fc:	4709                	li	a4,2
    800041fe:	06e79a63          	bne	a5,a4,80004272 <fileread+0x9e>
    ilock(f->ip);
    80004202:	6d08                	ld	a0,24(a0)
    80004204:	87cff0ef          	jal	80003280 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004208:	874e                	mv	a4,s3
    8000420a:	5094                	lw	a3,32(s1)
    8000420c:	864a                	mv	a2,s2
    8000420e:	4585                	li	a1,1
    80004210:	6c88                	ld	a0,24(s1)
    80004212:	c00ff0ef          	jal	80003612 <readi>
    80004216:	892a                	mv	s2,a0
    80004218:	00a05563          	blez	a0,80004222 <fileread+0x4e>
      f->off += r;
    8000421c:	509c                	lw	a5,32(s1)
    8000421e:	9fa9                	addw	a5,a5,a0
    80004220:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004222:	6c88                	ld	a0,24(s1)
    80004224:	90aff0ef          	jal	8000332e <iunlock>
    80004228:	64e2                	ld	s1,24(sp)
    8000422a:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000422c:	854a                	mv	a0,s2
    8000422e:	70a2                	ld	ra,40(sp)
    80004230:	7402                	ld	s0,32(sp)
    80004232:	6942                	ld	s2,16(sp)
    80004234:	6145                	addi	sp,sp,48
    80004236:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004238:	6908                	ld	a0,16(a0)
    8000423a:	3b0000ef          	jal	800045ea <piperead>
    8000423e:	892a                	mv	s2,a0
    80004240:	64e2                	ld	s1,24(sp)
    80004242:	69a2                	ld	s3,8(sp)
    80004244:	b7e5                	j	8000422c <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004246:	02451783          	lh	a5,36(a0)
    8000424a:	03079693          	slli	a3,a5,0x30
    8000424e:	92c1                	srli	a3,a3,0x30
    80004250:	4725                	li	a4,9
    80004252:	02d76963          	bltu	a4,a3,80004284 <fileread+0xb0>
    80004256:	0792                	slli	a5,a5,0x4
    80004258:	0001b717          	auipc	a4,0x1b
    8000425c:	78870713          	addi	a4,a4,1928 # 8001f9e0 <devsw>
    80004260:	97ba                	add	a5,a5,a4
    80004262:	639c                	ld	a5,0(a5)
    80004264:	c78d                	beqz	a5,8000428e <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80004266:	4505                	li	a0,1
    80004268:	9782                	jalr	a5
    8000426a:	892a                	mv	s2,a0
    8000426c:	64e2                	ld	s1,24(sp)
    8000426e:	69a2                	ld	s3,8(sp)
    80004270:	bf75                	j	8000422c <fileread+0x58>
    panic("fileread");
    80004272:	00003517          	auipc	a0,0x3
    80004276:	30650513          	addi	a0,a0,774 # 80007578 <etext+0x578>
    8000427a:	daafc0ef          	jal	80000824 <panic>
    return -1;
    8000427e:	57fd                	li	a5,-1
    80004280:	893e                	mv	s2,a5
    80004282:	b76d                	j	8000422c <fileread+0x58>
      return -1;
    80004284:	57fd                	li	a5,-1
    80004286:	893e                	mv	s2,a5
    80004288:	64e2                	ld	s1,24(sp)
    8000428a:	69a2                	ld	s3,8(sp)
    8000428c:	b745                	j	8000422c <fileread+0x58>
    8000428e:	57fd                	li	a5,-1
    80004290:	893e                	mv	s2,a5
    80004292:	64e2                	ld	s1,24(sp)
    80004294:	69a2                	ld	s3,8(sp)
    80004296:	bf59                	j	8000422c <fileread+0x58>

0000000080004298 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004298:	00954783          	lbu	a5,9(a0)
    8000429c:	10078f63          	beqz	a5,800043ba <filewrite+0x122>
{
    800042a0:	711d                	addi	sp,sp,-96
    800042a2:	ec86                	sd	ra,88(sp)
    800042a4:	e8a2                	sd	s0,80(sp)
    800042a6:	e0ca                	sd	s2,64(sp)
    800042a8:	f456                	sd	s5,40(sp)
    800042aa:	f05a                	sd	s6,32(sp)
    800042ac:	1080                	addi	s0,sp,96
    800042ae:	892a                	mv	s2,a0
    800042b0:	8b2e                	mv	s6,a1
    800042b2:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800042b4:	411c                	lw	a5,0(a0)
    800042b6:	4705                	li	a4,1
    800042b8:	02e78a63          	beq	a5,a4,800042ec <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800042bc:	470d                	li	a4,3
    800042be:	02e78b63          	beq	a5,a4,800042f4 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800042c2:	4709                	li	a4,2
    800042c4:	0ce79f63          	bne	a5,a4,800043a2 <filewrite+0x10a>
    800042c8:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800042ca:	0ac05a63          	blez	a2,8000437e <filewrite+0xe6>
    800042ce:	e4a6                	sd	s1,72(sp)
    800042d0:	fc4e                	sd	s3,56(sp)
    800042d2:	ec5e                	sd	s7,24(sp)
    800042d4:	e862                	sd	s8,16(sp)
    800042d6:	e466                	sd	s9,8(sp)
    int i = 0;
    800042d8:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800042da:	6b85                	lui	s7,0x1
    800042dc:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800042e0:	6785                	lui	a5,0x1
    800042e2:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800042e6:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800042e8:	4c05                	li	s8,1
    800042ea:	a8ad                	j	80004364 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800042ec:	6908                	ld	a0,16(a0)
    800042ee:	204000ef          	jal	800044f2 <pipewrite>
    800042f2:	a04d                	j	80004394 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800042f4:	02451783          	lh	a5,36(a0)
    800042f8:	03079693          	slli	a3,a5,0x30
    800042fc:	92c1                	srli	a3,a3,0x30
    800042fe:	4725                	li	a4,9
    80004300:	0ad76f63          	bltu	a4,a3,800043be <filewrite+0x126>
    80004304:	0792                	slli	a5,a5,0x4
    80004306:	0001b717          	auipc	a4,0x1b
    8000430a:	6da70713          	addi	a4,a4,1754 # 8001f9e0 <devsw>
    8000430e:	97ba                	add	a5,a5,a4
    80004310:	679c                	ld	a5,8(a5)
    80004312:	cbc5                	beqz	a5,800043c2 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80004314:	4505                	li	a0,1
    80004316:	9782                	jalr	a5
    80004318:	a8b5                	j	80004394 <filewrite+0xfc>
      if(n1 > max)
    8000431a:	2981                	sext.w	s3,s3
      begin_op();
    8000431c:	971ff0ef          	jal	80003c8c <begin_op>
      ilock(f->ip);
    80004320:	01893503          	ld	a0,24(s2)
    80004324:	f5dfe0ef          	jal	80003280 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004328:	874e                	mv	a4,s3
    8000432a:	02092683          	lw	a3,32(s2)
    8000432e:	016a0633          	add	a2,s4,s6
    80004332:	85e2                	mv	a1,s8
    80004334:	01893503          	ld	a0,24(s2)
    80004338:	bccff0ef          	jal	80003704 <writei>
    8000433c:	84aa                	mv	s1,a0
    8000433e:	00a05763          	blez	a0,8000434c <filewrite+0xb4>
        f->off += r;
    80004342:	02092783          	lw	a5,32(s2)
    80004346:	9fa9                	addw	a5,a5,a0
    80004348:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000434c:	01893503          	ld	a0,24(s2)
    80004350:	fdffe0ef          	jal	8000332e <iunlock>
      end_op();
    80004354:	9a9ff0ef          	jal	80003cfc <end_op>

      if(r != n1){
    80004358:	02999563          	bne	s3,s1,80004382 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000435c:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004360:	015a5963          	bge	s4,s5,80004372 <filewrite+0xda>
      int n1 = n - i;
    80004364:	414a87bb          	subw	a5,s5,s4
    80004368:	89be                	mv	s3,a5
      if(n1 > max)
    8000436a:	fafbd8e3          	bge	s7,a5,8000431a <filewrite+0x82>
    8000436e:	89e6                	mv	s3,s9
    80004370:	b76d                	j	8000431a <filewrite+0x82>
    80004372:	64a6                	ld	s1,72(sp)
    80004374:	79e2                	ld	s3,56(sp)
    80004376:	6be2                	ld	s7,24(sp)
    80004378:	6c42                	ld	s8,16(sp)
    8000437a:	6ca2                	ld	s9,8(sp)
    8000437c:	a801                	j	8000438c <filewrite+0xf4>
    int i = 0;
    8000437e:	4a01                	li	s4,0
    80004380:	a031                	j	8000438c <filewrite+0xf4>
    80004382:	64a6                	ld	s1,72(sp)
    80004384:	79e2                	ld	s3,56(sp)
    80004386:	6be2                	ld	s7,24(sp)
    80004388:	6c42                	ld	s8,16(sp)
    8000438a:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000438c:	034a9d63          	bne	s5,s4,800043c6 <filewrite+0x12e>
    80004390:	8556                	mv	a0,s5
    80004392:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004394:	60e6                	ld	ra,88(sp)
    80004396:	6446                	ld	s0,80(sp)
    80004398:	6906                	ld	s2,64(sp)
    8000439a:	7aa2                	ld	s5,40(sp)
    8000439c:	7b02                	ld	s6,32(sp)
    8000439e:	6125                	addi	sp,sp,96
    800043a0:	8082                	ret
    800043a2:	e4a6                	sd	s1,72(sp)
    800043a4:	fc4e                	sd	s3,56(sp)
    800043a6:	f852                	sd	s4,48(sp)
    800043a8:	ec5e                	sd	s7,24(sp)
    800043aa:	e862                	sd	s8,16(sp)
    800043ac:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800043ae:	00003517          	auipc	a0,0x3
    800043b2:	1da50513          	addi	a0,a0,474 # 80007588 <etext+0x588>
    800043b6:	c6efc0ef          	jal	80000824 <panic>
    return -1;
    800043ba:	557d                	li	a0,-1
}
    800043bc:	8082                	ret
      return -1;
    800043be:	557d                	li	a0,-1
    800043c0:	bfd1                	j	80004394 <filewrite+0xfc>
    800043c2:	557d                	li	a0,-1
    800043c4:	bfc1                	j	80004394 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800043c6:	557d                	li	a0,-1
    800043c8:	7a42                	ld	s4,48(sp)
    800043ca:	b7e9                	j	80004394 <filewrite+0xfc>

00000000800043cc <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800043cc:	7179                	addi	sp,sp,-48
    800043ce:	f406                	sd	ra,40(sp)
    800043d0:	f022                	sd	s0,32(sp)
    800043d2:	ec26                	sd	s1,24(sp)
    800043d4:	e052                	sd	s4,0(sp)
    800043d6:	1800                	addi	s0,sp,48
    800043d8:	84aa                	mv	s1,a0
    800043da:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800043dc:	0005b023          	sd	zero,0(a1)
    800043e0:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800043e4:	c29ff0ef          	jal	8000400c <filealloc>
    800043e8:	e088                	sd	a0,0(s1)
    800043ea:	c549                	beqz	a0,80004474 <pipealloc+0xa8>
    800043ec:	c21ff0ef          	jal	8000400c <filealloc>
    800043f0:	00aa3023          	sd	a0,0(s4)
    800043f4:	cd25                	beqz	a0,8000446c <pipealloc+0xa0>
    800043f6:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800043f8:	f4cfc0ef          	jal	80000b44 <kalloc>
    800043fc:	892a                	mv	s2,a0
    800043fe:	c12d                	beqz	a0,80004460 <pipealloc+0x94>
    80004400:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004402:	4985                	li	s3,1
    80004404:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004408:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000440c:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004410:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004414:	00003597          	auipc	a1,0x3
    80004418:	18458593          	addi	a1,a1,388 # 80007598 <etext+0x598>
    8000441c:	f82fc0ef          	jal	80000b9e <initlock>
  (*f0)->type = FD_PIPE;
    80004420:	609c                	ld	a5,0(s1)
    80004422:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004426:	609c                	ld	a5,0(s1)
    80004428:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000442c:	609c                	ld	a5,0(s1)
    8000442e:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004432:	609c                	ld	a5,0(s1)
    80004434:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004438:	000a3783          	ld	a5,0(s4)
    8000443c:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004440:	000a3783          	ld	a5,0(s4)
    80004444:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004448:	000a3783          	ld	a5,0(s4)
    8000444c:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004450:	000a3783          	ld	a5,0(s4)
    80004454:	0127b823          	sd	s2,16(a5)
  return 0;
    80004458:	4501                	li	a0,0
    8000445a:	6942                	ld	s2,16(sp)
    8000445c:	69a2                	ld	s3,8(sp)
    8000445e:	a01d                	j	80004484 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004460:	6088                	ld	a0,0(s1)
    80004462:	c119                	beqz	a0,80004468 <pipealloc+0x9c>
    80004464:	6942                	ld	s2,16(sp)
    80004466:	a029                	j	80004470 <pipealloc+0xa4>
    80004468:	6942                	ld	s2,16(sp)
    8000446a:	a029                	j	80004474 <pipealloc+0xa8>
    8000446c:	6088                	ld	a0,0(s1)
    8000446e:	c10d                	beqz	a0,80004490 <pipealloc+0xc4>
    fileclose(*f0);
    80004470:	c41ff0ef          	jal	800040b0 <fileclose>
  if(*f1)
    80004474:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004478:	557d                	li	a0,-1
  if(*f1)
    8000447a:	c789                	beqz	a5,80004484 <pipealloc+0xb8>
    fileclose(*f1);
    8000447c:	853e                	mv	a0,a5
    8000447e:	c33ff0ef          	jal	800040b0 <fileclose>
  return -1;
    80004482:	557d                	li	a0,-1
}
    80004484:	70a2                	ld	ra,40(sp)
    80004486:	7402                	ld	s0,32(sp)
    80004488:	64e2                	ld	s1,24(sp)
    8000448a:	6a02                	ld	s4,0(sp)
    8000448c:	6145                	addi	sp,sp,48
    8000448e:	8082                	ret
  return -1;
    80004490:	557d                	li	a0,-1
    80004492:	bfcd                	j	80004484 <pipealloc+0xb8>

0000000080004494 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004494:	1101                	addi	sp,sp,-32
    80004496:	ec06                	sd	ra,24(sp)
    80004498:	e822                	sd	s0,16(sp)
    8000449a:	e426                	sd	s1,8(sp)
    8000449c:	e04a                	sd	s2,0(sp)
    8000449e:	1000                	addi	s0,sp,32
    800044a0:	84aa                	mv	s1,a0
    800044a2:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800044a4:	f84fc0ef          	jal	80000c28 <acquire>
  if(writable){
    800044a8:	02090763          	beqz	s2,800044d6 <pipeclose+0x42>
    pi->writeopen = 0;
    800044ac:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800044b0:	21848513          	addi	a0,s1,536
    800044b4:	ac5fd0ef          	jal	80001f78 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800044b8:	2204a783          	lw	a5,544(s1)
    800044bc:	e781                	bnez	a5,800044c4 <pipeclose+0x30>
    800044be:	2244a783          	lw	a5,548(s1)
    800044c2:	c38d                	beqz	a5,800044e4 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800044c4:	8526                	mv	a0,s1
    800044c6:	ff6fc0ef          	jal	80000cbc <release>
}
    800044ca:	60e2                	ld	ra,24(sp)
    800044cc:	6442                	ld	s0,16(sp)
    800044ce:	64a2                	ld	s1,8(sp)
    800044d0:	6902                	ld	s2,0(sp)
    800044d2:	6105                	addi	sp,sp,32
    800044d4:	8082                	ret
    pi->readopen = 0;
    800044d6:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800044da:	21c48513          	addi	a0,s1,540
    800044de:	a9bfd0ef          	jal	80001f78 <wakeup>
    800044e2:	bfd9                	j	800044b8 <pipeclose+0x24>
    release(&pi->lock);
    800044e4:	8526                	mv	a0,s1
    800044e6:	fd6fc0ef          	jal	80000cbc <release>
    kfree((char*)pi);
    800044ea:	8526                	mv	a0,s1
    800044ec:	d70fc0ef          	jal	80000a5c <kfree>
    800044f0:	bfe9                	j	800044ca <pipeclose+0x36>

00000000800044f2 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800044f2:	7159                	addi	sp,sp,-112
    800044f4:	f486                	sd	ra,104(sp)
    800044f6:	f0a2                	sd	s0,96(sp)
    800044f8:	eca6                	sd	s1,88(sp)
    800044fa:	e8ca                	sd	s2,80(sp)
    800044fc:	e4ce                	sd	s3,72(sp)
    800044fe:	e0d2                	sd	s4,64(sp)
    80004500:	fc56                	sd	s5,56(sp)
    80004502:	1880                	addi	s0,sp,112
    80004504:	84aa                	mv	s1,a0
    80004506:	8aae                	mv	s5,a1
    80004508:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000450a:	c24fd0ef          	jal	8000192e <myproc>
    8000450e:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004510:	8526                	mv	a0,s1
    80004512:	f16fc0ef          	jal	80000c28 <acquire>
  while(i < n){
    80004516:	0d405263          	blez	s4,800045da <pipewrite+0xe8>
    8000451a:	f85a                	sd	s6,48(sp)
    8000451c:	f45e                	sd	s7,40(sp)
    8000451e:	f062                	sd	s8,32(sp)
    80004520:	ec66                	sd	s9,24(sp)
    80004522:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004524:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004526:	f9f40c13          	addi	s8,s0,-97
    8000452a:	4b85                	li	s7,1
    8000452c:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000452e:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004532:	21c48c93          	addi	s9,s1,540
    80004536:	a82d                	j	80004570 <pipewrite+0x7e>
      release(&pi->lock);
    80004538:	8526                	mv	a0,s1
    8000453a:	f82fc0ef          	jal	80000cbc <release>
      return -1;
    8000453e:	597d                	li	s2,-1
    80004540:	7b42                	ld	s6,48(sp)
    80004542:	7ba2                	ld	s7,40(sp)
    80004544:	7c02                	ld	s8,32(sp)
    80004546:	6ce2                	ld	s9,24(sp)
    80004548:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000454a:	854a                	mv	a0,s2
    8000454c:	70a6                	ld	ra,104(sp)
    8000454e:	7406                	ld	s0,96(sp)
    80004550:	64e6                	ld	s1,88(sp)
    80004552:	6946                	ld	s2,80(sp)
    80004554:	69a6                	ld	s3,72(sp)
    80004556:	6a06                	ld	s4,64(sp)
    80004558:	7ae2                	ld	s5,56(sp)
    8000455a:	6165                	addi	sp,sp,112
    8000455c:	8082                	ret
      wakeup(&pi->nread);
    8000455e:	856a                	mv	a0,s10
    80004560:	a19fd0ef          	jal	80001f78 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004564:	85a6                	mv	a1,s1
    80004566:	8566                	mv	a0,s9
    80004568:	9c5fd0ef          	jal	80001f2c <sleep>
  while(i < n){
    8000456c:	05495a63          	bge	s2,s4,800045c0 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80004570:	2204a783          	lw	a5,544(s1)
    80004574:	d3f1                	beqz	a5,80004538 <pipewrite+0x46>
    80004576:	854e                	mv	a0,s3
    80004578:	bf1fd0ef          	jal	80002168 <killed>
    8000457c:	fd55                	bnez	a0,80004538 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000457e:	2184a783          	lw	a5,536(s1)
    80004582:	21c4a703          	lw	a4,540(s1)
    80004586:	2007879b          	addiw	a5,a5,512
    8000458a:	fcf70ae3          	beq	a4,a5,8000455e <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000458e:	86de                	mv	a3,s7
    80004590:	01590633          	add	a2,s2,s5
    80004594:	85e2                	mv	a1,s8
    80004596:	0509b503          	ld	a0,80(s3)
    8000459a:	978fd0ef          	jal	80001712 <copyin>
    8000459e:	05650063          	beq	a0,s6,800045de <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800045a2:	21c4a783          	lw	a5,540(s1)
    800045a6:	0017871b          	addiw	a4,a5,1
    800045aa:	20e4ae23          	sw	a4,540(s1)
    800045ae:	1ff7f793          	andi	a5,a5,511
    800045b2:	97a6                	add	a5,a5,s1
    800045b4:	f9f44703          	lbu	a4,-97(s0)
    800045b8:	00e78c23          	sb	a4,24(a5)
      i++;
    800045bc:	2905                	addiw	s2,s2,1
    800045be:	b77d                	j	8000456c <pipewrite+0x7a>
    800045c0:	7b42                	ld	s6,48(sp)
    800045c2:	7ba2                	ld	s7,40(sp)
    800045c4:	7c02                	ld	s8,32(sp)
    800045c6:	6ce2                	ld	s9,24(sp)
    800045c8:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800045ca:	21848513          	addi	a0,s1,536
    800045ce:	9abfd0ef          	jal	80001f78 <wakeup>
  release(&pi->lock);
    800045d2:	8526                	mv	a0,s1
    800045d4:	ee8fc0ef          	jal	80000cbc <release>
  return i;
    800045d8:	bf8d                	j	8000454a <pipewrite+0x58>
  int i = 0;
    800045da:	4901                	li	s2,0
    800045dc:	b7fd                	j	800045ca <pipewrite+0xd8>
    800045de:	7b42                	ld	s6,48(sp)
    800045e0:	7ba2                	ld	s7,40(sp)
    800045e2:	7c02                	ld	s8,32(sp)
    800045e4:	6ce2                	ld	s9,24(sp)
    800045e6:	6d42                	ld	s10,16(sp)
    800045e8:	b7cd                	j	800045ca <pipewrite+0xd8>

00000000800045ea <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800045ea:	711d                	addi	sp,sp,-96
    800045ec:	ec86                	sd	ra,88(sp)
    800045ee:	e8a2                	sd	s0,80(sp)
    800045f0:	e4a6                	sd	s1,72(sp)
    800045f2:	e0ca                	sd	s2,64(sp)
    800045f4:	fc4e                	sd	s3,56(sp)
    800045f6:	f852                	sd	s4,48(sp)
    800045f8:	f456                	sd	s5,40(sp)
    800045fa:	1080                	addi	s0,sp,96
    800045fc:	84aa                	mv	s1,a0
    800045fe:	892e                	mv	s2,a1
    80004600:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004602:	b2cfd0ef          	jal	8000192e <myproc>
    80004606:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004608:	8526                	mv	a0,s1
    8000460a:	e1efc0ef          	jal	80000c28 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000460e:	2184a703          	lw	a4,536(s1)
    80004612:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004616:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000461a:	02f71763          	bne	a4,a5,80004648 <piperead+0x5e>
    8000461e:	2244a783          	lw	a5,548(s1)
    80004622:	cf85                	beqz	a5,8000465a <piperead+0x70>
    if(killed(pr)){
    80004624:	8552                	mv	a0,s4
    80004626:	b43fd0ef          	jal	80002168 <killed>
    8000462a:	e11d                	bnez	a0,80004650 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000462c:	85a6                	mv	a1,s1
    8000462e:	854e                	mv	a0,s3
    80004630:	8fdfd0ef          	jal	80001f2c <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004634:	2184a703          	lw	a4,536(s1)
    80004638:	21c4a783          	lw	a5,540(s1)
    8000463c:	fef701e3          	beq	a4,a5,8000461e <piperead+0x34>
    80004640:	f05a                	sd	s6,32(sp)
    80004642:	ec5e                	sd	s7,24(sp)
    80004644:	e862                	sd	s8,16(sp)
    80004646:	a829                	j	80004660 <piperead+0x76>
    80004648:	f05a                	sd	s6,32(sp)
    8000464a:	ec5e                	sd	s7,24(sp)
    8000464c:	e862                	sd	s8,16(sp)
    8000464e:	a809                	j	80004660 <piperead+0x76>
      release(&pi->lock);
    80004650:	8526                	mv	a0,s1
    80004652:	e6afc0ef          	jal	80000cbc <release>
      return -1;
    80004656:	59fd                	li	s3,-1
    80004658:	a09d                	j	800046be <piperead+0xd4>
    8000465a:	f05a                	sd	s6,32(sp)
    8000465c:	ec5e                	sd	s7,24(sp)
    8000465e:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004660:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004662:	faf40c13          	addi	s8,s0,-81
    80004666:	4b85                	li	s7,1
    80004668:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000466a:	05505063          	blez	s5,800046aa <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    8000466e:	2184a783          	lw	a5,536(s1)
    80004672:	21c4a703          	lw	a4,540(s1)
    80004676:	02f70a63          	beq	a4,a5,800046aa <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    8000467a:	0017871b          	addiw	a4,a5,1
    8000467e:	20e4ac23          	sw	a4,536(s1)
    80004682:	1ff7f793          	andi	a5,a5,511
    80004686:	97a6                	add	a5,a5,s1
    80004688:	0187c783          	lbu	a5,24(a5)
    8000468c:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004690:	86de                	mv	a3,s7
    80004692:	8662                	mv	a2,s8
    80004694:	85ca                	mv	a1,s2
    80004696:	050a3503          	ld	a0,80(s4)
    8000469a:	fbbfc0ef          	jal	80001654 <copyout>
    8000469e:	01650663          	beq	a0,s6,800046aa <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800046a2:	2985                	addiw	s3,s3,1
    800046a4:	0905                	addi	s2,s2,1
    800046a6:	fd3a94e3          	bne	s5,s3,8000466e <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800046aa:	21c48513          	addi	a0,s1,540
    800046ae:	8cbfd0ef          	jal	80001f78 <wakeup>
  release(&pi->lock);
    800046b2:	8526                	mv	a0,s1
    800046b4:	e08fc0ef          	jal	80000cbc <release>
    800046b8:	7b02                	ld	s6,32(sp)
    800046ba:	6be2                	ld	s7,24(sp)
    800046bc:	6c42                	ld	s8,16(sp)
  return i;
}
    800046be:	854e                	mv	a0,s3
    800046c0:	60e6                	ld	ra,88(sp)
    800046c2:	6446                	ld	s0,80(sp)
    800046c4:	64a6                	ld	s1,72(sp)
    800046c6:	6906                	ld	s2,64(sp)
    800046c8:	79e2                	ld	s3,56(sp)
    800046ca:	7a42                	ld	s4,48(sp)
    800046cc:	7aa2                	ld	s5,40(sp)
    800046ce:	6125                	addi	sp,sp,96
    800046d0:	8082                	ret

00000000800046d2 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800046d2:	1141                	addi	sp,sp,-16
    800046d4:	e406                	sd	ra,8(sp)
    800046d6:	e022                	sd	s0,0(sp)
    800046d8:	0800                	addi	s0,sp,16
    800046da:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800046dc:	0035151b          	slliw	a0,a0,0x3
    800046e0:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    800046e2:	8b89                	andi	a5,a5,2
    800046e4:	c399                	beqz	a5,800046ea <flags2perm+0x18>
      perm |= PTE_W;
    800046e6:	00456513          	ori	a0,a0,4
    return perm;
}
    800046ea:	60a2                	ld	ra,8(sp)
    800046ec:	6402                	ld	s0,0(sp)
    800046ee:	0141                	addi	sp,sp,16
    800046f0:	8082                	ret

00000000800046f2 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800046f2:	de010113          	addi	sp,sp,-544
    800046f6:	20113c23          	sd	ra,536(sp)
    800046fa:	20813823          	sd	s0,528(sp)
    800046fe:	20913423          	sd	s1,520(sp)
    80004702:	21213023          	sd	s2,512(sp)
    80004706:	1400                	addi	s0,sp,544
    80004708:	892a                	mv	s2,a0
    8000470a:	dea43823          	sd	a0,-528(s0)
    8000470e:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004712:	a1cfd0ef          	jal	8000192e <myproc>
    80004716:	84aa                	mv	s1,a0

  begin_op();
    80004718:	d74ff0ef          	jal	80003c8c <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    8000471c:	854a                	mv	a0,s2
    8000471e:	b90ff0ef          	jal	80003aae <namei>
    80004722:	cd21                	beqz	a0,8000477a <kexec+0x88>
    80004724:	fbd2                	sd	s4,496(sp)
    80004726:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004728:	b59fe0ef          	jal	80003280 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000472c:	04000713          	li	a4,64
    80004730:	4681                	li	a3,0
    80004732:	e5040613          	addi	a2,s0,-432
    80004736:	4581                	li	a1,0
    80004738:	8552                	mv	a0,s4
    8000473a:	ed9fe0ef          	jal	80003612 <readi>
    8000473e:	04000793          	li	a5,64
    80004742:	00f51a63          	bne	a0,a5,80004756 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004746:	e5042703          	lw	a4,-432(s0)
    8000474a:	464c47b7          	lui	a5,0x464c4
    8000474e:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004752:	02f70863          	beq	a4,a5,80004782 <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004756:	8552                	mv	a0,s4
    80004758:	d35fe0ef          	jal	8000348c <iunlockput>
    end_op();
    8000475c:	da0ff0ef          	jal	80003cfc <end_op>
  }
  return -1;
    80004760:	557d                	li	a0,-1
    80004762:	7a5e                	ld	s4,496(sp)
}
    80004764:	21813083          	ld	ra,536(sp)
    80004768:	21013403          	ld	s0,528(sp)
    8000476c:	20813483          	ld	s1,520(sp)
    80004770:	20013903          	ld	s2,512(sp)
    80004774:	22010113          	addi	sp,sp,544
    80004778:	8082                	ret
    end_op();
    8000477a:	d82ff0ef          	jal	80003cfc <end_op>
    return -1;
    8000477e:	557d                	li	a0,-1
    80004780:	b7d5                	j	80004764 <kexec+0x72>
    80004782:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004784:	8526                	mv	a0,s1
    80004786:	ab2fd0ef          	jal	80001a38 <proc_pagetable>
    8000478a:	8b2a                	mv	s6,a0
    8000478c:	26050f63          	beqz	a0,80004a0a <kexec+0x318>
    80004790:	ffce                	sd	s3,504(sp)
    80004792:	f7d6                	sd	s5,488(sp)
    80004794:	efde                	sd	s7,472(sp)
    80004796:	ebe2                	sd	s8,464(sp)
    80004798:	e7e6                	sd	s9,456(sp)
    8000479a:	e3ea                	sd	s10,448(sp)
    8000479c:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000479e:	e8845783          	lhu	a5,-376(s0)
    800047a2:	0e078963          	beqz	a5,80004894 <kexec+0x1a2>
    800047a6:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800047aa:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800047ac:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800047ae:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    800047b2:	6c85                	lui	s9,0x1
    800047b4:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800047b8:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800047bc:	6a85                	lui	s5,0x1
    800047be:	a085                	j	8000481e <kexec+0x12c>
      panic("loadseg: address should exist");
    800047c0:	00003517          	auipc	a0,0x3
    800047c4:	de050513          	addi	a0,a0,-544 # 800075a0 <etext+0x5a0>
    800047c8:	85cfc0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    800047cc:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800047ce:	874a                	mv	a4,s2
    800047d0:	009b86bb          	addw	a3,s7,s1
    800047d4:	4581                	li	a1,0
    800047d6:	8552                	mv	a0,s4
    800047d8:	e3bfe0ef          	jal	80003612 <readi>
    800047dc:	22a91b63          	bne	s2,a0,80004a12 <kexec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    800047e0:	009a84bb          	addw	s1,s5,s1
    800047e4:	0334f263          	bgeu	s1,s3,80004808 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    800047e8:	02049593          	slli	a1,s1,0x20
    800047ec:	9181                	srli	a1,a1,0x20
    800047ee:	95e2                	add	a1,a1,s8
    800047f0:	855a                	mv	a0,s6
    800047f2:	835fc0ef          	jal	80001026 <walkaddr>
    800047f6:	862a                	mv	a2,a0
    if(pa == 0)
    800047f8:	d561                	beqz	a0,800047c0 <kexec+0xce>
    if(sz - i < PGSIZE)
    800047fa:	409987bb          	subw	a5,s3,s1
    800047fe:	893e                	mv	s2,a5
    80004800:	fcfcf6e3          	bgeu	s9,a5,800047cc <kexec+0xda>
    80004804:	8956                	mv	s2,s5
    80004806:	b7d9                	j	800047cc <kexec+0xda>
    sz = sz1;
    80004808:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000480c:	2d05                	addiw	s10,s10,1
    8000480e:	e0843783          	ld	a5,-504(s0)
    80004812:	0387869b          	addiw	a3,a5,56
    80004816:	e8845783          	lhu	a5,-376(s0)
    8000481a:	06fd5e63          	bge	s10,a5,80004896 <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000481e:	e0d43423          	sd	a3,-504(s0)
    80004822:	876e                	mv	a4,s11
    80004824:	e1840613          	addi	a2,s0,-488
    80004828:	4581                	li	a1,0
    8000482a:	8552                	mv	a0,s4
    8000482c:	de7fe0ef          	jal	80003612 <readi>
    80004830:	1db51f63          	bne	a0,s11,80004a0e <kexec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80004834:	e1842783          	lw	a5,-488(s0)
    80004838:	4705                	li	a4,1
    8000483a:	fce799e3          	bne	a5,a4,8000480c <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    8000483e:	e4043483          	ld	s1,-448(s0)
    80004842:	e3843783          	ld	a5,-456(s0)
    80004846:	1ef4e463          	bltu	s1,a5,80004a2e <kexec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    8000484a:	e2843783          	ld	a5,-472(s0)
    8000484e:	94be                	add	s1,s1,a5
    80004850:	1ef4e263          	bltu	s1,a5,80004a34 <kexec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80004854:	de843703          	ld	a4,-536(s0)
    80004858:	8ff9                	and	a5,a5,a4
    8000485a:	1e079063          	bnez	a5,80004a3a <kexec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000485e:	e1c42503          	lw	a0,-484(s0)
    80004862:	e71ff0ef          	jal	800046d2 <flags2perm>
    80004866:	86aa                	mv	a3,a0
    80004868:	8626                	mv	a2,s1
    8000486a:	85ca                	mv	a1,s2
    8000486c:	855a                	mv	a0,s6
    8000486e:	a8ffc0ef          	jal	800012fc <uvmalloc>
    80004872:	dea43c23          	sd	a0,-520(s0)
    80004876:	1c050563          	beqz	a0,80004a40 <kexec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000487a:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    8000487e:	00098863          	beqz	s3,8000488e <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004882:	e2843c03          	ld	s8,-472(s0)
    80004886:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    8000488a:	4481                	li	s1,0
    8000488c:	bfb1                	j	800047e8 <kexec+0xf6>
    sz = sz1;
    8000488e:	df843903          	ld	s2,-520(s0)
    80004892:	bfad                	j	8000480c <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004894:	4901                	li	s2,0
  iunlockput(ip);
    80004896:	8552                	mv	a0,s4
    80004898:	bf5fe0ef          	jal	8000348c <iunlockput>
  end_op();
    8000489c:	c60ff0ef          	jal	80003cfc <end_op>
  p = myproc();
    800048a0:	88efd0ef          	jal	8000192e <myproc>
    800048a4:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    800048a6:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    800048aa:	6985                	lui	s3,0x1
    800048ac:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    800048ae:	99ca                	add	s3,s3,s2
    800048b0:	77fd                	lui	a5,0xfffff
    800048b2:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800048b6:	4691                	li	a3,4
    800048b8:	6609                	lui	a2,0x2
    800048ba:	964e                	add	a2,a2,s3
    800048bc:	85ce                	mv	a1,s3
    800048be:	855a                	mv	a0,s6
    800048c0:	a3dfc0ef          	jal	800012fc <uvmalloc>
    800048c4:	8a2a                	mv	s4,a0
    800048c6:	e105                	bnez	a0,800048e6 <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    800048c8:	85ce                	mv	a1,s3
    800048ca:	855a                	mv	a0,s6
    800048cc:	9f0fd0ef          	jal	80001abc <proc_freepagetable>
  return -1;
    800048d0:	557d                	li	a0,-1
    800048d2:	79fe                	ld	s3,504(sp)
    800048d4:	7a5e                	ld	s4,496(sp)
    800048d6:	7abe                	ld	s5,488(sp)
    800048d8:	7b1e                	ld	s6,480(sp)
    800048da:	6bfe                	ld	s7,472(sp)
    800048dc:	6c5e                	ld	s8,464(sp)
    800048de:	6cbe                	ld	s9,456(sp)
    800048e0:	6d1e                	ld	s10,448(sp)
    800048e2:	7dfa                	ld	s11,440(sp)
    800048e4:	b541                	j	80004764 <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800048e6:	75f9                	lui	a1,0xffffe
    800048e8:	95aa                	add	a1,a1,a0
    800048ea:	855a                	mv	a0,s6
    800048ec:	be3fc0ef          	jal	800014ce <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800048f0:	800a0b93          	addi	s7,s4,-2048
    800048f4:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    800048f8:	e0043783          	ld	a5,-512(s0)
    800048fc:	6388                	ld	a0,0(a5)
  sp = sz;
    800048fe:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80004900:	4481                	li	s1,0
    ustack[argc] = sp;
    80004902:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004906:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    8000490a:	cd21                	beqz	a0,80004962 <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    8000490c:	d76fc0ef          	jal	80000e82 <strlen>
    80004910:	0015079b          	addiw	a5,a0,1
    80004914:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004918:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    8000491c:	13796563          	bltu	s2,s7,80004a46 <kexec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004920:	e0043d83          	ld	s11,-512(s0)
    80004924:	000db983          	ld	s3,0(s11)
    80004928:	854e                	mv	a0,s3
    8000492a:	d58fc0ef          	jal	80000e82 <strlen>
    8000492e:	0015069b          	addiw	a3,a0,1
    80004932:	864e                	mv	a2,s3
    80004934:	85ca                	mv	a1,s2
    80004936:	855a                	mv	a0,s6
    80004938:	d1dfc0ef          	jal	80001654 <copyout>
    8000493c:	10054763          	bltz	a0,80004a4a <kexec+0x358>
    ustack[argc] = sp;
    80004940:	00349793          	slli	a5,s1,0x3
    80004944:	97e6                	add	a5,a5,s9
    80004946:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde488>
  for(argc = 0; argv[argc]; argc++) {
    8000494a:	0485                	addi	s1,s1,1
    8000494c:	008d8793          	addi	a5,s11,8
    80004950:	e0f43023          	sd	a5,-512(s0)
    80004954:	008db503          	ld	a0,8(s11)
    80004958:	c509                	beqz	a0,80004962 <kexec+0x270>
    if(argc >= MAXARG)
    8000495a:	fb8499e3          	bne	s1,s8,8000490c <kexec+0x21a>
  sz = sz1;
    8000495e:	89d2                	mv	s3,s4
    80004960:	b7a5                	j	800048c8 <kexec+0x1d6>
  ustack[argc] = 0;
    80004962:	00349793          	slli	a5,s1,0x3
    80004966:	f9078793          	addi	a5,a5,-112
    8000496a:	97a2                	add	a5,a5,s0
    8000496c:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004970:	00349693          	slli	a3,s1,0x3
    80004974:	06a1                	addi	a3,a3,8
    80004976:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    8000497a:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    8000497e:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80004980:	f57964e3          	bltu	s2,s7,800048c8 <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004984:	e9040613          	addi	a2,s0,-368
    80004988:	85ca                	mv	a1,s2
    8000498a:	855a                	mv	a0,s6
    8000498c:	cc9fc0ef          	jal	80001654 <copyout>
    80004990:	f2054ce3          	bltz	a0,800048c8 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004994:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004998:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    8000499c:	df043783          	ld	a5,-528(s0)
    800049a0:	0007c703          	lbu	a4,0(a5)
    800049a4:	cf11                	beqz	a4,800049c0 <kexec+0x2ce>
    800049a6:	0785                	addi	a5,a5,1
    if(*s == '/')
    800049a8:	02f00693          	li	a3,47
    800049ac:	a029                	j	800049b6 <kexec+0x2c4>
  for(last=s=path; *s; s++)
    800049ae:	0785                	addi	a5,a5,1
    800049b0:	fff7c703          	lbu	a4,-1(a5)
    800049b4:	c711                	beqz	a4,800049c0 <kexec+0x2ce>
    if(*s == '/')
    800049b6:	fed71ce3          	bne	a4,a3,800049ae <kexec+0x2bc>
      last = s+1;
    800049ba:	def43823          	sd	a5,-528(s0)
    800049be:	bfc5                	j	800049ae <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    800049c0:	4641                	li	a2,16
    800049c2:	df043583          	ld	a1,-528(s0)
    800049c6:	158a8513          	addi	a0,s5,344
    800049ca:	c82fc0ef          	jal	80000e4c <safestrcpy>
  oldpagetable = p->pagetable;
    800049ce:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    800049d2:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    800049d6:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    800049da:	058ab783          	ld	a5,88(s5)
    800049de:	e6843703          	ld	a4,-408(s0)
    800049e2:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800049e4:	058ab783          	ld	a5,88(s5)
    800049e8:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800049ec:	85ea                	mv	a1,s10
    800049ee:	8cefd0ef          	jal	80001abc <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800049f2:	0004851b          	sext.w	a0,s1
    800049f6:	79fe                	ld	s3,504(sp)
    800049f8:	7a5e                	ld	s4,496(sp)
    800049fa:	7abe                	ld	s5,488(sp)
    800049fc:	7b1e                	ld	s6,480(sp)
    800049fe:	6bfe                	ld	s7,472(sp)
    80004a00:	6c5e                	ld	s8,464(sp)
    80004a02:	6cbe                	ld	s9,456(sp)
    80004a04:	6d1e                	ld	s10,448(sp)
    80004a06:	7dfa                	ld	s11,440(sp)
    80004a08:	bbb1                	j	80004764 <kexec+0x72>
    80004a0a:	7b1e                	ld	s6,480(sp)
    80004a0c:	b3a9                	j	80004756 <kexec+0x64>
    80004a0e:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004a12:	df843583          	ld	a1,-520(s0)
    80004a16:	855a                	mv	a0,s6
    80004a18:	8a4fd0ef          	jal	80001abc <proc_freepagetable>
  if(ip){
    80004a1c:	79fe                	ld	s3,504(sp)
    80004a1e:	7abe                	ld	s5,488(sp)
    80004a20:	7b1e                	ld	s6,480(sp)
    80004a22:	6bfe                	ld	s7,472(sp)
    80004a24:	6c5e                	ld	s8,464(sp)
    80004a26:	6cbe                	ld	s9,456(sp)
    80004a28:	6d1e                	ld	s10,448(sp)
    80004a2a:	7dfa                	ld	s11,440(sp)
    80004a2c:	b32d                	j	80004756 <kexec+0x64>
    80004a2e:	df243c23          	sd	s2,-520(s0)
    80004a32:	b7c5                	j	80004a12 <kexec+0x320>
    80004a34:	df243c23          	sd	s2,-520(s0)
    80004a38:	bfe9                	j	80004a12 <kexec+0x320>
    80004a3a:	df243c23          	sd	s2,-520(s0)
    80004a3e:	bfd1                	j	80004a12 <kexec+0x320>
    80004a40:	df243c23          	sd	s2,-520(s0)
    80004a44:	b7f9                	j	80004a12 <kexec+0x320>
  sz = sz1;
    80004a46:	89d2                	mv	s3,s4
    80004a48:	b541                	j	800048c8 <kexec+0x1d6>
    80004a4a:	89d2                	mv	s3,s4
    80004a4c:	bdb5                	j	800048c8 <kexec+0x1d6>

0000000080004a4e <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004a4e:	7179                	addi	sp,sp,-48
    80004a50:	f406                	sd	ra,40(sp)
    80004a52:	f022                	sd	s0,32(sp)
    80004a54:	ec26                	sd	s1,24(sp)
    80004a56:	e84a                	sd	s2,16(sp)
    80004a58:	1800                	addi	s0,sp,48
    80004a5a:	892e                	mv	s2,a1
    80004a5c:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004a5e:	fdc40593          	addi	a1,s0,-36
    80004a62:	e45fd0ef          	jal	800028a6 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004a66:	fdc42703          	lw	a4,-36(s0)
    80004a6a:	47bd                	li	a5,15
    80004a6c:	02e7ea63          	bltu	a5,a4,80004aa0 <argfd+0x52>
    80004a70:	ebffc0ef          	jal	8000192e <myproc>
    80004a74:	fdc42703          	lw	a4,-36(s0)
    80004a78:	00371793          	slli	a5,a4,0x3
    80004a7c:	0d078793          	addi	a5,a5,208
    80004a80:	953e                	add	a0,a0,a5
    80004a82:	611c                	ld	a5,0(a0)
    80004a84:	c385                	beqz	a5,80004aa4 <argfd+0x56>
    return -1;
  if(pfd)
    80004a86:	00090463          	beqz	s2,80004a8e <argfd+0x40>
    *pfd = fd;
    80004a8a:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004a8e:	4501                	li	a0,0
  if(pf)
    80004a90:	c091                	beqz	s1,80004a94 <argfd+0x46>
    *pf = f;
    80004a92:	e09c                	sd	a5,0(s1)
}
    80004a94:	70a2                	ld	ra,40(sp)
    80004a96:	7402                	ld	s0,32(sp)
    80004a98:	64e2                	ld	s1,24(sp)
    80004a9a:	6942                	ld	s2,16(sp)
    80004a9c:	6145                	addi	sp,sp,48
    80004a9e:	8082                	ret
    return -1;
    80004aa0:	557d                	li	a0,-1
    80004aa2:	bfcd                	j	80004a94 <argfd+0x46>
    80004aa4:	557d                	li	a0,-1
    80004aa6:	b7fd                	j	80004a94 <argfd+0x46>

0000000080004aa8 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004aa8:	1101                	addi	sp,sp,-32
    80004aaa:	ec06                	sd	ra,24(sp)
    80004aac:	e822                	sd	s0,16(sp)
    80004aae:	e426                	sd	s1,8(sp)
    80004ab0:	1000                	addi	s0,sp,32
    80004ab2:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004ab4:	e7bfc0ef          	jal	8000192e <myproc>
    80004ab8:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004aba:	0d050793          	addi	a5,a0,208
    80004abe:	4501                	li	a0,0
    80004ac0:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004ac2:	6398                	ld	a4,0(a5)
    80004ac4:	cb19                	beqz	a4,80004ada <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004ac6:	2505                	addiw	a0,a0,1
    80004ac8:	07a1                	addi	a5,a5,8
    80004aca:	fed51ce3          	bne	a0,a3,80004ac2 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004ace:	557d                	li	a0,-1
}
    80004ad0:	60e2                	ld	ra,24(sp)
    80004ad2:	6442                	ld	s0,16(sp)
    80004ad4:	64a2                	ld	s1,8(sp)
    80004ad6:	6105                	addi	sp,sp,32
    80004ad8:	8082                	ret
      p->ofile[fd] = f;
    80004ada:	00351793          	slli	a5,a0,0x3
    80004ade:	0d078793          	addi	a5,a5,208
    80004ae2:	963e                	add	a2,a2,a5
    80004ae4:	e204                	sd	s1,0(a2)
      return fd;
    80004ae6:	b7ed                	j	80004ad0 <fdalloc+0x28>

0000000080004ae8 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004ae8:	715d                	addi	sp,sp,-80
    80004aea:	e486                	sd	ra,72(sp)
    80004aec:	e0a2                	sd	s0,64(sp)
    80004aee:	fc26                	sd	s1,56(sp)
    80004af0:	f84a                	sd	s2,48(sp)
    80004af2:	f44e                	sd	s3,40(sp)
    80004af4:	f052                	sd	s4,32(sp)
    80004af6:	ec56                	sd	s5,24(sp)
    80004af8:	e85a                	sd	s6,16(sp)
    80004afa:	0880                	addi	s0,sp,80
    80004afc:	892e                	mv	s2,a1
    80004afe:	8a2e                	mv	s4,a1
    80004b00:	8ab2                	mv	s5,a2
    80004b02:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004b04:	fb040593          	addi	a1,s0,-80
    80004b08:	fc1fe0ef          	jal	80003ac8 <nameiparent>
    80004b0c:	84aa                	mv	s1,a0
    80004b0e:	10050763          	beqz	a0,80004c1c <create+0x134>
    return 0;

  ilock(dp);
    80004b12:	f6efe0ef          	jal	80003280 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004b16:	4601                	li	a2,0
    80004b18:	fb040593          	addi	a1,s0,-80
    80004b1c:	8526                	mv	a0,s1
    80004b1e:	cfdfe0ef          	jal	8000381a <dirlookup>
    80004b22:	89aa                	mv	s3,a0
    80004b24:	c131                	beqz	a0,80004b68 <create+0x80>
    iunlockput(dp);
    80004b26:	8526                	mv	a0,s1
    80004b28:	965fe0ef          	jal	8000348c <iunlockput>
    ilock(ip);
    80004b2c:	854e                	mv	a0,s3
    80004b2e:	f52fe0ef          	jal	80003280 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004b32:	4789                	li	a5,2
    80004b34:	02f91563          	bne	s2,a5,80004b5e <create+0x76>
    80004b38:	0449d783          	lhu	a5,68(s3)
    80004b3c:	37f9                	addiw	a5,a5,-2
    80004b3e:	17c2                	slli	a5,a5,0x30
    80004b40:	93c1                	srli	a5,a5,0x30
    80004b42:	4705                	li	a4,1
    80004b44:	00f76d63          	bltu	a4,a5,80004b5e <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004b48:	854e                	mv	a0,s3
    80004b4a:	60a6                	ld	ra,72(sp)
    80004b4c:	6406                	ld	s0,64(sp)
    80004b4e:	74e2                	ld	s1,56(sp)
    80004b50:	7942                	ld	s2,48(sp)
    80004b52:	79a2                	ld	s3,40(sp)
    80004b54:	7a02                	ld	s4,32(sp)
    80004b56:	6ae2                	ld	s5,24(sp)
    80004b58:	6b42                	ld	s6,16(sp)
    80004b5a:	6161                	addi	sp,sp,80
    80004b5c:	8082                	ret
    iunlockput(ip);
    80004b5e:	854e                	mv	a0,s3
    80004b60:	92dfe0ef          	jal	8000348c <iunlockput>
    return 0;
    80004b64:	4981                	li	s3,0
    80004b66:	b7cd                	j	80004b48 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004b68:	85ca                	mv	a1,s2
    80004b6a:	4088                	lw	a0,0(s1)
    80004b6c:	da4fe0ef          	jal	80003110 <ialloc>
    80004b70:	892a                	mv	s2,a0
    80004b72:	cd15                	beqz	a0,80004bae <create+0xc6>
  ilock(ip);
    80004b74:	f0cfe0ef          	jal	80003280 <ilock>
  ip->major = major;
    80004b78:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004b7c:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004b80:	4785                	li	a5,1
    80004b82:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004b86:	854a                	mv	a0,s2
    80004b88:	e44fe0ef          	jal	800031cc <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004b8c:	4705                	li	a4,1
    80004b8e:	02ea0463          	beq	s4,a4,80004bb6 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004b92:	00492603          	lw	a2,4(s2)
    80004b96:	fb040593          	addi	a1,s0,-80
    80004b9a:	8526                	mv	a0,s1
    80004b9c:	e69fe0ef          	jal	80003a04 <dirlink>
    80004ba0:	06054263          	bltz	a0,80004c04 <create+0x11c>
  iunlockput(dp);
    80004ba4:	8526                	mv	a0,s1
    80004ba6:	8e7fe0ef          	jal	8000348c <iunlockput>
  return ip;
    80004baa:	89ca                	mv	s3,s2
    80004bac:	bf71                	j	80004b48 <create+0x60>
    iunlockput(dp);
    80004bae:	8526                	mv	a0,s1
    80004bb0:	8ddfe0ef          	jal	8000348c <iunlockput>
    return 0;
    80004bb4:	bf51                	j	80004b48 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004bb6:	00492603          	lw	a2,4(s2)
    80004bba:	00003597          	auipc	a1,0x3
    80004bbe:	a0658593          	addi	a1,a1,-1530 # 800075c0 <etext+0x5c0>
    80004bc2:	854a                	mv	a0,s2
    80004bc4:	e41fe0ef          	jal	80003a04 <dirlink>
    80004bc8:	02054e63          	bltz	a0,80004c04 <create+0x11c>
    80004bcc:	40d0                	lw	a2,4(s1)
    80004bce:	00003597          	auipc	a1,0x3
    80004bd2:	9fa58593          	addi	a1,a1,-1542 # 800075c8 <etext+0x5c8>
    80004bd6:	854a                	mv	a0,s2
    80004bd8:	e2dfe0ef          	jal	80003a04 <dirlink>
    80004bdc:	02054463          	bltz	a0,80004c04 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004be0:	00492603          	lw	a2,4(s2)
    80004be4:	fb040593          	addi	a1,s0,-80
    80004be8:	8526                	mv	a0,s1
    80004bea:	e1bfe0ef          	jal	80003a04 <dirlink>
    80004bee:	00054b63          	bltz	a0,80004c04 <create+0x11c>
    dp->nlink++;  // for ".."
    80004bf2:	04a4d783          	lhu	a5,74(s1)
    80004bf6:	2785                	addiw	a5,a5,1
    80004bf8:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004bfc:	8526                	mv	a0,s1
    80004bfe:	dcefe0ef          	jal	800031cc <iupdate>
    80004c02:	b74d                	j	80004ba4 <create+0xbc>
  ip->nlink = 0;
    80004c04:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004c08:	854a                	mv	a0,s2
    80004c0a:	dc2fe0ef          	jal	800031cc <iupdate>
  iunlockput(ip);
    80004c0e:	854a                	mv	a0,s2
    80004c10:	87dfe0ef          	jal	8000348c <iunlockput>
  iunlockput(dp);
    80004c14:	8526                	mv	a0,s1
    80004c16:	877fe0ef          	jal	8000348c <iunlockput>
  return 0;
    80004c1a:	b73d                	j	80004b48 <create+0x60>
    return 0;
    80004c1c:	89aa                	mv	s3,a0
    80004c1e:	b72d                	j	80004b48 <create+0x60>

0000000080004c20 <sys_dup>:
{
    80004c20:	7179                	addi	sp,sp,-48
    80004c22:	f406                	sd	ra,40(sp)
    80004c24:	f022                	sd	s0,32(sp)
    80004c26:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004c28:	fd840613          	addi	a2,s0,-40
    80004c2c:	4581                	li	a1,0
    80004c2e:	4501                	li	a0,0
    80004c30:	e1fff0ef          	jal	80004a4e <argfd>
    return -1;
    80004c34:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004c36:	02054363          	bltz	a0,80004c5c <sys_dup+0x3c>
    80004c3a:	ec26                	sd	s1,24(sp)
    80004c3c:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004c3e:	fd843483          	ld	s1,-40(s0)
    80004c42:	8526                	mv	a0,s1
    80004c44:	e65ff0ef          	jal	80004aa8 <fdalloc>
    80004c48:	892a                	mv	s2,a0
    return -1;
    80004c4a:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004c4c:	00054d63          	bltz	a0,80004c66 <sys_dup+0x46>
  filedup(f);
    80004c50:	8526                	mv	a0,s1
    80004c52:	c18ff0ef          	jal	8000406a <filedup>
  return fd;
    80004c56:	87ca                	mv	a5,s2
    80004c58:	64e2                	ld	s1,24(sp)
    80004c5a:	6942                	ld	s2,16(sp)
}
    80004c5c:	853e                	mv	a0,a5
    80004c5e:	70a2                	ld	ra,40(sp)
    80004c60:	7402                	ld	s0,32(sp)
    80004c62:	6145                	addi	sp,sp,48
    80004c64:	8082                	ret
    80004c66:	64e2                	ld	s1,24(sp)
    80004c68:	6942                	ld	s2,16(sp)
    80004c6a:	bfcd                	j	80004c5c <sys_dup+0x3c>

0000000080004c6c <sys_read>:
{
    80004c6c:	7179                	addi	sp,sp,-48
    80004c6e:	f406                	sd	ra,40(sp)
    80004c70:	f022                	sd	s0,32(sp)
    80004c72:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004c74:	fd840593          	addi	a1,s0,-40
    80004c78:	4505                	li	a0,1
    80004c7a:	c49fd0ef          	jal	800028c2 <argaddr>
  argint(2, &n);
    80004c7e:	fe440593          	addi	a1,s0,-28
    80004c82:	4509                	li	a0,2
    80004c84:	c23fd0ef          	jal	800028a6 <argint>
  if(argfd(0, 0, &f) < 0)
    80004c88:	fe840613          	addi	a2,s0,-24
    80004c8c:	4581                	li	a1,0
    80004c8e:	4501                	li	a0,0
    80004c90:	dbfff0ef          	jal	80004a4e <argfd>
    80004c94:	87aa                	mv	a5,a0
    return -1;
    80004c96:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004c98:	0007ca63          	bltz	a5,80004cac <sys_read+0x40>
  return fileread(f, p, n);
    80004c9c:	fe442603          	lw	a2,-28(s0)
    80004ca0:	fd843583          	ld	a1,-40(s0)
    80004ca4:	fe843503          	ld	a0,-24(s0)
    80004ca8:	d2cff0ef          	jal	800041d4 <fileread>
}
    80004cac:	70a2                	ld	ra,40(sp)
    80004cae:	7402                	ld	s0,32(sp)
    80004cb0:	6145                	addi	sp,sp,48
    80004cb2:	8082                	ret

0000000080004cb4 <sys_write>:
{
    80004cb4:	7179                	addi	sp,sp,-48
    80004cb6:	f406                	sd	ra,40(sp)
    80004cb8:	f022                	sd	s0,32(sp)
    80004cba:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004cbc:	fd840593          	addi	a1,s0,-40
    80004cc0:	4505                	li	a0,1
    80004cc2:	c01fd0ef          	jal	800028c2 <argaddr>
  argint(2, &n);
    80004cc6:	fe440593          	addi	a1,s0,-28
    80004cca:	4509                	li	a0,2
    80004ccc:	bdbfd0ef          	jal	800028a6 <argint>
  if(argfd(0, 0, &f) < 0)
    80004cd0:	fe840613          	addi	a2,s0,-24
    80004cd4:	4581                	li	a1,0
    80004cd6:	4501                	li	a0,0
    80004cd8:	d77ff0ef          	jal	80004a4e <argfd>
    80004cdc:	87aa                	mv	a5,a0
    return -1;
    80004cde:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004ce0:	0007ca63          	bltz	a5,80004cf4 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ce4:	fe442603          	lw	a2,-28(s0)
    80004ce8:	fd843583          	ld	a1,-40(s0)
    80004cec:	fe843503          	ld	a0,-24(s0)
    80004cf0:	da8ff0ef          	jal	80004298 <filewrite>
}
    80004cf4:	70a2                	ld	ra,40(sp)
    80004cf6:	7402                	ld	s0,32(sp)
    80004cf8:	6145                	addi	sp,sp,48
    80004cfa:	8082                	ret

0000000080004cfc <sys_close>:
{
    80004cfc:	1101                	addi	sp,sp,-32
    80004cfe:	ec06                	sd	ra,24(sp)
    80004d00:	e822                	sd	s0,16(sp)
    80004d02:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004d04:	fe040613          	addi	a2,s0,-32
    80004d08:	fec40593          	addi	a1,s0,-20
    80004d0c:	4501                	li	a0,0
    80004d0e:	d41ff0ef          	jal	80004a4e <argfd>
    return -1;
    80004d12:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004d14:	02054163          	bltz	a0,80004d36 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004d18:	c17fc0ef          	jal	8000192e <myproc>
    80004d1c:	fec42783          	lw	a5,-20(s0)
    80004d20:	078e                	slli	a5,a5,0x3
    80004d22:	0d078793          	addi	a5,a5,208
    80004d26:	953e                	add	a0,a0,a5
    80004d28:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004d2c:	fe043503          	ld	a0,-32(s0)
    80004d30:	b80ff0ef          	jal	800040b0 <fileclose>
  return 0;
    80004d34:	4781                	li	a5,0
}
    80004d36:	853e                	mv	a0,a5
    80004d38:	60e2                	ld	ra,24(sp)
    80004d3a:	6442                	ld	s0,16(sp)
    80004d3c:	6105                	addi	sp,sp,32
    80004d3e:	8082                	ret

0000000080004d40 <sys_fstat>:
{
    80004d40:	1101                	addi	sp,sp,-32
    80004d42:	ec06                	sd	ra,24(sp)
    80004d44:	e822                	sd	s0,16(sp)
    80004d46:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004d48:	fe040593          	addi	a1,s0,-32
    80004d4c:	4505                	li	a0,1
    80004d4e:	b75fd0ef          	jal	800028c2 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004d52:	fe840613          	addi	a2,s0,-24
    80004d56:	4581                	li	a1,0
    80004d58:	4501                	li	a0,0
    80004d5a:	cf5ff0ef          	jal	80004a4e <argfd>
    80004d5e:	87aa                	mv	a5,a0
    return -1;
    80004d60:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d62:	0007c863          	bltz	a5,80004d72 <sys_fstat+0x32>
  return filestat(f, st);
    80004d66:	fe043583          	ld	a1,-32(s0)
    80004d6a:	fe843503          	ld	a0,-24(s0)
    80004d6e:	c04ff0ef          	jal	80004172 <filestat>
}
    80004d72:	60e2                	ld	ra,24(sp)
    80004d74:	6442                	ld	s0,16(sp)
    80004d76:	6105                	addi	sp,sp,32
    80004d78:	8082                	ret

0000000080004d7a <sys_link>:
{
    80004d7a:	7169                	addi	sp,sp,-304
    80004d7c:	f606                	sd	ra,296(sp)
    80004d7e:	f222                	sd	s0,288(sp)
    80004d80:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004d82:	08000613          	li	a2,128
    80004d86:	ed040593          	addi	a1,s0,-304
    80004d8a:	4501                	li	a0,0
    80004d8c:	b53fd0ef          	jal	800028de <argstr>
    return -1;
    80004d90:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004d92:	0c054e63          	bltz	a0,80004e6e <sys_link+0xf4>
    80004d96:	08000613          	li	a2,128
    80004d9a:	f5040593          	addi	a1,s0,-176
    80004d9e:	4505                	li	a0,1
    80004da0:	b3ffd0ef          	jal	800028de <argstr>
    return -1;
    80004da4:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004da6:	0c054463          	bltz	a0,80004e6e <sys_link+0xf4>
    80004daa:	ee26                	sd	s1,280(sp)
  begin_op();
    80004dac:	ee1fe0ef          	jal	80003c8c <begin_op>
  if((ip = namei(old)) == 0){
    80004db0:	ed040513          	addi	a0,s0,-304
    80004db4:	cfbfe0ef          	jal	80003aae <namei>
    80004db8:	84aa                	mv	s1,a0
    80004dba:	c53d                	beqz	a0,80004e28 <sys_link+0xae>
  ilock(ip);
    80004dbc:	cc4fe0ef          	jal	80003280 <ilock>
  if(ip->type == T_DIR){
    80004dc0:	04449703          	lh	a4,68(s1)
    80004dc4:	4785                	li	a5,1
    80004dc6:	06f70663          	beq	a4,a5,80004e32 <sys_link+0xb8>
    80004dca:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004dcc:	04a4d783          	lhu	a5,74(s1)
    80004dd0:	2785                	addiw	a5,a5,1
    80004dd2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004dd6:	8526                	mv	a0,s1
    80004dd8:	bf4fe0ef          	jal	800031cc <iupdate>
  iunlock(ip);
    80004ddc:	8526                	mv	a0,s1
    80004dde:	d50fe0ef          	jal	8000332e <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004de2:	fd040593          	addi	a1,s0,-48
    80004de6:	f5040513          	addi	a0,s0,-176
    80004dea:	cdffe0ef          	jal	80003ac8 <nameiparent>
    80004dee:	892a                	mv	s2,a0
    80004df0:	cd21                	beqz	a0,80004e48 <sys_link+0xce>
  ilock(dp);
    80004df2:	c8efe0ef          	jal	80003280 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004df6:	854a                	mv	a0,s2
    80004df8:	00092703          	lw	a4,0(s2)
    80004dfc:	409c                	lw	a5,0(s1)
    80004dfe:	04f71263          	bne	a4,a5,80004e42 <sys_link+0xc8>
    80004e02:	40d0                	lw	a2,4(s1)
    80004e04:	fd040593          	addi	a1,s0,-48
    80004e08:	bfdfe0ef          	jal	80003a04 <dirlink>
    80004e0c:	02054b63          	bltz	a0,80004e42 <sys_link+0xc8>
  iunlockput(dp);
    80004e10:	854a                	mv	a0,s2
    80004e12:	e7afe0ef          	jal	8000348c <iunlockput>
  iput(ip);
    80004e16:	8526                	mv	a0,s1
    80004e18:	deafe0ef          	jal	80003402 <iput>
  end_op();
    80004e1c:	ee1fe0ef          	jal	80003cfc <end_op>
  return 0;
    80004e20:	4781                	li	a5,0
    80004e22:	64f2                	ld	s1,280(sp)
    80004e24:	6952                	ld	s2,272(sp)
    80004e26:	a0a1                	j	80004e6e <sys_link+0xf4>
    end_op();
    80004e28:	ed5fe0ef          	jal	80003cfc <end_op>
    return -1;
    80004e2c:	57fd                	li	a5,-1
    80004e2e:	64f2                	ld	s1,280(sp)
    80004e30:	a83d                	j	80004e6e <sys_link+0xf4>
    iunlockput(ip);
    80004e32:	8526                	mv	a0,s1
    80004e34:	e58fe0ef          	jal	8000348c <iunlockput>
    end_op();
    80004e38:	ec5fe0ef          	jal	80003cfc <end_op>
    return -1;
    80004e3c:	57fd                	li	a5,-1
    80004e3e:	64f2                	ld	s1,280(sp)
    80004e40:	a03d                	j	80004e6e <sys_link+0xf4>
    iunlockput(dp);
    80004e42:	854a                	mv	a0,s2
    80004e44:	e48fe0ef          	jal	8000348c <iunlockput>
  ilock(ip);
    80004e48:	8526                	mv	a0,s1
    80004e4a:	c36fe0ef          	jal	80003280 <ilock>
  ip->nlink--;
    80004e4e:	04a4d783          	lhu	a5,74(s1)
    80004e52:	37fd                	addiw	a5,a5,-1
    80004e54:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004e58:	8526                	mv	a0,s1
    80004e5a:	b72fe0ef          	jal	800031cc <iupdate>
  iunlockput(ip);
    80004e5e:	8526                	mv	a0,s1
    80004e60:	e2cfe0ef          	jal	8000348c <iunlockput>
  end_op();
    80004e64:	e99fe0ef          	jal	80003cfc <end_op>
  return -1;
    80004e68:	57fd                	li	a5,-1
    80004e6a:	64f2                	ld	s1,280(sp)
    80004e6c:	6952                	ld	s2,272(sp)
}
    80004e6e:	853e                	mv	a0,a5
    80004e70:	70b2                	ld	ra,296(sp)
    80004e72:	7412                	ld	s0,288(sp)
    80004e74:	6155                	addi	sp,sp,304
    80004e76:	8082                	ret

0000000080004e78 <sys_unlink>:
{
    80004e78:	7151                	addi	sp,sp,-240
    80004e7a:	f586                	sd	ra,232(sp)
    80004e7c:	f1a2                	sd	s0,224(sp)
    80004e7e:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004e80:	08000613          	li	a2,128
    80004e84:	f3040593          	addi	a1,s0,-208
    80004e88:	4501                	li	a0,0
    80004e8a:	a55fd0ef          	jal	800028de <argstr>
    80004e8e:	14054d63          	bltz	a0,80004fe8 <sys_unlink+0x170>
    80004e92:	eda6                	sd	s1,216(sp)
  begin_op();
    80004e94:	df9fe0ef          	jal	80003c8c <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004e98:	fb040593          	addi	a1,s0,-80
    80004e9c:	f3040513          	addi	a0,s0,-208
    80004ea0:	c29fe0ef          	jal	80003ac8 <nameiparent>
    80004ea4:	84aa                	mv	s1,a0
    80004ea6:	c955                	beqz	a0,80004f5a <sys_unlink+0xe2>
  ilock(dp);
    80004ea8:	bd8fe0ef          	jal	80003280 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004eac:	00002597          	auipc	a1,0x2
    80004eb0:	71458593          	addi	a1,a1,1812 # 800075c0 <etext+0x5c0>
    80004eb4:	fb040513          	addi	a0,s0,-80
    80004eb8:	94dfe0ef          	jal	80003804 <namecmp>
    80004ebc:	10050b63          	beqz	a0,80004fd2 <sys_unlink+0x15a>
    80004ec0:	00002597          	auipc	a1,0x2
    80004ec4:	70858593          	addi	a1,a1,1800 # 800075c8 <etext+0x5c8>
    80004ec8:	fb040513          	addi	a0,s0,-80
    80004ecc:	939fe0ef          	jal	80003804 <namecmp>
    80004ed0:	10050163          	beqz	a0,80004fd2 <sys_unlink+0x15a>
    80004ed4:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004ed6:	f2c40613          	addi	a2,s0,-212
    80004eda:	fb040593          	addi	a1,s0,-80
    80004ede:	8526                	mv	a0,s1
    80004ee0:	93bfe0ef          	jal	8000381a <dirlookup>
    80004ee4:	892a                	mv	s2,a0
    80004ee6:	0e050563          	beqz	a0,80004fd0 <sys_unlink+0x158>
    80004eea:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004eec:	b94fe0ef          	jal	80003280 <ilock>
  if(ip->nlink < 1)
    80004ef0:	04a91783          	lh	a5,74(s2)
    80004ef4:	06f05863          	blez	a5,80004f64 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004ef8:	04491703          	lh	a4,68(s2)
    80004efc:	4785                	li	a5,1
    80004efe:	06f70963          	beq	a4,a5,80004f70 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004f02:	fc040993          	addi	s3,s0,-64
    80004f06:	4641                	li	a2,16
    80004f08:	4581                	li	a1,0
    80004f0a:	854e                	mv	a0,s3
    80004f0c:	dedfb0ef          	jal	80000cf8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004f10:	4741                	li	a4,16
    80004f12:	f2c42683          	lw	a3,-212(s0)
    80004f16:	864e                	mv	a2,s3
    80004f18:	4581                	li	a1,0
    80004f1a:	8526                	mv	a0,s1
    80004f1c:	fe8fe0ef          	jal	80003704 <writei>
    80004f20:	47c1                	li	a5,16
    80004f22:	08f51863          	bne	a0,a5,80004fb2 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004f26:	04491703          	lh	a4,68(s2)
    80004f2a:	4785                	li	a5,1
    80004f2c:	08f70963          	beq	a4,a5,80004fbe <sys_unlink+0x146>
  iunlockput(dp);
    80004f30:	8526                	mv	a0,s1
    80004f32:	d5afe0ef          	jal	8000348c <iunlockput>
  ip->nlink--;
    80004f36:	04a95783          	lhu	a5,74(s2)
    80004f3a:	37fd                	addiw	a5,a5,-1
    80004f3c:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004f40:	854a                	mv	a0,s2
    80004f42:	a8afe0ef          	jal	800031cc <iupdate>
  iunlockput(ip);
    80004f46:	854a                	mv	a0,s2
    80004f48:	d44fe0ef          	jal	8000348c <iunlockput>
  end_op();
    80004f4c:	db1fe0ef          	jal	80003cfc <end_op>
  return 0;
    80004f50:	4501                	li	a0,0
    80004f52:	64ee                	ld	s1,216(sp)
    80004f54:	694e                	ld	s2,208(sp)
    80004f56:	69ae                	ld	s3,200(sp)
    80004f58:	a061                	j	80004fe0 <sys_unlink+0x168>
    end_op();
    80004f5a:	da3fe0ef          	jal	80003cfc <end_op>
    return -1;
    80004f5e:	557d                	li	a0,-1
    80004f60:	64ee                	ld	s1,216(sp)
    80004f62:	a8bd                	j	80004fe0 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004f64:	00002517          	auipc	a0,0x2
    80004f68:	66c50513          	addi	a0,a0,1644 # 800075d0 <etext+0x5d0>
    80004f6c:	8b9fb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004f70:	04c92703          	lw	a4,76(s2)
    80004f74:	02000793          	li	a5,32
    80004f78:	f8e7f5e3          	bgeu	a5,a4,80004f02 <sys_unlink+0x8a>
    80004f7c:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004f7e:	4741                	li	a4,16
    80004f80:	86ce                	mv	a3,s3
    80004f82:	f1840613          	addi	a2,s0,-232
    80004f86:	4581                	li	a1,0
    80004f88:	854a                	mv	a0,s2
    80004f8a:	e88fe0ef          	jal	80003612 <readi>
    80004f8e:	47c1                	li	a5,16
    80004f90:	00f51b63          	bne	a0,a5,80004fa6 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004f94:	f1845783          	lhu	a5,-232(s0)
    80004f98:	ebb1                	bnez	a5,80004fec <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004f9a:	29c1                	addiw	s3,s3,16
    80004f9c:	04c92783          	lw	a5,76(s2)
    80004fa0:	fcf9efe3          	bltu	s3,a5,80004f7e <sys_unlink+0x106>
    80004fa4:	bfb9                	j	80004f02 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004fa6:	00002517          	auipc	a0,0x2
    80004faa:	64250513          	addi	a0,a0,1602 # 800075e8 <etext+0x5e8>
    80004fae:	877fb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    80004fb2:	00002517          	auipc	a0,0x2
    80004fb6:	64e50513          	addi	a0,a0,1614 # 80007600 <etext+0x600>
    80004fba:	86bfb0ef          	jal	80000824 <panic>
    dp->nlink--;
    80004fbe:	04a4d783          	lhu	a5,74(s1)
    80004fc2:	37fd                	addiw	a5,a5,-1
    80004fc4:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004fc8:	8526                	mv	a0,s1
    80004fca:	a02fe0ef          	jal	800031cc <iupdate>
    80004fce:	b78d                	j	80004f30 <sys_unlink+0xb8>
    80004fd0:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004fd2:	8526                	mv	a0,s1
    80004fd4:	cb8fe0ef          	jal	8000348c <iunlockput>
  end_op();
    80004fd8:	d25fe0ef          	jal	80003cfc <end_op>
  return -1;
    80004fdc:	557d                	li	a0,-1
    80004fde:	64ee                	ld	s1,216(sp)
}
    80004fe0:	70ae                	ld	ra,232(sp)
    80004fe2:	740e                	ld	s0,224(sp)
    80004fe4:	616d                	addi	sp,sp,240
    80004fe6:	8082                	ret
    return -1;
    80004fe8:	557d                	li	a0,-1
    80004fea:	bfdd                	j	80004fe0 <sys_unlink+0x168>
    iunlockput(ip);
    80004fec:	854a                	mv	a0,s2
    80004fee:	c9efe0ef          	jal	8000348c <iunlockput>
    goto bad;
    80004ff2:	694e                	ld	s2,208(sp)
    80004ff4:	69ae                	ld	s3,200(sp)
    80004ff6:	bff1                	j	80004fd2 <sys_unlink+0x15a>

0000000080004ff8 <sys_open>:

uint64
sys_open(void)
{
    80004ff8:	7131                	addi	sp,sp,-192
    80004ffa:	fd06                	sd	ra,184(sp)
    80004ffc:	f922                	sd	s0,176(sp)
    80004ffe:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005000:	f4c40593          	addi	a1,s0,-180
    80005004:	4505                	li	a0,1
    80005006:	8a1fd0ef          	jal	800028a6 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000500a:	08000613          	li	a2,128
    8000500e:	f5040593          	addi	a1,s0,-176
    80005012:	4501                	li	a0,0
    80005014:	8cbfd0ef          	jal	800028de <argstr>
    80005018:	87aa                	mv	a5,a0
    return -1;
    8000501a:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000501c:	0a07c363          	bltz	a5,800050c2 <sys_open+0xca>
    80005020:	f526                	sd	s1,168(sp)

  begin_op();
    80005022:	c6bfe0ef          	jal	80003c8c <begin_op>

  if(omode & O_CREATE){
    80005026:	f4c42783          	lw	a5,-180(s0)
    8000502a:	2007f793          	andi	a5,a5,512
    8000502e:	c3dd                	beqz	a5,800050d4 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80005030:	4681                	li	a3,0
    80005032:	4601                	li	a2,0
    80005034:	4589                	li	a1,2
    80005036:	f5040513          	addi	a0,s0,-176
    8000503a:	aafff0ef          	jal	80004ae8 <create>
    8000503e:	84aa                	mv	s1,a0
    if(ip == 0){
    80005040:	c549                	beqz	a0,800050ca <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80005042:	04449703          	lh	a4,68(s1)
    80005046:	478d                	li	a5,3
    80005048:	00f71763          	bne	a4,a5,80005056 <sys_open+0x5e>
    8000504c:	0464d703          	lhu	a4,70(s1)
    80005050:	47a5                	li	a5,9
    80005052:	0ae7ee63          	bltu	a5,a4,8000510e <sys_open+0x116>
    80005056:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005058:	fb5fe0ef          	jal	8000400c <filealloc>
    8000505c:	892a                	mv	s2,a0
    8000505e:	c561                	beqz	a0,80005126 <sys_open+0x12e>
    80005060:	ed4e                	sd	s3,152(sp)
    80005062:	a47ff0ef          	jal	80004aa8 <fdalloc>
    80005066:	89aa                	mv	s3,a0
    80005068:	0a054b63          	bltz	a0,8000511e <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000506c:	04449703          	lh	a4,68(s1)
    80005070:	478d                	li	a5,3
    80005072:	0cf70363          	beq	a4,a5,80005138 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005076:	4789                	li	a5,2
    80005078:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000507c:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005080:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005084:	f4c42783          	lw	a5,-180(s0)
    80005088:	0017f713          	andi	a4,a5,1
    8000508c:	00174713          	xori	a4,a4,1
    80005090:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005094:	0037f713          	andi	a4,a5,3
    80005098:	00e03733          	snez	a4,a4
    8000509c:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800050a0:	4007f793          	andi	a5,a5,1024
    800050a4:	c791                	beqz	a5,800050b0 <sys_open+0xb8>
    800050a6:	04449703          	lh	a4,68(s1)
    800050aa:	4789                	li	a5,2
    800050ac:	08f70d63          	beq	a4,a5,80005146 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    800050b0:	8526                	mv	a0,s1
    800050b2:	a7cfe0ef          	jal	8000332e <iunlock>
  end_op();
    800050b6:	c47fe0ef          	jal	80003cfc <end_op>

  return fd;
    800050ba:	854e                	mv	a0,s3
    800050bc:	74aa                	ld	s1,168(sp)
    800050be:	790a                	ld	s2,160(sp)
    800050c0:	69ea                	ld	s3,152(sp)
}
    800050c2:	70ea                	ld	ra,184(sp)
    800050c4:	744a                	ld	s0,176(sp)
    800050c6:	6129                	addi	sp,sp,192
    800050c8:	8082                	ret
      end_op();
    800050ca:	c33fe0ef          	jal	80003cfc <end_op>
      return -1;
    800050ce:	557d                	li	a0,-1
    800050d0:	74aa                	ld	s1,168(sp)
    800050d2:	bfc5                	j	800050c2 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800050d4:	f5040513          	addi	a0,s0,-176
    800050d8:	9d7fe0ef          	jal	80003aae <namei>
    800050dc:	84aa                	mv	s1,a0
    800050de:	c11d                	beqz	a0,80005104 <sys_open+0x10c>
    ilock(ip);
    800050e0:	9a0fe0ef          	jal	80003280 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800050e4:	04449703          	lh	a4,68(s1)
    800050e8:	4785                	li	a5,1
    800050ea:	f4f71ce3          	bne	a4,a5,80005042 <sys_open+0x4a>
    800050ee:	f4c42783          	lw	a5,-180(s0)
    800050f2:	d3b5                	beqz	a5,80005056 <sys_open+0x5e>
      iunlockput(ip);
    800050f4:	8526                	mv	a0,s1
    800050f6:	b96fe0ef          	jal	8000348c <iunlockput>
      end_op();
    800050fa:	c03fe0ef          	jal	80003cfc <end_op>
      return -1;
    800050fe:	557d                	li	a0,-1
    80005100:	74aa                	ld	s1,168(sp)
    80005102:	b7c1                	j	800050c2 <sys_open+0xca>
      end_op();
    80005104:	bf9fe0ef          	jal	80003cfc <end_op>
      return -1;
    80005108:	557d                	li	a0,-1
    8000510a:	74aa                	ld	s1,168(sp)
    8000510c:	bf5d                	j	800050c2 <sys_open+0xca>
    iunlockput(ip);
    8000510e:	8526                	mv	a0,s1
    80005110:	b7cfe0ef          	jal	8000348c <iunlockput>
    end_op();
    80005114:	be9fe0ef          	jal	80003cfc <end_op>
    return -1;
    80005118:	557d                	li	a0,-1
    8000511a:	74aa                	ld	s1,168(sp)
    8000511c:	b75d                	j	800050c2 <sys_open+0xca>
      fileclose(f);
    8000511e:	854a                	mv	a0,s2
    80005120:	f91fe0ef          	jal	800040b0 <fileclose>
    80005124:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005126:	8526                	mv	a0,s1
    80005128:	b64fe0ef          	jal	8000348c <iunlockput>
    end_op();
    8000512c:	bd1fe0ef          	jal	80003cfc <end_op>
    return -1;
    80005130:	557d                	li	a0,-1
    80005132:	74aa                	ld	s1,168(sp)
    80005134:	790a                	ld	s2,160(sp)
    80005136:	b771                	j	800050c2 <sys_open+0xca>
    f->type = FD_DEVICE;
    80005138:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    8000513c:	04649783          	lh	a5,70(s1)
    80005140:	02f91223          	sh	a5,36(s2)
    80005144:	bf35                	j	80005080 <sys_open+0x88>
    itrunc(ip);
    80005146:	8526                	mv	a0,s1
    80005148:	a26fe0ef          	jal	8000336e <itrunc>
    8000514c:	b795                	j	800050b0 <sys_open+0xb8>

000000008000514e <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000514e:	7175                	addi	sp,sp,-144
    80005150:	e506                	sd	ra,136(sp)
    80005152:	e122                	sd	s0,128(sp)
    80005154:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005156:	b37fe0ef          	jal	80003c8c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000515a:	08000613          	li	a2,128
    8000515e:	f7040593          	addi	a1,s0,-144
    80005162:	4501                	li	a0,0
    80005164:	f7afd0ef          	jal	800028de <argstr>
    80005168:	02054363          	bltz	a0,8000518e <sys_mkdir+0x40>
    8000516c:	4681                	li	a3,0
    8000516e:	4601                	li	a2,0
    80005170:	4585                	li	a1,1
    80005172:	f7040513          	addi	a0,s0,-144
    80005176:	973ff0ef          	jal	80004ae8 <create>
    8000517a:	c911                	beqz	a0,8000518e <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000517c:	b10fe0ef          	jal	8000348c <iunlockput>
  end_op();
    80005180:	b7dfe0ef          	jal	80003cfc <end_op>
  return 0;
    80005184:	4501                	li	a0,0
}
    80005186:	60aa                	ld	ra,136(sp)
    80005188:	640a                	ld	s0,128(sp)
    8000518a:	6149                	addi	sp,sp,144
    8000518c:	8082                	ret
    end_op();
    8000518e:	b6ffe0ef          	jal	80003cfc <end_op>
    return -1;
    80005192:	557d                	li	a0,-1
    80005194:	bfcd                	j	80005186 <sys_mkdir+0x38>

0000000080005196 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005196:	7135                	addi	sp,sp,-160
    80005198:	ed06                	sd	ra,152(sp)
    8000519a:	e922                	sd	s0,144(sp)
    8000519c:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000519e:	aeffe0ef          	jal	80003c8c <begin_op>
  argint(1, &major);
    800051a2:	f6c40593          	addi	a1,s0,-148
    800051a6:	4505                	li	a0,1
    800051a8:	efefd0ef          	jal	800028a6 <argint>
  argint(2, &minor);
    800051ac:	f6840593          	addi	a1,s0,-152
    800051b0:	4509                	li	a0,2
    800051b2:	ef4fd0ef          	jal	800028a6 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800051b6:	08000613          	li	a2,128
    800051ba:	f7040593          	addi	a1,s0,-144
    800051be:	4501                	li	a0,0
    800051c0:	f1efd0ef          	jal	800028de <argstr>
    800051c4:	02054563          	bltz	a0,800051ee <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800051c8:	f6841683          	lh	a3,-152(s0)
    800051cc:	f6c41603          	lh	a2,-148(s0)
    800051d0:	458d                	li	a1,3
    800051d2:	f7040513          	addi	a0,s0,-144
    800051d6:	913ff0ef          	jal	80004ae8 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800051da:	c911                	beqz	a0,800051ee <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800051dc:	ab0fe0ef          	jal	8000348c <iunlockput>
  end_op();
    800051e0:	b1dfe0ef          	jal	80003cfc <end_op>
  return 0;
    800051e4:	4501                	li	a0,0
}
    800051e6:	60ea                	ld	ra,152(sp)
    800051e8:	644a                	ld	s0,144(sp)
    800051ea:	610d                	addi	sp,sp,160
    800051ec:	8082                	ret
    end_op();
    800051ee:	b0ffe0ef          	jal	80003cfc <end_op>
    return -1;
    800051f2:	557d                	li	a0,-1
    800051f4:	bfcd                	j	800051e6 <sys_mknod+0x50>

00000000800051f6 <sys_chdir>:

uint64
sys_chdir(void)
{
    800051f6:	7135                	addi	sp,sp,-160
    800051f8:	ed06                	sd	ra,152(sp)
    800051fa:	e922                	sd	s0,144(sp)
    800051fc:	e14a                	sd	s2,128(sp)
    800051fe:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005200:	f2efc0ef          	jal	8000192e <myproc>
    80005204:	892a                	mv	s2,a0
  
  begin_op();
    80005206:	a87fe0ef          	jal	80003c8c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    8000520a:	08000613          	li	a2,128
    8000520e:	f6040593          	addi	a1,s0,-160
    80005212:	4501                	li	a0,0
    80005214:	ecafd0ef          	jal	800028de <argstr>
    80005218:	04054363          	bltz	a0,8000525e <sys_chdir+0x68>
    8000521c:	e526                	sd	s1,136(sp)
    8000521e:	f6040513          	addi	a0,s0,-160
    80005222:	88dfe0ef          	jal	80003aae <namei>
    80005226:	84aa                	mv	s1,a0
    80005228:	c915                	beqz	a0,8000525c <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000522a:	856fe0ef          	jal	80003280 <ilock>
  if(ip->type != T_DIR){
    8000522e:	04449703          	lh	a4,68(s1)
    80005232:	4785                	li	a5,1
    80005234:	02f71963          	bne	a4,a5,80005266 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005238:	8526                	mv	a0,s1
    8000523a:	8f4fe0ef          	jal	8000332e <iunlock>
  iput(p->cwd);
    8000523e:	15093503          	ld	a0,336(s2)
    80005242:	9c0fe0ef          	jal	80003402 <iput>
  end_op();
    80005246:	ab7fe0ef          	jal	80003cfc <end_op>
  p->cwd = ip;
    8000524a:	14993823          	sd	s1,336(s2)
  return 0;
    8000524e:	4501                	li	a0,0
    80005250:	64aa                	ld	s1,136(sp)
}
    80005252:	60ea                	ld	ra,152(sp)
    80005254:	644a                	ld	s0,144(sp)
    80005256:	690a                	ld	s2,128(sp)
    80005258:	610d                	addi	sp,sp,160
    8000525a:	8082                	ret
    8000525c:	64aa                	ld	s1,136(sp)
    end_op();
    8000525e:	a9ffe0ef          	jal	80003cfc <end_op>
    return -1;
    80005262:	557d                	li	a0,-1
    80005264:	b7fd                	j	80005252 <sys_chdir+0x5c>
    iunlockput(ip);
    80005266:	8526                	mv	a0,s1
    80005268:	a24fe0ef          	jal	8000348c <iunlockput>
    end_op();
    8000526c:	a91fe0ef          	jal	80003cfc <end_op>
    return -1;
    80005270:	557d                	li	a0,-1
    80005272:	64aa                	ld	s1,136(sp)
    80005274:	bff9                	j	80005252 <sys_chdir+0x5c>

0000000080005276 <sys_exec>:

uint64
sys_exec(void)
{
    80005276:	7105                	addi	sp,sp,-480
    80005278:	ef86                	sd	ra,472(sp)
    8000527a:	eba2                	sd	s0,464(sp)
    8000527c:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000527e:	e2840593          	addi	a1,s0,-472
    80005282:	4505                	li	a0,1
    80005284:	e3efd0ef          	jal	800028c2 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005288:	08000613          	li	a2,128
    8000528c:	f3040593          	addi	a1,s0,-208
    80005290:	4501                	li	a0,0
    80005292:	e4cfd0ef          	jal	800028de <argstr>
    80005296:	87aa                	mv	a5,a0
    return -1;
    80005298:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000529a:	0e07c063          	bltz	a5,8000537a <sys_exec+0x104>
    8000529e:	e7a6                	sd	s1,456(sp)
    800052a0:	e3ca                	sd	s2,448(sp)
    800052a2:	ff4e                	sd	s3,440(sp)
    800052a4:	fb52                	sd	s4,432(sp)
    800052a6:	f756                	sd	s5,424(sp)
    800052a8:	f35a                	sd	s6,416(sp)
    800052aa:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    800052ac:	e3040a13          	addi	s4,s0,-464
    800052b0:	10000613          	li	a2,256
    800052b4:	4581                	li	a1,0
    800052b6:	8552                	mv	a0,s4
    800052b8:	a41fb0ef          	jal	80000cf8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800052bc:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800052be:	89d2                	mv	s3,s4
    800052c0:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800052c2:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800052c6:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800052c8:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800052cc:	00391513          	slli	a0,s2,0x3
    800052d0:	85d6                	mv	a1,s5
    800052d2:	e2843783          	ld	a5,-472(s0)
    800052d6:	953e                	add	a0,a0,a5
    800052d8:	d44fd0ef          	jal	8000281c <fetchaddr>
    800052dc:	02054663          	bltz	a0,80005308 <sys_exec+0x92>
    if(uarg == 0){
    800052e0:	e2043783          	ld	a5,-480(s0)
    800052e4:	c7a1                	beqz	a5,8000532c <sys_exec+0xb6>
    argv[i] = kalloc();
    800052e6:	85ffb0ef          	jal	80000b44 <kalloc>
    800052ea:	85aa                	mv	a1,a0
    800052ec:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800052f0:	cd01                	beqz	a0,80005308 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800052f2:	865a                	mv	a2,s6
    800052f4:	e2043503          	ld	a0,-480(s0)
    800052f8:	d6efd0ef          	jal	80002866 <fetchstr>
    800052fc:	00054663          	bltz	a0,80005308 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    80005300:	0905                	addi	s2,s2,1
    80005302:	09a1                	addi	s3,s3,8
    80005304:	fd7914e3          	bne	s2,s7,800052cc <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005308:	100a0a13          	addi	s4,s4,256
    8000530c:	6088                	ld	a0,0(s1)
    8000530e:	cd31                	beqz	a0,8000536a <sys_exec+0xf4>
    kfree(argv[i]);
    80005310:	f4cfb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005314:	04a1                	addi	s1,s1,8
    80005316:	ff449be3          	bne	s1,s4,8000530c <sys_exec+0x96>
  return -1;
    8000531a:	557d                	li	a0,-1
    8000531c:	64be                	ld	s1,456(sp)
    8000531e:	691e                	ld	s2,448(sp)
    80005320:	79fa                	ld	s3,440(sp)
    80005322:	7a5a                	ld	s4,432(sp)
    80005324:	7aba                	ld	s5,424(sp)
    80005326:	7b1a                	ld	s6,416(sp)
    80005328:	6bfa                	ld	s7,408(sp)
    8000532a:	a881                	j	8000537a <sys_exec+0x104>
      argv[i] = 0;
    8000532c:	0009079b          	sext.w	a5,s2
    80005330:	e3040593          	addi	a1,s0,-464
    80005334:	078e                	slli	a5,a5,0x3
    80005336:	97ae                	add	a5,a5,a1
    80005338:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    8000533c:	f3040513          	addi	a0,s0,-208
    80005340:	bb2ff0ef          	jal	800046f2 <kexec>
    80005344:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005346:	100a0a13          	addi	s4,s4,256
    8000534a:	6088                	ld	a0,0(s1)
    8000534c:	c511                	beqz	a0,80005358 <sys_exec+0xe2>
    kfree(argv[i]);
    8000534e:	f0efb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005352:	04a1                	addi	s1,s1,8
    80005354:	ff449be3          	bne	s1,s4,8000534a <sys_exec+0xd4>
  return ret;
    80005358:	854a                	mv	a0,s2
    8000535a:	64be                	ld	s1,456(sp)
    8000535c:	691e                	ld	s2,448(sp)
    8000535e:	79fa                	ld	s3,440(sp)
    80005360:	7a5a                	ld	s4,432(sp)
    80005362:	7aba                	ld	s5,424(sp)
    80005364:	7b1a                	ld	s6,416(sp)
    80005366:	6bfa                	ld	s7,408(sp)
    80005368:	a809                	j	8000537a <sys_exec+0x104>
  return -1;
    8000536a:	557d                	li	a0,-1
    8000536c:	64be                	ld	s1,456(sp)
    8000536e:	691e                	ld	s2,448(sp)
    80005370:	79fa                	ld	s3,440(sp)
    80005372:	7a5a                	ld	s4,432(sp)
    80005374:	7aba                	ld	s5,424(sp)
    80005376:	7b1a                	ld	s6,416(sp)
    80005378:	6bfa                	ld	s7,408(sp)
}
    8000537a:	60fe                	ld	ra,472(sp)
    8000537c:	645e                	ld	s0,464(sp)
    8000537e:	613d                	addi	sp,sp,480
    80005380:	8082                	ret

0000000080005382 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005382:	7139                	addi	sp,sp,-64
    80005384:	fc06                	sd	ra,56(sp)
    80005386:	f822                	sd	s0,48(sp)
    80005388:	f426                	sd	s1,40(sp)
    8000538a:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000538c:	da2fc0ef          	jal	8000192e <myproc>
    80005390:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005392:	fd840593          	addi	a1,s0,-40
    80005396:	4501                	li	a0,0
    80005398:	d2afd0ef          	jal	800028c2 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000539c:	fc840593          	addi	a1,s0,-56
    800053a0:	fd040513          	addi	a0,s0,-48
    800053a4:	828ff0ef          	jal	800043cc <pipealloc>
    return -1;
    800053a8:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800053aa:	0a054763          	bltz	a0,80005458 <sys_pipe+0xd6>
  fd0 = -1;
    800053ae:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800053b2:	fd043503          	ld	a0,-48(s0)
    800053b6:	ef2ff0ef          	jal	80004aa8 <fdalloc>
    800053ba:	fca42223          	sw	a0,-60(s0)
    800053be:	08054463          	bltz	a0,80005446 <sys_pipe+0xc4>
    800053c2:	fc843503          	ld	a0,-56(s0)
    800053c6:	ee2ff0ef          	jal	80004aa8 <fdalloc>
    800053ca:	fca42023          	sw	a0,-64(s0)
    800053ce:	06054263          	bltz	a0,80005432 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800053d2:	4691                	li	a3,4
    800053d4:	fc440613          	addi	a2,s0,-60
    800053d8:	fd843583          	ld	a1,-40(s0)
    800053dc:	68a8                	ld	a0,80(s1)
    800053de:	a76fc0ef          	jal	80001654 <copyout>
    800053e2:	00054e63          	bltz	a0,800053fe <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800053e6:	4691                	li	a3,4
    800053e8:	fc040613          	addi	a2,s0,-64
    800053ec:	fd843583          	ld	a1,-40(s0)
    800053f0:	95b6                	add	a1,a1,a3
    800053f2:	68a8                	ld	a0,80(s1)
    800053f4:	a60fc0ef          	jal	80001654 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800053f8:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800053fa:	04055f63          	bgez	a0,80005458 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800053fe:	fc442783          	lw	a5,-60(s0)
    80005402:	078e                	slli	a5,a5,0x3
    80005404:	0d078793          	addi	a5,a5,208
    80005408:	97a6                	add	a5,a5,s1
    8000540a:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000540e:	fc042783          	lw	a5,-64(s0)
    80005412:	078e                	slli	a5,a5,0x3
    80005414:	0d078793          	addi	a5,a5,208
    80005418:	97a6                	add	a5,a5,s1
    8000541a:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000541e:	fd043503          	ld	a0,-48(s0)
    80005422:	c8ffe0ef          	jal	800040b0 <fileclose>
    fileclose(wf);
    80005426:	fc843503          	ld	a0,-56(s0)
    8000542a:	c87fe0ef          	jal	800040b0 <fileclose>
    return -1;
    8000542e:	57fd                	li	a5,-1
    80005430:	a025                	j	80005458 <sys_pipe+0xd6>
    if(fd0 >= 0)
    80005432:	fc442783          	lw	a5,-60(s0)
    80005436:	0007c863          	bltz	a5,80005446 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    8000543a:	078e                	slli	a5,a5,0x3
    8000543c:	0d078793          	addi	a5,a5,208
    80005440:	97a6                	add	a5,a5,s1
    80005442:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005446:	fd043503          	ld	a0,-48(s0)
    8000544a:	c67fe0ef          	jal	800040b0 <fileclose>
    fileclose(wf);
    8000544e:	fc843503          	ld	a0,-56(s0)
    80005452:	c5ffe0ef          	jal	800040b0 <fileclose>
    return -1;
    80005456:	57fd                	li	a5,-1
}
    80005458:	853e                	mv	a0,a5
    8000545a:	70e2                	ld	ra,56(sp)
    8000545c:	7442                	ld	s0,48(sp)
    8000545e:	74a2                	ld	s1,40(sp)
    80005460:	6121                	addi	sp,sp,64
    80005462:	8082                	ret
	...

0000000080005470 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005470:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005472:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005474:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005476:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005478:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000547a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000547c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000547e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005480:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005482:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005484:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005486:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005488:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000548a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000548c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000548e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005490:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005492:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005494:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005496:	a94fd0ef          	jal	8000272a <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000549a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000549c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000549e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800054a0:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800054a2:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800054a4:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800054a6:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800054a8:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800054aa:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800054ac:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800054ae:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800054b0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800054b2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800054b4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800054b6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800054b8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800054ba:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800054bc:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800054be:	10200073          	sret
    800054c2:	00000013          	nop
    800054c6:	00000013          	nop
    800054ca:	00000013          	nop

00000000800054ce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800054ce:	1141                	addi	sp,sp,-16
    800054d0:	e406                	sd	ra,8(sp)
    800054d2:	e022                	sd	s0,0(sp)
    800054d4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800054d6:	0c000737          	lui	a4,0xc000
    800054da:	4785                	li	a5,1
    800054dc:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800054de:	c35c                	sw	a5,4(a4)
}
    800054e0:	60a2                	ld	ra,8(sp)
    800054e2:	6402                	ld	s0,0(sp)
    800054e4:	0141                	addi	sp,sp,16
    800054e6:	8082                	ret

00000000800054e8 <plicinithart>:

void
plicinithart(void)
{
    800054e8:	1141                	addi	sp,sp,-16
    800054ea:	e406                	sd	ra,8(sp)
    800054ec:	e022                	sd	s0,0(sp)
    800054ee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800054f0:	c0afc0ef          	jal	800018fa <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800054f4:	0085171b          	slliw	a4,a0,0x8
    800054f8:	0c0027b7          	lui	a5,0xc002
    800054fc:	97ba                	add	a5,a5,a4
    800054fe:	40200713          	li	a4,1026
    80005502:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005506:	00d5151b          	slliw	a0,a0,0xd
    8000550a:	0c2017b7          	lui	a5,0xc201
    8000550e:	97aa                	add	a5,a5,a0
    80005510:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005514:	60a2                	ld	ra,8(sp)
    80005516:	6402                	ld	s0,0(sp)
    80005518:	0141                	addi	sp,sp,16
    8000551a:	8082                	ret

000000008000551c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000551c:	1141                	addi	sp,sp,-16
    8000551e:	e406                	sd	ra,8(sp)
    80005520:	e022                	sd	s0,0(sp)
    80005522:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005524:	bd6fc0ef          	jal	800018fa <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005528:	00d5151b          	slliw	a0,a0,0xd
    8000552c:	0c2017b7          	lui	a5,0xc201
    80005530:	97aa                	add	a5,a5,a0
  return irq;
}
    80005532:	43c8                	lw	a0,4(a5)
    80005534:	60a2                	ld	ra,8(sp)
    80005536:	6402                	ld	s0,0(sp)
    80005538:	0141                	addi	sp,sp,16
    8000553a:	8082                	ret

000000008000553c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000553c:	1101                	addi	sp,sp,-32
    8000553e:	ec06                	sd	ra,24(sp)
    80005540:	e822                	sd	s0,16(sp)
    80005542:	e426                	sd	s1,8(sp)
    80005544:	1000                	addi	s0,sp,32
    80005546:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005548:	bb2fc0ef          	jal	800018fa <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000554c:	00d5179b          	slliw	a5,a0,0xd
    80005550:	0c201737          	lui	a4,0xc201
    80005554:	97ba                	add	a5,a5,a4
    80005556:	c3c4                	sw	s1,4(a5)
}
    80005558:	60e2                	ld	ra,24(sp)
    8000555a:	6442                	ld	s0,16(sp)
    8000555c:	64a2                	ld	s1,8(sp)
    8000555e:	6105                	addi	sp,sp,32
    80005560:	8082                	ret

0000000080005562 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005562:	1141                	addi	sp,sp,-16
    80005564:	e406                	sd	ra,8(sp)
    80005566:	e022                	sd	s0,0(sp)
    80005568:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000556a:	479d                	li	a5,7
    8000556c:	04a7ca63          	blt	a5,a0,800055c0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005570:	0001b797          	auipc	a5,0x1b
    80005574:	4c878793          	addi	a5,a5,1224 # 80020a38 <disk>
    80005578:	97aa                	add	a5,a5,a0
    8000557a:	0187c783          	lbu	a5,24(a5)
    8000557e:	e7b9                	bnez	a5,800055cc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005580:	00451693          	slli	a3,a0,0x4
    80005584:	0001b797          	auipc	a5,0x1b
    80005588:	4b478793          	addi	a5,a5,1204 # 80020a38 <disk>
    8000558c:	6398                	ld	a4,0(a5)
    8000558e:	9736                	add	a4,a4,a3
    80005590:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005594:	6398                	ld	a4,0(a5)
    80005596:	9736                	add	a4,a4,a3
    80005598:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000559c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800055a0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800055a4:	97aa                	add	a5,a5,a0
    800055a6:	4705                	li	a4,1
    800055a8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800055ac:	0001b517          	auipc	a0,0x1b
    800055b0:	4a450513          	addi	a0,a0,1188 # 80020a50 <disk+0x18>
    800055b4:	9c5fc0ef          	jal	80001f78 <wakeup>
}
    800055b8:	60a2                	ld	ra,8(sp)
    800055ba:	6402                	ld	s0,0(sp)
    800055bc:	0141                	addi	sp,sp,16
    800055be:	8082                	ret
    panic("free_desc 1");
    800055c0:	00002517          	auipc	a0,0x2
    800055c4:	05050513          	addi	a0,a0,80 # 80007610 <etext+0x610>
    800055c8:	a5cfb0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    800055cc:	00002517          	auipc	a0,0x2
    800055d0:	05450513          	addi	a0,a0,84 # 80007620 <etext+0x620>
    800055d4:	a50fb0ef          	jal	80000824 <panic>

00000000800055d8 <virtio_disk_init>:
{
    800055d8:	1101                	addi	sp,sp,-32
    800055da:	ec06                	sd	ra,24(sp)
    800055dc:	e822                	sd	s0,16(sp)
    800055de:	e426                	sd	s1,8(sp)
    800055e0:	e04a                	sd	s2,0(sp)
    800055e2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800055e4:	00002597          	auipc	a1,0x2
    800055e8:	04c58593          	addi	a1,a1,76 # 80007630 <etext+0x630>
    800055ec:	0001b517          	auipc	a0,0x1b
    800055f0:	57450513          	addi	a0,a0,1396 # 80020b60 <disk+0x128>
    800055f4:	daafb0ef          	jal	80000b9e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800055f8:	100017b7          	lui	a5,0x10001
    800055fc:	4398                	lw	a4,0(a5)
    800055fe:	2701                	sext.w	a4,a4
    80005600:	747277b7          	lui	a5,0x74727
    80005604:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005608:	14f71863          	bne	a4,a5,80005758 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000560c:	100017b7          	lui	a5,0x10001
    80005610:	43dc                	lw	a5,4(a5)
    80005612:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005614:	4709                	li	a4,2
    80005616:	14e79163          	bne	a5,a4,80005758 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000561a:	100017b7          	lui	a5,0x10001
    8000561e:	479c                	lw	a5,8(a5)
    80005620:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005622:	12e79b63          	bne	a5,a4,80005758 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005626:	100017b7          	lui	a5,0x10001
    8000562a:	47d8                	lw	a4,12(a5)
    8000562c:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000562e:	554d47b7          	lui	a5,0x554d4
    80005632:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005636:	12f71163          	bne	a4,a5,80005758 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000563a:	100017b7          	lui	a5,0x10001
    8000563e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005642:	4705                	li	a4,1
    80005644:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005646:	470d                	li	a4,3
    80005648:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000564a:	10001737          	lui	a4,0x10001
    8000564e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005650:	c7ffe6b7          	lui	a3,0xc7ffe
    80005654:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fddbe7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005658:	8f75                	and	a4,a4,a3
    8000565a:	100016b7          	lui	a3,0x10001
    8000565e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005660:	472d                	li	a4,11
    80005662:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005664:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005668:	439c                	lw	a5,0(a5)
    8000566a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000566e:	8ba1                	andi	a5,a5,8
    80005670:	0e078a63          	beqz	a5,80005764 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005674:	100017b7          	lui	a5,0x10001
    80005678:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000567c:	43fc                	lw	a5,68(a5)
    8000567e:	2781                	sext.w	a5,a5
    80005680:	0e079863          	bnez	a5,80005770 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005684:	100017b7          	lui	a5,0x10001
    80005688:	5bdc                	lw	a5,52(a5)
    8000568a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000568c:	0e078863          	beqz	a5,8000577c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005690:	471d                	li	a4,7
    80005692:	0ef77b63          	bgeu	a4,a5,80005788 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005696:	caefb0ef          	jal	80000b44 <kalloc>
    8000569a:	0001b497          	auipc	s1,0x1b
    8000569e:	39e48493          	addi	s1,s1,926 # 80020a38 <disk>
    800056a2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800056a4:	ca0fb0ef          	jal	80000b44 <kalloc>
    800056a8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800056aa:	c9afb0ef          	jal	80000b44 <kalloc>
    800056ae:	87aa                	mv	a5,a0
    800056b0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800056b2:	6088                	ld	a0,0(s1)
    800056b4:	0e050063          	beqz	a0,80005794 <virtio_disk_init+0x1bc>
    800056b8:	0001b717          	auipc	a4,0x1b
    800056bc:	38873703          	ld	a4,904(a4) # 80020a40 <disk+0x8>
    800056c0:	cb71                	beqz	a4,80005794 <virtio_disk_init+0x1bc>
    800056c2:	cbe9                	beqz	a5,80005794 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    800056c4:	6605                	lui	a2,0x1
    800056c6:	4581                	li	a1,0
    800056c8:	e30fb0ef          	jal	80000cf8 <memset>
  memset(disk.avail, 0, PGSIZE);
    800056cc:	0001b497          	auipc	s1,0x1b
    800056d0:	36c48493          	addi	s1,s1,876 # 80020a38 <disk>
    800056d4:	6605                	lui	a2,0x1
    800056d6:	4581                	li	a1,0
    800056d8:	6488                	ld	a0,8(s1)
    800056da:	e1efb0ef          	jal	80000cf8 <memset>
  memset(disk.used, 0, PGSIZE);
    800056de:	6605                	lui	a2,0x1
    800056e0:	4581                	li	a1,0
    800056e2:	6888                	ld	a0,16(s1)
    800056e4:	e14fb0ef          	jal	80000cf8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800056e8:	100017b7          	lui	a5,0x10001
    800056ec:	4721                	li	a4,8
    800056ee:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800056f0:	4098                	lw	a4,0(s1)
    800056f2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800056f6:	40d8                	lw	a4,4(s1)
    800056f8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800056fc:	649c                	ld	a5,8(s1)
    800056fe:	0007869b          	sext.w	a3,a5
    80005702:	10001737          	lui	a4,0x10001
    80005706:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    8000570a:	9781                	srai	a5,a5,0x20
    8000570c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005710:	689c                	ld	a5,16(s1)
    80005712:	0007869b          	sext.w	a3,a5
    80005716:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000571a:	9781                	srai	a5,a5,0x20
    8000571c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005720:	4785                	li	a5,1
    80005722:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005724:	00f48c23          	sb	a5,24(s1)
    80005728:	00f48ca3          	sb	a5,25(s1)
    8000572c:	00f48d23          	sb	a5,26(s1)
    80005730:	00f48da3          	sb	a5,27(s1)
    80005734:	00f48e23          	sb	a5,28(s1)
    80005738:	00f48ea3          	sb	a5,29(s1)
    8000573c:	00f48f23          	sb	a5,30(s1)
    80005740:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005744:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005748:	07272823          	sw	s2,112(a4)
}
    8000574c:	60e2                	ld	ra,24(sp)
    8000574e:	6442                	ld	s0,16(sp)
    80005750:	64a2                	ld	s1,8(sp)
    80005752:	6902                	ld	s2,0(sp)
    80005754:	6105                	addi	sp,sp,32
    80005756:	8082                	ret
    panic("could not find virtio disk");
    80005758:	00002517          	auipc	a0,0x2
    8000575c:	ee850513          	addi	a0,a0,-280 # 80007640 <etext+0x640>
    80005760:	8c4fb0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005764:	00002517          	auipc	a0,0x2
    80005768:	efc50513          	addi	a0,a0,-260 # 80007660 <etext+0x660>
    8000576c:	8b8fb0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    80005770:	00002517          	auipc	a0,0x2
    80005774:	f1050513          	addi	a0,a0,-240 # 80007680 <etext+0x680>
    80005778:	8acfb0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    8000577c:	00002517          	auipc	a0,0x2
    80005780:	f2450513          	addi	a0,a0,-220 # 800076a0 <etext+0x6a0>
    80005784:	8a0fb0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    80005788:	00002517          	auipc	a0,0x2
    8000578c:	f3850513          	addi	a0,a0,-200 # 800076c0 <etext+0x6c0>
    80005790:	894fb0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    80005794:	00002517          	auipc	a0,0x2
    80005798:	f4c50513          	addi	a0,a0,-180 # 800076e0 <etext+0x6e0>
    8000579c:	888fb0ef          	jal	80000824 <panic>

00000000800057a0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800057a0:	711d                	addi	sp,sp,-96
    800057a2:	ec86                	sd	ra,88(sp)
    800057a4:	e8a2                	sd	s0,80(sp)
    800057a6:	e4a6                	sd	s1,72(sp)
    800057a8:	e0ca                	sd	s2,64(sp)
    800057aa:	fc4e                	sd	s3,56(sp)
    800057ac:	f852                	sd	s4,48(sp)
    800057ae:	f456                	sd	s5,40(sp)
    800057b0:	f05a                	sd	s6,32(sp)
    800057b2:	ec5e                	sd	s7,24(sp)
    800057b4:	e862                	sd	s8,16(sp)
    800057b6:	1080                	addi	s0,sp,96
    800057b8:	89aa                	mv	s3,a0
    800057ba:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800057bc:	00c52b83          	lw	s7,12(a0)
    800057c0:	001b9b9b          	slliw	s7,s7,0x1
    800057c4:	1b82                	slli	s7,s7,0x20
    800057c6:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    800057ca:	0001b517          	auipc	a0,0x1b
    800057ce:	39650513          	addi	a0,a0,918 # 80020b60 <disk+0x128>
    800057d2:	c56fb0ef          	jal	80000c28 <acquire>
  for(int i = 0; i < NUM; i++){
    800057d6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800057d8:	0001ba97          	auipc	s5,0x1b
    800057dc:	260a8a93          	addi	s5,s5,608 # 80020a38 <disk>
  for(int i = 0; i < 3; i++){
    800057e0:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800057e2:	5c7d                	li	s8,-1
    800057e4:	a095                	j	80005848 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    800057e6:	00fa8733          	add	a4,s5,a5
    800057ea:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800057ee:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800057f0:	0207c563          	bltz	a5,8000581a <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    800057f4:	2905                	addiw	s2,s2,1
    800057f6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800057f8:	05490c63          	beq	s2,s4,80005850 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    800057fc:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800057fe:	0001b717          	auipc	a4,0x1b
    80005802:	23a70713          	addi	a4,a4,570 # 80020a38 <disk>
    80005806:	4781                	li	a5,0
    if(disk.free[i]){
    80005808:	01874683          	lbu	a3,24(a4)
    8000580c:	fee9                	bnez	a3,800057e6 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    8000580e:	2785                	addiw	a5,a5,1
    80005810:	0705                	addi	a4,a4,1
    80005812:	fe979be3          	bne	a5,s1,80005808 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005816:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    8000581a:	01205d63          	blez	s2,80005834 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000581e:	fa042503          	lw	a0,-96(s0)
    80005822:	d41ff0ef          	jal	80005562 <free_desc>
      for(int j = 0; j < i; j++)
    80005826:	4785                	li	a5,1
    80005828:	0127d663          	bge	a5,s2,80005834 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000582c:	fa442503          	lw	a0,-92(s0)
    80005830:	d33ff0ef          	jal	80005562 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005834:	0001b597          	auipc	a1,0x1b
    80005838:	32c58593          	addi	a1,a1,812 # 80020b60 <disk+0x128>
    8000583c:	0001b517          	auipc	a0,0x1b
    80005840:	21450513          	addi	a0,a0,532 # 80020a50 <disk+0x18>
    80005844:	ee8fc0ef          	jal	80001f2c <sleep>
  for(int i = 0; i < 3; i++){
    80005848:	fa040613          	addi	a2,s0,-96
    8000584c:	4901                	li	s2,0
    8000584e:	b77d                	j	800057fc <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005850:	fa042503          	lw	a0,-96(s0)
    80005854:	00451693          	slli	a3,a0,0x4

  if(write)
    80005858:	0001b797          	auipc	a5,0x1b
    8000585c:	1e078793          	addi	a5,a5,480 # 80020a38 <disk>
    80005860:	00451713          	slli	a4,a0,0x4
    80005864:	0a070713          	addi	a4,a4,160
    80005868:	973e                	add	a4,a4,a5
    8000586a:	01603633          	snez	a2,s6
    8000586e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005870:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005874:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005878:	6398                	ld	a4,0(a5)
    8000587a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000587c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005880:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005882:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005884:	6390                	ld	a2,0(a5)
    80005886:	00d60833          	add	a6,a2,a3
    8000588a:	4741                	li	a4,16
    8000588c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005890:	4585                	li	a1,1
    80005892:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005896:	fa442703          	lw	a4,-92(s0)
    8000589a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000589e:	0712                	slli	a4,a4,0x4
    800058a0:	963a                	add	a2,a2,a4
    800058a2:	05898813          	addi	a6,s3,88
    800058a6:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800058aa:	0007b883          	ld	a7,0(a5)
    800058ae:	9746                	add	a4,a4,a7
    800058b0:	40000613          	li	a2,1024
    800058b4:	c710                	sw	a2,8(a4)
  if(write)
    800058b6:	001b3613          	seqz	a2,s6
    800058ba:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800058be:	8e4d                	or	a2,a2,a1
    800058c0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800058c4:	fa842603          	lw	a2,-88(s0)
    800058c8:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800058cc:	00451813          	slli	a6,a0,0x4
    800058d0:	02080813          	addi	a6,a6,32
    800058d4:	983e                	add	a6,a6,a5
    800058d6:	577d                	li	a4,-1
    800058d8:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800058dc:	0612                	slli	a2,a2,0x4
    800058de:	98b2                	add	a7,a7,a2
    800058e0:	03068713          	addi	a4,a3,48
    800058e4:	973e                	add	a4,a4,a5
    800058e6:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800058ea:	6398                	ld	a4,0(a5)
    800058ec:	9732                	add	a4,a4,a2
    800058ee:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800058f0:	4689                	li	a3,2
    800058f2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800058f6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800058fa:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    800058fe:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005902:	6794                	ld	a3,8(a5)
    80005904:	0026d703          	lhu	a4,2(a3)
    80005908:	8b1d                	andi	a4,a4,7
    8000590a:	0706                	slli	a4,a4,0x1
    8000590c:	96ba                	add	a3,a3,a4
    8000590e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005912:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005916:	6798                	ld	a4,8(a5)
    80005918:	00275783          	lhu	a5,2(a4)
    8000591c:	2785                	addiw	a5,a5,1
    8000591e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005922:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005926:	100017b7          	lui	a5,0x10001
    8000592a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000592e:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80005932:	0001b917          	auipc	s2,0x1b
    80005936:	22e90913          	addi	s2,s2,558 # 80020b60 <disk+0x128>
  while(b->disk == 1) {
    8000593a:	84ae                	mv	s1,a1
    8000593c:	00b79a63          	bne	a5,a1,80005950 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005940:	85ca                	mv	a1,s2
    80005942:	854e                	mv	a0,s3
    80005944:	de8fc0ef          	jal	80001f2c <sleep>
  while(b->disk == 1) {
    80005948:	0049a783          	lw	a5,4(s3)
    8000594c:	fe978ae3          	beq	a5,s1,80005940 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005950:	fa042903          	lw	s2,-96(s0)
    80005954:	00491713          	slli	a4,s2,0x4
    80005958:	02070713          	addi	a4,a4,32
    8000595c:	0001b797          	auipc	a5,0x1b
    80005960:	0dc78793          	addi	a5,a5,220 # 80020a38 <disk>
    80005964:	97ba                	add	a5,a5,a4
    80005966:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000596a:	0001b997          	auipc	s3,0x1b
    8000596e:	0ce98993          	addi	s3,s3,206 # 80020a38 <disk>
    80005972:	00491713          	slli	a4,s2,0x4
    80005976:	0009b783          	ld	a5,0(s3)
    8000597a:	97ba                	add	a5,a5,a4
    8000597c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005980:	854a                	mv	a0,s2
    80005982:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005986:	bddff0ef          	jal	80005562 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    8000598a:	8885                	andi	s1,s1,1
    8000598c:	f0fd                	bnez	s1,80005972 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000598e:	0001b517          	auipc	a0,0x1b
    80005992:	1d250513          	addi	a0,a0,466 # 80020b60 <disk+0x128>
    80005996:	b26fb0ef          	jal	80000cbc <release>
}
    8000599a:	60e6                	ld	ra,88(sp)
    8000599c:	6446                	ld	s0,80(sp)
    8000599e:	64a6                	ld	s1,72(sp)
    800059a0:	6906                	ld	s2,64(sp)
    800059a2:	79e2                	ld	s3,56(sp)
    800059a4:	7a42                	ld	s4,48(sp)
    800059a6:	7aa2                	ld	s5,40(sp)
    800059a8:	7b02                	ld	s6,32(sp)
    800059aa:	6be2                	ld	s7,24(sp)
    800059ac:	6c42                	ld	s8,16(sp)
    800059ae:	6125                	addi	sp,sp,96
    800059b0:	8082                	ret

00000000800059b2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800059b2:	1101                	addi	sp,sp,-32
    800059b4:	ec06                	sd	ra,24(sp)
    800059b6:	e822                	sd	s0,16(sp)
    800059b8:	e426                	sd	s1,8(sp)
    800059ba:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800059bc:	0001b497          	auipc	s1,0x1b
    800059c0:	07c48493          	addi	s1,s1,124 # 80020a38 <disk>
    800059c4:	0001b517          	auipc	a0,0x1b
    800059c8:	19c50513          	addi	a0,a0,412 # 80020b60 <disk+0x128>
    800059cc:	a5cfb0ef          	jal	80000c28 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800059d0:	100017b7          	lui	a5,0x10001
    800059d4:	53bc                	lw	a5,96(a5)
    800059d6:	8b8d                	andi	a5,a5,3
    800059d8:	10001737          	lui	a4,0x10001
    800059dc:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    800059de:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800059e2:	689c                	ld	a5,16(s1)
    800059e4:	0204d703          	lhu	a4,32(s1)
    800059e8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    800059ec:	04f70863          	beq	a4,a5,80005a3c <virtio_disk_intr+0x8a>
    __sync_synchronize();
    800059f0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800059f4:	6898                	ld	a4,16(s1)
    800059f6:	0204d783          	lhu	a5,32(s1)
    800059fa:	8b9d                	andi	a5,a5,7
    800059fc:	078e                	slli	a5,a5,0x3
    800059fe:	97ba                	add	a5,a5,a4
    80005a00:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005a02:	00479713          	slli	a4,a5,0x4
    80005a06:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005a0a:	9726                	add	a4,a4,s1
    80005a0c:	01074703          	lbu	a4,16(a4)
    80005a10:	e329                	bnez	a4,80005a52 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005a12:	0792                	slli	a5,a5,0x4
    80005a14:	02078793          	addi	a5,a5,32
    80005a18:	97a6                	add	a5,a5,s1
    80005a1a:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005a1c:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005a20:	d58fc0ef          	jal	80001f78 <wakeup>

    disk.used_idx += 1;
    80005a24:	0204d783          	lhu	a5,32(s1)
    80005a28:	2785                	addiw	a5,a5,1
    80005a2a:	17c2                	slli	a5,a5,0x30
    80005a2c:	93c1                	srli	a5,a5,0x30
    80005a2e:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005a32:	6898                	ld	a4,16(s1)
    80005a34:	00275703          	lhu	a4,2(a4)
    80005a38:	faf71ce3          	bne	a4,a5,800059f0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005a3c:	0001b517          	auipc	a0,0x1b
    80005a40:	12450513          	addi	a0,a0,292 # 80020b60 <disk+0x128>
    80005a44:	a78fb0ef          	jal	80000cbc <release>
}
    80005a48:	60e2                	ld	ra,24(sp)
    80005a4a:	6442                	ld	s0,16(sp)
    80005a4c:	64a2                	ld	s1,8(sp)
    80005a4e:	6105                	addi	sp,sp,32
    80005a50:	8082                	ret
      panic("virtio_disk_intr status");
    80005a52:	00002517          	auipc	a0,0x2
    80005a56:	ca650513          	addi	a0,a0,-858 # 800076f8 <etext+0x6f8>
    80005a5a:	dcbfa0ef          	jal	80000824 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
